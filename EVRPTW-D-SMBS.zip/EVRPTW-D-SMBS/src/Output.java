import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class Output {

    public static void outputSolution(Solution solution) {
        // 打印解决方案
        // 打印EV的路径  solution.evPaths[]
        int evindex = 0;
        for (EV_Route evRoute : solution.evPaths) {   // evRoute 包括ev的路径信息和其支持的UAV的行程信息
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                evindex++;
                continue;
            }

            // 打印EV的路径
            System.out.println("EV Route- " + evindex++);

            for(int i = 0 ; i < evRoute.route.size(); i++){
                Node node = evRoute.route.get(i);
                System.out.print(node.NodeID + " -> ");
            }
            System.out.println();

            // 打印EV所属的UAV的路径
//            System.out.println("UAV Trip: ");
            int i = 1;  // 计数器
            for (List<Node> uavTrip : evRoute.uavTrips) {
                System.out.print("UAV Trip " + i++ + ": ");
                for (Node node : uavTrip) {
                    System.out.print(node.NodeID + " -> ");
                }
                System.out.println();
            }
            System.out.println();
            evindex++;
        }
        // 打印BSV的路径  solution.bsvPaths[]
        int bsvindex = 0;
        for (BSV_Route bsvRoute : solution.bsvPaths) {   // bsvRoute 包括bsv的路径信息
            if (bsvRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                bsvindex++;
                continue;
            }
            // 打印BSV的路径
            System.out.println("BSV Route- " + bsvindex++);
            for(int i = 0 ; i < bsvRoute.route.size(); i++){
                Node node = bsvRoute.route.get(i);
                System.out.print(node.NodeID + " -> ");
            }
            System.out.println();
            bsvindex++;
        }
    }
    public static void printSolution(Solution solution) {

        for (EV_Route evRoute : solution.evPaths) {   // evRoute 包括ev的路径信息和其支持的UAV的行程信息
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }

            System.out.println("EV总能耗"+ evRoute.energyConsumption);
            System.out.println("能量是否违反"+ evRoute.energy_violated);
            System.out.println("总违反时间窗"+ evRoute.violationTime);
            System.out.println("总载重量"+ evRoute.total_load);
            // 打印EV的路径
            System.out.println("EV Route: ");
            for(int i = 0 ; i < evRoute.route.size(); i++){
                Node node = evRoute.route.get(i);
                System.out.println(node.NodeID + " -> ");
                if(i != 0){
                    System.out.println("到达该节点耗能" + evRoute.energy_consum_travel.get(i-1)) ;
                }
                System.out.print("到达该节点的时间" + node.evArrivalTime );
                System.out.print("服务该节点的时间" + node.evServiceTime );
                System.out.print("离开该节点的时间" + node.evDepartureTime );

                System.out.println();
            }

            // 打印EV所属的UAV的路径
            System.out.println("UAV Trip: ");
            System.out.println("UAV总能耗"+ evRoute.energyConsumption_uav);
            int i = 1;  // 计数器
            for (List<Node> uavTrip : evRoute.uavTrips) {
                System.out.print("UAV Trip " + i++ + ": ");
                for (Node node : uavTrip) {
                    System.out.print(node.NodeID + " -> ");
                    System.out.print("到达该节点的时间" + node.uavArrivalTime );
                    System.out.print("服务该节点的时间" + node.uavServiceTime );
                    System.out.print("离开该节点的时间" + node.uavDepartureTime );
                    System.out.println();
                }
                System.out.println();
            }

        }

    }
}
