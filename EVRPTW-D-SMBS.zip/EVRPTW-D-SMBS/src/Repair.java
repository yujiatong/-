import java.util.*;

public class Repair {
    // 1、First random insertion and then UAV trip repair
    public static void Random_Repair(Solution solution) {
        ArrayList<Node> delete_NodeList = new ArrayList<>();   // 用于存放插入失败的节点
        ArrayList<Node> insert_NodeList = new ArrayList<>();   // 用于存放待插入的节点
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            insert_NodeList.add(Parameter.Remove_NodeList.get(i));
        }
        // 将移除节点列表随机排序
        Collections.shuffle(Parameter.Remove_NodeList);

        // 强制规定使用的EV车辆的数量，由此确定EV-UAV路径的数量，如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
        if (Parameter.suggest_use_evnum_flag) {
            force_EVnum_used(solution);
        }

        // 将移除列表中的节点重新插入到线路中
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            // 获取待插入的节点
            Node insertNode = Parameter.Remove_NodeList.get(i);
            // 计算候选插入点的位置列表,根据插入距离从小到大排序
            List<List<Double>> insert_position = Repair.calculateCandidatePositions(solution.evPaths, Parameter.Remove_NodeList.get(i));
            // 将insert_position 随机排序
            Collections.shuffle(insert_position);

            boolean inserted = false;  // 标记是否成功插入
            // 遍历候选插入点的位置列表，尝试插入
            for (int j = 0; j < insert_position.size(); j++) {
                List<Double> value = insert_position.get(j);
                // 执行插入操作，将节点插入到当前解中，调用insertNodeIntoSolution函数，传入参数为：插入节点、插入位置、当前解，返回值为插入是否成功，成功返回true，否则返回false
                inserted = insertNodeIntoSolution(insertNode, value, solution);
                if (inserted) {
                    break;
                }
            }
            // 如果插入失败，将节点添加到删除节点列表中
            if (!inserted) {
                delete_NodeList.add(insertNode);
            }
        }

        // 如果删除列表中存在客户，则将为删除列表中的这些客户建立新的EV-UAV-BSV路线
        if (delete_NodeList.size() > 0) {
            double nodenum = Repair.Generate_routes(solution, delete_NodeList);
            if (nodenum > 0) {
                System.out.println("插入失败的节点数：" + nodenum);
            }
        }

        // 判断解的结构是否合法
        if (!judge_solution_isfeasible(solution)) {
            System.out.println("解的结构不合法！");
        }
        // 清空移除节点列表
        Parameter.Remove_NodeList.clear();

        // 更新解的信息
        Calculate_Tool.updateSolutionMetrics(solution);

    }

    // 2、First greedy insertion and then UAV trip repair
    public static void Greedy_Repair(Solution solution) {

        ArrayList<Node> delete_NodeList = new ArrayList<>();   // 用于存放插入失败的节点

        // 将移除节点列表随机排序
        Collections.shuffle(Parameter.Remove_NodeList);

        // 强制规定使用的EV车辆的数量，由此确定EV-UAV路径的数量，如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
        if (Parameter.suggest_use_evnum_flag) {
            force_EVnum_used(solution);
        }

        // 将移除节点列表按照客户的时间窗口紧迫度进行升序排序  紧迫度= e_i + (e_i - l_i)/2 ，其中e_i为节点i的时间窗的开始时间，l_i为节点i的时间窗的结束时间，值越小，时间窗越紧迫
        Collections.sort(Parameter.Remove_NodeList, new Comparator<Node>() {
            @Override
            public int compare(Node o1, Node o2) {
                double urgency1 = o1.ReadyTime + (o1.DueTime - o1.ReadyTime) / 2;
                double urgency2 = o2.ReadyTime + (o2.DueTime - o2.ReadyTime) / 2;
                if (urgency1 < urgency2) {
                    return -1;
                } else if (urgency1 > urgency2) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        // 将移除列表中的节点重新插入到线路中
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            // 获取待插入的节点
            Node insertNode = Parameter.Remove_NodeList.get(i);
            // 计算候选插入点的位置列表,根据插入距离从小到大排序
            List<List<Double>> insert_position = Repair.calculateCandidatePositions(solution.evPaths, Parameter.Remove_NodeList.get(i));
            boolean inserted = false;  // 标记是否成功插入
            // 遍历候选插入点的位置列表，尝试插入
            for (int j = 0; j < insert_position.size(); j++) {
                List<Double> value = insert_position.get(j);
                // 执行插入操作，将节点插入到当前解中，调用insertNodeIntoSolution函数，传入参数为：插入节点、插入位置、当前解，返回值为插入是否成功，成功返回true，否则返回false
                inserted = insertNodeIntoSolution(insertNode, value, solution);
                if (inserted) {
                    break;
                }
            }
            // 如果插入失败，将节点添加到删除节点列表中
            if (!inserted) {
                delete_NodeList.add(insertNode);
            }
        }
        // 如果删除列表中存在客户，则将为删除列表中的这些客户建立新的EV-UAV-BSV路线
        if (delete_NodeList.size() > 0) {
            double nodenum = Repair.Generate_routes(solution, delete_NodeList);
            if (nodenum > 0) {
                System.out.println("插入失败的节点数：" + nodenum);
            }
        }
        // 判断解的结构是否合法
        if (!judge_solution_isfeasible(solution)) {
            System.out.println("解的结构不合法！");
        }

        // 清空移除节点列表
        Parameter.Remove_NodeList.clear();

        // 更新解的信息
        Calculate_Tool.updateSolutionMetrics(solution);
    }

    // 3、 EV greedy insertion and then UAV trip repair
    //第一阶段中，每次随机选择一个移除列表中的客户，将它以卡车服务的形式“贪婪”的插入到当前解中，即插入位置为使当前解的目标函数值增加最小的位置；若无法插入，则为该客户开辟一条新路线.重复以上步骤直至移除列表中的客户全部被插入当前解中。
    //第二阶段中，借助 Find-sortie 算法，逐步在当前解中构建无人机飞行单元，每次被选择的飞行单元都是使当前解的目标函数值降低最多的飞行单元
    public static void EVGreedy_Repair(Solution solution) {
        ArrayList<Node> delete_NodeList = new ArrayList<>();   // 用于存放插入失败的节点
        // 将移除节点列表随机排序
        Collections.shuffle(Parameter.Remove_NodeList);

        // 强制规定使用的EV车辆的数量，由此确定EV-UAV路径的数量，如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
        if (Parameter.suggest_use_evnum_flag) {
            force_EVnum_used(solution);
        }
        // 将移除列表中的节点重新插入到线路中
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            // 获取待插入的节点
            Node insertNode = Parameter.Remove_NodeList.get(i);
            // 计算卡车路径中的候选插入点的位置列表,并根据插入成本从小到大排序
            List<List<Double>> insert_position = Repair.calculateEVCandidatePositions_Cost(solution.evPaths, Parameter.Remove_NodeList.get(i));
            boolean inserted = false;  // 标记是否成功插入
            // 贪婪插入，选择使目标函数值增加最小的插入点，insert_position的第一个元素，即插入成本最小的插入点，尝试插入
            if (insert_position.size() > 0) {
                // 遍历候选插入点的位置列表，尝试插入
                for (int j = 0; j < insert_position.size(); j++) {
//                inserted = false; // 标记是否成功插入
                    List<Double> value = insert_position.get(j);
                    // 执行插入操作，将节点插入到当前解中，调用insertNodeIntoSolution函数，传入参数为：插入节点、插入位置、当前解，返回值为插入是否成功，成功返回true，否则返回false
                    inserted = insertNodeIntoSolution(insertNode, value, solution);
                    if (inserted) {
                        break;
                    }
                }
            }
            // 如果插入失败，将节点添加到删除节点列表中
            if (!inserted) {
                delete_NodeList.add(insertNode);
            }
        }
        // 如果删除列表中存在客户，则将为删除列表中的这些客户建立新的EV-UAV-BSV路线
        if (delete_NodeList.size() > 0) {
            double nodenum = Repair.Generate_routes(solution, delete_NodeList);
            if (nodenum > 0) {
                System.out.println("插入失败的节点数：" + nodenum);
            }
        }
        // 判断解的结构是否合法
        if (!judge_solution_isfeasible(solution)) {
            System.out.println("解的结构不合法！");
        }

        // 清空移除节点列表
        Parameter.Remove_NodeList.clear();
        // 更新解的信息
        Calculate_Tool.updateSolutionMetrics(solution);

    }

    // 4、后悔修复算子
    //计算移除列表中所有客户的“后悔”值，最后选择“后悔”值最小的客户插入到当前解中最优的位置
    //对于每个待插入的客户，“后悔”值为将该客户分别插入到当前解中最优位置与次优位置时，分别导致目标函数增加值的差值
    public static void Regret_Repair(Solution solution) {
        ArrayList<Node> delete_NodeList = new ArrayList<>();   // 用于存放插入失败的节点

        // 将移除节点列表随机排序
        Collections.shuffle(Parameter.Remove_NodeList);

        // 强制规定使用的EV车辆的数量，由此确定EV-UAV路径的数量，如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
        if (Parameter.suggest_use_evnum_flag) {
            force_EVnum_used(solution);
        }

        // 用于存放待插入的节点以及其后悔值，使用字典存储，key为节点，value为后悔值，后悔值的初始化为-1，key一开始为移除列表中的节点
        HashMap<Node, Double> insert_NodeListmap_regretValue = new HashMap<>();
        HashMap<Node, List<List<Double>>> insert_NodeListmap_CandidatePositions = new HashMap<>();
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            insert_NodeListmap_regretValue.put(Parameter.Remove_NodeList.get(i), -1.0);
        }
        // 对待插入节点按照”后悔“插入原则进行插入操作，直到insert_NodeListmap_regretValue为空
        while (insert_NodeListmap_regretValue.size() > 0) {
            // 遍历待插入的节点
            for (Node insertNode : insert_NodeListmap_regretValue.keySet()) {
                // 计算卡车路径和无人机航程中的候选插入点的位置列表,并根据插入成本从小到大排序
                List<List<Double>> insert_position = Repair.calculateCandidatePositions_Cost(solution.evPaths, insertNode);
                // 将insert_position存储到insert_NodeListmap_CandidatePositions中
                insert_NodeListmap_CandidatePositions.put(insertNode, insert_position);
                if (insert_position.size() >= 2) {   // 如果候选插入点的位置列表的长度小于2，说明无法计算后悔值，直接跳过
                    // 计算插入点的后悔值，即将该客户分别插入到当前解中最优位置与次优位置时，分别导致目标函数增加值的差值
                    double regret = insert_position.get(1).get(0) - insert_position.get(0).get(0);
                    // 更新插入节点的后悔值
                    insert_NodeListmap_regretValue.put(insertNode, regret);
                } else {
                    // 如果候选插入点的位置列表的长度小于2，说明无法计算后悔值，将后悔值初始化为-1
                    insert_NodeListmap_regretValue.put(insertNode, -1.0);
                }
            }
            // 将insert_NodeListmap_regretValue按照后悔值从大到小排序
            List<Map.Entry<Node, Double>> list = new ArrayList<>(insert_NodeListmap_regretValue.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<Node, Double>>() {
                @Override
                public int compare(Map.Entry<Node, Double> o1, Map.Entry<Node, Double> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });
            // 将排序后的节点插入到当前解中
            boolean inserted_this_round = false;  // 标记本轮是否有节点插入(或加入到删除列表中)，如果有，则完成一轮插入操作，否则结束，保证每一轮有且仅有一个节点插入，因为在计算插入位置时，都是基于当前的解计算的，在插入一个节点后，解会发生变化，所以每一轮只能插入一个节点
            // 首先，如果存在后悔值为-1的节点，说明无法计算后悔值，存在两种情况：1.无法插入到当前解中；2.只有一种插入位置，无法计算后悔值，对此类节点，优先进行插入操作，按照插入成本最小的位置插入
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getValue() == -1) {
                    Node insertNode = list.get(i).getKey();
                    List<List<Double>> insert_position = insert_NodeListmap_CandidatePositions.get(insertNode);
                    if (insert_position.size() > 0) {  // 如果候选插入点的位置列表的长度大于0，说明可以插入到当前解中
                        // 执行插入操作,将节点插入到当前解中，调用insertNodeIntoSolution函数，传入参数为：插入节点、插入位置、当前解，返回值为插入是否成功，成功返回true，否则返回false
                        boolean insertFlag = insertNodeIntoSolution(insertNode, insert_position.get(0), solution);
                        // 如果插入失败，将节点添加到删除节点列表中
                        if (!insertFlag) {
                            delete_NodeList.add(insertNode);
                        } else {  // 如果插入成功，标记本轮有节点插入
                            inserted_this_round = true;
                        }
                    } else {
                        // 如果候选插入点为空或不存在，直接跳过，将节点添加到删除节点列表中
                        delete_NodeList.add(insertNode);
                    }
//                    // 判断解的结构是否合法
//                    if (!judge_solution_isfeasible(solution)) {
//                        System.out.println("解的结构不合法！");
//                    }
                    // 删除插入节点的后悔值以及候选插入点
                    insert_NodeListmap_regretValue.remove(insertNode);
                    insert_NodeListmap_CandidatePositions.remove(insertNode);
                    if (inserted_this_round) {
                        break;
                    }
                }
            }
            // 如果本轮已有节点插入，则继续下一轮插入操作
            if (inserted_this_round) {
                continue;
            }
            // 然后，选取后悔值最大的节点插入到当前解的最优位置
            if (list.size() == 0) {  // 如果后悔值列表为空，说明所有节点都已插入到当前解中，结束插入操作
                continue;
            }
            Double regret_now = list.get(0).getValue();  // 获取后悔值最大的节点
            if (regret_now >= 0) {  // 如果最大的后悔值大于0，说明有节点可以按照”后悔“插入原则插入到当前解中
                Node insertNode_now = list.get(0).getKey();  // 获取后悔值最大的节点
                List<Double> insert_position_now = insert_NodeListmap_CandidatePositions.get(insertNode_now).get(0);  // 获取插入位置,即插入成本最小的位置
                // 执行插入操作，将节点插入到当前解中，调用insertNodeIntoSolution函数，传入参数为：插入节点、插入位置、当前解，返回值为插入是否成功，成功返回true，否则返回false
                boolean insert_flag = insertNodeIntoSolution(insertNode_now, insert_position_now, solution);
                // 如果插入失败，将节点添加到删除节点列表中
                if (!insert_flag) {
                    delete_NodeList.add(insertNode_now);
                } else {
                    inserted_this_round = true;
                }
                // 判断解的结构是否合法
//                if (!judge_solution_isfeasible(solution)) {
//                    System.out.println("解的结构不合法！");
//                }
                // 删除插入节点的后悔值以及候选插入点
                insert_NodeListmap_regretValue.remove(insertNode_now);
                insert_NodeListmap_CandidatePositions.remove(insertNode_now);
            }
        }
        // 如果删除列表中存在客户，则将为删除列表中的这些客户建立新的EV-UAV-BSV路线
        if (delete_NodeList.size() > 0) {
            double nodenum = Repair.Generate_routes(solution, delete_NodeList);
            if (nodenum > 0) {
                System.out.println("插入失败的节点数：" + nodenum);
            }
        }
        // 判断解的结构是否合法
        if (!judge_solution_isfeasible(solution)) {
            System.out.println("解的结构不合法！");
        }

        // 清空移除节点列表
        Parameter.Remove_NodeList.clear();
        // 更新解的信息
        Calculate_Tool.updateSolutionMetrics(solution);

    }

    // 执行插入操作，将节点插入到当前解中，输入参数为插入节点、插入位置、当前解
    public static boolean insertNodeIntoSolution(Node insertNode, List<Double> insert_position, Solution solution) {
        boolean inserted = false;  // 标记是否成功插入
        // 插入点属于EV路径还是UAV行程 1:EV路径  2:UAV行程 3:新建UAV行程
        int type = insert_position.get(1).intValue();
        // 插入点的候选位置
        if (type == 1) {  // 插入点属于EV路径
            // 插入点所在的EV路径的索引
            int ev_route_index = insert_position.get(2).intValue();
            // 插入点在EV路径中的位置
            int position_index = insert_position.get(3).intValue();
            // 尝试将插入点插入到EV路径中
            if (Repair.can_insertIntoEVRoute(solution, ev_route_index, position_index, insertNode)) {
                //在指定位置插入节点
                solution.evPaths[ev_route_index].route.add(position_index, insertNode);
                // 如果节点成功插入EV路径，尝试更新UAV航程
                Repair.updateUAVTrip(solution, ev_route_index);
                // 更新该EV路径的载重量、能耗、违反时间窗等信息
                EV_Route evRoute = solution.evPaths[ev_route_index];
                Calculate_Tool.updateEVRoutesMetrics(evRoute);
                if (evRoute.total_load > Parameter.EVCapacity) {
                    solution.solution_overcapicity_all += evRoute.total_load - Parameter.EVCapacity;
                }
                if (evRoute.energy_violated) {
                    solution.solution_energy_violated = true;
                }
                solution.solution_overtime_all += evRoute.violationTime;

                inserted = true; // 标记插入成功
            }

        } else if (type == 2) {   // 插入点属于UAV行程
            // 插入点所在的EV路径的索引
            int ev_route_index = insert_position.get(2).intValue();
            // 插入点在EV路线的UAV行程的索引
            int uav_trip_index = insert_position.get(3).intValue();
            // 插入点所在的UAV行程
            int uav_position_index = insert_position.get(4).intValue();
            if (Repair.can_insertIntoUAVtrip(solution, ev_route_index, uav_trip_index, uav_position_index, insertNode)) {
                // 在指定位置插入节点
                solution.evPaths[ev_route_index].uavTrips.get(uav_trip_index).add(uav_position_index, insertNode);
                inserted = true; // 标记插入成功
                // 更新该EV路径的载重量、能耗、违反时间窗等信息
                EV_Route evRoute = solution.evPaths[ev_route_index];
                Calculate_Tool.updateEVRoutesMetrics(evRoute);
                if (evRoute.total_load > Parameter.EVCapacity) {
                    solution.solution_overcapicity_all += evRoute.total_load - Parameter.EVCapacity;
                }
                if (evRoute.energy_violated) {
                    solution.solution_energy_violated = true;
                }
                solution.solution_overtime_all += evRoute.violationTime;
            }
        } else if (type == 3) {   // 插入点新建UAV行程
            // 插入点所在的EV路径的索引
            int ev_route_index = insert_position.get(2).intValue();
            // 新建的UAV行程
            List<Node> uav_trip = new ArrayList<>();
            uav_trip.add(solution.evPaths[ev_route_index].route.get(insert_position.get(3).intValue()));  // 添加起点
            uav_trip.add(insertNode);  // 添加插入点
            uav_trip.add(solution.evPaths[ev_route_index].route.get(insert_position.get(4).intValue()));  // 添加终点
            // 插入新建的UAV行程在EV路径的UAV行程列表中UAV行程的索引
            int uav_trip_index = insert_position.get(5).intValue();
            // 将新建的UAV行程插入到EV路径的UAV行程列表中
            solution.evPaths[ev_route_index].uavTrips.add(uav_trip_index, uav_trip);
            inserted = true; // 标记插入成功
            // 更新该EV路径的载重量、能耗、违反时间窗等信息
            EV_Route evRoute = solution.evPaths[ev_route_index];
            Calculate_Tool.updateEVRoutesMetrics(evRoute);
            if (evRoute.total_load > Parameter.EVCapacity) {
                solution.solution_overcapicity_all += evRoute.total_load - Parameter.EVCapacity;
            }
            if (evRoute.energy_violated) {
                solution.solution_energy_violated = true;
            }
            solution.solution_overtime_all += evRoute.violationTime;
        }
        return inserted;
    }

    // // 强制规定使用的EV车辆的数量，由此确定EV-UAV路径的数量，如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
    public static void force_EVnum_used(Solution solution) {
        int current_EVnum_used = 0;   // 计算当前解中使用的EV车辆数量
        for (EV_Route evRoute : solution.evPaths) {
            if (evRoute.route.size() > 2) {  // 如果EV路径不为空，则使用了该EV车辆
                current_EVnum_used++;
            }
        }
        // 如果当前解中的EV车辆数量小于规定的数量，则添加新的EV车辆（路径）
        if (current_EVnum_used < Parameter.suggest_use_evnum) {
            // 新建EV-UAV路径的方式是：从移除列表中随机选择一部分节点，然后按照贪婪插入原则构建新的EV-UAV路径
            // 从移除列表中随机选择一部分节点(1/3,向上取整)
            ArrayList<Node> random_select_partNodeList = new ArrayList<>();
            int select_num = (int) Math.ceil(Parameter.Remove_NodeList.size() / 3.0);
            for (int i = 0; i < select_num; i++) {
                random_select_partNodeList.add(Parameter.Remove_NodeList.get(i));
            }
            // 将选择的节点从移除列表中删除
            for (Node node : random_select_partNodeList) {
                Parameter.Remove_NodeList.remove(node);
            }
            // 按照贪婪插入原则构建新的EV-UAV路径
            int num_return = Generate_routes(solution, random_select_partNodeList);
            if (num_return > 0) {
                System.out.println("插入失败的节点数：" + num_return);
            }
        }
    }

    // 计算插入点的候选位置，放宽约束条件，尝试更多的插入位置
    public static List<List<Double>> calculateCandidatePositions(EV_Route[] evPaths, Node insertNode) {
        ArrayList<List<Double>> candidatePositions = new ArrayList<>();
        // 遍历所有EV路径(包括其所属的UAV行程)
        for (int i = 0; i < evPaths.length; i++) {
            ArrayList<Node> ev_route = evPaths[i].route;
            // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
            if (ev_route.size() <= 2) {
                continue;
            }
            // 如果插入该节点后，EV路径的载重量超过了限制，则跳过该EV路径  evPaths[i].total_load 为EV路径的总载重量
//            if (evPaths[i].total_load + insertNode.Demand > Parameter.EVCapacity) {
//                continue;
//            }
            // 1、遍历EV路径中的节点，计算插入距离，l(j) = lij + ljl − lil，其中i和 l分别是j之前和j之后的两个节点
            for (int j = 1; j < ev_route.size(); j++) {
                // 如果插入点的 “时间” [明显]不符合时间窗约束，则不插入
                // 计算插入点的前一个节点到插入点的时间, 应该小于插入点的DueTime才合理
                double pre_time = ev_route.get(j - 1).evDepartureTime + Parameter.DisMatrix[ev_route.get(j - 1).NodeID][insertNode.NodeID] / Parameter.EVSpeed;
                // 计算如果插入后，插入点到后一个节点的时间，应该小于后一个节点的DueTime才合理
                double later_time = Math.max(pre_time, insertNode.ReadyTime) + insertNode.ServiceTime + Parameter.DisMatrix[insertNode.NodeID][ev_route.get(j).NodeID] / Parameter.EVSpeed;
                if (pre_time > insertNode.DueTime || later_time > ev_route.get(j).DueTime) {
                    continue;
                }

                double distance = Parameter.DisMatrix[ev_route.get(j - 1).NodeID][insertNode.NodeID] + Parameter.DisMatrix[insertNode.NodeID][ev_route.get(j).NodeID] - Parameter.DisMatrix[ev_route.get(j - 1).NodeID][ev_route.get(j).NodeID];
                distance = distance / Parameter.EVSpeed; // 距离 / 速度
                ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,
                // 添加Double对象到列表中
                value.add(distance); // 在该点的插入距离
                value.add(1.0); // 插入点属于EV路径
                value.add((double) i); // 插入点所在的EV路径的索引
                value.add((double) j); // 插入点在EV路径中的位置


                candidatePositions.add(value);  // 添加到列表中
            }

            // 2、遍历EV路径所属的UAV行程中的节点，计算插入距离
            for (int m = 0; m < evPaths[i].uavTrips.size(); m++) {
                List<Node> uav_trip = evPaths[i].uavTrips.get(m);
                // 如果插入该节点后，UAV航程的载重量超过了限制，则跳过该UAV航程
                double uav_load = 0;
                for (int j = 1; j < uav_trip.size() - 1; j++) {
                    uav_load += uav_trip.get(j).Demand;
                }
                if (uav_load + insertNode.Demand > Parameter.UAVCapacity) {
                    continue;
                }

                for (int n = 1; n < uav_trip.size(); n++) {
                    // 如果插入点的 “时间” 明显不符合时间窗约束，则不插入
                    // 计算插入点的前一个节点到插入点的时间, 应该小于插入点的DueTime才合理
                    double pre_time = uav_trip.get(n - 1).uavDepartureTime + Parameter.DisMatrix[uav_trip.get(n - 1).NodeID][insertNode.NodeID] / Parameter.UAVSpeed;
                    if (pre_time > insertNode.DueTime) {
                        continue;
                    }
                    // 如果插入后，能量消耗超过限制，则不插入
                    List<Node> uav_trip_new = new ArrayList<>();
                    for (Node node : uav_trip) {
                        uav_trip_new.add(node);
                    }
                    uav_trip_new.add(n, insertNode);
                    double energy_consumption = Calculate_Tool.calculate_uavtrip_energy(uav_trip_new);
                    if (energy_consumption > Parameter.UAVEnergy) {
                        continue;
                    }
                    // 计算插入距离，l(j) = lij + ljl − lil，其中i和 l分别是j之前和j之后的两个节点
                    double distance = Parameter.DisMatrix[uav_trip.get(n - 1).NodeID][insertNode.NodeID] + Parameter.DisMatrix[insertNode.NodeID][uav_trip.get(n).NodeID] - Parameter.DisMatrix[uav_trip.get(n - 1).NodeID][uav_trip.get(n).NodeID];
                    distance = distance / Parameter.UAVSpeed;
                    ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,
                    // 添加Double对象到列表中
                    value.add(distance); // 在该点的插入距离
                    value.add(2.0); // 插入点属于UAV行程
                    value.add((double) i); // 插入点所在的EV路径的索引
                    value.add((double) m); // 插入点在EV路线的UAV行程的索引
                    value.add((double) n); // 插入点所在的UAV行程的位置

                    candidatePositions.add(value);  // 添加到列表中
                }
            }
            // 上面两种寻找插入点的方法，都是在当前的路径中寻找插入点（EV路径和UAV行程），下面的方法是在当前的路径中为insertnode尝试构建新的UAV行程
            // 3、为insertnode尝试构建新的UAV行程，如果该节点的需求量超过了UAV的载重量，则无法构建新的UAV行程
            if (insertNode.Demand > Parameter.UAVCapacity) {
                continue;
            }
            // 3.1 先更新路径中的节点信息
            // 遍历EV路径中的每个节点,除去起点和终点
            for (int k = 1; k < ev_route.size() - 1; k++) {
                ev_route.get(k).EV_service = true;  // EV服务该节点
                ev_route.get(k).UAV_service = false;  // UAV不服务该节点
                ev_route.get(k).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
                ev_route.get(k).UAV_landing_to_here = false;  // 重置UAV降落标志
                ev_route.get(k).Position = k; // 客户节点在ev路径中的位置索引
            }
            ev_route.get(0).Position = 0; // 起点在ev路径中的位置索引
            ev_route.get(0).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.get(0).UAV_landing_to_here = false;  // 重置UAV降落标志
            ev_route.get(ev_route.size() - 1).Position = ev_route.size() - 1; // 终点在ev路径中的位置索引
            ev_route.get(ev_route.size() - 1).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.get(ev_route.size() - 1).UAV_landing_to_here = false;  // 重置UAV降落标志

            ArrayList<Integer> takeoff_index = new ArrayList<>();  // 记录UAV起飞点的索引
            ArrayList<Integer> landing_index = new ArrayList<>();  // 记录UAV降落点的索引
            // 遍历EV的UAV航线中的每个节点
            for (List<Node> uavTrip : evPaths[i].uavTrips) {
                for (int t = 0; t < uavTrip.size(); t++) {
                    if (t == 0) {  // 对于起始节点（即起飞节点）
                        uavTrip.get(t).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                        takeoff_index.add(uavTrip.get(t).Position);  // 记录UAV起飞点的索引
                    } else if (t == uavTrip.size() - 1) {  // 对于终点（即降落节点）
                        uavTrip.get(t).UAV_landing_to_here = true;  // UAV降落到该节点
                        landing_index.add(uavTrip.get(t).Position);  // 记录UAV降落点的索引
                    } else {  // 对于中间节点
                        uavTrip.get(t).UAV_service = true;  // UAV服务该节点
                        uavTrip.get(t).EV_service = false;  // EV不服务该节点
                    }
                }
            }
            // 3.2 尝试所有的可能的起飞点和降落点组合，构建新的UAV行程
            ArrayList<List<Node>> uavTrips_all = new ArrayList<>();   // 用于存放所有的UAV行程
            ArrayList<Integer> uavTrips_all_position = new ArrayList<>();  // 用于存放所有的UAV行程的位置
            // 3.2.1 当前路径中不存在UAV行程
            if (evPaths[i].uavTrips.size() == 0) {
                //尝试所有的可能的起飞点和降落点组合，构建新的UAV行程（后续统一进行简单的根据约束判断新的UAV行程是否可行）
                for (int i1 = 0; i1 < ev_route.size() - 1; i1++) {
                    for (int j1 = i1 + 1; j1 < ev_route.size(); j1++) {
                        List<Node> uavTrip = new ArrayList<>();
                        uavTrip.add(ev_route.get(i1));  // 起飞节点
                        uavTrip.add(insertNode);  // 插入节点
                        uavTrip.add(ev_route.get(j1));  // 降落节点
                        uavTrips_all.add(uavTrip);
                        uavTrips_all_position.add(0);  // 记录UAV行程的位置,由于当前路径中不存在UAV行程，所以新构建的UAV行程的位置为0
                    }
                }
            } else {
                // 3.2.2 在已有UAV行程的第一个起飞节点的 前面 尝试插入新的UAV行程
                if (takeoff_index.get(0) > 0) {  // 如果第一个UAV行程的起飞点不是起点
                    for (int i1 = 0; i1 < takeoff_index.get(0); i1++) {
                        for (int j1 = i1 + 1; j1 < takeoff_index.get(0); j1++) {
                            List<Node> uavTrip = new ArrayList<>();
                            uavTrip.add(ev_route.get(i1));  // 起飞节点
                            uavTrip.add(insertNode);  // 插入节点
                            uavTrip.add(ev_route.get(j1));  // 降落节点
                            uavTrips_all.add(uavTrip);
                            uavTrips_all_position.add(0);  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的前面，所以位置为0
                        }
                    }
                }
                // 3.2.3 在已有UAV行程的最后一个降落节点的 后面 尝试插入新的UAV行程
                if (landing_index.get(landing_index.size() - 1) < ev_route.size() - 1) {  // 如果最后一个UAV行程的降落点不是终点
                    for (int i1 = landing_index.get(landing_index.size() - 1); i1 < ev_route.size() - 1; i1++) {
                        for (int j1 = i1 + 1; j1 < ev_route.size(); j1++) {
                            List<Node> uavTrip = new ArrayList<>();
                            uavTrip.add(ev_route.get(i1));  // 起飞节点
                            uavTrip.add(insertNode);  // 插入节点
                            uavTrip.add(ev_route.get(j1));  // 降落节点
                            uavTrips_all.add(uavTrip);
                            uavTrips_all_position.add(evPaths[i].uavTrips.size());  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的后面，所以位置为已有UAV行程的数量
                        }
                    }
                }
                // 3.2.4 在已有UAV行程的中间节点之间 尝试插入新的UAV行程，值得注意的是，需要保证新的UAV行程的起飞点和降落点不在已有UAV行程的起飞点和降落点之间，即新的UAV行程不与已有UAV行程重叠
                if (evPaths[i].uavTrips.size() >= 2) {  // 已有UAV行程大于2
                    for (int uavtrip_index = 0; uavtrip_index < evPaths[i].uavTrips.size() - 1; uavtrip_index++) {   // 遍历已有UAV行程（除去最后一个UAV行程）
                        for (int i1 = landing_index.get(uavtrip_index); i1 < takeoff_index.get(uavtrip_index + 1); i1++) {   // 新UAV行程的起飞点在已有UAV行程的上一个降落点和下一个起飞点之间，包括降落点，但不包括起飞点
                            for (int j1 = i1 + 1; j1 <= takeoff_index.get(uavtrip_index + 1); j1++) {  // 新UAV行程的降落点在已有UAV行程的下一个起飞点和降落点之间，包括起飞点，但不包括降落点
                                List<Node> uavTrip = new ArrayList<>();
                                uavTrip.add(ev_route.get(i1));  // 起飞节点
                                uavTrip.add(insertNode);  // 插入节点
                                uavTrip.add(ev_route.get(j1));  // 降落节点
                                uavTrips_all.add(uavTrip);
                                uavTrips_all_position.add(uavtrip_index + 1);  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的中间，所以位置为已有UAV行程的索引+1
                            }
                        }
                    }
                }
            }
            // 3.3 剔除不符合约束条件的UAV行程(放宽约束条件，只简单判断插入点的时间窗是否满足，而没有考虑新建UAV行程后对整条路径的影响)
            for (int index = 0; index < uavTrips_all.size(); index++) {
                List<Node> uavTrip = uavTrips_all.get(index);
                boolean flag = judgeUAVtrip(evPaths[i], uavTrip);
                if (flag) {  // 如果UAV行程符合约束条件
                    ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,并将uavTrip的信息存放到列表中（即起飞点、插入点、降落点）
                    // 添加Double对象到列表中
                    value.add(Parameter.BigValue); // 在该点的插入距离(由于是新建的UAV行程，所以插入距离设置为一个很大的值)
                    value.add(3.0); // 插入点属于新建的UAV行程
                    value.add((double) i); // 插入点所在的EV路径的索引
                    value.add((double) uavTrip.get(0).Position); // 新建的UAV行程的起飞点在EV路径中的位置
                    value.add((double) uavTrip.get(2).Position); // 新建的UAV行程的降落点在EV路径中的位置
                    value.add((double) uavTrips_all_position.get(index)); // 插入点在EV路线的UAV行程的索引
                    candidatePositions.add(value);  // 添加到列表中
                }
            }
        }
        // 将候选位置列表按照插入距离从小到大排序
        // 创建自定义Comparator
        Comparator<List<Double>> comparator = new Comparator<List<Double>>() {
            @Override
            public int compare(List<Double> o1, List<Double> o2) {
                // 比较两个List的第一个元素
                return o1.get(0).compareTo(o2.get(0));
            }
        };
        // 使用自定义Comparator对candidatePositions进行从小到大排序
        Collections.sort(candidatePositions, comparator);

        return candidatePositions;
    }

    // 判断UAV行程是否符合约束条件 (放宽约束条件，只简单判断插入点的时间窗是否满足，而没有考虑新建UAV行程后对整条路径的影响)
    public static boolean judgeUAVtrip(EV_Route ev_route, List<Node> uavTrip) {  // 传入的UAV行程，包括起飞点和降落点，加一个插入点，size为3
        double uav_load = 0;
        for (int j = 1; j < uavTrip.size() - 1; j++) {
            uav_load += uavTrip.get(j).Demand;
        }
        if (uav_load > Parameter.UAVCapacity) {    // 如果UAV行程的载重量超过了限制，则不插入
            return false;
        }
        // 如果插入后，能量消耗超过限制，则不插入
        double energy_consumption = Calculate_Tool.calculate_uavtrip_energy(uavTrip);
        if (energy_consumption > Parameter.UAVEnergy) {
            return false;
        }
        // 时间窗约束(放宽约束条件，只简单判断插入点的时间窗是否满足，而没有考虑新建UAV行程后对整条路径的影响)
        if (uavTrip.get(0).UAV_landing_to_here) { // 如果该UAV行程的起飞点是上一个UAV行程的降落点，则到达插入点的时间为上一个UAV行程到达降落点的时间+ UAV降落时间 + UAV起飞时间 + UAV装卸时间 + UAV飞行时间
            double pre_time = uavTrip.get(0).uavArrivalTime + Parameter.UAV_landing_time + Parameter.UAV_takeoff_time + Parameter.equip_UAV_time + Parameter.DisMatrix[uavTrip.get(0).NodeID][uavTrip.get(1).NodeID] / Parameter.UAVSpeed;
            if (pre_time + Parameter.UAV_landing_time > uavTrip.get(1).DueTime) {  // 如果到达插入点的时间大于插入点的DueTime，则该UAV行程不符合时间窗约束
                return false;
            } else {
                double later_time = Math.max(pre_time + Parameter.UAV_landing_time, uavTrip.get(1).ReadyTime) + uavTrip.get(1).ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[uavTrip.get(1).NodeID][uavTrip.get(2).NodeID] / Parameter.UAVSpeed;
                if (later_time + Parameter.UAV_landing_time > uavTrip.get(2).DueTime) {
                    return false;
                }
            }
        } else {  // 如果该UAV行程的起飞点不是上一个UAV行程的降落点，则到达插入点的时间为起飞节点的EV到达时间 + UAV起飞时间 + UAV装卸时间 + UAV飞行时间
            double pre_time = uavTrip.get(0).evArrivalTime + Parameter.UAV_takeoff_time + Parameter.equip_UAV_time + Parameter.DisMatrix[uavTrip.get(0).NodeID][uavTrip.get(1).NodeID] / Parameter.UAVSpeed;
            if (pre_time > uavTrip.get(1).DueTime) {  // 如果到达插入点的时间大于插入点的DueTime，则该UAV行程不符合时间窗约束
                return false;
            } else {
                double later_time = Math.max(pre_time + Parameter.UAV_landing_time, uavTrip.get(1).ReadyTime) + uavTrip.get(1).ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[uavTrip.get(1).NodeID][uavTrip.get(2).NodeID] / Parameter.UAVSpeed;
                if (later_time + Parameter.UAV_landing_time > uavTrip.get(2).DueTime) {
                    return false;
                }
            }
        }

        return true;
    }


    // 计算插入点在卡车路径中的候选位置，并计算插入成本
    public static List<List<Double>> calculateEVCandidatePositions_Cost(EV_Route[] evPaths, Node insertNode) {
        ArrayList<List<Double>> candidatePositions = new ArrayList<>();
        // 遍历所有EV路径(包括其所属的UAV行程)
        for (int i = 0; i < evPaths.length; i++) {
            ArrayList<Node> ev_route = evPaths[i].route;
            // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
            if (ev_route.size() <= 2) {
                continue;
            }
            // 计算ev_route的成本
            double origin_ev_route_cost = Calculate_Tool.calculateEVrouteCost(evPaths[i]);

//             如果插入该节点后，EV路径的载重量超过了限制，则跳过该EV路径  evPaths[i].total_load 为EV路径的总载重量
            if (evPaths[i].total_load + insertNode.Demand > Parameter.EVCapacity) {
                continue;
            }
            // 遍历EV路径中的节点，计算插入距离，l(j) = lij + ljl − lil，其中i和 l分别是j之前和j之后的两个节点
            for (int j = 1; j < ev_route.size(); j++) {
                // 如果插入点的 “时间” [明显]不符合时间窗约束，则不插入
                // 计算插入点的前一个节点到插入点的时间, 应该小于插入点的DueTime才合理
                double pre_time = ev_route.get(j - 1).evDepartureTime + Parameter.DisMatrix[ev_route.get(j - 1).NodeID][insertNode.NodeID] / Parameter.EVSpeed;
                // 计算如果插入后，插入点到后一个节点的时间，应该小于后一个节点的DueTime才合理
                double later_time = Math.max(pre_time, insertNode.ReadyTime) + insertNode.ServiceTime + Parameter.DisMatrix[insertNode.NodeID][ev_route.get(j).NodeID] / Parameter.EVSpeed;
                if (pre_time > insertNode.DueTime || later_time > ev_route.get(j).DueTime) {
                    continue;
                }

                double insert_cost = Repair.calculate_insert_cost_evroute(evPaths[i], origin_ev_route_cost, j, insertNode);

                ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,
                // 添加Double对象到列表中
                value.add(insert_cost); // 在该点的插入成本
                value.add(1.0); // 插入点属于EV路径
                value.add((double) i); // 插入点所在的EV路径的索引
                value.add((double) j); // 插入点在EV路径中的位置

                candidatePositions.add(value);  // 添加到列表中
            }

        }
        // 将候选位置列表按照插入成本从小到大排序
        // 创建自定义Comparator
        Comparator<List<Double>> comparator = new Comparator<List<Double>>() {
            @Override
            public int compare(List<Double> o1, List<Double> o2) {
                // 比较两个List的第一个元素
                return o1.get(0).compareTo(o2.get(0));
            }
        };

        // 使用自定义Comparator对candidatePositions进行从小到大排序
        Collections.sort(candidatePositions, comparator);

        return candidatePositions;
    }

    // 计算插入点在卡车路径和无人机航程中的候选位置，并计算插入成本
    public static List<List<Double>> calculateCandidatePositions_Cost(EV_Route[] evPaths, Node insertNode) {
        ArrayList<List<Double>> candidatePositions = new ArrayList<>();
        // 遍历所有EV路径(包括其所属的UAV行程)
        for (int i = 0; i < evPaths.length; i++) {
            ArrayList<Node> ev_route = evPaths[i].route;
            // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
            if (ev_route.size() <= 2) {
                continue;
            }
            // 计算ev_route的成本
            double origin_ev_route_cost = Calculate_Tool.calculateEVrouteCost(evPaths[i]);

            // 如果插入该节点后，EV路径的载重量超过了限制，则跳过该EV路径  evPaths[i].total_load 为EV路径的总载重量
            if (evPaths[i].total_load + insertNode.Demand > Parameter.EVCapacity) {
                continue;
            }
            // 遍历EV路径中的节点，计算插入距离，l(j) = lij + ljl − lil，其中i和 l分别是j之前和j之后的两个节点
            for (int j = 1; j < ev_route.size(); j++) {
                // 如果插入点的 “时间” [明显]不符合时间窗约束，则不插入
                // 计算插入点的前一个节点到插入点的时间, 应该小于插入点的DueTime才合理
                double pre_time = ev_route.get(j - 1).evDepartureTime + Parameter.DisMatrix[ev_route.get(j - 1).NodeID][insertNode.NodeID] / Parameter.EVSpeed;
                // 计算如果插入后，插入点到后一个节点的时间，应该小于后一个节点的DueTime才合理
                double later_time = Math.max(pre_time, insertNode.ReadyTime) + insertNode.ServiceTime + Parameter.DisMatrix[insertNode.NodeID][ev_route.get(j).NodeID] / Parameter.EVSpeed;
                if (pre_time > insertNode.DueTime || later_time > ev_route.get(j).DueTime) {
                    continue;
                }

                double insert_cost = Repair.calculate_insert_cost_evroute(evPaths[i], origin_ev_route_cost, j, insertNode);

                ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,
                // 添加Double对象到列表中
                value.add(insert_cost); // 在该点的插入成本
                value.add(1.0); // 插入点属于EV路径
                value.add((double) i); // 插入点所在的EV路径的索引
                value.add((double) j); // 插入点在EV路径中的位置

                candidatePositions.add(value);  // 添加到列表中
            }
            // 遍历EV路径所属的UAV行程中的节点，计算插入距离
            for (int m = 0; m < evPaths[i].uavTrips.size(); m++) {
                List<Node> uav_trip = evPaths[i].uavTrips.get(m);
                // 如果插入该节点后，UAV航程的载重量超过了限制，则跳过该UAV航程
                double uav_load = 0;
                for (int j = 1; j < uav_trip.size() - 1; j++) {
                    uav_load += uav_trip.get(j).Demand;
                }
                if (uav_load + insertNode.Demand > Parameter.UAVCapacity) {
                    continue;
                }

                for (int n = 1; n < uav_trip.size(); n++) {
                    // 如果插入点的 “时间” 明显不符合时间窗约束，则不插入
                    // 计算插入点的前一个节点到插入点的时间, 应该小于插入点的DueTime才合理
                    double pre_time = uav_trip.get(n - 1).uavDepartureTime + Parameter.DisMatrix[uav_trip.get(n - 1).NodeID][insertNode.NodeID] / Parameter.UAVSpeed;
                    if (pre_time > insertNode.DueTime) {
                        continue;
                    }
                    // 如果插入后，能量消耗超过限制，则不插入
                    List<Node> uav_trip_new = new ArrayList<>();
                    for (Node node : uav_trip) {
                        uav_trip_new.add(node);
                    }
                    uav_trip_new.add(n, insertNode);
                    double energy_consumption = Calculate_Tool.calculate_uavtrip_energy(uav_trip_new);
                    if (energy_consumption > Parameter.UAVEnergy) {
                        continue;
                    }
                    // 计算插入成本
                    double insert_cost = Repair.calculate_insert_cost_uavtrip(evPaths[i], origin_ev_route_cost, m, n, insertNode);
                    ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,
                    // 添加Double对象到列表中
                    value.add(insert_cost); // 在该点的插入成本
                    value.add(2.0); // 插入点属于UAV行程
                    value.add((double) i); // 插入点所在的EV路径的索引
                    value.add((double) m); // 插入点在EV路线的UAV行程的索引
                    value.add((double) n); // 插入点所在的UAV行程的位置

                    candidatePositions.add(value);  // 添加到列表中
                }
            }
            // 上面两种寻找插入点的方法，都是在当前的路径中寻找插入点（EV路径和UAV行程），下面的方法是在当前的路径中为insertnode尝试构建新的UAV行程
            // 3、为insertnode尝试构建新的UAV行程，如果该节点的需求量超过了UAV的载重量，则无法构建新的UAV行程
            if (insertNode.Demand > Parameter.UAVCapacity) {
                continue;
            }
            // 3.1 先更新路径中的节点信息
            // 遍历EV路径中的每个节点,除去起点和终点
            for (int k = 1; k < ev_route.size() - 1; k++) {
                ev_route.get(k).EV_service = true;  // EV服务该节点
                ev_route.get(k).UAV_service = false;  // UAV不服务该节点
                ev_route.get(k).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
                ev_route.get(k).UAV_landing_to_here = false;  // 重置UAV降落标志
                ev_route.get(k).Position = k; // 客户节点在ev路径中的位置索引
            }
            ev_route.get(0).Position = 0; // 起点在ev路径中的位置索引
            ev_route.get(0).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.get(0).UAV_landing_to_here = false;  // 重置UAV降落标志
            ev_route.get(ev_route.size() - 1).Position = ev_route.size() - 1; // 终点在ev路径中的位置索引
            ev_route.get(ev_route.size() - 1).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.get(ev_route.size() - 1).UAV_landing_to_here = false;  // 重置UAV降落标志

            ArrayList<Integer> takeoff_index = new ArrayList<>();  // 记录UAV起飞点的索引
            ArrayList<Integer> landing_index = new ArrayList<>();  // 记录UAV降落点的索引
            // 遍历EV的UAV航线中的每个节点
            for (List<Node> uavTrip : evPaths[i].uavTrips) {
                for (int t = 0; t < uavTrip.size(); t++) {
                    if (t == 0) {  // 对于起始节点（即起飞节点）
                        uavTrip.get(t).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                        takeoff_index.add(uavTrip.get(t).Position);  // 记录UAV起飞点的索引
                    } else if (t == uavTrip.size() - 1) {  // 对于终点（即降落节点）
                        uavTrip.get(t).UAV_landing_to_here = true;  // UAV降落到该节点
                        landing_index.add(uavTrip.get(t).Position);  // 记录UAV降落点的索引
                    } else {  // 对于中间节点
                        uavTrip.get(t).UAV_service = true;  // UAV服务该节点
                        uavTrip.get(t).EV_service = false;  // EV不服务该节点
                    }
                }
            }
            // 3.2 尝试所有的可能的起飞点和降落点组合，构建新的UAV行程
            ArrayList<List<Node>> uavTrips_all = new ArrayList<>();   // 用于存放所有的UAV行程
            ArrayList<Integer> uavTrips_all_position = new ArrayList<>();  // 用于存放所有的UAV行程的位置
            // 3.2.1 当前路径中不存在UAV行程
            if (evPaths[i].uavTrips.size() == 0) {
                //尝试所有的可能的起飞点和降落点组合，构建新的UAV行程（后续统一进行简单的根据约束判断新的UAV行程是否可行）
                for (int i1 = 0; i1 < ev_route.size() - 1; i1++) {
                    for (int j1 = i1 + 1; j1 < ev_route.size(); j1++) {
                        List<Node> uavTrip = new ArrayList<>();
                        uavTrip.add(ev_route.get(i1));  // 起飞节点
                        uavTrip.add(insertNode);  // 插入节点
                        uavTrip.add(ev_route.get(j1));  // 降落节点
                        uavTrips_all.add(uavTrip);
                        uavTrips_all_position.add(0);  // 记录UAV行程的位置,由于当前路径中不存在UAV行程，所以新构建的UAV行程的位置为0
                    }
                }
            } else {
                // 3.2.2 在已有UAV行程的第一个起飞节点的 前面 尝试插入新的UAV行程
                if (takeoff_index.get(0) > 0) {  // 如果第一个UAV行程的起飞点不是起点
                    for (int i1 = 0; i1 < takeoff_index.get(0); i1++) {
                        for (int j1 = i1 + 1; j1 < takeoff_index.get(0); j1++) {
                            List<Node> uavTrip = new ArrayList<>();
                            uavTrip.add(ev_route.get(i1));  // 起飞节点
                            uavTrip.add(insertNode);  // 插入节点
                            uavTrip.add(ev_route.get(j1));  // 降落节点
                            uavTrips_all.add(uavTrip);
                            uavTrips_all_position.add(0);  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的前面，所以位置为0
                        }
                    }
                }
                // 3.2.3 在已有UAV行程的最后一个降落节点的 后面 尝试插入新的UAV行程
                if (landing_index.get(landing_index.size() - 1) < ev_route.size() - 1) {  // 如果最后一个UAV行程的降落点不是终点
                    for (int i1 = landing_index.get(landing_index.size() - 1); i1 < ev_route.size() - 1; i1++) {
                        for (int j1 = i1 + 1; j1 < ev_route.size(); j1++) {
                            List<Node> uavTrip = new ArrayList<>();
                            uavTrip.add(ev_route.get(i1));  // 起飞节点
                            uavTrip.add(insertNode);  // 插入节点
                            uavTrip.add(ev_route.get(j1));  // 降落节点
                            uavTrips_all.add(uavTrip);
                            uavTrips_all_position.add(evPaths[i].uavTrips.size());  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的后面，所以位置为已有UAV行程的数量
                        }
                    }
                }
                // 3.2.4 在已有UAV行程的中间节点之间 尝试插入新的UAV行程，值得注意的是，需要保证新的UAV行程的起飞点和降落点不在已有UAV行程的起飞点和降落点之间，即新的UAV行程不与已有UAV行程重叠
                if (evPaths[i].uavTrips.size() >= 2) {  // 已有UAV行程大于2
                    for (int uavtrip_index = 0; uavtrip_index < evPaths[i].uavTrips.size() - 1; uavtrip_index++) {   // 遍历已有UAV行程（除去最后一个UAV行程）
                        for (int i1 = landing_index.get(uavtrip_index); i1 < takeoff_index.get(uavtrip_index + 1); i1++) {   // 新UAV行程的起飞点在已有UAV行程的上一个降落点和下一个起飞点之间，包括降落点，但不包括起飞点
                            for (int j1 = i1 + 1; j1 <= takeoff_index.get(uavtrip_index + 1); j1++) {  // 新UAV行程的降落点在已有UAV行程的下一个起飞点和降落点之间，包括起飞点，但不包括降落点
                                List<Node> uavTrip = new ArrayList<>();
                                uavTrip.add(ev_route.get(i1));  // 起飞节点
                                uavTrip.add(insertNode);  // 插入节点
                                uavTrip.add(ev_route.get(j1));  // 降落节点
                                uavTrips_all.add(uavTrip);
                                uavTrips_all_position.add(uavtrip_index + 1);  // 记录UAV行程的位置，由于插入的UAV行程在已有UAV行程的中间，所以位置为已有UAV行程的索引+1
                            }
                        }
                    }
                }
            }
            // 3.3 剔除不符合约束条件的UAV行程(放宽约束条件，只简单判断插入点的时间窗是否满足，而没有考虑新建UAV行程后对整条路径的影响)
            for (int index = 0; index < uavTrips_all.size(); index++) {
                List<Node> uavTrip = uavTrips_all.get(index);
                boolean flag = judgeUAVtrip(evPaths[i], uavTrip);
                if (flag) {  // 如果UAV行程符合约束条件
                    double insert_cost = Repair.calculate_insert_cost_new_uavtrip(evPaths[i], origin_ev_route_cost, uavTrip, uavTrips_all_position.get(index));
                    ArrayList<Double> value = new ArrayList<>(); // 创建一个列表,用于存放插入点的候选位置,并将uavTrip的信息存放到列表中（即起飞点、插入点、降落点）
                    // 添加Double对象到列表中
                    value.add(insert_cost); // 在该点的插入成本
                    value.add(3.0); // 插入点属于新建的UAV行程
                    value.add((double) i); // 插入点所在的EV路径的索引
                    value.add((double) uavTrip.get(0).Position); // 新建的UAV行程的起飞点在EV路径中的位置
                    value.add((double) uavTrip.get(2).Position); // 新建的UAV行程的降落点在EV路径中的位置
                    value.add((double) uavTrips_all_position.get(index)); // 插入点在EV路线的UAV行程的索引
                    candidatePositions.add(value);  // 添加到列表中
                }
            }
        }
        // 将候选位置列表按照插入成本从小到大排序
        // 创建自定义Comparator
        Comparator<List<Double>> comparator = new Comparator<List<Double>>() {
            @Override
            public int compare(List<Double> o1, List<Double> o2) {
                // 比较两个List的第一个元素
                return o1.get(0).compareTo(o2.get(0));
            }
        };
        // 使用自定义Comparator对candidatePositions进行从小到大排序
        Collections.sort(candidatePositions, comparator);
        return candidatePositions;
    }

    // 计算新建UAV行程的插入成本
    public static double calculate_insert_cost_new_uavtrip(EV_Route origin_ev_route, double origin_ev_route_cost, List<Node> uavTrip, int uavTrips_insert_position) {
        double insert_cost = 0;
        EV_Route temp_ev_route = new EV_Route();
        // 复制EV路径以及其所属的UAV行程
        temp_ev_route.route = new ArrayList<>();
        for (Node node : origin_ev_route.route) {
            temp_ev_route.route.add(node);
        }
        temp_ev_route.uavTrips = new ArrayList<>();
        for (List<Node> uav_trip : origin_ev_route.uavTrips) {
            List<Node> uav_trip_new = new ArrayList<>();
            for (Node node : uav_trip) {
                uav_trip_new.add(node);
            }
            temp_ev_route.uavTrips.add(uav_trip_new);
        }
        // 在temp_ev_route中新建一个UAV行程，即在temp_ev_route.uavTrips中的position_index位置插入一个新的UAV行程
        temp_ev_route.uavTrips.add(uavTrips_insert_position, uavTrip);
        // 计算插入节点后的成本
        double temp_ev_route_cost = Calculate_Tool.calculateEVrouteCost(temp_ev_route);
        insert_cost = temp_ev_route_cost - origin_ev_route_cost;
        // 是否考虑预估的换电成本
        insert_cost += Parameter.consider_battery_change_cost * (temp_ev_route.battery_change_times - origin_ev_route.battery_change_times) * Parameter.battery_change_cost;
        return insert_cost;
    }

    // 计算在EV路径的指定位置插入节点的成本增加值  (考虑预估的换电成本）
    public static double calculate_insert_cost_evroute(EV_Route origin_ev_route, double origin_ev_route_cost, int position_index, Node insertNode) {
        double insert_cost = 0;
        EV_Route temp_ev_route = new EV_Route();
        // 复制EV路径以及其所属的UAV行程
        temp_ev_route.route = new ArrayList<>();
        for (Node node : origin_ev_route.route) {
            temp_ev_route.route.add(node);
        }
        temp_ev_route.uavTrips = new ArrayList<>();
        for (List<Node> uav_trip : origin_ev_route.uavTrips) {
            List<Node> uav_trip_new = new ArrayList<>();
            for (Node node : uav_trip) {
                uav_trip_new.add(node);
            }
            temp_ev_route.uavTrips.add(uav_trip_new);
        }
        // 在指定位置插入节点
        temp_ev_route.route.add(position_index, insertNode);
        // 计算插入节点后的成本
        double temp_ev_route_cost = Calculate_Tool.calculateEVrouteCost(temp_ev_route);
        insert_cost = temp_ev_route_cost - origin_ev_route_cost;
        // 是否考虑预估的换电成本
        insert_cost += Parameter.consider_battery_change_cost * (temp_ev_route.battery_change_times - origin_ev_route.battery_change_times) * Parameter.battery_change_cost;
        return insert_cost;
    }

    // 计算在指定的EV路径所属的UAV行程的指定位置插入节点的成本增加值
    public static double calculate_insert_cost_uavtrip(EV_Route origin_ev_route, double origin_ev_route_cost, int uav_trip_index, int position_index, Node insertNode) {
        double insert_cost = 0;
        EV_Route temp_ev_route = new EV_Route();
        // 复制EV路径以及其所属的UAV行程
        temp_ev_route.route = new ArrayList<>();
        for (Node node : origin_ev_route.route) {
            temp_ev_route.route.add(node);
        }
        temp_ev_route.uavTrips = new ArrayList<>();
        for (List<Node> uav_trip : origin_ev_route.uavTrips) {
            List<Node> uav_trip_new = new ArrayList<>();
            for (Node node : uav_trip) {
                uav_trip_new.add(node);
            }
            temp_ev_route.uavTrips.add(uav_trip_new);
        }
        // 在temp_ev_route中的指定的UAV行程的指定位置插入节点，即在temp_ev_route.uavTrips.get(uav_trip_index)的position_index位置插入insertNode，而不是新建一个UAV行程
        List<Node> uav_trip = temp_ev_route.uavTrips.get(uav_trip_index);
        List<Node> uav_trip_new = new ArrayList<>();
        for (Node node : uav_trip) {
            uav_trip_new.add(node);
        }
        uav_trip_new.add(position_index, insertNode);
        temp_ev_route.uavTrips.set(uav_trip_index, uav_trip_new);

        // 计算插入节点后的成本
        double temp_ev_route_cost = Calculate_Tool.calculateEVrouteCost(temp_ev_route);
        insert_cost = temp_ev_route_cost - origin_ev_route_cost;
        // 是否考虑预估的换电成本
        insert_cost += Parameter.consider_battery_change_cost * (temp_ev_route.battery_change_times - origin_ev_route.battery_change_times) * Parameter.battery_change_cost;
        return insert_cost;
    }

    // 检查是否可以在EV路径的指定位置插入节点
    public static boolean can_insertIntoEVRoute(Solution solution, int ev_route_index, int position_index, Node insertNode) { // 传入参数：解，EV路径索引，插入位置索引，插入节点
        boolean can_insert = true;
        // 检查容量、能耗、时间窗口等约束
        EV_Route ev_route = solution.evPaths[ev_route_index];
        // 1. 检查EV路径的载重量是否超过限制
        double current_total_Load = 0; // 当前路径的总载重量,即中间节点的需求量加和，不包括起飞和降落节点

        Calculate_Tool.updateEVRoutesMetrics(ev_route);

        current_total_Load = ev_route.total_load;
        boolean Capacity_flag = current_total_Load + insertNode.Demand <= Parameter.EVCapacity;
        if (!Capacity_flag) {   // 如果当前路径的总载重量大于电动汽车的容量，则不满足容量约束
            can_insert = false;
        }
        // 2. 检查EV路径的能量是否违反


        return can_insert;

    }

    // 检查是否可以在UAV航程的指定位置插入节点
    public static boolean can_insertIntoUAVtrip(Solution solution, int ev_route_index, int uav_trip_index, int position_index, Node insertNode) { // 传入参数：解，EV路径索引，UAV航程索引，插入位置索引，插入节点
        boolean can_insert = true;
        List<Node> uav_trip = solution.evPaths[ev_route_index].uavTrips.get(uav_trip_index);
        List<Node> uav_trip_new = new ArrayList<>();
        for (Node node : uav_trip) {
            uav_trip_new.add(node);
        }
        uav_trip_new.add(position_index, insertNode);

        // 检查容量、能耗、时间窗口等约束
        // 1. 检查UAV航程的载重量是否超过限制
        double current_total_Load = 0; // 当前航线的总载重量,即中间节点的需求量加和，不包括起飞和降落节点
        for (int i = 1; i < uav_trip.size() - 1; i++) {
            current_total_Load += uav_trip.get(i).Demand;
        }
        boolean Capacity_flag = current_total_Load + insertNode.Demand <= Parameter.UAVCapacity;
        if (!Capacity_flag) {   // 如果当前航线的总载重量大于无人机的容量，则不满足容量约束
            can_insert = false;
        }
        // 2. 检查UAV航程的能量是否违反
        double energy_consumption = Calculate_Tool.calculate_uavtrip_energy(uav_trip_new);
        if (energy_consumption > Parameter.UAVEnergy) {
            can_insert = false;
        }
        // 3. 检查UAV航程的时间窗是否满足,简单检查插入点的时间窗是否满足即可
//        double pre_time = uav_trip.get(position_index - 1).uavDepartureTime + Parameter.DisMatrix[uav_trip.get(position_index - 1).NodeID][insertNode.NodeID] / Parameter.UAVSpeed;
//        if (pre_time > insertNode.DueTime) {  // 如果插入点的前一个节点到插入点的时间大于插入点的DueTime，则不满足时间窗约束
//            can_insert = false;
//        }
        // 如果uav_trip_new的节点的duetime不是从小到大排列，则不满足时间窗约束，不算起飞节点和降落节点
        for (int i = 2; i < uav_trip_new.size() - 1; i++) {
            if (uav_trip_new.get(i).DueTime < uav_trip_new.get(i - 1).DueTime) {
                can_insert = false;
                break;
            }
        }

        return can_insert;
    }

    // 更新UAV行程
    public static Integer updateUAVTrip(Solution solution, int ev_route_index) {
        // 更新UAV行程
        EV_Route ev_route = solution.evPaths[ev_route_index];
        // 如果ev路径只有起点终点以及一个客户节点，则不需要更新UAV行程
        if (ev_route.route.size() <= 3) {
            return 0;
        }
        // ***************************DEBUG***************************ev_route有重复元素，通过NodeID来判断
        for (Node node : ev_route.route) {
            int count = 0;
            for (Node node1 : ev_route.route) {
                if (node.NodeID == node1.NodeID) {
                    count++;
                }
            }
            if (count > 1) {
                System.out.println("EV路径有重复元素");
                break;
            }
        }
        //  ***************************DEBUG***************************

        // 重新规划UAV行程   如果客户m当前由电动汽车服务且不进行发射或回收操作，则通过查找现有无人机行程或构建新的无人机行程，同时仅考虑无人机有效负载能力和能耗约束，将其服务模式从电动汽车更改为无人机。
        // 遍历EV路径中的每个节点,除去起点和终点
        for (int i = 1; i < ev_route.route.size() - 1; i++) {
            ev_route.route.get(i).EV_service = true;  // EV服务该节点
            ev_route.route.get(i).UAV_service = false;  // UAV不服务该节点
            ev_route.route.get(i).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.route.get(i).UAV_landing_to_here = false;  // 重置UAV降落标志
            ev_route.route.get(i).Position = i; // 客户节点在ev路径中的位置索引
        }
        ev_route.route.get(0).Position = 0; // 起点在ev路径中的位置索引
        ev_route.route.get(0).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
        ev_route.route.get(0).UAV_landing_to_here = false;  // 重置UAV降落标志
        ev_route.route.get(ev_route.route.size() - 1).Position = ev_route.route.size() - 1; // 终点在ev路径中的位置索引
        ev_route.route.get(ev_route.route.size() - 1).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
        ev_route.route.get(ev_route.route.size() - 1).UAV_landing_to_here = false;  // 重置UAV降落标志

        ArrayList<Integer> takeoff_index = new ArrayList<>();  // 记录UAV起飞点的索引
        ArrayList<Integer> landing_index = new ArrayList<>();  // 记录UAV降落点的索引
        // 遍历EV的UAV航线中的每个节点
        for (List<Node> uavTrip : ev_route.uavTrips) {
            for (int i = 0; i < uavTrip.size(); i++) {
                if (i == 0) {  // 对于起始节点（即起飞节点）
                    uavTrip.get(i).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                    takeoff_index.add(uavTrip.get(i).Position);  // 记录UAV起飞点的索引
                } else if (i == uavTrip.size() - 1) {  // 对于终点（即降落节点）
                    uavTrip.get(i).UAV_landing_to_here = true;  // UAV降落到该节点
                    landing_index.add(uavTrip.get(i).Position);  // 记录UAV降落点的索引
                } else {  // 对于中间节点
                    uavTrip.get(i).UAV_service = true;  // UAV服务该节点
                    uavTrip.get(i).EV_service = false;  // EV不服务该节点
                }
            }
        }
        // 从当前EV路径中随机选择一个客户节点，不包括起点和终点
        int index = (int) (Math.random() * (ev_route.route.size() - 2)) + 1;
        Node random_node = ev_route.route.get(index);   // bug!!!
        // 如果客户m当前由电动汽车服务且不进行发射或回收操作，则通过查找现有无人机行程或构建新的无人机行程，同时仅考虑无人机有效负载能力和能耗约束，将其服务模式从电动汽车更改为无人机。
        if (!random_node.UAV_landing_to_here && !random_node.UAV_takeoff_from_here && random_node.Demand < Parameter.UAVCapacity) {
            // 重新规划UAV行程
            ArrayList<Integer> between_trip_index = new ArrayList<>();  // 跨过random_node节点的UAV航程
            ArrayList<Integer> else_trip_index = new ArrayList<>();   // 没有跨过random_node节点的UAV航程
            Node pre_node = ev_route.route.get(0);  // random_node节点的前一个uav航程降落的节点，如果没有则为起点
            Node after_node = ev_route.route.get(ev_route.route.size() - 1);  // random_node节点的后的第一个uav航程起飞的节点，如果没有则为终点
            boolean flag_first = false;  // 标记是否找到random_node节点的后的第一个uav航程起飞的节点
            for (int i = 0; i < takeoff_index.size(); i++) {
                if (takeoff_index.get(i) > random_node.Position && !flag_first) {
                    after_node = ev_route.route.get(takeoff_index.get(i));
                    flag_first = true;          // 找到random_node节点的后的第一个uav航程起飞的节点
                }
                if (landing_index.get(i) < random_node.Position) {
                    pre_node = ev_route.route.get(landing_index.get(i));
                }
                if (takeoff_index.get(i) < random_node.Position && landing_index.get(i) > random_node.Position) {
                    between_trip_index.add(i);
                } else {
                    else_trip_index.add(i);
                }
            }
            // 计算当前路径的cost
            double origin_ev_route_cost = Calculate_Tool.calculateEVrouteCost(ev_route);

            // 尝试将random_node节点服务模式从EV更改为UAV，即将random_node节点从EV路径中移除，并将其添加到UAV行程中
            // 1. 尝试将random_node节点添加到跨过它的UAV航程中
            if (between_trip_index.size() > 0) {
                for (int i = 0; i < between_trip_index.size(); i++) {
                    List<Node> uavTrip = ev_route.uavTrips.get(between_trip_index.get(i)); // 获取UAV航程
                    for (int j = 1; j < uavTrip.size() - 1; j++) {
                        if (Repair.can_insertIntoUAVtrip(solution, ev_route_index, between_trip_index.get(i), j, random_node)) {
                            uavTrip.add(j, random_node);   // 插入random_node节点
                            ev_route.route.remove(random_node);  // 在EV路径中删除random_node节点
                            random_node.UAV_service = true;  // UAV服务该节点
                            random_node.EV_service = false;  // EV不服务该节点

                            //***************************DEBUG***************************
                            // 存储ev_route.uavTrips的起飞节点和降落节点的位置索引
                            ArrayList<Integer> takeoff_index1 = new ArrayList<>();  // 记录UAV起飞点的索引
                            ArrayList<Integer> landing_index1 = new ArrayList<>();  // 记录UAV降落点的索引
                            ArrayList<Integer> index1 = new ArrayList<>();
                            for (List<Node> uavTrip1 : ev_route.uavTrips) {
                                for (int k = 0; k < uavTrip1.size(); k++) {
                                    if (k == 0) {  // 对于起始节点（即起飞节点）
                                        takeoff_index1.add(uavTrip1.get(k).Position);  // 记录UAV起飞点的索引
                                        index1.add(uavTrip1.get(k).Position);
                                    } else if (k == uavTrip1.size() - 1) {  // 对于终点（即降落节点）
                                        landing_index1.add(uavTrip1.get(k).Position);  // 记录UAV降落点的索引
                                        index1.add(uavTrip1.get(k).Position);
                                    }
                                }
                            }
                            // 判断是否有交叉的UAV航程,即index1是否递增
                            boolean UAV_trip_cross = true;
                            for (int t = 0; t < index1.size() - 1; t++) {
                                if (index1.get(t) > index1.get(t + 1)) {
                                    UAV_trip_cross = false;
                                    break;
                                }
                            }
                            // 判断UAV航程是否有误（重合元素）
                            for (List<Node> uavTrip2 : ev_route.uavTrips) {
                                // uavTrip2 中节点是否有重复,根据NodeID来判断
                                for (Node node : uavTrip2) {
                                    int count = 0;
                                    for (Node node1 : uavTrip2) {
                                        if (node.NodeID == node1.NodeID) {
                                            count++;
                                        }
                                    }
                                    if (count > 1) {
                                        System.out.println("UAV航程有误");
                                        break;
                                    }
                                }
                                for (int k = 1; k < uavTrip2.size() - 1; k++) {
                                    if (uavTrip2.get(k).NodeID == Parameter.NodeNumber) {
                                        System.out.println("UAV航程中间节点有误");
                                    }
                                }

                            }
                            //***************************DEBUG***************************

                            return 1;   // 插入成功，直接返回
                        }
                    }
                }
            } else {  // 2. 尝试构建新的UAV航程，为random_node节点服务
                // 当前的repair算子构建跨节点的uavtrip的能力很弱，从而算法会陷入局部最优解中，需要进一步优化。
                // 优化思路1：构建新的UAV航程时，起飞节点和降落节点的选择更加灵活，不一定是相邻的节点
                ArrayList<Node> takeoff_nodes = new ArrayList<>();
                ArrayList<Node> landing_nodes = new ArrayList<>();
                for (int i = 0; i < ev_route.route.size(); i++) {
                    if (pre_node.Position <= i && i < random_node.Position) {
                        takeoff_nodes.add(ev_route.route.get(i));
                    }
                    if (random_node.Position < i && i <= after_node.Position) {
                        landing_nodes.add(ev_route.route.get(i));
                    }
                }
                // 从takeoff_nodes和landing_nodes中选择起飞节点和降落节点
                ArrayList<List<Node>> uavTrips_feasible = new ArrayList<>();
                for (int i = 0; i < takeoff_nodes.size(); i++) {
                    for (int j = 0; j < landing_nodes.size(); j++) {
                        List<Node> uavTrip = new ArrayList<>();
                        uavTrip.add(takeoff_nodes.get(i));  // 添加起飞节点
                        uavTrip.add(random_node);  // 添加random_node节点
                        uavTrip.add(landing_nodes.get(j));  // 添加降落节点
                        if (Repair.can_buildNewUAVtrip(uavTrip)) {
                            uavTrips_feasible.add(uavTrip);
                        }
                    }
                }
                if (uavTrips_feasible.size() > 0) {
                    // 从feasible_uavTrips中随机选择一个UAV航程
                    int random_index = (int) (Math.random() * uavTrips_feasible.size());
                    List<Node> uavTrip = uavTrips_feasible.get(random_index);
                    // 添加新的UAV航程, 找到插入索引，即插入到uavtrips列表的位置
                    int insert_index = 0;
                    for (int i = 0; i < ev_route.uavTrips.size(); i++) {
                        if (ev_route.uavTrips.get(i).get(0).Position < random_node.Position) {
                            insert_index++;
                        }
                    }
                    ev_route.uavTrips.add(insert_index, uavTrip);  // 添加新的UAV航程
                    random_node.UAV_service = true;  // UAV服务该节点
                    random_node.EV_service = false;  // EV不服务该节点
                    ev_route.route.get(index - 1).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                    ev_route.route.get(index + 1).UAV_landing_to_here = true;  // UAV降落到该节点
                    ev_route.route.remove(random_node);  // 在EV路径中删除random_node节点

                    // *****************debug******************新建uav航程交叉
                    // 存储ev_route.uavTrips的起飞节点和降落节点的位置索引
                    ArrayList<Integer> takeoff_index1 = new ArrayList<>();  // 记录UAV起飞点的索引
                    ArrayList<Integer> landing_index1 = new ArrayList<>();  // 记录UAV降落点的索引
                    ArrayList<Integer> index1 = new ArrayList<>();
                    for (List<Node> uavTrip1 : ev_route.uavTrips) {
                        for (int i = 0; i < uavTrip1.size(); i++) {
                            if (i == 0) {  // 对于起始节点（即起飞节点）
                                takeoff_index1.add(uavTrip1.get(i).Position);  // 记录UAV起飞点的索引
                                index1.add(uavTrip1.get(i).Position);
                            } else if (i == uavTrip1.size() - 1) {  // 对于终点（即降落节点）
                                landing_index1.add(uavTrip1.get(i).Position);  // 记录UAV降落点的索引
                                index1.add(uavTrip1.get(i).Position);
                            }
                        }
                    }
                    // 判断是否有交叉的UAV航程,即index1是否递增
                    boolean UAV_trip_cross = true;
                    for (int i = 0; i < index1.size() - 1; i++) {
                        if (index1.get(i) > index1.get(i + 1)) {
                            UAV_trip_cross = false;
                            break;
                        }
                    }
                    // 判断UAV航程是否有误（重合元素）
                    for (List<Node> uavTrip2 : ev_route.uavTrips) {
                        // uavTrip2 中节点是否有重复,根据NodeID来判断
                        for (Node node : uavTrip2) {
                            int count = 0;
                            for (Node node1 : uavTrip2) {
                                if (node.NodeID == node1.NodeID) {
                                    count++;
                                }
                            }
                            if (count > 1) {
                                UAV_trip_cross = false;
                                break;
                            }
                        }
                        for (int k = 1; k < uavTrip2.size() - 1; k++) {
                            if (uavTrip2.get(k).NodeID == Parameter.NodeNumber) {
                                System.out.println("UAV航程中间节点有误");
                            }
                        }
                    }


                    //*****************debug******************新建uav航程交叉
                    return 1; // 插入成功，直接返回
                }

//                // 思路2：构建新的UAV航程时，起飞节点和降落节点的选择为相邻的前后节点
//                List<Node> uavTrip = new ArrayList<>();
//                uavTrip.add(ev_route.route.get(index - 1));  // 添加起飞节点
//                uavTrip.add(random_node);  // 添加random_node节点
//                uavTrip.add(ev_route.route.get(index + 1));  // 添加降落节点
//                if (Repair.can_buildNewUAVtrip(uavTrip)) {
//                    // 添加新的UAV航程, 找到插入索引，即插入到uavtrips列表的位置
//                    int insert_index = 0;
//                    for (int i = 0; i < ev_route.uavTrips.size(); i++) {
//                        if (ev_route.uavTrips.get(i).get(0).Position < random_node.Position) {
//                            insert_index++;
//                        }
//                    }
//                    ev_route.uavTrips.add(insert_index, uavTrip);  // 添加新的UAV航程
//                    random_node.UAV_service = true;  // UAV服务该节点
//                    random_node.EV_service = false;  // EV不服务该节点
//                    ev_route.route.get(index - 1).UAV_takeoff_from_here = true;  // UAV从该节点起飞
//                    ev_route.route.get(index + 1).UAV_landing_to_here = true;  // UAV降落到该节点
//                    ev_route.route.remove(random_node);  // 在EV路径中删除random_node节点
//                    return 1; // 插入成功，直接返回
//                }

            }
        }
        return 0;
    }

    // 优化UAV行程
    //在 Ev Route插入完成后，检查哪些客户节点可以转移到 UvRoute中进行服务，以分担卡车负担。
    //对于这些客户，重新调整 EV_Route的起飞和降落点，使无人机服务尽量覆盖多个客户，并减少 Ev_Route 的负载。
    public static Integer optimizeUAVTrip(Solution solution, int ev_route_index) {
        EV_Route ev_route = solution.evPaths[ev_route_index];  // 获取待优化的EV路径
        // 如果ev路径只有起点终点以及一个客户节点，且没有UAV行程，则不需要优化UAV行程
        if (ev_route.route.size() <= 3 || ev_route.uavTrips.size() == 0) {
            return 0;
        }
        // 遍历EV路径中的每个节点,除去起点和终点
        for (int i = 1; i < ev_route.route.size() - 1; i++) {
            ev_route.route.get(i).EV_service = true;  // EV服务该节点
            ev_route.route.get(i).UAV_service = false;  // UAV不服务该节点
            ev_route.route.get(i).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
            ev_route.route.get(i).UAV_landing_to_here = false;  // 重置UAV降落标志
            ev_route.route.get(i).Position = i; // 客户节点在ev路径中的位置索引
        }
        ev_route.route.get(0).Position = 0; // 起点在ev路径中的位置索引
        ev_route.route.get(0).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
        ev_route.route.get(0).UAV_landing_to_here = false;  // 重置UAV降落标志
        ev_route.route.get(ev_route.route.size() - 1).Position = ev_route.route.size() - 1; // 终点在ev路径中的位置索引
        ev_route.route.get(ev_route.route.size() - 1).UAV_takeoff_from_here = false;  // 重置UAV起飞标志
        ev_route.route.get(ev_route.route.size() - 1).UAV_landing_to_here = false;  // 重置UAV降落标志

        ArrayList<Integer> takeoff_index = new ArrayList<>();  // 记录UAV起飞点的索引
        ArrayList<Integer> landing_index = new ArrayList<>();  // 记录UAV降落点的索引
        // 遍历EV的UAV航线中的每个节点
        for (List<Node> uavTrip : ev_route.uavTrips) {
            for (int i = 0; i < uavTrip.size(); i++) {
                if (i == 0) {  // 对于起始节点（即起飞节点）
                    uavTrip.get(i).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                    takeoff_index.add(uavTrip.get(i).Position);  // 记录UAV起飞点的索引
                } else if (i == uavTrip.size() - 1) {  // 对于终点（即降落节点）
                    uavTrip.get(i).UAV_landing_to_here = true;  // UAV降落到该节点
                    landing_index.add(uavTrip.get(i).Position);  // 记录UAV降落点的索引
                } else {  // 对于中间节点
                    uavTrip.get(i).UAV_service = true;  // UAV服务该节点
                    uavTrip.get(i).EV_service = false;  // EV不服务该节点
                }
            }
        }
        // 从当前EV路径中寻找潜在的UAV服务节点
        ArrayList<Node> potential_UAV_service_nodes = new ArrayList<>();

        return 1; // 插入成功，直接返回
    }


    public static boolean can_buildNewUAVtrip(List<Node> uavtrip) {
        boolean can_build = true;
        // 判断容量约束条件
        double current_total_Load = 0; // 当前航线的总载重量,即中间节点的需求量加和，不包括起飞和降落节点
        for (int i = 1; i < uavtrip.size() - 1; i++) {
            current_total_Load += uavtrip.get(i).Demand;
        }
        boolean Capacity_flag = current_total_Load <= Parameter.UAVCapacity;
        if (!Capacity_flag) {   // 如果当前航线的总载重量大于无人机的容量，则不满足容量约束
            return false;
        }
        // 2. 检查UAV航程的能量是否违反
        double energy_consumption = Calculate_Tool.calculate_uavtrip_energy(uavtrip);
        if (energy_consumption > Parameter.UAVEnergy) {
            return false;
        }
        // 3. 检查UAV航程的时间窗是否满足
        // 待实现

        return can_build;
    }

    public static Integer Generate_routes(Solution solution, ArrayList<Node> delete_NodeList) {
        // 打印删除节点列表id
//        System.out.println("删除节点列表：");
//        for(Node node:delete_NodeList){
//            System.out.print(node.NodeID+" ");
//        }

        //***************************DEBUG***************************
        for (EV_Route evRoute : solution.evPaths) {
            for (Node node : evRoute.route) {
                int count = 0;
                for (Node node1 : evRoute.route) {
                    if (node.NodeID == node1.NodeID) {
                        count++;
                    }
                }
                if (count > 1) {
                    System.out.println("EV路径有重复元素");
                    break;
                }
            }
            // 判断UAV航程是否有误（重合元素）
            for (List<Node> uavTrip2 : evRoute.uavTrips) {
                // uavTrip2 中节点是否有重复,根据NodeID来判断
                for (Node node : uavTrip2) {
                    int count = 0;
                    for (Node node1 : uavTrip2) {
                        if (node.NodeID == node1.NodeID) {
                            count++;
                        }
                    }
                    if (count > 1) {
                        System.out.println("UAV航程有误");
                        break;
                    }
                }
                for (int k = 1; k < uavTrip2.size() - 1; k++) {
                    if (uavTrip2.get(k).NodeID ==  Parameter.NodeNumber) {
                        System.out.println("UAV航程中间节点有误");
                    }
                }
            }
        }
        //***************************DEBUG***************************


        //建立新的EV-UAV-BSV路线
        //第一阶段：构建EV路线，寻找一条空路径，从配送中心（Depot）开始，然后依次向路径中插入节点。
        int currentRouteid = -1;  // 当前正在构建的EV路线的编号
        ArrayList<Integer> evRouteIndex = new ArrayList<>();  // 存储新建的EV路线的索引
        for (EV_Route evRoute : solution.evPaths) {        // 遍历每辆EV, 为每辆EV初始化路径
            currentRouteid++;
            if (evRoute.route.size() > 2) {  // 如果路径长度大于2，说明有中间节点,路径不为空，直接跳过
                continue;
            }
            // 先清空EV路径
            evRoute.route.clear();
            // 重新构建EV路径
            evRouteIndex.add(currentRouteid);  // 记录新建的EV路线的索引
            evRoute.route.add(Parameter.All_NodeList[0]);     // 路径从配送中心开始
            double currentLoad = 0;
            double currentTime = 0;
            Node currentNode = Parameter.All_NodeList[0];    // 当前节点为配送中心

            // 直到所有客户节点被分配或者当前EV的容量达到上限，则结束当前EV的路径构建
            while (!delete_NodeList.isEmpty() && currentLoad < Parameter.EVCapacity) {
                //在每一步，我们选择离当前节点最近的且符合容量和时间约束的下一个节点。
                Node nextNode = ReadData.findNextNode(evRoute, currentNode, currentLoad, currentTime, delete_NodeList);

                if (nextNode != null) {
                    evRoute.route.add(nextNode);     // 添加下一个节点
                    currentLoad += nextNode.Demand;  // 更新载重量
                    // 更新时间, 从当前节点到下一个节点的时间 + 下一个节点的服务时间,因为可能需要等待，所以取最大值
                    currentTime = Math.max(nextNode.ReadyTime, currentTime + Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID] / Parameter.EVSpeed) + nextNode.ServiceTime;

                    // 更新节点状态
                    nextNode.NodeWithEVID = currentRouteid;
                    nextNode.Position = evRoute.route.size() - 1;

                    // 从待分配节点列表中移除已经分配的节点
                    delete_NodeList.remove(nextNode);
                    // 更新当前节点
                    currentNode = nextNode;
                } else {
                    break;  // 没有合适的下一个节点，结束当前EV的路径构建
                }
            }
            // 结束当前EV的路径构建，回到配送中心
            evRoute.route.add(Parameter.All_NodeList[Parameter.NodeNumber]);  // 回到配送中心，-1表示虚拟仓库节点
            Calculate_Tool.updateEVRoutesMetrics(evRoute);  // 更新EV路径的距离、能耗,路径中节点到达时间等信息

        }
        // 如果将所有可用的EV构建路线完毕后，还有未分配的节点，则将其分配给最近的EV（待改进，可以考虑将其插入到EV路径中，而非最后）！！！
        while (!delete_NodeList.isEmpty()) {
            Node nearestNode = null;
            double minDistance = Double.MAX_VALUE;
            EV_Route nearestEVRoute = null;
            for (Node node : delete_NodeList) {
                for (EV_Route evRoute : solution.evPaths) {
                    double distance = Parameter.DisMatrix[evRoute.route.get(evRoute.route.size() - 1).NodeID][node.NodeID];
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearestNode = node;
                        nearestEVRoute = evRoute;
                    }
                }
            }
            if (nearestNode != null) {
                nearestEVRoute.route.add(nearestEVRoute.route.size() - 1, nearestNode);  // 将节点插入到EV路径中，倒数第二个位置，即倒数第一个节点之前
                Calculate_Tool.updateEVRoutesMetrics(nearestEVRoute);  // 更新EV路径的距离、能耗,路径中节点到达时间等信息
                delete_NodeList.remove(nearestNode);
            }
        }
        //第二阶段：构建UAV航线，找出可以转移到无人机航线的节点，然后将其转移到无人机航线。
        // 遍历每个EV路径, 只为刚刚新建的EV路径构建UAV航线
        for (int index = 0; index < evRouteIndex.size(); index++) {
            EV_Route evRoute = solution.evPaths[evRouteIndex.get(index)];
            // 如果路径长度小于3，说明只有两个节点，即起点和终点，以及一个中间节点，不构建EV路线，直接跳过
            if (evRoute.route.size() <= 3) {
                continue;
            }
            ArrayList<List<Node>> uavTrips = new ArrayList<>();  // 存储当前EV路径上的UAV航线
            // 遍历EV路径上的每个客户节点
            for (int i = 1; i < evRoute.route.size() - 1; i++) { // 从第一个客户节点开始，忽略起点和终点
                Node takeoffNode = evRoute.route.get(i - 1);   // UAV本次航线的拟起飞节点
                Node landingNode = evRoute.route.get(i + 1);   // UAV本次航线的拟降落节点
                Node currentNode = evRoute.route.get(i);

                // 判断当前节点是否可以转移到UAV航线
                if (ReadData.canMoveToUAV(takeoffNode, currentNode, landingNode)) {
                    List<Node> uavTrip = new ArrayList<>();
                    uavTrip.add(takeoffNode);  // 将起飞节点添加到UAV航线
                    uavTrip.add(currentNode);  // 将当前节点添加到UAV航线
                    uavTrip.add(landingNode);  // 将降落节点添加到UAV航线

                    // 因为一次UAV航线可以为多个客户进行服务，故尝试继续添加后续的节点到当前UAV航线
                    for (int j = i + 1; j < evRoute.route.size() - 1; j++) {
                        Node nextNode = evRoute.route.get(j);
                        Node nextLandingNode = evRoute.route.get(j + 1);

                        // 判断下一个节点是否也可以转移到当前UAV航线
                        List<Node> uavTrip_judge = new ArrayList<>();
                        uavTrip_judge.addAll(uavTrip); // 复制当前UAV航线
                        uavTrip_judge.add(nextLandingNode);   // 尝试添加下一个节点

                        if (ReadData.satisfiesUAVTripConstraints(uavTrip_judge) && evRoute.route.size()!=uavTrip_judge.size() ) {  // 判断当前UAV航线是否满足约束条件，如果满足，则将下一个节点加入到当前UAV航线
                            uavTrip.add(nextLandingNode);
                        } else {
                            break; // 如果下一个节点不能加入当前UAV航线，则停止尝试
                        }
                    }

                    // 如果UAV航线有效，则将其加入到EV的UAV任务列表
                    if (!uavTrip.isEmpty()) {
                        uavTrips.add(uavTrip);
                        i += uavTrip.size() - 2;  // 更新i的值，跳过已经分配给UAV的节点
                        // 从EV路径中移除已分配给UAV的节点，不移除起飞和降落节点
                        for (int j = 1; j < uavTrip.size() - 1; j++) {
                            Node node = uavTrip.get(j);
                            evRoute.route.remove(node);
                        }
                    }
                }
            }

            // 将生成的UAV航线添加到EV路径的UAV任务列表中
            evRoute.uavTrips.addAll(uavTrips);
            Calculate_Tool.updateEVRoutesMetrics(evRoute);  // 更新EV路径的距离、能耗,路径中节点到达时间等信息
            //***************************DEBUG***************************
            for (Node node : evRoute.route) {
                int count = 0;
                for (Node node1 : evRoute.route) {
                    if (node.NodeID == node1.NodeID) {
                        count++;
                    }
                }
                if (count > 1) {
                    System.out.println("EV路径有重复元素");
                    break;
                }
            }
            // 判断UAV航程是否有误（重合元素）
            for (List<Node> uavTrip2 : evRoute.uavTrips) {
                // uavTrip2 中节点是否有重复,根据NodeID来判断
                for (Node node : uavTrip2) {
                    int count = 0;
                    for (Node node1 : uavTrip2) {
                        if (node.NodeID == node1.NodeID) {
                            count++;
                        }
                    }
                    if (count > 1) {
                        System.out.println("UAV航程有误");
                        break;
                    }
                }
                for (int k = 1; k < uavTrip2.size() - 1; k++) {
                    if (uavTrip2.get(k).NodeID ==  Parameter.NodeNumber) {
                        System.out.println("UAV航程中间节点有误");
                    }
                }
            }
            //***************************DEBUG***************************
        }
        return delete_NodeList.size();

    }

    // 判断repair后的解的结构是否合法
    public static boolean judge_solution_isfeasible(Solution solution) {
        boolean isfeasible = true;

        //**********
        ArrayList<Integer> NodeList_ID = new ArrayList<>();
        for (int i = 0; i < solution.evPaths.length; i++) {
            EV_Route evRoute = solution.evPaths[i];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }

            for (int j = 1; j < evRoute.route.size() - 1; j++) {
                NodeList_ID.add(evRoute.route.get(j).NodeID);  // 将节点ID放入列表
            }

            for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                List<Node> uavTrip = evRoute.uavTrips.get(j);
                for (int k = 1; k < uavTrip.size() - 1; k++) {
                    NodeList_ID.add(uavTrip.get(k).NodeID);
                }
            }
        }

        if (NodeList_ID.size() != Parameter.NodeNumber - 1) {
            System.out.println("节点数有误：" + NodeList_ID.size());
            Output.outputSolution(solution);
        }

        //**********
        for (EV_Route evRoute : solution.evPaths) {
            // 将EV路径中的Position重置
            for (int i = 0; i < evRoute.route.size(); i++) {
                evRoute.route.get(i).Position = i;
            }
            for (Node node : evRoute.route) {
                int count = 0;
                for (Node node1 : evRoute.route) {
                    if (node.NodeID == node1.NodeID) {
                        count++;
                    }
                }
                if (count > 1) {
                    System.out.println("EV路径有重复元素");
                    return false;
                }
            }
            // 判断UAV航程是否有误（重合元素）
            for (List<Node> uavTrip2 : evRoute.uavTrips) {
                // uavTrip2 中节点是否有重复,根据NodeID来判断
                for (Node node : uavTrip2) {
                    int count = 0;
                    for (Node node1 : uavTrip2) {
                        if (node.NodeID == node1.NodeID) {
                            count++;
                        }
                    }
                    if (count > 1) {
                        System.out.println("UAV航程有误");
                        return false;
                    }
                }
                for (int k = 1; k < uavTrip2.size() - 1; k++) {
                    if (uavTrip2.get(k).NodeID == Parameter.NodeNumber) {
                        System.out.println("UAV航程中间节点有误");
                        return false;
                    }
                }
            }
            // *****************debug******************新建uav航程交叉
            // 存储ev_route.uavTrips的起飞节点和降落节点的位置索引
            ArrayList<Integer> takeoff_index1 = new ArrayList<>();  // 记录UAV起飞点的索引
            ArrayList<Integer> landing_index1 = new ArrayList<>();  // 记录UAV降落点的索引
            ArrayList<Integer> index1 = new ArrayList<>();
            for (List<Node> uavTrip1 : evRoute.uavTrips) {
                for (int i = 0; i < uavTrip1.size(); i++) {
                    if (i == 0) {  // 对于起始节点（即起飞节点）
                        takeoff_index1.add(uavTrip1.get(i).Position);  // 记录UAV起飞点的索引
                        index1.add(uavTrip1.get(i).Position);
                    } else if (i == uavTrip1.size() - 1) {  // 对于终点（即降落节点）
                        landing_index1.add(uavTrip1.get(i).Position);  // 记录UAV降落点的索引
                        index1.add(uavTrip1.get(i).Position);
                    }
                }
            }
            // 判断是否有交叉的UAV航程,即index1是否递增
            boolean UAV_trip_cross = true;
            for (int i = 0; i < index1.size() - 1; i++) {
                if (index1.get(i) > index1.get(i + 1)) {
                    System.out.println("UAV航程重叠");
                    UAV_trip_cross = false;
                    return false;
                }
            }

        }


        return isfeasible;
    }
}
