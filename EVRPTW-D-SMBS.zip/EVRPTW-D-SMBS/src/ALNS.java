import gurobi.GRBException;

import java.util.ArrayList;
import java.util.List;

public class ALNS {

    public static void solve_ALNS() throws GRBException {

        // 起始时，置最优值为初始解的Cost,并将初始解赋值给最优解
        Parameter.Best_Solution_Value = Parameter.Local_solution.getTotalCost();
        Calculate_Tool.cloneSolution(Parameter.Best_Solution, Parameter.Local_solution);
        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）
        double T;                                // 模拟退火的温度
        double Down = 0.99;                      // 退火降温系数
        int CountSameNumber = 0;                 // 计算相同解的出现次数

        // 主迭代循环，直到达到最大迭代次数
        int Iteration = 0;                       // 迭代计数器
        while (Iteration <= Parameter.MaxIteration) {

            T = 100.0;                            // 初始化温度
            // 初始化修复算子相关参数
            for (int i = 0; i < Parameter.WRepair.length; i++) {
                Parameter.WRepair[i] = 1;
                Parameter.RepairUseTime[i] = 0;
            }
            // 初始化破坏算子相关参数
            for (int i = 0; i < Parameter.WDestroy.length; i++) {
                Parameter.WDestroy[i] = 1;
                Parameter.DestroyUseTime[i] = 0;
            }

//            if(Iteration>5){
//                // ***********************test
//                    // 在这里，考虑是否需要调整EV-UAV联合路径的使用数量
//                    if (!Parameter.suggest_use_evnum_flag) {
//                        Parameter.suggest_use_evnum_flag = true;
//                        Parameter.suggest_use_evnum = 3;
//                    }
//                    // ***********************test
//            }

            // 模拟退火循环，直到温度降低到阈值以下
            int Count = 0;                      // 内部循环计数器
            while (T > 5) {                     // 当温度降到5以下时，停止迭代

                // 自适应调整参数：Remove_NodeNumber
                //即：在迭代初期Remove_NodeNumber大，迭代后期减小
                if (T > 50) {
                    Parameter.Remove_NodeNumber = 3;
                } else if (T > 20) {
                    Parameter.Remove_NodeNumber = 2;
                } else {
                    Parameter.Remove_NodeNumber = 1;
                }

                Count++;
                // 当迭代次数超过20次后，检查当前解与新解是否相同
                if (Iteration >= 20) {      // 从第20次迭代开始，才开始记录
                    if (Calculate_Tool.CompareRoute(Parameter.Local_solution, Parameter.New_Solution)) {
                        //若解集相同，则相同计数+1
                        CountSameNumber++;
                    }
                }

                Parameter.Local_solution_Value = Parameter.Local_solution.getTotalCost();    // 记录当前解的Cost
                // 如果Parameter.Local_solution_Value的值与 5029.6003相差小于0.0001，则直接跳出循环
                if (Math.abs(Parameter.Local_solution.totalCost - 5029.6003) < 0.1) {
                    // 记录时间
                    long endtime = System.nanoTime();    //记录程序结束执行的时间
                    //输出程序运行时间 以秒为单位
                    System.out.println("程序运行时间： " + (endtime - begintime) / 1e9 + "s");
                    System.out.println("最终的最优解为：" + Parameter.Local_solution_Value);
                    Output.outputSolution(Parameter.Best_Solution);
                    System.exit(0);
                }

                if (CountSameNumber == 30) {                            // 若解30次没有发生变化，则进行强制跳出（采用随机破坏和随机插入算子并直接接受）
                    //将当前的Parameter.New_Solution清空
                    Calculate_Tool.clearSolution(Parameter.New_Solution);
                    //将原始Parameter.Local_solution克隆到Parameter.New_Solution中
                    Calculate_Tool.cloneSolution(Parameter.New_Solution, Parameter.Local_solution);
                    //清空移除节点列表
                    Parameter.Remove_NodeList.clear();

                    // 应用随机破坏和修复算子
                    Destroy.Random_Destroy(Parameter.New_Solution);
                    Repair.Random_Repair(Parameter.New_Solution);

                    if (!Calculate_Tool.CompareRoute(Parameter.Local_solution, Parameter.New_Solution)) {
                        // 若新解与当前局部最优解不同，则重新构建BSV路径,否则不用重新构建
                        BuildBSVPaths.buildBSVPathes(Parameter.New_Solution);
                        Calculate_Tool.updateSolutionMetrics(Parameter.New_Solution);  // 更新新解的各项指标
                    }

                    //直接更新结果
                    Calculate_Tool.clearSolution(Parameter.Local_solution);
                    Calculate_Tool.cloneSolution(Parameter.Local_solution, Parameter.New_Solution);
                    //计算更新后的Value
                    Parameter.New_Solution_Value = Parameter.New_Solution.getTotalCost();
                    Parameter.Local_solution_Value = Parameter.New_Solution_Value;
                    CountSameNumber = 0;                 // 重置相同解计数

                } else {      //若相同的次数不足30次
                    //将当前的Parameter.New_Solution清空
                    Calculate_Tool.clearSolution(Parameter.New_Solution);
                    //将原始Parameter.Local_solution克隆到Parameter.New_Solution中
                    Calculate_Tool.cloneSolution(Parameter.New_Solution, Parameter.Local_solution);
                    //清空移除节点列表
                    Parameter.Remove_NodeList.clear();

                    //通过轮盘赌的方式选择破坏算子和修复算子
                    ALNS.selectSol_Operators();
                    // 应用选择的破坏和修复算子
                    ALNS.destroyAndRepair();

//                    if (!Calculate_Tool.CompareRoute(Parameter.Local_solution, Parameter.New_Solution)) {  // 若新解与当前局部最优解不同，则重新构建BSV路径,否则不用重新构建BSV路径
//                        if(Parameter.Local_solution.solution_battery_change_times < Parameter.New_Solution.solution_battery_change_times){  // 另外，如果新解的预计换电次数小于当前最优解的预计换电次数，也可以考虑不用重新构建BSV路径
//                            BuildBSVPaths.buildBSVPathes(Parameter.New_Solution);
//                        }else {
//                            Parameter.New_Solution.cost_BSV = 1000000;  // 重新构建BSV路径
//                        }
//                    }


                    if (!Calculate_Tool.CompareRoute(Parameter.Local_solution, Parameter.New_Solution)) {  // 若新解与当前局部最优解不同，则重新构建BSV路径,否则不用重新构建BSV路径
                        BuildBSVPaths.buildBSVPathes(Parameter.New_Solution);
                        Calculate_Tool.updateSolutionMetrics(Parameter.New_Solution);  // 更新新解的各项指标
                    }

                    // ************test
                    Solution solution_local = new Solution();
                    Calculate_Tool.cloneSolution(solution_local, Parameter.Local_solution);
                    double local_value = Parameter.Local_solution.getTotalCost();
                    Solution solution_new = new Solution();
                    Calculate_Tool.cloneSolution(solution_new, Parameter.New_Solution);
                    double new_value = Parameter.New_Solution.getTotalCost();
                    Solution solution_best = new Solution();
                    Calculate_Tool.cloneSolution(solution_best, Parameter.Best_Solution);
                    double best_value = Parameter.Best_Solution.getTotalCost();
                    // ************test


                    //根据Metropolis准则接受解
                    acceptSolution(T);

                    // 检查solution的BSV是否有误
                    if(!Calculate_Tool.checkBSV(Parameter.Local_solution)){
                        System.out.println("BSV路径有误");
                        // 重置Parameter.Local_solution、Parameter.New_Solution、Parameter.Best_Solution
                        Calculate_Tool.clearSolution(Parameter.Local_solution);
                        Calculate_Tool.cloneSolution(Parameter.Local_solution, solution_local);
                        Calculate_Tool.clearSolution(Parameter.New_Solution);
                        Calculate_Tool.cloneSolution(Parameter.New_Solution, solution_new);
                        Calculate_Tool.clearSolution(Parameter.Best_Solution);
                        Calculate_Tool.cloneSolution(Parameter.Best_Solution, solution_best);
                        // 重置Parameter.Local_solution_Value、Parameter.New_Solution_Value、Parameter.Best_Solution_Value
                        Parameter.Local_solution_Value = local_value;
                        Parameter.New_Solution_Value = new_value;
                        Parameter.Best_Solution_Value = best_value;
                        // 重新尝试
                        acceptSolution(T);
                    }
                    Calculate_Tool.checkBSV(Parameter.New_Solution);
                    Calculate_Tool.checkBSV(Parameter.Best_Solution);

                }
                // 降低温度
                T *= Down;
            }
            Iteration++;
            // 内层循环结束后，将内层循环得到的全局最优解 置为 外层循环的当前解
            Calculate_Tool.clearSolution(Parameter.Local_solution);
            Calculate_Tool.cloneSolution(Parameter.Local_solution, Parameter.Best_Solution);
            Parameter.Best_Solution_Value = Parameter.Local_solution.getTotalCost();
            // 记录每次迭代的最优解
            Parameter.BestValueList.add(Parameter.Best_Solution_Value);
            // 打印每次迭代的最优解
            System.out.println("第" + Iteration + "次迭代的最优解为：" + Parameter.Best_Solution_Value + "   cost1:" + Parameter.Local_solution.cost_EVandUAV + "  cost2:" + Parameter.Local_solution.cost_BSV + "   cost1+cost2:" + (Parameter.Local_solution.cost_EVandUAV + Parameter.Local_solution.cost_BSV) + "  预估换电次数:" + Parameter.Local_solution.solution_battery_change_times);
            Output.outputSolution(Parameter.Local_solution);

        }
        System.out.println("最终的最优解为：" + Parameter.Best_Solution_Value);
        Output.outputSolution(Parameter.Best_Solution);
    }

    //根据Metropolis准则接受解,传入参数为：当前温度,并且更新破坏算子和修复算子的权重
    public static void acceptSolution(double T) {
        // 计算破坏-修复后的Parameter.New_Solution的Cost
        Parameter.New_Solution_Value = Parameter.New_Solution.getTotalCost();
        //首先与当前最优解比较，若破坏-修复后的新解更优，则更新当前解
        if (Parameter.New_Solution_Value < Parameter.Local_solution_Value) {
            //清空当前线路
            Calculate_Tool.clearSolution(Parameter.Local_solution);
            //更新当前路线与当前最优Cost
            Calculate_Tool.cloneSolution(Parameter.Local_solution, Parameter.New_Solution);
            Parameter.Local_solution_Value = Parameter.New_Solution_Value;

            //更新算子权重，使用一次后，权重+1.3，若新解为全局最优，则权重再+0.8
//            Parameter.WDestroy[Parameter.Destroy_Selection] += 1.3;
            Parameter.WRepair[Parameter.Repair_Selection] += 1.3;

            // 若破坏-修复后的新解比全局最优解更优，则更新全局最优解
            if (Parameter.New_Solution_Value < Parameter.Best_Solution_Value) {
                //清空最优解线路
                Calculate_Tool.clearSolution(Parameter.Best_Solution);
                //更新全局最优解线路与全局最优Cost
                Calculate_Tool.cloneSolution(Parameter.Best_Solution, Parameter.New_Solution);
                Parameter.Best_Solution_Value = Parameter.New_Solution_Value;

                //再次更新算子权重
//                Parameter.WDestroy[Parameter.Destroy_Selection] += 0.8;
                Parameter.WRepair[Parameter.Repair_Selection] += 0.8;

            }
        } else {  // 若新解与当前局部最优解相比更差，则根据Metropolis准则决定是否接受劣解
            double p = Math.exp(-(Parameter.New_Solution_Value - Parameter.Local_solution_Value) / T);
            double r = Math.random();
            if (r < p) {
                //接受劣解
                Calculate_Tool.clearSolution(Parameter.Local_solution);
                Calculate_Tool.cloneSolution(Parameter.Local_solution, Parameter.New_Solution);
                Parameter.Local_solution_Value = Parameter.New_Solution_Value;
                // 更新算子权重，接受劣解后，权重+0.5
//                Parameter.WDestroy[Parameter.Destroy_Selection] += 0.5;
                Parameter.WRepair[Parameter.Repair_Selection] += 0.5;
            } else {
                // 若不接受劣解，则维持原解，权重不变
//                Parameter.WDestroy[Parameter.Destroy_Selection] += 0;
                Parameter.WRepair[Parameter.Repair_Selection] += 0;
            }
        }

    }

    // 通过轮盘赌的方式选择破坏算子和修复算子
    public static void selectSol_Operators() {
        // 选择破坏算子
        double sumDestroy = 0;
        for (int i = 0; i < Parameter.WDestroy.length; i++) {
            sumDestroy += Parameter.WDestroy[i];
        }
        double r = Math.random() * sumDestroy;
        double tempSum = 0;
        for (int i = 0; i < Parameter.WDestroy.length; i++) {
            tempSum += Parameter.WDestroy[i];
            if (r < tempSum) {
                Parameter.Destroy_Selection = i;
                break;
            }
        }
        // 选择修复算子
        double sumRepair = 0;
        for (int i = 0; i < Parameter.WRepair.length; i++) {
            sumRepair += Parameter.WRepair[i];
        }
        r = Math.random() * sumRepair;
        tempSum = 0;
        for (int i = 0; i < Parameter.WRepair.length; i++) {
            tempSum += Parameter.WRepair[i];
            if (r < tempSum) {
                Parameter.Repair_Selection = i;
                break;
            }
        }
    }

    // 采用选中的算子进行破坏和修复
    public static void destroyAndRepair() {
        //采用选中的算子破坏Parameter.new_Solution
        if (Parameter.Destroy_Selection == 0) {
            Destroy.Random_Destroy(Parameter.New_Solution);
        } else if (Parameter.Destroy_Selection == 1) {
            Destroy.Longest_Destroy(Parameter.New_Solution);
        } else if (Parameter.Destroy_Selection == 2) {
            Destroy.Related_Destroy(Parameter.New_Solution);
        } else if (Parameter.Destroy_Selection == 3) {
            Destroy.Cluster_Destroy(Parameter.New_Solution);
        }
        Parameter.DestroyUseTime[Parameter.Destroy_Selection] += 1;     //次数+1
        Destroy.check_destroyed_solution_isfeasible(Parameter.New_Solution);  // 判断新解是否满足约束条件

        //采用选中的算子修复Parameter.new_Solution
        if (Parameter.Repair_Selection == 0) {
            Repair.Random_Repair(Parameter.New_Solution);
        } else if (Parameter.Repair_Selection == 1) {
            Repair.Greedy_Repair(Parameter.New_Solution);
        } else if (Parameter.Repair_Selection == 2) {
            Repair.EVGreedy_Repair(Parameter.New_Solution);
        } else if (Parameter.Repair_Selection == 3) {
            Repair.Regret_Repair(Parameter.New_Solution);
        }
        Parameter.RepairUseTime[Parameter.Repair_Selection] += 1;       //次数+1
        Repair.judge_solution_isfeasible(Parameter.New_Solution);  // 判断新解是否满足约束条件
    }

    // 检查当前的EV-UAV联合路径 与 BSV路径是否 存在可调整的可能性
    public static boolean checkJudgePossibility(Solution solution) {
        // 计算已用的EV-UAV路径有多少
        int count_ev_uav = 0;
        for (int i = 0; i < solution.evPaths.length; i++) {
            if (solution.evPaths[i].route.size() > 2) {
                count_ev_uav++;
            }
        }
        // 计算已用的BSV路径有多少，以及换电节点的数量
        int count_bsv = 0;
        int count_bsv_node = 0;
        for (int i = 0; i < solution.bsvPaths.length; i++) {
            if (solution.bsvPaths[i].route.size() > 2) {
                count_bsv++;
                count_bsv_node += solution.bsvPaths[i].route.size() - 2;  // 换电节点数量,不包括起点和终点
            }
        }

        // 若EV-UAV路径数量小于等于BSV路径数量，则可以考虑调整，建议增加EV-UAV路径
        if (count_ev_uav <= count_bsv && count_ev_uav < Parameter.EVNumber) {
            Parameter.suggest_use_evnum = count_ev_uav + 1;
            Parameter.suggest_use_evnum_flag = true;
            return true;
        }
//        // 若换电节点数量小于等于所用BSV车辆数-1 辆车所能携带的电池数量，则可以考虑调整，这说明当前的EV路径中的节点顺序不合理或者更合理的换电节点在UAV行程中
//        if (count_bsv_node <= (count_bsv - 1) * Parameter.BSVCapacity) {
//            return true;
//        }

        return true;
    }
}