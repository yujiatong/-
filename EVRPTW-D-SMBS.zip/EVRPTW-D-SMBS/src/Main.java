import gurobi.GRBException;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");


        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test1";                    //输入想要测试的文件名称
        String name = "c101";                    //输入想要测试的文件名称
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵
        ReadData.Generate_Initial_Solution();                                 //生成初始解路线集 ，在满足绝对容量要求、（但可能会违反时间窗约束）
//       BuildBSVPaths.buildBSVPathes(Parameter.Local_solution);                //为初始解路线生成移动换电车的路径
        //算法实现

        System.out.println("Total Cost: " + Parameter.Local_solution.getTotalCost());
        ALNS.solve_ALNS();

        // 记录时间
        long endtime = System.nanoTime();    //记录程序结束执行的时间
        //输出程序运行时间 以秒为单位
        System.out.println("程序运行时间： " + (endtime - begintime) / 1e9 + "s");

        System.out.println("bye world!");


    }
}