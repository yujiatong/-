import java.util.ArrayList;
import java.util.List;

public class Destroy {

    // 1、随机破坏算子，顾名思义，随机选取n个节点进行破坏（将选中的节点从线路中删除）：这里的n为Parameter.Remove_NodeNumber
    public static void Random_Destroy(Solution solution) {
        // *********************
        Solution solution_copy = new Solution();
        Calculate_Tool.cloneSolution(solution_copy, solution);
        ArrayList<Integer> NodeList_ID1 = new ArrayList<>();
        for (int i = 0; i < solution_copy.evPaths.length; i++) {
            EV_Route evRoute = solution_copy.evPaths[i];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }

            for (int j = 1; j < evRoute.route.size() - 1; j++) {
                NodeList_ID1.add(evRoute.route.get(j).NodeID);  // 将节点ID放入列表
            }

            for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                List<Node> uavTrip = evRoute.uavTrips.get(j);
                for (int k = 1; k < uavTrip.size() - 1; k++) {
                    NodeList_ID1.add(uavTrip.get(k).NodeID);
                }
            }
        }

        if (NodeList_ID1.size() != Parameter.NodeNumber - 1) {
            System.out.println("pre_destory---节点数：" + NodeList_ID1.size());
        }
        // *********************
        //*************************** debug
        for (EV_Route ev_route : solution.evPaths) {
            for (int m = 0; m < ev_route.route.size(); m++) {
                ev_route.route.get(m).Position = m;
            }

            // 判断UAV航程是否有误（重合元素）
            for (List<Node> uavTrip2 : ev_route.uavTrips) {
                // uavTrip2 中节点是否有重复,根据NodeID来判断
                for (Node node : uavTrip2) {
                    int count = 0;
                    for (Node node1 : uavTrip2) {
                        if (node.NodeID == node1.NodeID) {
                            count++;
                        }
                    }
                    if (count > 1) {
                        System.out.println("UAV航程中有重复元素");
                        break;
                    }
                }
            }

            ArrayList<Integer> start_position_list = new ArrayList<>();
            for (List<Node> uavtrip : ev_route.uavTrips) {
                Node start = uavtrip.get(0);
                start_position_list.add(start.Position);
                boolean flag_start_in_evroute = false;
                Node end = uavtrip.get(uavtrip.size() - 1);
                boolean flag_end_in_evroute = false;
                for (Node node : ev_route.route) {
                    if (node.NodeID == start.NodeID) {
                        flag_start_in_evroute = true;
                    }
                    if (node.NodeID == end.NodeID) {
                        flag_end_in_evroute = true;
                    }
                }
                // 如果起点或终点不在EV路径中，则跳出循环
                if (!flag_start_in_evroute) {
                    System.out.println("起点不在EV路径中");
                }
                if (!flag_end_in_evroute) {
                    System.out.println("终点不在EV路径中");
                }
            }
            //如果start_position_list不是从小到大排列，则输出
            for (int i = 0; i < start_position_list.size() - 1; i++) {
                if (start_position_list.get(i) > start_position_list.get(i + 1)) {
                    System.out.println("UAV航程的起点没有按照从小到大排列");
                }
            }
        }
        //*************************** debug

        // 更新解
        Calculate_Tool.updateSolutionMetrics(solution);

        // 清空以前的移除节点列表
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            Parameter.Remove_NodeList.remove(i);
        }

        // 用于存放随机选中的节点
        Node[] random_select_Node = new Node[Parameter.Remove_NodeNumber];
        // 随机选取n个节点
        for (int i = 0; i < random_select_Node.length; i++) {
            int index = Calculate_Tool.IntRandom(1, Parameter.NodeNumber);  // 随机选取一个节点的ID
            random_select_Node[i] = Parameter.All_NodeList[index];  // 将选中的节点存入数组中
            // 若该节点已经被选中，则重新选取
            for (int j = 0; j < i; j++) {
                if (index == random_select_Node[j].NodeID) {
                    i--;
                    break;
                }
            }
        }

        // 遍历所有线路，找到随机编号节点的具体线路，具体线路中的位置，然后移除
        for (int i = 0; i < random_select_Node.length; i++) {
            for (int ev_route_index = 0; ev_route_index < solution.evPaths.length; ev_route_index++) {
                // 遍历EV路线中的所有节点
                for (int j = 1; j < solution.evPaths[ev_route_index].route.size() - 1; j++) {  // 不包括起点和终点
                    if (random_select_Node[i].NodeID == solution.evPaths[ev_route_index].route.get(j).NodeID) {
                        // 在指定的ev线路中移除选定节点
                        Destroy.Remove_EVNode(solution.evPaths[ev_route_index], j, random_select_Node[i]);
                        break;
                    }
                }
                // 遍历EV路线所属的UAV航程的所有节点
                for (int m = 0; m < solution.evPaths[ev_route_index].uavTrips.size(); m++) {
                    for (int n = 1; n < solution.evPaths[ev_route_index].uavTrips.get(m).size() - 1; n++) { // 不包括航程的起点和终点
                        if (random_select_Node[i].NodeID == solution.evPaths[ev_route_index].uavTrips.get(m).get(n).NodeID) {
                            // 在指定的UAV航程中移除选定节点
                            Destroy.Remove_UAVNode(solution.evPaths[ev_route_index], m, n, random_select_Node[i]);
                            break;
                        }
                    }
                }
            }

        }

        // 如果EV路径中只有一个服务客户，并且这个客户已经被移除，那么相对应的UAV行程也会被删除（即起点为仓库，终点为虚拟仓库的UAV行程），即：未被启用的EV不能支持UAV
        for (EV_Route evRoute : solution.evPaths) {
            if (evRoute.route.size() == 2) {
                for (int i = 0; i < evRoute.uavTrips.size(); i++) {
                    // 将移除的无人机行程的节点放入移除节点列表
                    for (int j = 1; j < evRoute.uavTrips.get(i).size() - 1; j++) {
                        Parameter.Remove_NodeList.add(evRoute.uavTrips.get(i).get(j));
                        // *********************
                        if (Parameter.Remove_NodeList.get(Parameter.Remove_NodeList.size() - 1).NodeID ==  Parameter.NodeNumber) {
                            System.out.println("remove 11");
                        }
                        // *********************
                    }
                    evRoute.uavTrips.remove(i);
                    i--;   // 移除一个元素后，需要将i减1
                }
            }
        }


        //**********
        ArrayList<Integer> NodeList_ID = new ArrayList<>();
        for (int i = 0; i < solution.evPaths.length; i++) {
            EV_Route evRoute = solution.evPaths[i];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }

            for (int j = 1; j < evRoute.route.size() - 1; j++) {
                NodeList_ID.add(evRoute.route.get(j).NodeID);  // 将节点ID放入列表
            }

            for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                List<Node> uavTrip = evRoute.uavTrips.get(j);
                for (int k = 1; k < uavTrip.size() - 1; k++) {
                    NodeList_ID.add(uavTrip.get(k).NodeID);
                }
            }
        }

        if (NodeList_ID.size() + Parameter.Remove_NodeList.size() != Parameter.NodeNumber - 1) {
            System.out.println("destory---节点数：" + NodeList_ID.size());
            Output.outputSolution(solution);
        }

        //**********
        //*************************** debug
        for (EV_Route ev_route : solution.evPaths) {
            for (int m = 0; m < ev_route.route.size(); m++) {
                ev_route.route.get(m).Position = m;
            }

            ArrayList<Integer> start_position_list = new ArrayList<>();
            for (List<Node> uavtrip : ev_route.uavTrips) {
                Node start = uavtrip.get(0);
                start_position_list.add(start.Position);
                boolean flag_start_in_evroute = false;
                Node end = uavtrip.get(uavtrip.size() - 1);
                boolean flag_end_in_evroute = false;
                for (Node node : ev_route.route) {
                    if (node.NodeID == start.NodeID) {
                        flag_start_in_evroute = true;
                    }
                    if (node.NodeID == end.NodeID) {
                        flag_end_in_evroute = true;
                    }
                }
                // 如果起点或终点不在EV路径中，则跳出循环
                if (!flag_start_in_evroute) {
                    System.out.println("起点不在EV路径中");
                }
                if (!flag_end_in_evroute) {
                    System.out.println("终点不在EV路径中");
                }
            }
            //如果start_position_list不是从小到大排列，则输出
            for (int i = 0; i < start_position_list.size() - 1; i++) {
                if (start_position_list.get(i) > start_position_list.get(i + 1)) {
                    System.out.println("UAV航程的起点没有按照从小到大排列");
                }
            }
        }
        //***************************


    }
    // 2、卡车路径最坏点破坏算子，以移除客户点所带来的距离节省值为衡量标准
    // 首先，计算卡车路径中的所有客户的距离节省值，然后按照距离节省值从大到小的顺序进行移除
    public static void Longest_Destroy(Solution solution) {
        // 清空以前的移除节点列表
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            Parameter.Remove_NodeList.remove(i);
        }
        // 存储所有的节点
        ArrayList<Node> NodeList = new ArrayList<>();
        for (int i = 1; i < Parameter.NodeNumber; i++) {
            NodeList.add(Parameter.All_NodeList[i]);
        }
        ArrayList<Node> temp_NodeList= new ArrayList<>(); // 存储暂时的移除节点列表，因为后续将节点从soluton中移除时，还需要根据解的情况判断是否需要移除相应的UAV行程

        // 计算卡车路径中的所有客户的距离节省值 l_ij + l_jk - l_ik
        // 创建一个临时的节点列表，用于存储所有的卡车路径中的节点
        ArrayList<Node> temp_EVnodelist = new ArrayList<>();
        ArrayList<Double> temp_distance_save = new ArrayList<>();
        //遍历卡车路径
        for (int ev_route_index = 0; ev_route_index < solution.evPaths.length; ev_route_index++) {
            EV_Route evRoute = solution.evPaths[ev_route_index];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }
            // 遍历EV路线中的所有节点,计算距离节省值
            for (int j = 1; j < evRoute.route.size() - 1; j++) {  // 不包括起点和终点
                Node node_i = evRoute.route.get(j - 1);
                Node node_j = evRoute.route.get(j);
                Node node_k = evRoute.route.get(j + 1);
                double distance_ij = Parameter.DisMatrix[node_i.NodeID][node_j.NodeID];
                double distance_jk = Parameter.DisMatrix[node_j.NodeID][node_k.NodeID];
                double distance_ik = Parameter.DisMatrix[node_i.NodeID][node_k.NodeID];
                double distance_save = distance_ij + distance_jk - distance_ik;
                temp_EVnodelist.add(node_j);
                temp_distance_save.add(distance_save);
            }
        }
        // 按照距离节省值从大到小的顺序进行移除
        while (temp_NodeList.size() < Parameter.Remove_NodeNumber && temp_EVnodelist.size() > 0) {
            double max_distance_save = 0;
            Node max_distance_save_node = null;
            for (int i = 0; i < temp_EVnodelist.size(); i++) {
                if (temp_distance_save.get(i) > max_distance_save) {
                    max_distance_save = temp_distance_save.get(i);
                    max_distance_save_node = temp_EVnodelist.get(i);
                }
            }
            // 移除距离节省值最大的客户
            if(max_distance_save_node != null){
                temp_NodeList.add(max_distance_save_node);  // 将选定的节点放入暂时的移除节点列表
                temp_EVnodelist.remove(max_distance_save_node);  // 从剩余节点中移除选定的节点
            }
        }

        // 遍历所有线路，找到待移除节点的具体线路，具体线路中的位置，然后移除
        for (Node node : temp_NodeList) {
            removeNodeInSolution(solution, node);
        }
    }

    // 3、相关破坏算子。
    // 1. 随机选取一个节点进行破坏
    // 2. 计算该客户与剩余客户之间的关联度 𝑆(𝑖,𝑗)
    // 3. 从剩余客户中移除与选定节点关联度最大的节点
    public static void Related_Destroy(Solution solution){
        // 清空以前的移除节点列表
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            Parameter.Remove_NodeList.remove(i);
        }
        // 存储所有的节点
        ArrayList<Node> NodeList = new ArrayList<>();
        for (int i = 1; i < Parameter.NodeNumber; i++) {
            NodeList.add(Parameter.All_NodeList[i]);
        }
        ArrayList<Node> temp_NodeList= new ArrayList<>(); // 存储暂时的移除节点列表，因为后续将节点从soluton中移除时，还需要根据解的情况判断是否需要移除相应的UAV行程

        // 随机选择一个客户作为初始客户
        int random_index = Calculate_Tool.IntRandom(1, Parameter.NodeNumber);
        Node select_remove_node = Parameter.All_NodeList[random_index];
        temp_NodeList.add(select_remove_node);   // 将选定的节点放入暂时的移除节点列表
        NodeList.remove(select_remove_node);  // 从剩余节点中移除选定的节点

        // 不断移除相似度最高的客户，直到达到目标数量
        while (temp_NodeList.size() < Parameter.Remove_NodeNumber && NodeList.size() > 0) {
            // 计算该客户与剩余客户之间的相似度 𝑆(𝑖,𝑗)
            Node last_remove_node = temp_NodeList.get(temp_NodeList.size() - 1);
            double max_similarity = 0;
            Node max_similarity_node = null;
            for (Node node : NodeList) {
                double similarity = calculateSimilarity(last_remove_node, node);
                if (similarity > max_similarity) {
                    max_similarity = similarity;
                    max_similarity_node = node;
                }
            }
            // 移除最相似的客户
            if(max_similarity_node != null){
                temp_NodeList.add(max_similarity_node);  // 将选定的节点放入暂时的移除节点列表
                NodeList.remove(max_similarity_node);  // 从剩余节点中移除选定的节点
            }
        }

        // 遍历所有线路，找到待移除节点的具体线路，具体线路中的位置，然后移除
        for (Node node : temp_NodeList) {
            removeNodeInSolution(solution, node);
        }

    }
    // 4、集群破坏算子
    // 首先随机选择一个客户，然后以选中的客户为圆心画一个半径𝑟的圆圈，在圆圈内随机移除一个客户，其他步骤与随机破坏算子操作相同。
    public static void Cluster_Destroy(Solution solution) {
        // 清空以前的移除节点列表
        for (int i = 0; i < Parameter.Remove_NodeList.size(); i++) {
            Parameter.Remove_NodeList.remove(i);
        }
        // 存储所有的节点
        ArrayList<Node> NodeList = new ArrayList<>();
        for (int i = 1; i < Parameter.NodeNumber; i++) {
            NodeList.add(Parameter.All_NodeList[i]);
        }
        ArrayList<Node> temp_NodeList= new ArrayList<>(); // 存储暂时的移除节点列表，因为后续将节点从soluton中移除时，还需要根据解的情况判断是否需要移除相应的UAV行程

        // 随机选择一个客户作为初始客户
        int random_index = Calculate_Tool.IntRandom(1, Parameter.NodeNumber);
        Node select_remove_node = Parameter.All_NodeList[random_index];
        temp_NodeList.add(select_remove_node);   // 将选定的节点放入暂时的移除节点列表
        NodeList.remove(select_remove_node);  // 从剩余节点中移除选定的节点

        // 不断移除集群中的客户，直到达到目标数量
        while (temp_NodeList.size() < Parameter.Remove_NodeNumber && NodeList.size() > 0) {
            Node last_remove_node = temp_NodeList.get(temp_NodeList.size() - 1);
            // 以选中的客户为圆心画一个半径𝑟的圆圈，在圆圈内随机移除一个客户
            // 选取半径r,这里取最大距离的1/3
            double r = 0;
            for (int i = 1; i < Parameter.NodeNumber; i++) {
                double distance = Math.sqrt(Math.pow(last_remove_node.x - Parameter.All_NodeList[i].x, 2) + Math.pow(last_remove_node.y - Parameter.All_NodeList[i].y, 2));
                if (distance > r) {
                    r = distance;
                }
            }
            r = r / 3;
            ArrayList<Node> cluster_node = new ArrayList<>();
            for (Node node : NodeList) {
                double distance = Math.sqrt(Math.pow(last_remove_node.x - node.x, 2) + Math.pow(last_remove_node.y - node.y, 2));
                if (distance <= r) {
                    cluster_node.add(node);
                }
            }
            // 如果集群中没有节点,则选择离选中节点最近的节点
            if (cluster_node.size() == 0) {
                double min_distance = 1000000;
                Node min_distance_node = null;
                for (Node node : NodeList) {
                    double distance = Math.sqrt(Math.pow(last_remove_node.x - node.x, 2) + Math.pow(last_remove_node.y - node.y, 2));
                    if (distance < min_distance) {
                        min_distance = distance;
                        min_distance_node = node;
                    }
                }
                cluster_node.add(min_distance_node);
            }
            // 随机选取一个节点
            int index = Calculate_Tool.IntRandom(0, cluster_node.size());
            Node temp_node = cluster_node.get(index);
            temp_NodeList.add(temp_node);  // 将选定的节点放入暂时的移除节点列表
            NodeList.remove(temp_node);  // 从剩余节点中移除选定的节点
        }

        // 遍历所有线路，找到待移除节点的具体线路，具体线路中的位置，然后移除
        for (Node node : temp_NodeList) {
            removeNodeInSolution(solution, node);
        }
    }

    public static double calculateSimilarity(Node select_remove_node, Node node){
        // 计算归一化系数,节点间的最大距离，节点间的最大需求量之差、节点间的最大时间窗开始时间之差、节点间的最大时间窗结束时间之差
        double max_distance = 0;
        double max_demand_diff = 0;
        double max_readyTime_diff = 0;
        double max_dueTime_diff = 0;
        for (int i = 1; i < Parameter.NodeNumber; i++) {
            for (int j = 1; j < Parameter.NodeNumber; j++) {
                if (i != j) {
                    double distance = Math.sqrt(Math.pow(Parameter.All_NodeList[i].x - Parameter.All_NodeList[j].x, 2) + Math.pow(Parameter.All_NodeList[i].y - Parameter.All_NodeList[j].y, 2));
                    double demand_diff = Math.abs(Parameter.All_NodeList[i].Demand - Parameter.All_NodeList[j].Demand);
                    double readyTime_diff = Math.abs(Parameter.All_NodeList[i].ReadyTime - Parameter.All_NodeList[j].ReadyTime);
                    double dueTime_diff = Math.abs(Parameter.All_NodeList[i].DueTime - Parameter.All_NodeList[j].DueTime);
                    if (distance > max_distance) {
                        max_distance = distance;
                    }
                    if (demand_diff > max_demand_diff) {
                        max_demand_diff = demand_diff;
                    }
                    if (readyTime_diff > max_readyTime_diff) {
                        max_readyTime_diff = readyTime_diff;
                    }
                    if (dueTime_diff > max_dueTime_diff) {
                        max_dueTime_diff = dueTime_diff;
                    }
                }
            }
        }
        // 计算节点间的相似度
        double distance = Math.sqrt(Math.pow(select_remove_node.x - node.x, 2) + Math.pow(select_remove_node.y - node.y, 2));
        double demand_diff = Math.abs(select_remove_node.Demand - node.Demand);
        double readyTime_diff = Math.abs(select_remove_node.ReadyTime - node.ReadyTime);
        double dueTime_diff = Math.abs(select_remove_node.DueTime - node.DueTime);

        // 四种属性的权重
        double w1 = 0.25;
        double w2 = 0.25;
        double w3 = 0.25;
        double w4 = 0.25;

        double similarity = ( w1 * distance / max_distance) +  (w2 * demand_diff / max_demand_diff) +  (w3 * readyTime_diff / max_readyTime_diff) +  (w4 * dueTime_diff / max_dueTime_diff) ;
        // 1 - similarity，使得相似度越大，值越大
        similarity = 1 - similarity;

        return similarity;
    }

    // 在solution中移除指定的节点
    public static void removeNodeInSolution(Solution solution, Node node){
        // 遍历所有线路，找到随机编号节点的具体线路，具体线路中的位置，然后移除
        boolean flag = false;  // 用于判断是否找到指定的节点
        for (int ev_route_index = 0; ev_route_index < solution.evPaths.length; ev_route_index++) {
            // 遍历EV路线中的所有节点
            for (int j = 1; j < solution.evPaths[ev_route_index].route.size() - 1; j++) {  // 不包括起点和终点
                if (node.NodeID == solution.evPaths[ev_route_index].route.get(j).NodeID) {
                    // 在指定的ev线路中移除选定节点
                    Destroy.Remove_EVNode(solution.evPaths[ev_route_index], j, node);
                    flag = true;
                    break;
                }
            }
            if (flag) {
                break;
            }
            // 遍历EV路线所属的UAV航程的所有节点
            for (int m = 0; m < solution.evPaths[ev_route_index].uavTrips.size(); m++) {
                for (int n = 1; n < solution.evPaths[ev_route_index].uavTrips.get(m).size() - 1; n++) { // 不包括航程的起点和终点
                    if (node.NodeID == solution.evPaths[ev_route_index].uavTrips.get(m).get(n).NodeID) {
                        // 在指定的UAV航程中移除选定节点
                        Destroy.Remove_UAVNode(solution.evPaths[ev_route_index], m, n, node);
                        flag = true;
                        break;
                    }
                }
            }
            if (flag) {
                break;
            }
        }
        // 如果EV路径中只有一个服务客户，并且这个客户已经被移除，那么相对应的UAV行程也会被删除（即起点为仓库，终点为虚拟仓库的UAV行程），即：未被启用的EV不能支持UAV
        for (EV_Route evRoute : solution.evPaths) {
            if (evRoute.route.size() == 2) {
                for (int i = 0; i < evRoute.uavTrips.size(); i++) {
                    // 将移除的无人机行程的节点放入移除节点列表
                    for (int j = 1; j < evRoute.uavTrips.get(i).size() - 1; j++) {
                        Parameter.Remove_NodeList.add(evRoute.uavTrips.get(i).get(j));
                    }
                    evRoute.uavTrips.remove(i);
                }
            }
        }
    }

    // 在指定ev线路中移除选定的EV节点
    public static void Remove_EVNode(EV_Route evRoute, int Position_index, Node select_remove_node) {
        // 在指定ev线路中移除选定节点
        evRoute.route.remove(Position_index);
        Parameter.Remove_NodeList.add(select_remove_node);  // 将移除的节点放入移除节点列表
        // *********************
        if (Parameter.Remove_NodeList.get(Parameter.Remove_NodeList.size() - 1).NodeID ==  Parameter.NodeNumber) {
            System.out.println("remove 11");
        }
        // *********************
        // 如果移除的节点是无人机启动或取回操作的客户，则移除相应的无人机行程
        if (select_remove_node.UAV_takeoff_from_here) {
            for (int i = 0; i < evRoute.uavTrips.size(); i++) {
                if (evRoute.uavTrips.get(i).get(0).NodeID == select_remove_node.NodeID) {
                    // 将移除的无人机行程的节点放入移除节点列表
                    for (int j = 1; j < evRoute.uavTrips.get(i).size() - 1; j++) {
                        Parameter.Remove_NodeList.add(evRoute.uavTrips.get(i).get(j));
                        // *********************
                        if (Parameter.Remove_NodeList.get(Parameter.Remove_NodeList.size() - 1).NodeID ==  Parameter.NodeNumber) {
                            System.out.println("remove 11");
                        }
                        // *********************
                    }
                    evRoute.uavTrips.remove(i); // 移除无人机行程
                    break;
                }
            }
        }

        if (select_remove_node.UAV_landing_to_here) {
            for (int i = 0; i < evRoute.uavTrips.size(); i++) {
                if (evRoute.uavTrips.get(i).get(evRoute.uavTrips.get(i).size() - 1).NodeID == select_remove_node.NodeID) {
                    // 将移除的无人机行程的节点放入移除节点列表
                    for (int j = 1; j < evRoute.uavTrips.get(i).size() - 1; j++) {
                        Parameter.Remove_NodeList.add(evRoute.uavTrips.get(i).get(j));
                        // *********************
                        if (Parameter.Remove_NodeList.get(Parameter.Remove_NodeList.size() - 1).NodeID ==  Parameter.NodeNumber) {
                            System.out.println("remove 11");
                        }
                        // *********************
                    }
                    evRoute.uavTrips.remove(i);
                    break;
                }
            }
        }

    }


    // 在指定的UAV航程中移除选定节点
    public static void Remove_UAVNode(EV_Route evRoute, int uavtrip_index, int position_index, Node select_remove_node) {
        // 在指定的UAV航程中移除选定节点
        evRoute.uavTrips.get(uavtrip_index).remove(position_index);
        Parameter.Remove_NodeList.add(select_remove_node);  // 将移除的节点放入移除节点列表
        // *********************
        if (Parameter.Remove_NodeList.get(Parameter.Remove_NodeList.size() - 1).NodeID ==  Parameter.NodeNumber) {
            System.out.println("remove 11");
        }
        // *********************

        // 如果行程中只有一个服务客户，并且这个客户已经被移除，那么这个行程也会被删除。
        if (evRoute.uavTrips.get(uavtrip_index).size() == 2) {
            evRoute.uavTrips.remove(uavtrip_index);
        }

    }

    // 判断破坏后的解是否合法
    public static boolean check_destroyed_solution_isfeasible(Solution solution){
        boolean flag = true;
        //**********
        ArrayList<Integer> NodeList_ID = new ArrayList<>();
        for (int i = 0; i < solution.evPaths.length; i++) {
            EV_Route evRoute = solution.evPaths[i];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }

            for (int j = 1; j < evRoute.route.size() - 1; j++) {
                NodeList_ID.add(evRoute.route.get(j).NodeID);  // 将节点ID放入列表
            }

            for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                List<Node> uavTrip = evRoute.uavTrips.get(j);
                for (int k = 1; k < uavTrip.size() - 1; k++) {
                    NodeList_ID.add(uavTrip.get(k).NodeID);
                }
            }
        }

        if (NodeList_ID.size() + Parameter.Remove_NodeList.size() != Parameter.NodeNumber - 1) {
            System.out.println("destory---节点数：" + NodeList_ID.size());
            Output.outputSolution(solution);
            return false;
        }

        //**********
        return flag;
    }

}
