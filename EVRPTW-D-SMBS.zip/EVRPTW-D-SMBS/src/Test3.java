import gurobi.GRBException;

import java.util.ArrayList;
import java.util.List;

public class Test3 {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");


        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test2";                    //输入想要测试的文件名称
        String name = "c201";
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵


        Solution solution_build = new Solution();
        ArrayList<Node> route1 = new ArrayList<>();
        route1.add(Parameter.All_NodeList[0]);
        route1.add(Parameter.All_NodeList[5]);
        route1.add(Parameter.All_NodeList[2]);
        route1.add(Parameter.All_NodeList[6]);
        route1.add(Parameter.All_NodeList[8]);
        route1.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[0].route = route1;
        ArrayList<List<Node>> uavTrips = new ArrayList<>();
        List<Node> uavTrip1 = new ArrayList<>();
        uavTrip1.add(Parameter.All_NodeList[2]);
        uavTrip1.add(Parameter.All_NodeList[3]);
        uavTrip1.add(Parameter.All_NodeList[8]);
        uavTrips.add(uavTrip1);
        solution_build.evPaths[0].uavTrips = uavTrips;

        ArrayList<Node> route2 = new ArrayList<>();
        route2.add(Parameter.All_NodeList[0]);
        route2.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[1].route = route2;


        ArrayList<Node> route3 = new ArrayList<>();
        route3.add(Parameter.All_NodeList[0]);
        route3.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[2].route = route3;

        ArrayList<Node> route4 = new ArrayList<>();
        route4.add(Parameter.All_NodeList[0]);
        route4.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[3].route = route4;

        ArrayList<Node> route5 = new ArrayList<>();
        route5.add(Parameter.All_NodeList[0]);
        route5.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[4].route = route5;

        ArrayList<Node> bsvroute1 = new ArrayList<>();
        solution_build.bsvPaths[0].route = bsvroute1;

        ArrayList<Node> bsvroute2 = new ArrayList<>();
        solution_build.bsvPaths[1].route = bsvroute2;

        ArrayList<Node> bsvroute3 = new ArrayList<>();
        solution_build.bsvPaths[2].route = bsvroute3;

        Solution solution_new = new Solution();
        // 克隆当前解
        Calculate_Tool.cloneSolution( solution_new,solution_build);

        ArrayList<Node> delete_NodeList_new = new ArrayList<>();
        delete_NodeList_new.add(Parameter.All_NodeList[9]);
        delete_NodeList_new.add(Parameter.All_NodeList[1]);
        delete_NodeList_new.add(Parameter.All_NodeList[7]);
        delete_NodeList_new.add(Parameter.All_NodeList[10]);
        delete_NodeList_new.add(Parameter.All_NodeList[4]);

        // 如果删除列表中存在客户，则将为删除列表中的这些客户建立新的EV-UAV-BSV路线
        if (delete_NodeList_new.size() > 0) {
            double nodenum = Repair.Generate_routes(solution_new, delete_NodeList_new);
            if (nodenum > 0) {
                System.out.println("插入失败的节点数：" + nodenum);
            }
        }


        System.out.println("bye world!");

    }
}
