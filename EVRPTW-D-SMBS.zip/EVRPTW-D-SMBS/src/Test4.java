import gurobi.GRBException;

import java.util.ArrayList;
import java.util.List;

public class Test4 {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");


        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test2";                    //输入想要测试的文件名称
        String name = "r201";
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵

        // 手动构建一个解
        //ev1 Route- 0
        // 0 - 3 - 10 - 11
        //#ev1_uavtrip1  0 - 7 - 3
        //ev1_uavtrip2  3 - 9  - 10

        //ev2 Route- 1
        //0 - 4 - 11
        //ev2_uavtrip1  0 - 1- 11

        //ev3 Route- 2
        //0 - 5 - 6 - 11
        //ev3_uavtrip1  0 - 2- 5
        //ev3_uavtrip2  5 - 8 - 11
        //
        //BSV Route- 0
        //0 - 3 - 10 - 11

        // 初始化解

        Solution solution_build = new Solution();
        ArrayList<Node> route1 = new ArrayList<>();
        route1.add(Parameter.All_NodeList[0]);
        route1.add(Parameter.All_NodeList[3]);
        route1.add(Parameter.All_NodeList[10]);
        route1.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[0].route = route1;
        ArrayList<List<Node>> uavTrips = new ArrayList<>();
        List<Node> uavTrip1 = new ArrayList<>();
        uavTrip1.add(Parameter.All_NodeList[0]);
        uavTrip1.add(Parameter.All_NodeList[7]);
        uavTrip1.add(Parameter.All_NodeList[3]);
        uavTrips.add(uavTrip1);
        List<Node> uavTrip2 = new ArrayList<>();
        uavTrip2.add(Parameter.All_NodeList[3]);
        uavTrip2.add(Parameter.All_NodeList[9]);
        uavTrip2.add(Parameter.All_NodeList[10]);
        uavTrips.add(uavTrip2);
        solution_build.evPaths[0].uavTrips = uavTrips;

        ArrayList<Node> route2 = new ArrayList<>();
        route2.add(Parameter.All_NodeList[0]);
        route2.add(Parameter.All_NodeList[4]);
        route2.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[1].route = route2;
        ArrayList<List<Node>> uavTrips2 = new ArrayList<>();
        List<Node> uavTrip2_1 = new ArrayList<>();
        uavTrip2_1.add(Parameter.All_NodeList[0]);
        uavTrip2_1.add(Parameter.All_NodeList[1]);
        uavTrip2_1.add(Parameter.All_NodeList[11]);
        uavTrips2.add(uavTrip2_1);
        solution_build.evPaths[1].uavTrips = uavTrips2;

        ArrayList<Node> route3 = new ArrayList<>();
        route3.add(Parameter.All_NodeList[0]);
        route3.add(Parameter.All_NodeList[5]);
        route3.add(Parameter.All_NodeList[6]);
        route3.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[2].route = route3;
        ArrayList<List<Node>> uavTrips3 = new ArrayList<>();
        List<Node> uavTrip3_1 = new ArrayList<>();
        uavTrip3_1.add(Parameter.All_NodeList[0]);
        uavTrip3_1.add(Parameter.All_NodeList[2]);
        uavTrip3_1.add(Parameter.All_NodeList[5]);
        uavTrips3.add(uavTrip3_1);
        List<Node> uavTrip3_2 = new ArrayList<>();
        uavTrip3_2.add(Parameter.All_NodeList[5]);
        uavTrip3_2.add(Parameter.All_NodeList[8]);
        uavTrip3_2.add(Parameter.All_NodeList[11]);
        uavTrips3.add(uavTrip3_2);
        solution_build.evPaths[2].uavTrips = uavTrips3;

        ArrayList<Node> route4 = new ArrayList<>();
        route4.add(Parameter.All_NodeList[0]);
        route4.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[3].route = route4;

        ArrayList<Node> route5 = new ArrayList<>();
        route5.add(Parameter.All_NodeList[0]);
        route5.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[4].route = route5;

        ArrayList<Node> bsvroute1 = new ArrayList<>();
        bsvroute1.add(Parameter.All_NodeList[0]);
        bsvroute1.add(Parameter.All_NodeList[3]);
        bsvroute1.add(Parameter.All_NodeList[10]);
        bsvroute1.add(Parameter.All_NodeList[11]);
        solution_build.bsvPaths[0].route = bsvroute1;

        ArrayList<Node> bsvroute2 = new ArrayList<>();
        solution_build.bsvPaths[1].route = bsvroute2;

        ArrayList<Node> bsvroute3 = new ArrayList<>();
        solution_build.bsvPaths[2].route = bsvroute3;


        Calculate_Tool.updateSolutionMetrics(solution_build);
        BuildBSVPaths.buildBSVPathes(solution_build);

        solution_build.totalCost = solution_build.getTotalCost();
        System.out.println("Initial solution cost: " + solution_build.totalCost + "   cost1:" + solution_build.cost_EVandUAV + "  cost2:" + solution_build.cost_BSV);
        Output.outputSolution(solution_build);

        System.out.println("bye world!");

    }
}
