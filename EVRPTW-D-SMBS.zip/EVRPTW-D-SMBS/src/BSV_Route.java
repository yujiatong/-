
// BSV_Route 类 用于存储换电车的路线信息 继承Route类
public class BSV_Route extends Route {
    public BSV_Route() {
        super();
    }
}