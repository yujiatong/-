

public class Solution {
    public  EV_Route[] evPaths = new EV_Route[Parameter.EVNumber];

    public  BSV_Route[] bsvPaths = new BSV_Route[Parameter.BSVNumber];

    public double totalCost; // 解的总成本
    public double cost_EVandUAV; // EV和UAV的成本
    public double cost_BSV; // BSV的成本
    public double totalEnergy; // 解的总能耗
    public double solution_overcapicity_all = 0.0 ; // 解的总超载量
    public double solution_overtime_all = 0.0 ;                  // 记录解的总超时量
    public int solution_battery_change_times = 0; // 解的总换电次数

    public boolean isFeasible; // 是否满足所有约束（时间窗、电量等）
    public boolean solution_energy_violated = false; // 能量是否违反(EV的满能量不足以到达下一个节点)

    // 无参构造函数
    public Solution() {
        for (int i = 0; i < Parameter.EVNumber; i++) {
            evPaths[i] = new EV_Route();
        }
        for (int i = 0; i < Parameter.BSVNumber; i++) {
            bsvPaths[i] = new BSV_Route();
        }
        totalCost = 0;
        totalEnergy = 0;
        isFeasible = false;
    }

    // getter
    public double getTotalCost() {
        this.cost_EVandUAV = calculate_totalCost(this);
        this.totalCost = this.cost_EVandUAV + this.cost_BSV;
//        this.totalCost = 1*this.cost_EVandUAV + 1.5*this.cost_BSV;
        // 加上预估换电成本
//        this.totalCost += calculate_battery_change_cost(this);
        return this.totalCost;
    }
    //  计算解的总能耗
    public double calculate_energy(Route[] R) {
        // 空白，待实现
        return 0;
    }

    //  计算解的总成本(EV-UAV部分，不包括BSV部分)
    public static double calculate_totalCost(Solution solution) {
        Calculate_Tool.updateSolutionMetrics(solution);
        double cost = 0;
        // EV车辆的使用成本
        for (EV_Route evRoute : solution.evPaths) {
            if(evRoute.route.size() > 2){  // 如果EV路径不为空，则使用了该EV车辆，计算成本
                cost += Parameter.EV_cost;
            }
        }
        // EV能耗成本  + UAV能耗成本
        for (EV_Route evRoute : solution.evPaths) {
            cost += evRoute.energyConsumption ;
            cost += evRoute.energyConsumption_uav ;
        }

        // 惩罚项
        // 超载量惩罚
        cost += Parameter.Alpha * solution.solution_overcapicity_all;
        // 超时量惩罚
        cost += Parameter.Beta * solution.solution_overtime_all;

        // 到达下一节点能耗违法惩罚
        if(solution.solution_energy_violated){
            cost += 1000000;
        }

        return cost;
    }

    // 计算解的预估换电成本
    public double calculate_battery_change_cost(Solution solution) {
        double cost = 0;
        for (EV_Route evRoute : solution.evPaths) {
//            cost += evRoute.battery_change_times * Parameter.consider_battery_change_cost * Parameter.battery_change_cost;
            cost += evRoute.battery_change_times  * Parameter.battery_change_cost;
        }
        return cost;
    }


    // 检查解是否满足约束条件
    public static boolean CheckSolution(Solution solution) {
        boolean flag = true;
        // 检查EV路径是否可行（包括UAV行程）
        for (EV_Route evRoute : solution.evPaths) {
            if (!EV_Route.check_evRoute_feasible(evRoute)) {
                flag = false;
                break;
            }
        }
        // 检查BSV路径是否可行
        // 待实现

        solution.isFeasible = flag;
        return flag;
    }

}
