//import java.util.ArrayList;
//
//public class Parameter {
//    public static double BigValue = Double.MAX_VALUE;                //表示一个很大的值
//    public static double SmallValue = Double.MIN_VALUE;                       //表示一个很小的值
//
//    public static int NodeNumber = 11;                        //表示用户需求点数量，包括仓库 但 不包括虚拟仓库
//    public static int EVNumber = 5;                      //表示提供运力的车辆数，最大数量
//    public static boolean suggest_use_evnum_flag = false;          //表示是否使用建议的车辆数
//    public static int suggest_use_evnum = 0;                      //建议使用的车辆数
//    public static double EVCapacity = 100;                        //表示每辆车的承载量
//    public static double EVEnergy = 300;                        //表示每辆车的能量
//    public static double EVSpeed = 1;                        //表示每辆车的速度
//    public static double EV_weight = 50;                        //表示每辆车的重量
//    public static double UAVCapacity = 25;                        //表示每辆无人机的承载量
//    public static double UAVEnergy = 25;                        //表示每辆无人机的能量
//    public static double UAVSpeed = 2;                        //表示每辆无人机的速度,无人机的速度是电动卡车的200%
//    public static double UAV_weight = 5;                        //表示每辆无人机的重量
//    public static int BSVNumber = 3;                       //表示移动换电车辆数
//    public static int BSVCapacity = 3;                       //表示移动换电车的容量，整数，即表示携带了多少个电池
//    public static double BSVEnergy = 100000;                       //表示移动换电车的能量, 100000表示足够大，即不会出现能量不足的情况
//    public static double BSVSpeed = 1;                       //表示移动换电车的速度
//    public static double BSV_weight = 50;                       //表示移动换电车的重量
//    public static double Battery_weight = 10;             //表示每个电池的重量
//
//
//    public static int MaxIteration = 100;                      //最大迭代次数
//    public static int Remove_NodeNumber = 3;                 //移除节点的数量
//    public static String type;                // 算例类型
//    public static String dataFileName = "";
//    public static double Alpha = 10000;                       //变化参数 : 载重量的惩罚系数
//    public static double Beta = 1000;                       //变化参数 :  违反时间窗
//
//    public static double Best_Solution_Value;                            //全局最优解的值
//    public static ArrayList<Double> BestValueList = new ArrayList<Double>();    // 记录每次迭代的最优解的值
//    public static double Local_solution_Value;                           //当前最优解的值
//    public static double New_Solution_Value;                             //经过破坏-修复后新解的值
//
//    public static Node[] All_NodeList = new Node[NodeNumber + 1]; //创建的节点集合，节点总数为NodeNumber+1，其中[0]和[Parameter.NodeNumber]为仓库与虚拟仓库
//    public static ArrayList<Node> Remove_NodeList = new ArrayList<Node>();  //移除节点集合
//
//    public static Solution Local_solution = new Solution();               //当前解
//    public static Solution New_Solution = new Solution();                 //新解
//    public static Solution Best_Solution = new Solution();                //最优解
//
//
//    public static double[][] DisMatrix = new double[NodeNumber + 1][NodeNumber + 1];          // 节点距离矩阵
//
//    public static double EV_consume_travel = 0.1;                       //电动卡车单位重量行驶单位时间的能耗消耗
//    public static double UAV_consume_travel = 0.05;                       //无人机单位重量行驶单位时间的能耗消耗
//    public static double BSV_consume_travel = 0.1;                       //移动换电车单位重量行驶单位时间的能耗消耗
//
//    public static double UAV_consume_takeoff = 0.05;                       //无人机起飞单位重量能耗消耗
//    public static double UAV_consume_landing = 0.05;                       //无人机降落单位重量能耗消耗
//    public static double equip_UAV_time = 5;                       //装备无人机的时间
//    public static double UAV_takeoff_time = 1;                       //无人机起飞时间
//    public static double UAV_landing_time = 1;                       //无人机降落时间
//    public static double UAV_max_delay_time = 200;                       //无人机最大延误时间
//
//    public static double exchange_battery_time = 20;                       //换电时间
//
//    public static double EV_cost = 1500;                       //电动卡车的成本(包括其所属的无人机)
//    public static double BSV_cost = 1000;                       //移动换电车的成本
//
//    public static int consider_battery_change_cost =0;                       //在破坏修复EV-UAV联合路径时，是否预估考虑电池更换成本(默认考虑) 1-考虑 0-不考虑
//    public static double battery_change_cost = 800;                       //预估单次电池更换成本
//
//    public static int useNumber = 0;                       //记录使用的次数
//    public static ArrayList<BatterySwapInfo> batterySwapInfos = new ArrayList<BatterySwapInfo>();    //记录换电组合信息
//
//    public static double[] WDestroy = new double[4];                  //破坏算子的初始权重
//    public static double[] WRepair = new double[4];                   //修复算子的初始权重
//    public static int[] DestroyUseTime = new int[4];                 //破坏算子的使用次数
//    public static int[] RepairUseTime = new int[4];                  //修复算子的使用次数
//    public static int Destroy_Selection;                             //破坏算子选择编号
//    public static int Repair_Selection;                             //修复算子选择编号
//
//
//}


import java.util.ArrayList;

    public class Parameter {
        public static double BigValue = Double.MAX_VALUE;                //表示一个很大的值
        public static double SmallValue = Double.MIN_VALUE;                       //表示一个很小的值

        public static int NodeNumber = 26;                        //表示用户需求点数量，包括仓库 但 不包括虚拟仓库
        public static int EVNumber = 15;                      //表示提供运力的车辆数，最大数量
        public static boolean suggest_use_evnum_flag = false;          //表示是否使用建议的车辆数
        public static int suggest_use_evnum = 0;                      //建议使用的车辆数
        public static double EVCapacity = 200;                        //表示每辆车的承载量
        public static double EVEnergy = 800;                        //表示每辆车的能量
        public static double EVSpeed = 1;                        //表示每辆车的速度
        public static double EV_weight = 50;                        //表示每辆车的重量
        public static double UAVCapacity = 30;                        //表示每辆无人机的承载量
        public static double UAVEnergy = 30;                        //表示每辆无人机的能量
        public static double UAVSpeed = 2;                        //表示每辆无人机的速度,无人机的速度是电动卡车的200%
        public static double UAV_weight = 5;                        //表示每辆无人机的重量
        public static int BSVNumber = 5;                       //表示移动换电车辆数
        public static int BSVCapacity = 5;                       //表示移动换电车的容量，整数，即表示携带了多少个电池
        public static double BSVEnergy = 1000000;                       //表示移动换电车的能量, 100000表示足够大，即不会出现能量不足的情况
        public static double BSVSpeed = 1;                       //表示移动换电车的速度
        public static double BSV_weight = 50;                       //表示移动换电车的重量
        public static double Battery_weight = 10;             //表示每个电池的重量


        public static int MaxIteration = 100;                      //最大迭代次数
        public static int Remove_NodeNumber = 5;                 //移除节点的数量
        public static String type;                // 算例类型
        public static String dataFileName = "";
        public static double Alpha = 10000000;                       //变化参数 : 载重量的惩罚系数
        public static double Beta = 1000000;                       //变化参数 :  违反时间窗

        public static double Best_Solution_Value;                            //全局最优解的值
        public static ArrayList<Double> BestValueList = new ArrayList<Double>();    // 记录每次迭代的最优解的值
        public static ArrayList<Solution> logSolutionList = new ArrayList<Solution>();    // 记录迭代过程中的一些解，用于分析
        public static double Local_solution_Value;                           //当前最优解的值
        public static double New_Solution_Value;                             //经过破坏-修复后新解的值

        public static Node[] All_NodeList = new Node[NodeNumber + 1]; //创建的节点集合，节点总数为NodeNumber+1，其中[0]和[Parameter.NodeNumber]为仓库与虚拟仓库
        public static ArrayList<Node> Remove_NodeList = new ArrayList<Node>();  //移除节点集合

        public static Solution Local_solution = new Solution();               //当前解
        public static Solution New_Solution = new Solution();                 //新解
        public static Solution Best_Solution = new Solution();                //最优解


        public static double[][] DisMatrix = new double[NodeNumber + 1][NodeNumber + 1];          // 节点距离矩阵

        public static double EV_consume_travel = 0.1;                       //电动卡车单位重量行驶单位时间的能耗消耗
        public static double UAV_consume_travel = 0.05;                       //无人机单位重量行驶单位时间的能耗消耗
        public static double BSV_consume_travel = 0.1;                       //移动换电车单位重量行驶单位时间的能耗消耗

        public static double UAV_consume_takeoff = 0.05;                       //无人机起飞单位重量能耗消耗
        public static double UAV_consume_landing = 0.05;                       //无人机降落单位重量能耗消耗
        public static double equip_UAV_time = 5;                       //装备无人机的时间
        public static double UAV_takeoff_time = 1;                       //无人机起飞时间
        public static double UAV_landing_time = 1;                       //无人机降落时间
        public static double UAV_max_delay_time = 200;                       //无人机最大延误时间

        public static double exchange_battery_time = 20;                       //换电时间

        public static double EV_cost = 3000;                       //电动卡车的成本(包括其所属的无人机)
        public static double BSV_cost = 2000;                       //移动换电车的成本

        public static int consider_battery_change_cost =1;                       //在破坏修复EV-UAV联合路径时，是否预估考虑电池更换成本(默认考虑) 1-考虑 0-不考虑
        public static double battery_change_cost = 500;                       //预估单次电池更换成本

        public static int useNumber = 0;                       //记录使用的次数
        public static ArrayList<BatterySwapInfo> batterySwapInfos = new ArrayList<BatterySwapInfo>();    //记录换电组合信息

        public static double[] WDestroy = new double[4];                  //破坏算子的初始权重
        public static double[] WRepair = new double[4];                   //修复算子的初始权重
        public static int[] DestroyUseTime = new int[4];                 //破坏算子的使用次数
        public static int[] RepairUseTime = new int[4];                  //修复算子的使用次数
        public static int Destroy_Selection;                             //破坏算子选择编号
        public static int Repair_Selection;                             //修复算子选择编号


        public static void InitParameter(){
            double Best_Solution_Value = BigValue;                            //全局最优解的值
            ArrayList<Double> BestValueList = new ArrayList<Double>();    // 记录每次迭代的最优解的值
            ArrayList<Solution> logSolutionList = new ArrayList<Solution>();    // 记录迭代过程中的一些解，用于分析
            double Local_solution_Value  = BigValue;                           //当前最优解的值
            double New_Solution_Value  = BigValue;                             //经过破坏-修复后新解的值

            Node[] All_NodeList = new Node[NodeNumber + 1]; //创建的节点集合，节点总数为NodeNumber+1，其中[0]和[Parameter.NodeNumber]为仓库与虚拟仓库
            ArrayList<Node> Remove_NodeList = new ArrayList<Node>();  //移除节点集合

            Solution Local_solution = new Solution();               //当前解
            Solution New_Solution = new Solution();                 //新解
            Solution Best_Solution = new Solution();                //最优解

            double[][] DisMatrix = new double[NodeNumber + 1][NodeNumber + 1];          // 节点距离矩阵

            int useNumber = 0;                       //记录使用的次数
            ArrayList<BatterySwapInfo> batterySwapInfos = new ArrayList<BatterySwapInfo>();    //记录换电组合信息

            double[] WDestroy = new double[4];                  //破坏算子的初始权重
            double[] WRepair = new double[4];                   //修复算子的初始权重
            int[] DestroyUseTime = new int[4];                 //破坏算子的使用次数
            int[] RepairUseTime = new int[4];                  //修复算子的使用次数
            int Destroy_Selection;                             //破坏算子选择编号
            int Repair_Selection;                             //修复算子选择编号
        }
    }
