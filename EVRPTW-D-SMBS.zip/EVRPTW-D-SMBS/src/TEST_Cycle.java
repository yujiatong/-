import gurobi.GRBException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class TEST_Cycle {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");
        // 实例文件列表
        ArrayList<String> instance_name_list = new ArrayList<String>();
//        instance_name_list.add("c101");
        instance_name_list.add("c201");
//        instance_name_list.add("r101");
//        instance_name_list.add("r201");
//        instance_name_list.add("rc101");
//        instance_name_list.add("rc201");

        for(String instance_name : instance_name_list) {
            // 将Parameter类中的公共变量初始化
            Parameter.InitParameter();
            for(int i = 0; i < 10 ; i++){

                slove(i,instance_name);
            }

        }

        System.out.println("bye world!");

    }

    public static void slove(int No,String instance_name) throws GRBException {
        System.out.println(instance_name +"_No:  " + No);
        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test1";                    //输入想要测试的文件名称
        String name = instance_name;                    //输入想要测试的文件名称
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵
        ReadData.Generate_Initial_Solution();                                 //生成初始解路线集 ，在满足绝对容量要求、（但可能会违反时间窗约束）
        BuildBSVPaths.buildBSVPathes(Parameter.Local_solution);                //为初始解路线生成移动换电车的路径
        //算法实现

        System.out.println("Total Cost: " + Parameter.Local_solution.getTotalCost());
        ALNS.solve_ALNS();
        // 记录时间
        long endtime = System.nanoTime();    //记录程序结束执行的时间
        double time_consum = (endtime - begintime) / 1e9;
        //输出程序运行时间 以秒为单位
        System.out.println("程序运行时间： " + (endtime - begintime) / 1e9 + "s");

        // 存储解决方案到文件
        saveSolutionToFile(Parameter.Best_Solution, "./result/" + name + "result.txt", time_consum,  Parameter.Best_Solution_Value, No);
    }



    public static void saveSolutionToFile(Solution solution, String filePath,double time, double cost,int No) {
        try {
            StringBuilder header = new StringBuilder();
            header.append("\n===================="+ filePath+ "====================\n");
            header.append("Timestamp: ").append(java.time.LocalDateTime.now()).append("\n\n");

            // 写入EV的路径 solution.evPaths[]
            int evIndex = 0;
            StringBuilder content = new StringBuilder();
            content.append("No: ").append(No).append("\n");
            content.append("Time: ").append(time).append("s\n");
            content.append("Cost: ").append(cost).append("\n");
            for (EV_Route evRoute : solution.evPaths) { // evRoute 包括ev的路径信息和其支持的UAV的行程信息
                if (evRoute.route.size() <= 2) { // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                    evIndex++;
                    continue;
                }

                // 写入EV的路径
                content.append("EV Route- ").append(evIndex++).append("\n");

                for (int i = 0; i < evRoute.route.size(); i++) {
                    Node node = evRoute.route.get(i);
                    content.append(node.NodeID).append(i < evRoute.route.size() - 1 ? " -> " : "\n");
                }

                // 写入EV所属的UAV的路径
                int uavTripIndex = 1; // UAV行程计数器
                for (List<Node> uavTrip : evRoute.uavTrips) {
                    content.append("UAV Trip ").append(uavTripIndex++).append(": ");
                    for (int i = 0; i < uavTrip.size(); i++) {
                        Node node = uavTrip.get(i);
                        content.append(node.NodeID).append(i < uavTrip.size() - 1 ? " -> " : "\n");
                    }
                }
                content.append("\n");
            }

            // 写入BSV的路径 solution.bsvPaths[]
            int bsvIndex = 0;
            for (BSV_Route bsvRoute : solution.bsvPaths) { // bsvRoute 包括bsv的路径信息
                if (bsvRoute.route.size() <= 2) { // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                    bsvIndex++;
                    continue;
                }

                // 写入BSV的路径
                content.append("BSV Route- ").append(bsvIndex++).append("\n");
                for (int i = 0; i < bsvRoute.route.size(); i++) {
                    Node node = bsvRoute.route.get(i);
                    content.append(node.NodeID).append(i < bsvRoute.route.size() - 1 ? " -> " : "\n");
                }
                content.append("\n");
            }

            // 在文件末尾追加内容，若文件不存在则创建
            Files.write(Paths.get(filePath), header.append(content).toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);

        } catch (IOException e) {
            System.err.println("Error while writing solution to file: " + e.getMessage());
        }
    }






}