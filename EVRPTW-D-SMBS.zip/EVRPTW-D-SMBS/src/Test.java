import gurobi.GRBException;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");


        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test2";                    //输入想要测试的文件名称
        String name = "c201";
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵

        // 手动构建一个解
        //EV Route- 0
        //0 -> 6 -> 8 -> 11
        //UAV Trip 1: 0 -> 9 -> 8
        //
        //EV Route- 2
        //0 -> 2 -> 7 -> 4 -> 11
        //UAV Trip 1: 0 -> 5 -> 2
        //UAV Trip 2: 2 -> 1 -> 3 -> 4
        //UAV Trip 3: 4 -> 10 -> 11
        //
        //BSV Route- 0
        //0 -> 6 -> 2 -> 11

        // 初始化解

        Solution solution_build = new Solution();
        ArrayList<Node> route1 = new ArrayList<>();
        route1.add(Parameter.All_NodeList[0]);
        route1.add(Parameter.All_NodeList[6]);
        route1.add(Parameter.All_NodeList[8]);
        route1.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[0].route = route1;
        ArrayList<List<Node>> uavTrips = new ArrayList<>();
        List<Node> uavTrip1 = new ArrayList<>();
        uavTrip1.add(Parameter.All_NodeList[0]);
        uavTrip1.add(Parameter.All_NodeList[9]);
        uavTrip1.add(Parameter.All_NodeList[8]);
        uavTrips.add(uavTrip1);
        List<Node> uavTrip2 = new ArrayList<>();
        uavTrip2.add(Parameter.All_NodeList[8]);
        uavTrip2.add(Parameter.All_NodeList[10]);
        uavTrip2.add(Parameter.All_NodeList[11]);
        uavTrips.add(uavTrip2);
        solution_build.evPaths[0].uavTrips = uavTrips;

        ArrayList<Node> route2 = new ArrayList<>();
        route2.add(Parameter.All_NodeList[0]);
//        route2.add(Parameter.All_NodeList[2]);
        route2.add(Parameter.All_NodeList[7]);
        route2.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[1].route = route2;

        ArrayList<Node> route3 = new ArrayList<>();
        route3.add(Parameter.All_NodeList[0]);
        route3.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[2].route = route3;

        ArrayList<Node> route4 = new ArrayList<>();
        route4.add(Parameter.All_NodeList[0]);
        route4.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[3].route = route4;

        ArrayList<Node> route5 = new ArrayList<>();
        route5.add(Parameter.All_NodeList[0]);
        route5.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[4].route = route5;

        ArrayList<Node> bsvroute1 = new ArrayList<>();
//        bsvroute1.add(Parameter.All_NodeList[0]);
//        bsvroute1.add(Parameter.All_NodeList[6]);
//        bsvroute1.add(Parameter.All_NodeList[2]);
//        bsvroute1.add(Parameter.All_NodeList[11]);
        solution_build.bsvPaths[0].route = bsvroute1;

        ArrayList<Node> bsvroute2 = new ArrayList<>();
        solution_build.bsvPaths[1].route = bsvroute2;

        ArrayList<Node> bsvroute3 = new ArrayList<>();
        solution_build.bsvPaths[2].route = bsvroute3;



        int count = 0;
        while (count < 10000) {

            Solution solution_new = new Solution();
            // 克隆当前解
            Calculate_Tool.cloneSolution( solution_new,solution_build);

            Parameter.Remove_NodeList.clear();
            Parameter.Remove_NodeList.add(Parameter.All_NodeList[5]);
            Parameter.Remove_NodeList.add(Parameter.All_NodeList[1]);
            Parameter.Remove_NodeList.add(Parameter.All_NodeList[2]);
            Parameter.Remove_NodeList.add(Parameter.All_NodeList[3]);
//            Parameter.Remove_NodeList.add(Parameter.All_NodeList[10]);
            Parameter.Remove_NodeList.add(Parameter.All_NodeList[4]);

            Calculate_Tool.updateSolutionMetrics(solution_new);
//            Repair.Random_Repair(solution_new);
            Repair.Regret_Repair(solution_new);

            Calculate_Tool.updateSolutionMetrics(solution_new);
            BuildBSVPaths.buildBSVPathes(solution_new);

            solution_new.totalCost = solution_new.getTotalCost();
            System.out.println("第" + count + "次迭代的解：");
            System.out.println("Total cost of the solution: " + solution_new.totalCost);
            if(solution_new.totalCost < 5715){
                Output.outputSolution(solution_new);
                System.out.println("Solution is feasible");
            }

            count++;
        }

        System.out.println("bye world!");

    }
}
