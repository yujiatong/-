import gurobi.GRBException;

import java.util.ArrayList;
import java.util.List;

public class Test5 {
    public static void main(String[] args) throws GRBException {

        System.out.println("Hello world!");


        long begintime = System.nanoTime();    //记录程序开始执行的时间（以纳秒为单位）

//        String name = "test2";                    //输入想要测试的文件名称
        String name = "r201";
        String dataFileName = "./instances" + "/" + name + ".txt";        // 读取solomon_100中的实例文件
        ReadData.InitNodeandRoute();                             //初始化节点、路线以及最优路线指标
        try {
            ReadData.importInfo(dataFileName);                                // 正式开始读取文件数据信息
        } catch (Exception e2) {
            e2.printStackTrace();
        }

        Calculate_Tool.generateDisMatrix();                        //生成初始距离矩阵

        // 手动构建一个解
        //EV Route- 0
        //0 -> 9 -> 10 -> 11
        //UAV Trip 1: 0 -> 7 -> 11
        //
        //EV Route- 1
        //0 -> 5 -> 6 -> 3 -> 4 -> 11
        //UAV Trip 1: 0 -> 2 -> 5
        //UAV Trip 2: 5 -> 8 -> 6
        //UAV Trip 3: 6 -> 1 -> 11
        //
        //BSV Route- 0
        //0 -> 5 -> 6 -> 11
        //BSV Route- 1
        //0 -> 9 -> 3 -> 11

        // 初始化解

        Solution solution_build = new Solution();
        ArrayList<Node> route1 = new ArrayList<>();
        route1.add(Parameter.All_NodeList[0]);
        route1.add(Parameter.All_NodeList[9]);
        route1.add(Parameter.All_NodeList[10]);
        route1.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[0].route = route1;
        ArrayList<List<Node>> uavTrips = new ArrayList<>();
        List<Node> uavTrip1 = new ArrayList<>();
        uavTrip1.add(Parameter.All_NodeList[0]);
        uavTrip1.add(Parameter.All_NodeList[7]);
        uavTrip1.add(Parameter.All_NodeList[11]);
        uavTrips.add(uavTrip1);
        solution_build.evPaths[0].uavTrips = uavTrips;

        ArrayList<Node> route2 = new ArrayList<>();
        route2.add(Parameter.All_NodeList[0]);
        route2.add(Parameter.All_NodeList[5]);
        route2.add(Parameter.All_NodeList[6]);
        route2.add(Parameter.All_NodeList[3]);
        route2.add(Parameter.All_NodeList[4]);
        route2.add(Parameter.All_NodeList[11]);
        solution_build.evPaths[1].route = route2;
        ArrayList<List<Node>> uavTrips2 = new ArrayList<>();
        List<Node> uavTrip2_1 = new ArrayList<>();
        uavTrip2_1.add(Parameter.All_NodeList[0]);
        uavTrip2_1.add(Parameter.All_NodeList[2]);
        uavTrip2_1.add(Parameter.All_NodeList[5]);
        uavTrips2.add(uavTrip2_1);
        List<Node> uavTrip2_2 = new ArrayList<>();
        uavTrip2_2.add(Parameter.All_NodeList[5]);
        uavTrip2_2.add(Parameter.All_NodeList[8]);
        uavTrip2_2.add(Parameter.All_NodeList[6]);
        uavTrips2.add(uavTrip2_2);
        List<Node> uavTrip2_3 = new ArrayList<>();
        uavTrip2_3.add(Parameter.All_NodeList[6]);
        uavTrip2_3.add(Parameter.All_NodeList[1]);
        uavTrip2_3.add(Parameter.All_NodeList[11]);
        uavTrips2.add(uavTrip2_3);
        solution_build.evPaths[1].uavTrips = uavTrips2;

        ArrayList<Node> route3 = new ArrayList<>();
        route3.add(Parameter.All_NodeList[0]);
        route3.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[2].route = route3;

        ArrayList<Node> route4 = new ArrayList<>();
        route4.add(Parameter.All_NodeList[0]);
        route4.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[3].route = route4;

        ArrayList<Node> route5 = new ArrayList<>();
        route5.add(Parameter.All_NodeList[0]);
        route5.add(Parameter.All_NodeList[Parameter.All_NodeList.length - 1]);
        solution_build.evPaths[4].route = route5;

        ArrayList<Node> bsvroute1 = new ArrayList<>();
        bsvroute1.add(Parameter.All_NodeList[0]);
        bsvroute1.add(Parameter.All_NodeList[5]);
        bsvroute1.add(Parameter.All_NodeList[6]);
        bsvroute1.add(Parameter.All_NodeList[11]);
        solution_build.bsvPaths[0].route = bsvroute1;

        ArrayList<Node> bsvroute2 = new ArrayList<>();
        bsvroute2.add(Parameter.All_NodeList[0]);
        bsvroute2.add(Parameter.All_NodeList[9]);
        bsvroute2.add(Parameter.All_NodeList[3]);
        bsvroute2.add(Parameter.All_NodeList[11]);
        solution_build.bsvPaths[1].route = bsvroute2;

        ArrayList<Node> bsvroute3 = new ArrayList<>();
        solution_build.bsvPaths[2].route = bsvroute3;

        Solution solution_new = new Solution();
        // 克隆当前解
        Calculate_Tool.cloneSolution( solution_new,solution_build);

        int count = 0;
        while (count < 10000) {

//            if(count <5000){
//                Parameter.Remove_NodeNumber = 4;
//            }
//            else if(count < 8000){
//                Parameter.Remove_NodeNumber = 2;
//            }
//            else{
//                Parameter.Remove_NodeNumber = 1;
//            }
            Parameter.Remove_NodeNumber = 5;
            Solution solution_now = new Solution();
            // 克隆当前解
            Calculate_Tool.clearSolution(solution_now);
            Calculate_Tool.cloneSolution( solution_now,solution_new);

            Parameter.Remove_NodeList.clear();
            Calculate_Tool.updateSolutionMetrics(solution_now);
            Destroy.Random_Destroy(solution_now);
            Calculate_Tool.updateSolutionMetrics(solution_now);
//            Repair.Random_Repair(solution_now);
//            Repair.Greedy_Repair(solution_now);
           Repair.Regret_Repair(solution_now);
            Calculate_Tool.updateSolutionMetrics(solution_now);
            BuildBSVPaths.buildBSVPathes(solution_now);

            solution_now.totalCost = solution_now.getTotalCost();
            System.out.println("第" + count + "次迭代的解：");
            System.out.println("Total cost of the solution: " + solution_now.totalCost);
            if(solution_now.totalCost < 7345){
                Output.outputSolution(solution_now);
                System.out.println("Solution is feasible");
            }
            count++;
        }

        System.out.println("bye world!");

    }
}
