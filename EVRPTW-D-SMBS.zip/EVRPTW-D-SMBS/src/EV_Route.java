import java.util.ArrayList;
import java.util.List;

// EV_Route 类 用于存储电动车的路线信息(包括其所属无人机的行程） 继承Route类
public class EV_Route extends Route {
    public ArrayList<List<Node>> uavTrips = new ArrayList<>();          // 该EV支持的UAV的行程

    public ArrayList<Double> energy_consum_uavtrip = new ArrayList<>();  // 记录每个UAV行程的能耗

    public double energyConsumption_uav = 0 ;                            //所有UAV航程的能耗加和

    public int battery_change_times = 0 ;   // 电动车换电次数

    // 构造器

    public static boolean check_evRoute_feasible(EV_Route evRoute){
        // 检查EV路径是否可行
        boolean feasible = true;
        // 1. 检查EV路径的载重量是否超过限制
        if (evRoute.total_load > Parameter.EVCapacity) {
            feasible = false;
        }

        // 2. 检查EV路径的能量是否足违反(满能量不足以到达下一个节点)
        if (evRoute.energy_violated) {
            feasible = false;
        }
        // 3. 检查EV路径的时间窗是否满足,包含了UAV行程的时间窗
        if (evRoute.violationTime > 0) {
            feasible = false;
        }
        // 4. 检查EV路径的支持的UAV行程是否可行
        for (List<Node> uavTrip : evRoute.uavTrips) {
            if (!EV_Route.check_uavTrip_feasible(uavTrip)) {
                feasible = false;
                break;
            }
        }
        return feasible;
    }

    public static boolean check_uavTrip_feasible(List<Node> uavTrip){
        // 检查UAV行程是否可行
        boolean feasible = true;
        // 1. 检查UAV行程的载重量是否超过限制
        double weight = 0;
        for(int i = 1; i < uavTrip.size()-1; i++){
            Node node = uavTrip.get(i);
            weight += node.Demand;
        }
        if (weight > Parameter.UAVCapacity) {
            feasible = false;
        }
        // 2. 检查UAV行程的能耗
        // 待实现

        return feasible;
    }


}


