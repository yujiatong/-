import gurobi.*;

import java.util.ArrayList;
import java.util.List;

public class SolveByGurobi {
    // 定义VRPTW的参数
    public int changeNodeNum;   // 需求点数 , 即需要换电的节点数
    public int nodeNum;   // 节点数 = 需求点数 + 2 ，加2 是因为有仓库和虚拟仓库
    public int BSVNum;   // BSV数量

    public int T0;    // 仓库开放时间
    public int T1;    // 仓库关闭时间
    public double[][] distanceMatrix;   // 距离矩阵
    public double[] dueTime;   // 服务时间窗
    public double[] ev_arrival_time;  // EV到达时间
    public List<Node> changeNodeList;  // 需要换电的节点列表;

    // 参数构造函数
    public SolveByGurobi(List<Node> changeNodeList) {
        this.changeNodeList = new ArrayList<>();
        this.changeNodeList.addAll(changeNodeList);
        this.changeNodeNum = changeNodeList.size();
        this.nodeNum = changeNodeList.size() + 2;
        this.BSVNum = Parameter.BSVNumber;
        // 将仓库和虚拟仓库加入到节点列表中 , 仓库为第一个节点，虚拟仓库为最后一个节点
        changeNodeList.add(0, Parameter.All_NodeList[0]);
        changeNodeList.add(Parameter.All_NodeList[Parameter.NodeNumber]);

        // 计算距离矩阵 , 距离矩阵的大小为 nodeNum * nodeNum, 根据节点的坐标来计算距离
        this.distanceMatrix = new double[nodeNum][nodeNum];
        for (int i = 0; i < nodeNum; i++) {
            for (int j = 0; j < nodeNum; j++) {
                this.distanceMatrix[i][j] = Math.sqrt(Math.pow(changeNodeList.get(i).x - changeNodeList.get(j).x, 2) + Math.pow(changeNodeList.get(i).y - changeNodeList.get(j).y, 2));
            }
        }

        // 仓库开放时间为 Parameter.All_NodeList[0].ReadyTime
        this.T0 = (int) Parameter.All_NodeList[0].ReadyTime;

        // 仓库关闭时间为 Parameter.All_NodeList[0].DueTime
        this.T1 = (int) Parameter.All_NodeList[0].DueTime;

        // 服务时间窗 ,等于需求点的 bsvArrivalTime_atlatest
        this.dueTime = new double[nodeNum];
        for (int i = 0; i < nodeNum; i++) {
            this.dueTime[i] = changeNodeList.get(i).bsvArrivalTime_atlatest;
        }
        // EV到达时间
        this.ev_arrival_time = new double[nodeNum];
        for (int i = 0; i < nodeNum; i++) {
            this.ev_arrival_time[i] = changeNodeList.get(i).evArrivalTime;
        }
        // 在实际实现时需要设定一个强假设！！即：t_b <=  t_e 恒成立 ！！！  以保证 bsvArrivalTime_atlatest >= evArrivalTime 必须成立
        // 如果不成立，需要对数据进行处理，使得该假设成立，否则无法求解
        // 1、简单处理：如果不成立，
        for (int i = 0; i < nodeNum; i++) {
            if (this.dueTime[i] < this.ev_arrival_time[i]) {
               this.dueTime[i] = this.ev_arrival_time[i];  // 将 bsvArrivalTime_atlatest 设置为 evArrivalTime
//                this.ev_arrival_time[i] = this.dueTime[i];   // 将 evArrivalTime 设置为 bsvArrivalTime_atlatest,
            }
        }
//         2、经过处理1后，可能会存在无法按时回到仓库的情况，为了避免这种情况，T1 加上 换电时间
        this.T1 += Parameter.exchange_battery_time;
    }

    //函数功能：根据VRPTW数学模型求解VRPTW的Gurobi模型
    public MultipleResults solveModel() throws GRBException {
        GRBEnv env = null;
        GRBModel model = null;
        try{
            Parameter.useNumber++;
//            System.out.println("第" + Parameter.useNumber + "次使用Gurobi求解VRPTW模型");
            int BIGM = 10* T1;   // 一个大M

            // 创建空的环境
            env = new GRBEnv(true);
            env.set("logFile", "mip1.log");
            // 关闭日志输出
            env.set(GRB.IntParam.OutputFlag, 0);
            // 设置内存限制
            env.set(GRB.DoubleParam.NodefileStart, 0.5);

            env.start();

            // 创建空的模型
            model = new GRBModel(env);


            // 设置决策变量
            GRBVar[][][] x = new GRBVar[nodeNum][nodeNum][BSVNum];
            for (int i = 0; i < nodeNum; i++) {
                for (int j = 0; j < nodeNum; j++) {
                    for (int k = 0; k < BSVNum; k++) {
                        x[i][j][k] = model.addVar(0, 1, 0, GRB.BINARY, "x_" + i + "_" + j + "_" + k);
                    }
                }
            }
            // 设置中间变量  $T^a_{ik}$ ：换电车辆k到达节点i的时间  $T^s_{ik}$ ：换电车辆k为节点i的开始进行换电服务的时间 $T^g_{ik}$ ：换电车辆k离开节点i的时间   $u_{ik}$ ：节点$i$在第k辆车的路线中的顺序
            GRBVar[][] T_a = new GRBVar[nodeNum][BSVNum];
            GRBVar[][] T_s = new GRBVar[nodeNum][BSVNum];
            GRBVar[][] T_g = new GRBVar[nodeNum][BSVNum];
            GRBVar[][] order = new GRBVar[nodeNum][BSVNum];
            for (int i = 0; i < nodeNum; i++) {
                for (int k = 0; k < BSVNum; k++) {
                    T_a[i][k] = model.addVar(0, T1, 0, GRB.CONTINUOUS, "Ta_" + i + "_" + k);
                    T_s[i][k] = model.addVar(0, T1, 0, GRB.CONTINUOUS, "Ts_" + i + "_" + k);
                    T_g[i][k] = model.addVar(0, T1, 0, GRB.CONTINUOUS, "Tg_" + i + "_" + k);
                    order[i][k] = model.addVar(0, nodeNum, 0, GRB.CONTINUOUS, "order_" + i + "_" + k);
                }
            }
            // E_b[i][j][k] 表示第k辆换电车从i到j的能耗
            GRBVar[][][] E_b = new GRBVar[nodeNum][nodeNum][BSVNum];
            for (int i = 0; i < nodeNum; i++) {
                for (int j = 0; j < nodeNum; j++) {
                    for (int k = 0; k < BSVNum; k++) {
                        E_b[i][j][k] = model.addVar(0, Parameter.BSVEnergy, 0, GRB.CONTINUOUS, "Eb_" + i + "_" + j + "_" + k);
                    }
                }
            }
            // Q_b[k] 表示第k辆换电车携带的电池数量
            GRBVar[] Q_b = new GRBVar[BSVNum];
            for (int k = 0; k < BSVNum; k++) {
                Q_b[k] = model.addVar(0, Parameter.BSVCapacity, 0, GRB.CONTINUOUS, "Qb_" + k);
            }
            // u1 u2 为二元变量
            GRBVar u1 = model.addVar(0, 1, 0, GRB.BINARY, "u1");
            GRBVar u2 = model.addVar(0, 1, 0, GRB.BINARY, "u2");

            // 设置目标函数  最小化车辆运营费用和路径能耗成本
            // \sum_{i \in V_0} \sum_{k \in K} C_b x_{0ik}
            GRBQuadExpr obj = new GRBQuadExpr();
//            GRBLinExpr obj = new GRBLinExpr();
            for (int i = 1; i < nodeNum - 1; i++) {  // V0 ，即仓库和虚拟仓库不需要考虑
                for (int k = 0; k < BSVNum; k++) {
                    obj.addTerm(Parameter.BSV_cost, x[0][i][k]);
                }
            }
            // + \sum_{i \in V_+} \sum_{j \in V_-} \sum_{k \in K} E_{ijk} * x_{ijk}  能耗成本
            for (int i = 0; i < nodeNum - 1; i++) {  // V+ ，即虚拟仓库不需要考虑
                for (int j = 1; j < nodeNum; j++) {  //  V- ， 即仓库不考虑，因为仓库不能到达
                    for (int k = 0; k < BSVNum; k++) {
                        obj.addTerm(1, E_b[i][j][k], x[i][j][k]);
                    }
                }
            }
            // 设置目标函数
            model.setObjective(obj, GRB.MINIMIZE);

            // 添加约束条件
            // 约束1：每个需求点只能被访问一次  \sum_{k \in K} \sum_{j \in V_-} x_{ijk} = 1 \; , \forall i \in V_0
            for (int i = 1; i < nodeNum - 1; i++) {     // V0 ，即仓库和虚拟仓库不需要考虑
                GRBLinExpr expr = new GRBLinExpr();
                for (int j = 1; j < nodeNum; j++) {    //  V- ， 即仓库不考虑，因为仓库不能到达
                    for (int k = 0; k < BSVNum; k++) {
                        expr.addTerm(1.0, x[i][j][k]);
                    }
                }
                model.addConstr(expr, GRB.EQUAL, 1.0, "1_customer_visited_once_" + i);
            }
            // 约束2： BSV换电车从仓库出发,最后返回仓库   \sum_{j \in V_0} x_{0jk} = \sum_{j \in V_0} x_{j(n+1)k} \leq 1 \;, \forall k \in K \\
            for (int k = 0; k < BSVNum; k++) {
                GRBLinExpr expr1 = new GRBLinExpr();
                GRBLinExpr expr2 = new GRBLinExpr();
                for (int j = 1; j < nodeNum - 1; j++) {  // V0 ，即仓库和虚拟仓库不需要考虑
                    expr1.addTerm(1.0, x[0][j][k]);
                    expr2.addTerm(1.0, x[j][nodeNum - 1][k]);
                }
                model.addConstr(expr1, GRB.EQUAL, expr2, "from_depot" + k);
                model.addConstr(expr1, GRB.LESS_EQUAL, 1.0, "to_depot" + k);
            }

            // 约束3： 保持BSV的流量守恒  \sum_{i \in V_+} x_{ijk} = \sum_{i \in V_-} x_{jik} = 1 \;, \forall j \in V_0,k \in K
            for (int j = 1; j < nodeNum - 1; j++) {   // V0 ，即仓库和虚拟仓库不需要考虑
                for (int k = 0; k < BSVNum; k++) {
                    GRBLinExpr expr1 = new GRBLinExpr();
                    GRBLinExpr expr2 = new GRBLinExpr();
                    for (int i = 0; i < nodeNum - 1; i++) {  // V+ ，即虚拟仓库不需要考虑
                        expr1.addTerm(1.0, x[i][j][k]);
                    }
                    for (int i = 1; i < nodeNum; i++) {    // V- ， 即仓库不考虑，因为仓库不能到达
                        expr2.addTerm(1.0, x[j][i][k]);
                    }
                    model.addConstr(expr1, GRB.EQUAL, expr2, "flow_conservation" + j + "_" + k);
                    model.addConstr(expr1, GRB.LESS_EQUAL, 1.0, "flow_conservation" + j + "_" + k);
                }
            }
            // 约束4：BSV路由的子环路消除 u_{ik} - u_{jk} +1 \leq (n+2)(1 - x_{ijk}) \;, \forall i \in V_+,j \in V_- , k \in K
            for (int i = 0; i < nodeNum - 1; i++) {   // V+ ，即虚拟仓库不需要考虑
                for (int j = 1; j < nodeNum; j++) {    //  V- ， 即仓库不考虑，因为仓库不能到达
                    for (int k = 0; k < BSVNum; k++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        GRBLinExpr expr1 = new GRBLinExpr();
                        expr.addTerm(1.0, order[i][k]);
                        expr.addTerm(-1.0, order[j][k]);
                        expr.addConstant(1.0);
                        expr1.addConstant(BIGM);
                        expr1.addTerm(-BIGM, x[i][j][k]);
                        model.addConstr(expr, GRB.LESS_EQUAL, expr1, "subtour_elimination_" + i + "_" + j + "_" + k);
                    }
                }
            }

            // 约束5： BSV负载约束 \sum_{i \in V_0} \sum_{j \in V_-} x_{ijk} \leq	Q \; , \forall k \in K
            for (int k = 0; k < BSVNum; k++) {
                GRBLinExpr expr = new GRBLinExpr();
                for (int i = 1; i < nodeNum - 1; i++) {   // V0 ，即仓库和虚拟仓库不需要考虑
                    for (int j = 1; j < nodeNum; j++) {    //  V- ， 即仓库不考虑，因为仓库不能到达
                        expr.addTerm(1.0, x[i][j][k]);
                    }
                }
                model.addConstr(expr, GRB.EQUAL, Q_b[k], "load" + k);
                model.addConstr(Q_b[k], GRB.LESS_EQUAL, Parameter.BSVCapacity, "load" + k);
            }
            // 约束6： 计算BSV到达每个访问节点的时间
            // T_{jk}^a \geq T_{ik}^g + t_{ij} - T_1( 1 - x_{ijk}) \;, \forall i \in V_+, j \in V_-, k \in K \\
            //T_{jk}^a \leq T_{ik}^g + t_{ij} + T_1( 1 - x_{ijk}) \;, \forall i \in V_+, j \in V_-, k \in K \\
            for (int i = 0; i < nodeNum - 1; i++) {   // V+ ，即虚拟仓库不需要考虑
                for (int j = 1; j < nodeNum; j++) {    //  V- ， 即仓库不考虑，因为仓库不能到达
                    for (int k = 0; k < BSVNum; k++) {
                        GRBLinExpr expr1 = new GRBLinExpr();
                        GRBLinExpr expr2 = new GRBLinExpr();
                        expr1.addTerm(1.0, T_g[i][k]);
                        expr1.addConstant(distanceMatrix[i][j]);
                        expr1.addConstant(-BIGM);
                        expr1.addTerm(BIGM, x[i][j][k]);
                        model.addConstr(T_a[j][k], GRB.GREATER_EQUAL, expr1, "arrive_" + i + "_" + j + "_" + k);
                        expr2.addTerm(1.0, T_g[i][k]);
                        expr2.addConstant(distanceMatrix[i][j]);
                        expr2.addConstant(BIGM);
                        expr2.addTerm(-BIGM, x[i][j][k]);
                        model.addConstr(T_a[j][k], GRB.LESS_EQUAL, expr2, "arrive_" + i + "_" + j + "_" + k);
                    }
                }
            }
            // 约束7： 计算BSV开始服务每个访问节点的时间  T_{ik}^s = max\{ t^a_i , T^a_{ik} \} ,\forall i \in V_0, k \in K\\
            // T_{ik}^s \geq t^a_i  ,\forall i \in V_0, k \in K\\
            //T_{ik}^s \geq T^a_{ik} ,\forall i \in V_0, k \in K\\
            //T_{ik}^s \leq t^a_i + M(1- u_1) ,\forall i \in V_0, k \in K\\
            //T_{ik}^s \leq T^a_{ik} + M(1- u_2) ,\forall i \in V_0, k \in K\\
            //u_1 + u_2 \geq 1  \\
            //u_1 , u_2 \in \{0,1\}
            for (int i = 1; i < nodeNum - 1; i++) {   // V0 ，即仓库和虚拟仓库不需要考虑
                for (int k = 0; k < BSVNum; k++) {
                    model.addConstr(T_s[i][k], GRB.GREATER_EQUAL, ev_arrival_time[i], "1-start_" + i + "_" + k);
                    model.addConstr(T_s[i][k], GRB.GREATER_EQUAL, T_a[i][k], "2-start_" + i + "_" + k);
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addConstant(ev_arrival_time[i]);
                    expr.addConstant(BIGM);
                    expr.addTerm(-BIGM, u1);
                    model.addConstr(T_s[i][k], GRB.LESS_EQUAL, expr, "3-start_" + i + "_" + k);
                    GRBLinExpr expr1 = new GRBLinExpr();
                    expr1.addTerm(1.0, T_a[i][k]);
                    expr1.addConstant(BIGM);
                    expr1.addTerm(-BIGM, u2);
                    model.addConstr(T_s[i][k], GRB.LESS_EQUAL, expr1, "4-start_" + i + "_" + k);
                }
            }
            GRBLinExpr expr2 = new GRBLinExpr();
            expr2.addTerm(1.0, u1);
            expr2.addTerm(1.0, u2);
            model.addConstr(expr2, GRB.GREATER_EQUAL, 1.0, "5-start_");


            // 确保BSV开始为EV换电池的时间符合要求 T_{ik}^s \leq l_i \;, \forall i \in V_0 , k \in K\\
            for (int i = 1; i < nodeNum - 1; i++) {   // V0 ，即仓库和虚拟仓库不需要考虑
                for (int k = 0; k < BSVNum; k++) {
                    model.addConstr(T_s[i][k], GRB.LESS_EQUAL, dueTime[i], "6-start_" + i + "_" + k);
                }
            }
            // 约束8： 计算BSV离开每个访问节点的时间  T_{ik}^g = T_{ik}^s + t_b ,\forall i \in V_0, k \in K\\
            for (int i = 1; i < nodeNum - 1; i++) {   // V0 ，即仓库和虚拟仓库不需要考虑
                for (int k = 0; k < BSVNum; k++) {
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, T_s[i][k]);
                    expr.addConstant(Parameter.exchange_battery_time);
                    model.addConstr(T_g[i][k], GRB.EQUAL, expr, "leave_" + i + "_" + k);
                }
            }
            //约束9：确保BSV的出行时间必须尊重仓库的运行时间窗口
            // T_{0k}^a \geq T_0 \;, \forall k \in K  \\
            // T_{(n+1)k}^a \leq T_1\;, \forall k \in K  \\
            for (int k = 0; k < BSVNum; k++) {
                model.addConstr(T_a[0][k], GRB.GREATER_EQUAL, T0, "c11_" + k);
                model.addConstr(T_a[nodeNum - 1][k], GRB.LESS_EQUAL, T1, "c12_" + k);
            }
            // 约束10： 计算BSV的能耗
            // E_b[i][j][k] >= expr2 - 2 * B_b * (1 - X_b[i][j][k]
            // E_b[i][j][k] <= expr2 + 2 * B_b * (1 - X_b[i][j][k]
            // expr2 = (Q_b[k] * data.Battery_weight + data.BSV_weight) * data.distanceMatrix[i][j] / 10
            for (int i = 0; i < nodeNum - 1; i++) {  // V+ ，即虚拟仓库不需要考虑
                for (int j = 1; j < nodeNum; j++) {  //  V- ， 即仓库不考虑，因为仓库不能到达
                    for (int k = 0; k < BSVNum; k++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        expr.addTerm(Parameter.Battery_weight * distanceMatrix[i][j] * Parameter.BSV_consume_travel, Q_b[k]);
                        expr.addConstant(Parameter.BSV_weight * distanceMatrix[i][j] * Parameter.BSV_consume_travel);
                        expr.addConstant(-Parameter.BSVEnergy);
                        expr.addTerm(Parameter.BSVEnergy, x[i][j][k]);
                        model.addConstr(E_b[i][j][k], GRB.GREATER_EQUAL, expr, "energy_consum_" + i + "_" + j + "_" + k);

                        GRBLinExpr expr1 = new GRBLinExpr();
                        expr1.addTerm(Parameter.Battery_weight * distanceMatrix[i][j] * Parameter.BSV_consume_travel, Q_b[k]);
                        expr1.addConstant(Parameter.BSV_weight * distanceMatrix[i][j] * Parameter.BSV_consume_travel);
                        expr1.addConstant(Parameter.BSVEnergy);
                        expr1.addTerm(-Parameter.BSVEnergy, x[i][j][k]);
                        model.addConstr(E_b[i][j][k], GRB.LESS_EQUAL, expr1, "energy_consum_" + i + "_" + j + "_" + k);

                    }
                }
            }

            // 边界条件
            // X[i][j][k] 中，i=j 时，X[i][j][k] = 0, 无意义, i = nodeNum - 1 时，X[i][j][k] = 0, 无意义 ,j = 0 时，X[i][j][k] = 0, 无意义
            // E_b[i][j][k] 中，i=j 时，E_b[i][j][k] = 0, 无意义, i = data.nodeNum - 1 时，E_b[i][j][k] = 0, 无意义 ,j = 0 时，E_b[i][j][k] = 0, 无意义
            for (int i = 0; i < nodeNum; i++) {
                for (int j = 0; j < nodeNum; j++) {
                    for (int k = 0; k < BSVNum; k++) {
                        if (i == j || i == nodeNum - 1 || j == 0) {
                            model.addConstr(x[i][j][k], GRB.EQUAL, 0, "c15_" + i + "_" + j + "_" + k);
                            model.addConstr(E_b[i][j][k], GRB.EQUAL, 0, "c16_" + i + "_" + j + "_" + k);
                        }
                        if (i == 0 && j == nodeNum - 1) {
                            model.addConstr(x[i][j][k], GRB.EQUAL, 0, "c17_" + i + "_" + j + "_" + k);
                            model.addConstr(E_b[i][j][k], GRB.EQUAL, 0, "c18_" + i + "_" + j + "_" + k);
                        }
                    }
                }
            }
            //  order[i][k] 中，i = 0 时，order[i][k] = 1 ,i = nodeNum - 1 时，order[i][k] = data.nodeNum
            for (int k = 0; k < BSVNum; k++) {
                model.addConstr(order[0][k], GRB.EQUAL, 1, "c19_" + k);
                model.addConstr(order[nodeNum - 1][k], GRB.EQUAL, nodeNum, "c20_" + k);

            }


            // 优化模型
            model.optimize();

            // model.status
            int status = model.get(GRB.IntAttr.Status);
            if (status == GRB.Status.OPTIMAL) {
                MultipleResults results = new MultipleResults();
                results.objValue = model.get(GRB.DoubleAttr.ObjVal);
                results.bsvPaths = parseModel(model, nodeNum, BSVNum, changeNodeList);

                return results;
            } else if (status == GRB.Status.INFEASIBLE) {
                System.out.println("ddd Model is infeasible");
                // do IIS computeIIS
//                model.computeIIS();
//                model.write("model.ilp");
//                System.out.println("IIS written to file 'model.ilp'");
//                // 打印IIS
//                for (GRBConstr c : model.getConstrs()) {
//                    if (c.get(GRB.IntAttr.IISConstr) > 0) {
//                        System.out.println(c.get(GRB.StringAttr.ConstrName));
//                    }
//                }

            } else if (status == GRB.Status.UNBOUNDED) {
                System.out.println("Model is unbounded");
            } else {
                System.out.println("Optimization was stopped with status = " + status);
            }

        } catch (
                GRBException e) { // 捕获Gurobi异常
            System.out.println("Error code:" + e.getErrorCode() + ". " + e.getMessage());
            // 打印具体的错误信息
            e.printStackTrace();

        }finally {
            if (model != null) {
                model.dispose();
            }
            if (env != null) {
                try {
                    env.dispose();
                } catch (GRBException e) {
                    System.out.println("Error code: " + e.getErrorCode() + ". " + e.getMessage());
                }
            }
        }
        return null;
    }

    // 解析model信息
    public static List<List<Node>> parseModel(GRBModel model, int nodeNum, int BSVNum, List<Node> input_nodes) throws GRBException {
        // 将仓库和虚拟仓库加入到input_nodes 中 , 仓库为第一个节点，虚拟仓库为最后一个节点
        input_nodes.add(0, Parameter.All_NodeList[0]);
        input_nodes.add(Parameter.All_NodeList[Parameter.NodeNumber]);

        List<List<Node>> result = new ArrayList<>();
        // 创建一个三维数组，用于存储X[i][j][k]的值，
        int[][][] X = new int[nodeNum][nodeNum][BSVNum];
        // model.status
        int status = model.get(GRB.IntAttr.Status);
        if (status == GRB.Status.OPTIMAL) {
            // 打印X[i][j][k]
            for (int i = 0; i < nodeNum; i++) {
                for (int j = 0; j < nodeNum; j++) {
                    for (int k = 0; k < BSVNum; k++) {
                        if (model.getVarByName("x_" + i + "_" + j + "_" + k).get(GRB.DoubleAttr.X) > 0.5) {
//                            System.out.println("x[" + i + "][" + j + "][" + k + "] = " + model.getVarByName("x_" + i + "_" + j + "_" + k).get(GRB.DoubleAttr.X));
                            X[i][j][k] = 1;
                        }
                    }
                }
            }
        }
        // 构建路径
        for (int k = 0; k < BSVNum; k++) {
            List<Node> path = new ArrayList<>();
            int i = 0;
            path.add(input_nodes.get(0));
            boolean finish = false;
            while (!finish) {
                for (int j = 1; j < nodeNum; j++) {
                    if (X[i][j][k] == 1) {
                        path.add(input_nodes.get(j));
                        i = j;
                        break;
                    }
                    if (j == nodeNum - 1) {
                        finish = true;
                    }
                }
                if (i == nodeNum - 1) {
                    finish = true;
                }
            }
            if (path.size() > 2) {
                result.add(path);
            }
        }
        // 判断bsvPaths中的路径是否有重复的节点
        ArrayList<Node> allNodes = new ArrayList<>();
        for (List<Node> path : result) {
            for(int i = 1; i < path.size()-1; i++) {
                Node node = path.get(i);
                allNodes.add(node);
            }
        }
        // 判断是否有重复的节点
        for (int i = 0; i < allNodes.size(); i++) {
            for (int j = i + 1; j < allNodes.size(); j++) {
                if (allNodes.get(i).NodeID == allNodes.get(j).NodeID) {
                    System.out.println("有重复的节点");
                }
            }
        }
        return result;
    }
}

class MultipleResults {
    public double objValue;
    public List<List<Node>> bsvPaths;
}

class BatterySwapInfo {
    public List<Node> BatterySwapNodes;  // 换电节点组合
    public List<List<Node>> BatterySwapNodesPath;  // 换电节点组合的最优路径
    public Double BatterySwapNodesCost;  // 换电节点组合的最优路径的成本

    //参数构造函数
    public BatterySwapInfo(List<Node> BatterySwapNodesGroup, List<List<Node>> BatterySwapNodesGroupPath, Double BatterySwapNodesGroupCost) {
        // 深拷贝
        this.BatterySwapNodes = new ArrayList<>();
        this.BatterySwapNodes.addAll(BatterySwapNodesGroup);
        this.BatterySwapNodesPath = new ArrayList<>();
        this.BatterySwapNodesPath.addAll(BatterySwapNodesGroupPath);
        this.BatterySwapNodesCost = BatterySwapNodesGroupCost;
    }
}