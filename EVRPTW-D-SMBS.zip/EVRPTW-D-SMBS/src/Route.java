import java.util.ArrayList;
import java.util.List;

public class Route {

    ArrayList<Node> route = new ArrayList<>();          //定义路线由节点构成，Node列表
    public double violationTime;                             //路线违反时间窗量
    public double total_load;                             //路线中的载重量
    public double distance;                              //路线距离
    public double energyConsumption = 0;                              //路线能耗

    public boolean energy_violated = false; // 能量是否违反(EV的满能量不足以到达下一个节点)
    public ArrayList<Double> energy_consum_travel = new ArrayList<>();  // 记录EV在路径上各节点上的能耗
    public ArrayList<Double> weight_travel = new ArrayList<>();  // 记录EV在路径上各节点上的载重量



    public static void calculateViolationTime(Route R) {            // 计算路线违反时间窗量
        double arrivalTime = 0;
        R.violationTime = 0;  //重置违反时间窗时间
        for (int i = 1; i < R.route.size(); i++) {
            //到达时间=上一个节点的到达时间+上一个节点的服务时间+两点之间距离（默认车辆速度为1）
            arrivalTime = arrivalTime + R.route.get(i - 1).ServiceTime + Parameter.DisMatrix[R.route.get(i - 1).NodeID][R.route.get(i).NodeID];
            //如果迟到，则新增违反时间
            if (arrivalTime > R.route.get(i).DueTime) {
                R.violationTime = R.violationTime + arrivalTime - R.route.get(i).DueTime;
            }
            //如果提前到，则需要进行等待，直到最早允许开始服务的时间，更新到达时间 为 最早服务开始时间
            else if (arrivalTime < R.route.get(i).ReadyTime) {
                arrivalTime = R.route.get(i).ReadyTime;
            }
        }
    }

    public static void calculateDistance(Route R) {       // 计算路线R的路线距离
        R.distance = 0;
        for (int i = 0;i < R.route.size()-1;i++) {
            R.distance  = R.distance + Parameter.DisMatrix[R.route.get(i).NodeID][R.route.get(i+1).NodeID];
        }
    }

}

