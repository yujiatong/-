import gurobi.GRBException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadData {

    public static void InitNodeandRoute() {
        // 创建存储节点的空间
        for (int i = 0; i < Parameter.NodeNumber + 1; i++) {        // 数目比节点数还多1个，即添加了虚拟仓库节点
            Parameter.All_NodeList[i] = new Node();
        }
        // 创建存储解的空间
        Parameter.Local_solution = new Solution();
        Parameter.Best_Solution = new Solution();
        Parameter.New_Solution = new Solution();
    }

    public static void importInfo(String dataFileName) throws IOException {         // 正式开始读取文件数据信息
        //写入车辆参数
//        BufferedReader VehicleReader = new BufferedReader(new FileReader(Parameter.dataFileName));
//        int Row = 0;      // 迭代行数计数
//        String Line;
//        while ((Line = VehicleReader.readLine()) != null) {           //若所读取Line中的信息不为空 (实际上没有作用，空白行为 “ ” is not null，但对文件最后的空白为null，可以用作循环的一类终止条件）
//            String DataValue[] = Line.split("\\s+");     //以一个或多个空白字符分割每行
//
//            if (Row == 4) {
//                //读取车辆数量
//                Parameter.EVNumber = Integer.valueOf(DataValue[1]);
//                //读取车辆最大容量
//                Parameter.EVCapacity = Integer.valueOf(DataValue[2]);
//                break;
//            }
//            Row++;            // 每循环一次，行数加一
//        }
//        VehicleReader.close();

        //写入节点参数
        BufferedReader NodeReader = new BufferedReader(new FileReader(dataFileName));
        int row = 0;
        String line;
        while ((line = NodeReader.readLine()) != null) {
            String dataValue[] = line.split("\\s+");

            if (row >= 9 && row - 9 < Parameter.NodeNumber ) {          //文件的第九行为节点数据开始行，存储到Parameter.All_NodeList的节点集合当中，
                Parameter.All_NodeList[row - 9].NodeID = Integer.valueOf(dataValue[1]);        // 节点id ，0表示仓库
                Parameter.All_NodeList[row - 9].x = Integer.valueOf(dataValue[2]);              // 节点x坐标
                Parameter.All_NodeList[row - 9].y = Integer.valueOf(dataValue[3]);              // 节点y坐标
                Parameter.All_NodeList[row - 9].Demand = Integer.valueOf(dataValue[4]);         // 节点需求量
                Parameter.All_NodeList[row - 9].ReadyTime = Integer.valueOf(dataValue[5]);      // 节点最早服务时间
                Parameter.All_NodeList[row - 9].DueTime = Integer.valueOf(dataValue[6]);        // 节点最晚服务时间
                Parameter.All_NodeList[row - 9].ServiceTime = Integer.valueOf(dataValue[7]);    // 节点服务时间
            }
            if (row == Parameter.NodeNumber + 9 ) {     // 如果已经读到了预先设定的Parameter.NodeNumber个节点的数据,则跳出循环，不再进行读取
                Parameter.All_NodeList[row - 9].NodeID = Parameter.NodeNumber ;             // 添加虚拟仓库节点，id为NodeNumber
                Parameter.All_NodeList[row - 9].x = Parameter.All_NodeList[0].x;               // 虚拟仓库节点的x坐标与仓库节点相同
                Parameter.All_NodeList[row - 9].y = Parameter.All_NodeList[0].y;               // 虚拟仓库节点的y坐标与仓库节点相同
                Parameter.All_NodeList[row - 9].Demand = Parameter.All_NodeList[0].Demand;     // 虚拟仓库节点的需求量与仓库节点相同
                Parameter.All_NodeList[row - 9].ReadyTime = Parameter.All_NodeList[0].ReadyTime;  // 虚拟仓库节点的最早服务时间与仓库节点相同
                Parameter.All_NodeList[row - 9].DueTime = Parameter.All_NodeList[0].DueTime;      // 虚拟仓库节点的最晚服务时间与仓库节点相同
                Parameter.All_NodeList[row - 9].ServiceTime = Parameter.All_NodeList[0].ServiceTime;  // 虚拟仓库节点的服务时间与仓库节点相同
                break;
            }
            row++;
        }
        // 检查最后一个节点是否为虚拟仓库节点，如果不是，则添加虚拟仓库节点
        if (Parameter.All_NodeList[Parameter.NodeNumber].NodeID != Parameter.NodeNumber) {
            Parameter.All_NodeList[Parameter.NodeNumber].NodeID = Parameter.NodeNumber ;             // 添加虚拟仓库节点，id为NodeNumber
            Parameter.All_NodeList[Parameter.NodeNumber].x = Parameter.All_NodeList[0].x;               // 虚拟仓库节点的x坐标与仓库节点相同
            Parameter.All_NodeList[Parameter.NodeNumber].y = Parameter.All_NodeList[0].y;               // 虚拟仓库节点的y坐标与仓库节点相同
            Parameter.All_NodeList[Parameter.NodeNumber].Demand = Parameter.All_NodeList[0].Demand;     // 虚拟仓库节点的需求量与仓库节点相同
            Parameter.All_NodeList[Parameter.NodeNumber].ReadyTime = Parameter.All_NodeList[0].ReadyTime;  // 虚拟仓库节点的最早服务时间与仓库节点相同
            Parameter.All_NodeList[Parameter.NodeNumber].DueTime = Parameter.All_NodeList[0].DueTime;      // 虚拟仓库节点的最晚服务时间与仓库节点相同
            Parameter.All_NodeList[Parameter.NodeNumber].ServiceTime = Parameter.All_NodeList[0].ServiceTime;  // 虚拟仓库节点的服务时间与仓库节点相同
        }
        NodeReader.close();
    }

    //生成初始解（不一定是可行解）
    public static void Generate_Initial_Solution() throws GRBException {
        //先构建EV路线，再构建UAV航线

        // 所有待分配的客户节点列表
        ArrayList<Node> allNodes = new ArrayList<>();   // 存储所有待分配的客户节点,不包括仓库节点和虚拟仓库节点
        for (int i = 1; i < Parameter.NodeNumber ; i++) {
            allNodes.add(Parameter.All_NodeList[i]);
        }
        int currentRouteid = -1;  // 当前正在构建的EV路线的编号

        //第一阶段：构建EV路线，为每辆EV初始化路径，从配送中心（Depot）开始，然后依次向路径中插入节点。
        for (EV_Route evRoute : Parameter.Local_solution.evPaths) {        // 遍历每辆EV, 为每辆EV初始化路径
            currentRouteid++;  // 当前EV的编号（从0开始）
            evRoute.route.add(Parameter.All_NodeList[0]);     // 路径从配送中心开始
            double currentLoad = 0;
            double currentTime = 0;
            Node currentNode = Parameter.All_NodeList[0];    // 当前节点为配送中心

            // 直到所有客户节点被分配或者当前EV的容量达到上限，则结束当前EV的路径构建
            while (!allNodes.isEmpty() && currentLoad < Parameter.EVCapacity) {
                //在每一步，我们选择离当前节点最近的且符合容量和时间约束的下一个节点。
                Node nextNode = findNextNode(evRoute, currentNode, currentLoad, currentTime, allNodes);

                if (nextNode != null) {
                    evRoute.route.add(nextNode);     // 添加下一个节点
                    currentLoad += nextNode.Demand;  // 更新载重量
                    // 更新时间, 从当前节点到下一个节点的时间 + 下一个节点的服务时间,因为可能需要等待，所以取最大值
                    currentTime = Math.max(nextNode.ReadyTime, currentTime + Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID] / Parameter.EVSpeed) + nextNode.ServiceTime;

                    // 更新节点状态
                    nextNode.NodeWithEVID = currentRouteid;
                    nextNode.Position = evRoute.route.size() - 1;

                    // 从待分配节点列表中移除已经分配的节点
                    allNodes.remove(nextNode);
                    // 更新当前节点
                    currentNode = nextNode;
                } else {
                    break;  // 没有合适的下一个节点，结束当前EV的路径构建
                }
            }
            // 结束当前EV的路径构建，回到配送中心
            evRoute.route.add(Parameter.All_NodeList[Parameter.NodeNumber]);  // 回到配送中心，-1表示虚拟仓库节点
        }
        // 如果将所有可用的EV构建路线完毕后，还有未分配的节点，则将其分配给最近的EV（待改进，可以考虑将其插入到EV路径中，而非最后）！！！
        while (!allNodes.isEmpty()) {
            Node nearestNode = null;
            double minDistance = Double.MAX_VALUE;
            EV_Route nearestEVRoute = null;
            for (Node node : allNodes) {
                for (EV_Route evRoute : Parameter.Local_solution.evPaths) {
                    double distance = Parameter.DisMatrix[evRoute.route.get(evRoute.route.size() - 1).NodeID][node.NodeID];
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearestNode = node;
                        nearestEVRoute = evRoute;
                    }
                }
            }
            if (nearestNode != null) {
                nearestEVRoute.route.add(nearestEVRoute.route.size() - 1, nearestNode);  // 将节点插入到EV路径中，倒数第二个位置，即倒数第一个节点之前
                allNodes.remove(nearestNode);
            }
        }
        // 更新EV路径的距离、能耗,路径中节点到达时间等信息
        for (EV_Route evRoute : Parameter.Local_solution.evPaths) {
            Calculate_Tool.updateEVRoutesMetrics(evRoute);
        }

        //第二阶段：构建UAV航线，找出可以转移到无人机航线的节点，然后将其转移到无人机航线。
        // 遍历每个EV路径
        for (EV_Route evRoute : Parameter.Local_solution.evPaths) {
            // 如果路径长度小于3，说明只有两个节点，即起点和终点，以及一个中间节点，不构建EV路线，直接跳过
            if (evRoute.route.size() <= 3) {
                continue;
            }
            ArrayList<List<Node>> uavTrips = new ArrayList<>();  // 存储当前EV路径上的UAV航线
            // 遍历EV路径上的每个客户节点
            for (int i = 1; i < evRoute.route.size() - 1; i++) { // 从第一个客户节点开始，忽略起点和终点
                Node takeoffNode = evRoute.route.get(i - 1);   // UAV本次航线的拟起飞节点
                Node landingNode = evRoute.route.get(i + 1);   // UAV本次航线的拟降落节点
                Node currentNode = evRoute.route.get(i);

                // 判断当前节点是否可以转移到UAV航线
                if (canMoveToUAV(takeoffNode, currentNode, landingNode)) {
                    List<Node> uavTrip = new ArrayList<>();
                    uavTrip.add(takeoffNode);  // 将起飞节点添加到UAV航线
                    uavTrip.add(currentNode);  // 将当前节点添加到UAV航线
                    uavTrip.add(landingNode);  // 将降落节点添加到UAV航线

                    // 因为一次UAV航线可以为多个客户进行服务，故尝试继续添加后续的节点到当前UAV航线
                    for (int j = i + 1; j < evRoute.route.size() - 1; j++) {
                        Node nextNode = evRoute.route.get(j);
                        Node nextLandingNode = evRoute.route.get(j + 1);

                        // 判断下一个节点是否也可以转移到当前UAV航线
                        List<Node> uavTrip_judge = new ArrayList<>();
                        uavTrip_judge.addAll(uavTrip); // 复制当前UAV航线
                        uavTrip_judge.add(nextLandingNode);   // 尝试添加下一个节点

                        if (satisfiesUAVTripConstraints(uavTrip_judge)) {  // 判断当前UAV航线是否满足约束条件，如果满足，则将下一个节点加入到当前UAV航线
                            uavTrip.add(nextLandingNode);
                        } else {
                            break; // 如果下一个节点不能加入当前UAV航线，则停止尝试
                        }
                    }

                    // 如果UAV航线有效，则将其加入到EV的UAV任务列表
                    if (!uavTrip.isEmpty()) {
                        uavTrips.add(uavTrip);
                        i += uavTrip.size() - 2;  // 更新i的值，跳过已经分配给UAV的节点
                        // 从EV路径中移除已分配给UAV的节点，不移除起飞和降落节点
                        for (int j = 1; j < uavTrip.size() - 1; j++) {
                            Node node = uavTrip.get(j);
                            evRoute.route.remove(node);
                        }
                    }
                }
            }

            // 将生成的UAV航线添加到EV路径的UAV任务列表中
            evRoute.uavTrips.addAll(uavTrips);
            Calculate_Tool.updateEVRoutesMetrics(evRoute);  // 更新EV路径的距离、能耗,路径中节点到达时间等信息
        }

        //第三阶段：构建BSV路线，将EV路径中的节点按照时间顺序插入到BSV路径中
        // 由于必须保证 BSV 不会因迟到而延误 EV，因此如果能够满足电池更换约束，集成的 BSV 路线不会导致 EV-UAV 路线发生变化。
        // 根据相关约束条件，以及假设 换电时间小于EV为客户服务的时间，则可以计算出 BSV 的最晚开始服务时间。

    }


    // （贪心策略）寻找下一个节点，选择离当前节点最近的且符合容量和时间约束的节点
    public static Node findNextNode(EV_Route evRoute, Node currentNode, double currentLoad, double currentTime, ArrayList<Node> allNodes) {
        Node bestNode = null;         // 最佳节点
        double minDistance = Double.MAX_VALUE;    // 最小距离

        for (Node node : allNodes) {     // 遍历所有待分配的客户节点
            if (node.Demand + currentLoad <= Parameter.EVCapacity) {  // 检查容量约束
                double distance = Parameter.DisMatrix[currentNode.NodeID][node.NodeID];
                double arrivalTime = currentTime + distance / Parameter.EVSpeed;  // 到达时间 = 当前时间 + 两点之间的距离 / 速度

                if (arrivalTime <= node.DueTime && distance < minDistance) {  // 在满足最晚开始服务时间的情况下选择距离当前最近的节点
                    minDistance = distance;   // 更新最小距离
                    bestNode = node;          // 更新最佳节点
                }
            }
        }
        return bestNode;
    }

    // 判断当前节点是否满足转移到UAV航线的条件
    public static boolean canMoveToUAV(Node takeoffNode, Node currentNode, Node landingNode) {
        // 判断容量、能耗、时间窗等约束条件
        boolean Capacity_flag = currentNode.Demand <= Parameter.UAVCapacity;
        if (!Capacity_flag) {   // 如果当前节点的需求量大于无人机的容量，则不满足容量约束
            return false;
        }

        double takeoff_Energy_1 = Calculate_Tool.Calculate_UAV_Takeoff_Energy(currentNode.Demand + Parameter.UAV_weight);
        double travel_Energy_1 = Calculate_Tool.Calculate_UAV_Travel_Energy(currentNode.Demand + Parameter.UAV_weight, Parameter.DisMatrix[takeoffNode.NodeID][currentNode.NodeID]);
        double landing_Energy_1 = Calculate_Tool.Calculate_UAV_Landing_Energy(currentNode.Demand + Parameter.UAV_weight);
        double takeoff_Energy_2 = Calculate_Tool.Calculate_UAV_Takeoff_Energy(Parameter.UAV_weight);
        double travel_Energy_2 = Calculate_Tool.Calculate_UAV_Travel_Energy(Parameter.UAV_weight, Parameter.DisMatrix[currentNode.NodeID][landingNode.NodeID]);
        double landing_Energy_2 = Calculate_Tool.Calculate_UAV_Landing_Energy(Parameter.UAV_weight);
        double UAV_Energy_consumption = takeoff_Energy_1 + travel_Energy_1 + landing_Energy_1 + takeoff_Energy_2 + travel_Energy_2 + landing_Energy_2;
        boolean Energy_flag = UAV_Energy_consumption <= Parameter.UAVEnergy;

        if (!Energy_flag) {   // 如果当前节点的能耗大于无人机的能量，则不满足能耗约束
            return false;
        }

        // 因为现在是拟将currentNode转移到UAV航线，所以在原始的EV路径中，没有了currentNode，故需要重新计算landingNode的到达时间，即为takeoffNode到landingNode的时间
        // 由于开始不存在UAV航线，故从takeoffNode起飞需要判断是否可以先进行无人机的准备工作，这会影响了UAV的起飞时间和EV的离开时间
        double ev_arrivaltime_to_landingNode;
        double uav_arrivaltime_to_landingNode;
        if (takeoffNode.NodeID == 0) {  // 如果起飞节点是仓库，则不需要判断，默认先为无人机准备
            ev_arrivaltime_to_landingNode = Parameter.equip_UAV_time + Parameter.DisMatrix[takeoffNode.NodeID][landingNode.NodeID] / Parameter.EVSpeed;
            double temp_time_1 = Parameter.equip_UAV_time + Parameter.UAV_takeoff_time + Parameter.DisMatrix[takeoffNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
            // UAV开始为currentNode节点服务的时间
            double uav_sevice_time_for_currentNode = Math.max(temp_time_1 + Parameter.UAV_landing_time, currentNode.ReadyTime);
            if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                return false;
            }
            double temp_time_2 = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][landingNode.NodeID] / Parameter.UAVSpeed;
            uav_arrivaltime_to_landingNode = temp_time_2;
        } else {     // 如果起飞节点不是仓库，则需要判断是否可以先为无人机准备
            boolean delta = takeoffNode.ReadyTime - Math.max(takeoffNode.evArrivalTime, takeoffNode.uavArrivalTime + Parameter.UAV_landing_time) - Parameter.equip_UAV_time >= 0;
            if (delta) {  // 如果可以先为无人机准备,则不影响EV的离开时间
                ev_arrivaltime_to_landingNode = takeoffNode.evDepartureTime + Parameter.DisMatrix[takeoffNode.NodeID][landingNode.NodeID] / Parameter.EVSpeed;
                double temp_time_1 = Math.max(takeoffNode.evArrivalTime, takeoffNode.uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time + Parameter.UAV_takeoff_time + Parameter.DisMatrix[takeoffNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                // UAV开始为currentNode节点服务的时间
                double uav_sevice_time_for_currentNode = Math.max(temp_time_1 + Parameter.UAV_landing_time, currentNode.ReadyTime);
                if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                    return false;
                }
                double temp_time_2 = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][landingNode.NodeID] / Parameter.UAVSpeed;
                uav_arrivaltime_to_landingNode = temp_time_2;

            } else {  // 不可以先为无人机准备,则需要等待，影响EV的离开时间
                // 计算UAV起飞时间
                double takeoffTime = Math.max(takeoffNode.evServiceTime + takeoffNode.ServiceTime, takeoffNode.uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time;
                ev_arrivaltime_to_landingNode = takeoffTime + Parameter.DisMatrix[takeoffNode.NodeID][landingNode.NodeID] / Parameter.EVSpeed;
                double temp_time_1 = takeoffTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[takeoffNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                // UAV开始为currentNode节点服务的时间
                double uav_sevice_time_for_currentNode = Math.max(temp_time_1 + Parameter.UAV_landing_time, currentNode.ReadyTime);
                if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                    return false;
                }
                double temp_time_2 = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][landingNode.NodeID] / Parameter.UAVSpeed;
                uav_arrivaltime_to_landingNode = temp_time_2;
            }
        }
        // UAV与EV在landingNode节点的交汇时间，如果UAV先到达，可以无限等待EV，但如果EV先到达，UAV不能迟到“太久”
        boolean rendezvous_time_flag = uav_arrivaltime_to_landingNode + Parameter.UAV_landing_time <= Math.max(landingNode.ReadyTime, ev_arrivaltime_to_landingNode) + landingNode.ServiceTime + Parameter.UAV_max_delay_time;
        if (!rendezvous_time_flag) {   // 如果UAV与EV在landingNode节点的交汇时间不满足约束，则不满足约束
            return false;
        }
        // 如果所有约束条件都满足，则返回true
        return true;
    }

    public static boolean satisfiesUAVTripConstraints(List<Node> uavtrip) {
        if (uavtrip.size() < 3) {  // 无人机航线至少包含起飞节点、中间节点和降落节点
            return false;
        }
        // 判断容量约束条件
        double current_total_Load = 0; // 当前航线的总载重量,即中间节点的需求量加和，不包括起飞和降落节点
        for (int i = 1; i < uavtrip.size() - 1; i++) {
            current_total_Load += uavtrip.get(i).Demand;
        }
        boolean Capacity_flag = current_total_Load <= Parameter.UAVCapacity;
        if (!Capacity_flag) {   // 如果当前航线的总载重量大于无人机的容量，则不满足容量约束
            return false;
        }
        // 判断能耗约束条件
        double energy_consumption = 0;   // 当前航线的总能耗，包括起飞、降落、飞行能耗，随着服务的进行，UAV的载重量会发生变化
        for (int i = 0; i < uavtrip.size() - 1; i++) {
            Node currentNode = uavtrip.get(i);
            Node nextNode = uavtrip.get(i + 1);
            // 起飞能耗，载重量为当前航线的总载重量加上无人机的重量
            double takeoff_Energy = Calculate_Tool.Calculate_UAV_Takeoff_Energy(current_total_Load + Parameter.UAV_weight);
            // 飞行能耗，载重量为当前航线的总载重量加上无人机的重量
            double travel_Energy = Calculate_Tool.Calculate_UAV_Travel_Energy(current_total_Load + Parameter.UAV_weight, Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID]);
            // 降落能耗，载重量为当前航线的总载重量加上无人机的重量
            double landing_Energy = Calculate_Tool.Calculate_UAV_Landing_Energy(current_total_Load + Parameter.UAV_weight);
            // 更新总能耗
            energy_consumption += takeoff_Energy + travel_Energy + landing_Energy;
            // 更新载重量，减去当前节点的需求量
            current_total_Load -= currentNode.Demand;
        }
        boolean Energy_flag = energy_consumption <= Parameter.UAVEnergy;
        if (!Energy_flag) {   // 如果当前航线的总能耗大于无人机的能量，则不满足能耗约束
            return false;
        }

        // 判断时间窗约束条件
        // 因为现在是拟将currentNode转移到UAV航线，所以在原始的EV路径中，没有了currentNode，故需要重新计算landingNode的到达时间，即为takeoffNode到landingNode的时间
        // 由于开始不存在UAV航线，故从takeoffNode起飞需要判断是否可以先进行无人机的准备工作，这会影响了UAV的起飞时间和EV的离开时间
        double ev_arrivaltime_to_landingNode = 0;
        double uav_arrivaltime_to_landingNode = 0;
        if (uavtrip.get(0).NodeID == 0) {  // 如果起飞节点是仓库，则不需要判断，默认先为无人机准备
            ev_arrivaltime_to_landingNode = Parameter.equip_UAV_time + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(uavtrip.size() - 1).NodeID] / Parameter.EVSpeed;

            // UAV从仓库起飞到达第一个节点的时间
            double temp_time = Parameter.equip_UAV_time + Parameter.UAV_takeoff_time + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(1).NodeID] / Parameter.UAVSpeed;
            // 从第一个节点开始，忽略起点，计算到达UAV航线的最后一个节点的时间
            for (int i = 1; i < uavtrip.size() - 1; i++) {
                Node currentNode = uavtrip.get(i);
                Node nextNode = uavtrip.get(i + 1);
                // UAV开始为currentNode节点服务的时间, 等于UAV到达currentNode的时间（加上降落时间）与最早开始时间的最大值
                double uav_sevice_time_for_currentNode = Math.max(temp_time + Parameter.UAV_landing_time, currentNode.ReadyTime);
                if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                    return false;
                }
                // UAV从currentNode到达下一个节点的时间，等于开始为currentNode服务的时间加上服务时间和起飞时间，再加上两点之间的距离除以速度，不包括降落时间
                temp_time = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID] / Parameter.UAVSpeed;
            }
            uav_arrivaltime_to_landingNode = temp_time;  // UAV到达最后一个节点的时间，不包括降落时间

        } else {     // 如果起飞节点不是仓库，则需要判断是否可以先为无人机准备
            boolean delta = uavtrip.get(0).ReadyTime - Math.max(uavtrip.get(0).evArrivalTime, uavtrip.get(0).uavArrivalTime + Parameter.UAV_landing_time) - Parameter.equip_UAV_time >= 0;
            if (delta) {  // 如果可以先为无人机准备,则不影响EV的离开时间
                ev_arrivaltime_to_landingNode = uavtrip.get(0).evDepartureTime + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(uavtrip.size() - 1).NodeID] / Parameter.EVSpeed;
                // UAV从起飞节点到达第一个中间节点的时间
                double temp_time = Math.max(uavtrip.get(0).evArrivalTime, uavtrip.get(0).uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time + Parameter.UAV_takeoff_time + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(1).NodeID] / Parameter.UAVSpeed;
                // 从第一个节点开始，忽略起点，计算到达UAV航线的最后一个节点的时间
                for (int i = 1; i < uavtrip.size() - 1; i++) {
                    Node currentNode = uavtrip.get(i);
                    Node nextNode = uavtrip.get(i + 1);
                    // UAV开始为currentNode节点服务的时间, 等于UAV到达currentNode的时间（加上降落时间）与最早开始时间的最大值
                    double uav_sevice_time_for_currentNode = Math.max(temp_time + Parameter.UAV_landing_time, currentNode.ReadyTime);
                    if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                        return false;
                    }
                    // UAV从currentNode到达下一个节点的时间，等于开始为currentNode服务的时间加上服务时间和起飞时间，再加上两点之间的距离除以速度，不包括降落时间
                    temp_time = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID] / Parameter.UAVSpeed;
                }
                uav_arrivaltime_to_landingNode = temp_time;  // UAV到达最后一个节点的时间，不包括降落时间
            } else {  // 不可以先为无人机准备,则需要等待，影响EV的离开时间
                // 计算UAV起飞时间
                double takeoffTime = Math.max(uavtrip.get(0).evServiceTime + uavtrip.get(0).ServiceTime, uavtrip.get(0).uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time;
                ev_arrivaltime_to_landingNode = takeoffTime + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(uavtrip.size() - 1).NodeID] / Parameter.EVSpeed;
                // UAV从起飞节点到达第一个中间节点的时间
                double temp_time = takeoffTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[uavtrip.get(0).NodeID][uavtrip.get(1).NodeID] / Parameter.UAVSpeed;
                // 从第一个节点开始，忽略起点，计算到达UAV航线的最后一个节点的时间
                for (int i = 1; i < uavtrip.size() - 1; i++) {
                    Node currentNode = uavtrip.get(i);
                    Node nextNode = uavtrip.get(i + 1);
                    // UAV开始为currentNode节点服务的时间, 等于UAV到达currentNode的时间（加上降落时间）与最早开始时间的最大值
                    double uav_sevice_time_for_currentNode = Math.max(temp_time + Parameter.UAV_landing_time, currentNode.ReadyTime);
                    if (uav_sevice_time_for_currentNode > currentNode.DueTime) { // 如果无人机开始为currentNode服务的时间超过了最晚开始服务时间，则不满足时间窗约束
                        return false;
                    }
                    // UAV从currentNode到达下一个节点的时间，等于开始为currentNode服务的时间加上服务时间和起飞时间，再加上两点之间的距离除以速度，不包括降落时间
                    temp_time = uav_sevice_time_for_currentNode + currentNode.ServiceTime + Parameter.UAV_takeoff_time + Parameter.DisMatrix[currentNode.NodeID][nextNode.NodeID] / Parameter.UAVSpeed;
                }
                uav_arrivaltime_to_landingNode = temp_time;  // UAV到达最后一个节点的时间，不包括降落时间
            }
        }

        // UAV与EV在landingNode节点的交汇时间，如果UAV先到达，可以无限等待EV，但如果EV先到达，UAV不能迟到“太久”
        boolean rendezvous_time_flag = uav_arrivaltime_to_landingNode + Parameter.UAV_landing_time <= Math.max(uavtrip.get(uavtrip.size() - 1).ReadyTime, ev_arrivaltime_to_landingNode) + uavtrip.get(uavtrip.size() - 1).ServiceTime + Parameter.UAV_max_delay_time;
        if (!rendezvous_time_flag) {   // 如果UAV与EV在landingNode节点的交汇时间不满足约束，则不满足约束
            return false;
        }
        // 如果所有约束条件都满足，则返回true

        return true;
    }

}
