public class Node {
    public int NodeID;   // 节点ID
    public double Demand;   // 节点需求量
    public double ReadyTime;   // 需求点最早开始服务时间
    public double ServiceTime;   // 需求点服务时间
    public double DueTime;   // 需求点最晚开始服务时间
    public double x;   // 需求点x坐标
    public double y;   // 需求点y坐标
    public int NodeWithEVID;   // 需求点所属(车队)线路
    public int Position;   // 需求点所在线路中的位置

    public boolean EV_service = false;   // EV来服务该节点
    public boolean UAV_service = false;   // UAV来服务该节点
    public boolean UAV_takeoff_from_here = false;   // UAV从该节点起飞
    public boolean UAV_landing_to_here = false;   // UAV降落到该节点

    public double evArrivalTime=0;   // EV到达该节点的时间
    public double evServiceTime=0;    // EV服务该节点的时间
    public double evDepartureTime=0;  // EV离开该节点的时间
    public double uavArrivalTime=0;   // UAV到达该节点的时间
    public double uavServiceTime =0;  // UAV服务该节点的时间
    public double uavDepartureTime=0;  // UAV离开该节点的时间
    public double bsvArrivalTime_atlatest=0;   // BSV可在该节点服务的最晚时间
    public boolean exchange_battary = false;   // 是否在该节点换电池
    public double bsvArrivalTime_real=0;   // BSV实际到达该节点的时间

   // 无参构造器
    public Node() {
        this.NodeID = 0;
        this.Demand = 0;
        this.ReadyTime = 0;
        this.ServiceTime = 0;
        this.DueTime = 0;
        this.x = 0;
        this.y = 0;
        this.NodeWithEVID = 0;
        this.Position = 0;
    }

    // 有参构造器
    public Node(int NodeID, double Demand, double ReadyTime, double ServiceTime, double DueTime, double x, double y, int NodeWithEVID, int Position) {
        this.NodeID = NodeID;
        this.Demand = Demand;
        this.ReadyTime = ReadyTime;
        this.ServiceTime = ServiceTime;
        this.DueTime = DueTime;
        this.x = x;
        this.y = y;
        this.NodeWithEVID = NodeWithEVID;
        this.Position = Position;
    }

    // 拷贝构造器
    public Node(Node N) {
        this.NodeID = N.NodeID;
        this.Demand = N.Demand;
        this.ReadyTime = N.ReadyTime;
        this.ServiceTime = N.ServiceTime;
        this.DueTime = N.DueTime;
        this.x = N.x;
        this.y = N.y;
        this.NodeWithEVID = N.NodeWithEVID;
        this.Position = N.Position;
    }


}
