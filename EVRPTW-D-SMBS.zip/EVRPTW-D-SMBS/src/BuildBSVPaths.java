import gurobi.GRB;
import gurobi.GRBException;
import gurobi.GRBModel;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class BuildBSVPaths {

    public static void buildBSVPathes(Solution solution) throws GRBException {
        // 如果EV的满能量不足以到达下一个节点，则直接返回
        if (solution.solution_energy_violated) {
            return;
        }

        // 寻找需要进行换电的EV路径,以及可能需要换电的次数的总次数
        int battery_change_times_total = 0;
        ArrayList<Integer> evPathIndex = new ArrayList<>();
        for (int i = 0; i < solution.evPaths.length; i++) {
            EV_Route evRoute = solution.evPaths[i];
            if (evRoute.route.size() <= 2) {  // 如果路径长度小于2，说明只有两个节点，即起点和终点，没有中间节点，直接跳过
                continue;
            }
            if (evRoute.energyConsumption > Parameter.EVEnergy) {  // 如果EV的能量消耗大于EVEnergy，说明EV的能量不足，需要换电
                evPathIndex.add(i); // 将需要换电的EV路径的索引加入到evPathIndex中
                // 计算EV的换电次数，从尾遍历evRoute.energy_consum_travel到头，加和数值直到大于EVEnergy，则换电次数加一，前移一位，重置加和数值，继续遍历
                double sum = 0;
                int battery_change_times = 0;
                for (int j = evRoute.energy_consum_travel.size() - 1; j >= 0; j--) {
                    sum += evRoute.energy_consum_travel.get(j);
                    if (sum > Parameter.EVEnergy) {
                        j++;  // 由于此时j位置的能量消耗已经大于EVEnergy，所以需要将j前移一位，即j+1位置的能量消耗小于EVEnergy，需要换电，
                        battery_change_times++;
                        battery_change_times_total++;
                        sum = 0;
                    }
                }
                evRoute.battery_change_times = battery_change_times;
            }
        }
        // 计算可能需要构建BSV路径的总数  等于 battery_change_times_total / Parameter.BSVCapacity 向上取整
        int BSVPathNum = (int) Math.ceil((double) battery_change_times_total / (double) Parameter.BSVCapacity);
        if (BSVPathNum == 0) {  // 如果BSV路径数量为0，说明不需要换电，直接返回
            BSV_Route[] bsvPaths = solution.bsvPaths;
            for (int i = 0; i < solution.bsvPaths.length; i++) {
                bsvPaths[i] = new BSV_Route();
            }
            // 跟新solution的相关信息
            solution.cost_BSV = 0;
            return;
        }
        if (BSVPathNum > Parameter.BSVNumber) {
            System.out.println("BSV路径数量不足，无法完成换电");
            BSVPathNum = Parameter.BSVNumber;
        }

        // 尝试对EV路径进行换电，构建BSV路径。
        ArrayList<List<Node>> battery_change_nodes_group = new ArrayList<>();    // 存储每次的换电节点组合，每个元素是一个List<Node>，表示一个换电节点组合
        ArrayList<Double> battery_change_nodes_group_cost = new ArrayList<>();    // 存储每次换电节点组合的成本
        ArrayList<List<List<Node>>> battery_change_nodes_group_bsvpaths = new ArrayList<>();    // 存储每次换电节点组合的最优BSV路径
        // 1. 首先在需要换电的EV路径中随机选择battery_change_times个可以合法完成换电的节点
        // ************************************************************
        // 循环100次，每次随机选择一个换电节点组合    (后续可以考虑使用启发式算法)
        int count = 0;
        while (count < 100) {
            ArrayList<Node> change_battery_nodes = new ArrayList<>();
            count++;
//            System.out.println("第" + count + "次尝试");
            for (int i = 0; i < evPathIndex.size(); i++) {
                EV_Route evRoute = solution.evPaths[evPathIndex.get(i)];
                // 随机选择evRoute.battery_change_times个节点进行换电
                List<Node> temp = random_select_change_battery_nodes(evRoute);
                change_battery_nodes.addAll(temp);
            }
            ArrayList<Node> test_nodes = new ArrayList<>();
            test_nodes.addAll(change_battery_nodes);
            // 检查 test_nodes 是否有重复的节点
            for (int i = 0; i < test_nodes.size(); i++) {
                for (int j = i + 1; j < test_nodes.size(); j++) {
                    if (test_nodes.get(i).NodeID == test_nodes.get(j).NodeID) {
                        System.out.println("change_battery_nodes中有重复的节点");
                    }
                }
            }

            // 将change_battery_nodes中的节点根据NodeID从小到大排序
            for (int i = 0; i < change_battery_nodes.size(); i++) {
                for (int j = i + 1; j < change_battery_nodes.size(); j++) {
                    if (change_battery_nodes.get(i).NodeID > change_battery_nodes.get(j).NodeID) {
                        Node temp = change_battery_nodes.get(i);
                        change_battery_nodes.set(i, change_battery_nodes.get(j));
                        change_battery_nodes.set(j, temp);
                    }
                }
            }


            // 将change_battery_nodes加入到battery_change_nodes_group中，表示一次换电节点组合（注意排他性，即不会出现重复的换电节点组合）
            // 如果count == 1 ，则将change_battery_nodes加入到battery_change_nodes_group中
            if (count == 1) {
                battery_change_nodes_group.add(change_battery_nodes);
            } else {
                // 1.1 检查change_battery_nodes是否已经存在于battery_change_nodes_group中，根据节点的NodeID进行比较
                boolean flag = false;
                for (List<Node> nodes : battery_change_nodes_group) {
                    if (nodes.size() != change_battery_nodes.size()) {
                        continue;
                    }
                    flag = true;    // 假设两个换电节点组合中的节点编号一致
                    for (int i = 0; i < nodes.size(); i++) {
                        if (nodes.get(i).NodeID != change_battery_nodes.get(i).NodeID) {   // 如果两个换电节点组合中的节点编号不一致，则继续比较下一个换电节点组合
                            flag = false;      // 两个换电节点组合中的节点编号不一致
                            break;
                        }
                    }
                    if (flag) {      // 两个换电节点组合中的节点编号一致,则跳出循环
                        break;
                    }
                }
                // 1.2 若change_battery_nodes不存在于battery_change_nodes_group中，则将其加入到battery_change_nodes_group中
                if (!flag) {
                    battery_change_nodes_group.add(change_battery_nodes);
                }
            }
        }

        // 2. 对每个换电节点组合，求解模型，找出成本最小的换电节点组合
        if (Parameter.batterySwapInfos.size() == 0) {   // 如果全局的换电组合信息为空，则直接使用Gurobi求解模型，并将结果加入其中
            for (List<Node> nodes : battery_change_nodes_group) {
                ArrayList<Node> input_nodes = new ArrayList<>();  // 用于存储换电节点组合中的节点
                input_nodes.addAll(nodes);
                SolveByGurobi solver = new SolveByGurobi(input_nodes);
                MultipleResults results = solver.solveModel();
                // 将solver对象的内存释放
                solver = null;
                // 如果results 不为空
                if (results != null) {
                    double cost = results.objValue;
                    battery_change_nodes_group_cost.add(cost);
                    battery_change_nodes_group_bsvpaths.add(results.bsvPaths);
                    // 将换电组合信息加入到全局的换电组合信息中
                    BatterySwapInfo batterySwapInfo = new BatterySwapInfo(nodes, results.bsvPaths, results.objValue);
                    Parameter.batterySwapInfos.add(batterySwapInfo);
                }
            }
        } else {   //如果全局的换电组合信息非空，则先进行比对，若存在则直接使用，若不存在则使用Gurobi求解模型，并将结果加入其中
            for (List<Node> nodes : battery_change_nodes_group) {
                // 与全局的换电组合信息进行比对，如果存在则返回index，否则返回-1
                int index = checkBatteryChangeNodesGroupExist(nodes);
//                System.out.println("index = " + index);
                if (index != -1) {   // 如果存在，则判断是否可以直接使用
                    boolean flag = checkBSVPathFeasible(Parameter.batterySwapInfos.get(index).BatterySwapNodesPath);
                    if (flag) {   // 如果可以直接使用，则将其加入到battery_change_nodes_group_cost和battery_change_nodes_group_bsvpaths中
                        battery_change_nodes_group_cost.add(Parameter.batterySwapInfos.get(index).BatterySwapNodesCost);
                        battery_change_nodes_group_bsvpaths.add(Parameter.batterySwapInfos.get(index).BatterySwapNodesPath);

                    } else {
                        // 如果不可行，则使用Gurobi求解模型，并将结果加入其中
                        ArrayList<Node> input_nodes = new ArrayList<>();  // 用于存储换电节点组合中的节点
                        input_nodes.addAll(nodes);
                        SolveByGurobi solver = new SolveByGurobi(input_nodes);
                        MultipleResults results = solver.solveModel();
                        // 将solver对象的内存释放
                        solver = null;
                        // 如果results 不为空
                        if (results != null) {
                            double cost = results.objValue;
                            battery_change_nodes_group_cost.add(cost);
                            battery_change_nodes_group_bsvpaths.add(results.bsvPaths);
//                        // 将换电组合信息加入到全局的换电组合信息中
//                        BatterySwapInfo batterySwapInfo = new BatterySwapInfo(nodes, results.bsvPaths, results.objValue);
////                        Parameter.batterySwapInfos.add(batterySwapInfo);
                        }
                    }
                } else {   // 如果不存在，则使用Gurobi求解模型，并将结果加入其中
                    ArrayList<Node> input_nodes = new ArrayList<>();  // 用于存储换电节点组合中的节点
                    input_nodes.addAll(nodes);
                    SolveByGurobi solver = new SolveByGurobi(input_nodes);
                    MultipleResults results = solver.solveModel();
                    // 将solver对象的内存释放
                    solver = null;
                    // 如果results 不为空
                    if (results != null) {
                        double cost = results.objValue;
                        battery_change_nodes_group_cost.add(cost);
                        battery_change_nodes_group_bsvpaths.add(results.bsvPaths);
                        // 将换电组合信息加入到全局的换电组合信息中
                        BatterySwapInfo batterySwapInfo = new BatterySwapInfo(nodes, results.bsvPaths, results.objValue);
                        Parameter.batterySwapInfos.add(batterySwapInfo);
                    }
                }

            }
        }

        // 找出成本最小的换电节点组合
        double min_cost = Double.MAX_VALUE;
        int min_index = -1;
        for (int i = 0; i < battery_change_nodes_group_cost.size(); i++) {
            if (battery_change_nodes_group_cost.get(i) < min_cost) {
                min_cost = battery_change_nodes_group_cost.get(i);
                min_index = i;
            }
        }
        if(min_index == -1){
            System.out.println("min_index = -1");
            solution.cost_BSV = 1000000;
        }else {
            // 将成本最小的换电节点组合对应的模型，即最优解，加入到solution中
            List<List<Node>> bsvpaths = battery_change_nodes_group_bsvpaths.get(min_index);
            BSV_Route[] bsvPaths = solution.bsvPaths;
            for (int i = 0; i < bsvpaths.size(); i++) {
                bsvPaths[i] = new BSV_Route();
//                bsvPaths[i].route = (ArrayList<Node>) bsvpaths.get(i);   // 这样赋值是浅拷贝，会导致solution.bsvPaths[i].route和battery_change_nodes_group_bsvpaths.get(min_index).get(i)指向同一个对象，修改一个会影响另一个
                // 需要进行深拷贝
                bsvPaths[i].route = new ArrayList<>();
                for (Node node : bsvpaths.get(i)) {
                    bsvPaths[i].route.add(node);
                }
            }
            for (int i = bsvpaths.size(); i < bsvPaths.length; i++) {
                bsvPaths[i] = new BSV_Route();
            }
            // 跟新solution的相关信息
            solution.cost_BSV = min_cost;

        }

        // ************************************************************

    }


    // 在需要换电的EV路径中随机选择battery_change_times个可以合法完成换电的节点
    public static List<Node> random_select_change_battery_nodes(EV_Route evRoute) {
        // 随机选择evRoute.battery_change_times个节点进行换电
        List<Node> change_battery_nodes = new ArrayList<>();
        boolean flag = false;  // 标记这种随机选择是否合法
        int[] randomIndex = new int[evRoute.battery_change_times];
        while (!flag) {
            // 随机选择evRoute.battery_change_times个节点,不能是起点和终点,不能重复
            for (int i = 0; i < evRoute.battery_change_times; i++) {
                int tempIndex = Calculate_Tool.IntRandom(1, evRoute.route.size() - 1);  // 选择的节点不能是起点和终点
                boolean flag1 = false; // 标记选择的节点是否重复
                for (int j = 0; j < i; j++) {   // 检查选择的节点是否重复,若重复则重新选择
                    if (randomIndex[j] == tempIndex) {
                        i--;
                        flag1 = true;
                        break;
                    }
                }
                if (flag1) {
                    continue;
                }
                randomIndex[i] = tempIndex;
            }
            // 检查选择的换电节点是否合法
            flag = check_change_battery_nodes(evRoute, randomIndex);
        }
        // 如果选择的换电节点合法，则将这些节点加入到change_battery_nodes中
        for (int i = 0; i < randomIndex.length; i++) {
            change_battery_nodes.add(evRoute.route.get(randomIndex[i]));
        }
        // 检查 change_battery_nodes 是否有重复的节点
        for (int i = 0; i < change_battery_nodes.size(); i++) {
            for (int j = i + 1; j < change_battery_nodes.size(); j++) {
                if (change_battery_nodes.get(i).NodeID == change_battery_nodes.get(j).NodeID) {
                    System.out.println("change_battery_nodes中有重复的节点");
                }
            }
        }
        return change_battery_nodes;
    }

    // 检查选择的换电节点是否合法
    public static boolean check_change_battery_nodes(EV_Route evRoute, int[] randomIndex) {
        // 将randomIndex数组的元素值从小到大排序
        for (int i = 0; i < randomIndex.length; i++) {
            for (int j = i + 1; j < randomIndex.length; j++) {
                if (randomIndex[i] > randomIndex[j]) {
                    int temp = randomIndex[i];
                    randomIndex[i] = randomIndex[j];
                    randomIndex[j] = temp;
                }
            }
        }
        // 检查选择的换电节点是否合法
        boolean flag = true;
        // 根据randomIndex数组的元素值，将evRoute.route.energy_consum_travel数组的元素划分为 randomIndex.length + 1 个子数组
        // 计算每个子数组的和，若有子数组的和大于EVEnergy，则flag = false
        int[] sum = new int[randomIndex.length + 1];

        for (int i = 0; i < randomIndex.length; i++) {
            if (i == 0) {
                for (int j = 0; j < randomIndex[i]; j++) {
                    sum[i] += evRoute.energy_consum_travel.get(j);
                }
            } else {
                for (int j = randomIndex[i - 1]; j < randomIndex[i]; j++) {
                    sum[i] += evRoute.energy_consum_travel.get(j);
                }
            }
        }
        for (int i = randomIndex[randomIndex.length - 1]; i < evRoute.energy_consum_travel.size(); i++) {
            sum[randomIndex.length] += evRoute.energy_consum_travel.get(i);
        }
        for (int i = 0; i < sum.length; i++) {
            if (sum[i] > Parameter.EVEnergy) {
                flag = false;
                break;
            }
        }

        return flag;
    }

    // 对于当前的换电节点组合，判断是否已经被求解过，如果已有则返回index，否则返回-1
    public static int checkBatteryChangeNodesGroupExist(List<Node> change_battery_nodes) {
        boolean flag = false;
        for (int index = 0; index < Parameter.batterySwapInfos.size(); index++) {
            BatterySwapInfo batterySwapInfo = Parameter.batterySwapInfos.get(index);
            if (batterySwapInfo.BatterySwapNodes.size() != change_battery_nodes.size()) {
                continue;
            }
            flag = true;    // 假设两个换电节点组合中的节点编号一致
            for (int i = 0; i < batterySwapInfo.BatterySwapNodes.size(); i++) {
                if (batterySwapInfo.BatterySwapNodes.get(i).NodeID != change_battery_nodes.get(i).NodeID) {   // 如果两个换电节点组合中的节点编号不一致，则继续比较下一个换电节点组合
                    flag = false;      // 两个换电节点组合中的节点编号不一致
                    break;
                }
            }
            if (flag) {      // 两个换电节点组合中的节点编号一致,则返回index
                return index;
            }
        }
        return -1;   // 如果没有找到，则返回-1
    }

    // 检查BSV路径是否可行，根据已求解的最优路径，基于最新的相关节点的时间信息，检查BSV路径是否可行
    public static boolean checkBSVPathFeasible(List<List<Node>> bsvpaths) {
        boolean flag = true;
        for (List<Node> route : bsvpaths) {
            double[] arriveTime = new double[route.size()];  // bsv路径中各节点的到达时间
            double[] changeTime = new double[route.size()];  // bsv路径中各节点的换电时间
            double[] leaveTime = new double[route.size()];   // bsv路径中各节点的离开时间
            // 检查BSV路径的时间窗约束
            for (int i = 0; i < route.size(); i++) {
                if (i == 0) {   // 第一个节点
                    arriveTime[i] = 0;
                    changeTime[i] = 0;
                    leaveTime[i] = 0;
                } else {   // 其他节点
                    // BSV到达时间 = 上一个节点的离开时间 + 两节点之间的距离
                    arriveTime[i] = leaveTime[i - 1] + Parameter.DisMatrix[route.get(i - 1).NodeID][route.get(i).NodeID];
                    // 换电时间 = BSV到达时间和EV到达时间的最大值
                    changeTime[i] = Math.max(arriveTime[i], route.get(i).evArrivalTime);
                    // BSV离开时间 = 换电时间 + 服务时间
                    leaveTime[i] = changeTime[i] + Parameter.exchange_battery_time;
                    // 检查换电时间是否满足时间窗约束: BSV的换电时间最晚不能超过规定的最晚时间

                    if (changeTime[i] > route.get(i).bsvArrivalTime_atlatest && i != route.size() - 1) {  // 如果换电时间超过最晚时间，则不可行
                        return false;
                    }
                }
            }
        }
        return flag;
    }
}
