// 设计局部搜索策略，得到更优的单条 卡车-无人机联合路径
public class LocalSearch {

}
