import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Calculate_Tool {

    // 计算无人机起飞的能耗
    public static double Calculate_UAV_Takeoff_Energy(double UAV_Takeoff_Weight) {
        return Parameter.UAV_consume_takeoff * UAV_Takeoff_Weight;
    }

    // 计算无人机降落的能耗
    public static double Calculate_UAV_Landing_Energy(double UAV_Landing_Weight) {
        return Parameter.UAV_consume_landing * UAV_Landing_Weight;
    }

    // 计算无人机的飞行能耗
    public static double Calculate_UAV_Travel_Energy(double UAV_Travel_Weight, double UAV_Travel_Distance) {
        return Parameter.UAV_consume_travel * UAV_Travel_Weight * UAV_Travel_Distance;
    }

    // 计算EV的行驶能耗
    public static double Calculate_EV_Travel_Energy(double EV_Travel_Weight, double EV_Travel_Distance) {
        return Parameter.EV_consume_travel * EV_Travel_Weight * EV_Travel_Distance;
    }

    // 计算BSV的行驶能耗
    public static double Calculate_BSV_Travel_Energy(double BSV_Travel_Weight, double BSV_Travel_Distance) {
        return Parameter.BSV_consume_travel * BSV_Travel_Weight * BSV_Travel_Distance;
    }

    //生成节点距离矩阵
    public static void generateDisMatrix() {
        for (int i = 0; i < Parameter.NodeNumber + 1; i++) {
            for (int j = 0; j < Parameter.NodeNumber + 1; j++) {
                Parameter.DisMatrix[i][j] = Math.sqrt(Math.pow(Parameter.All_NodeList[i].x - Parameter.All_NodeList[j].x, 2) + Math.pow(Parameter.All_NodeList[i].y - Parameter.All_NodeList[j].y, 2));
            }
        }
    }

    // 更新解的信息
    public static void updateSolutionMetrics(Solution solution) {
        // 更新解的信息
        solution.solution_overcapicity_all = 0;
        solution.solution_overtime_all = 0;
        solution.isFeasible = false;
        solution.totalEnergy = 0;
        solution.totalCost = 0;
        solution.solution_energy_violated = false;
        solution.cost_EVandUAV = 0;
        solution.solution_battery_change_times = 0;

        // 更新EV路径的信息
        for (EV_Route evRoute : solution.evPaths) {
            Calculate_Tool.updateEVRoutesMetrics(evRoute);
            if (evRoute.total_load > Parameter.EVCapacity) {
                solution.solution_overcapicity_all += evRoute.total_load - Parameter.EVCapacity;
            }
            if (evRoute.energy_violated) {
                solution.solution_energy_violated = true;
            }
            solution.solution_overtime_all += evRoute.violationTime;
            solution.solution_battery_change_times += evRoute.battery_change_times;
        }
        // 更新BSV路径的信息
        // 待实现

    }


    // 更新EV路径的距离、能耗、到达时间等信息
    public static void updateEVRoutesMetrics(EV_Route evRoute) {   // 存在一个小问题，就是在各个路径的节点的时间计算中，仓库节点和虚拟仓库节点的相关时间在每辆路径中实际上是不同的，但此处存储的是与最后一条路径相关的时间，这个问题可以在后续的优化中解决！！！

        evRoute.energy_consum_travel.clear();
        evRoute.energy_consum_uavtrip.clear();
        evRoute.weight_travel.clear();
        evRoute.energy_violated = false;
        evRoute.total_load = 0;
        evRoute.energyConsumption = 0;
        evRoute.distance = 0;
        evRoute.violationTime = 0;
        evRoute.energyConsumption_uav = 0;
        evRoute.battery_change_times = 0;

        // 将EV路径中的每个节点的到达时间和服务时间等信息重置为0
        for (Node node : evRoute.route) {
            node.evArrivalTime = 0;
            node.evServiceTime = 0;
            node.evDepartureTime = 0;
            node.uavArrivalTime = 0;
            node.uavServiceTime = 0;
            node.uavDepartureTime = 0;
            node.EV_service = false;
            node.UAV_service = false;
            node.UAV_takeoff_from_here = false;
            node.UAV_landing_to_here = false;
            node.bsvArrivalTime_atlatest = 0;
            node.exchange_battary = false;
            node.bsvArrivalTime_real = 0;

        }
        // 将EV的UAV航线中的每个节点的到达时间和服务时间等信息重置为0
        for (List<Node> uavTrip : evRoute.uavTrips) {
            for (Node node : uavTrip) {
                node.evArrivalTime = 0;
                node.evServiceTime = 0;
                node.evDepartureTime = 0;
                node.uavArrivalTime = 0;
                node.uavServiceTime = 0;
                node.uavDepartureTime = 0;
                node.EV_service = false;
                node.UAV_service = false;
                node.UAV_takeoff_from_here = false;
                node.UAV_landing_to_here = false;
                node.bsvArrivalTime_atlatest = 0;
                node.exchange_battary = false;
                node.bsvArrivalTime_real = 0;
            }
        }
        // 根据EV路径和其所属的UAV的航线，更新节点的 EV_service UAV_service UAV_takeoff_from_here UAV_landing_to_here 等信息
        // 遍历EV路径中的每个节点,除去起点和终点
        for (int i = 1; i < evRoute.route.size() - 1; i++) {
            evRoute.route.get(i).EV_service = true;  // EV服务该节点
            evRoute.route.get(i).UAV_service = false;  // UAV不服务该节点
        }
        // 遍历EV的UAV航线中的每个节点
        for (List<Node> uavTrip : evRoute.uavTrips) {
            for (int i = 0; i < uavTrip.size(); i++) {
                if (i == 0) {  // 对于起始节点（即起飞节点）
                    uavTrip.get(i).UAV_takeoff_from_here = true;  // UAV从该节点起飞
                } else if (i == uavTrip.size() - 1) {  // 对于终点（即降落节点）
                    uavTrip.get(i).UAV_landing_to_here = true;  // UAV降落到该节点
                } else {  // 对于中间节点
                    uavTrip.get(i).UAV_service = true;  // UAV服务该节点
                    uavTrip.get(i).EV_service = false;  // EV不服务该节点
                }
            }
        }

        boolean takeoff_depot = false;  // 记录在当前的EV中，其所属的UAV是否从仓库起飞

        for (int i = 0; i < evRoute.route.size(); i++) {   // 遍历EV路径中的每个节点
            if (evRoute.route.size() <= 2) {   // 如果EV路径中只有两个节点，直接跳过
                break;
            }
            Node currentNode = evRoute.route.get(i);     // 获取当前节点

            if (i == 0) {
                // 对于起始节点（通常是配送中心），EV的到达时间通常为0，服务时间也为0
                currentNode.evArrivalTime = 0;
                currentNode.evServiceTime = 0;
                if (evRoute.uavTrips.size() > 0) {  // 如果EV配备的无人机的航线不为空
                    if (evRoute.uavTrips.get(0).get(0).NodeID == 0) {   //考虑了如果EV配备的无人机在仓库起飞，需要装载货物的时间
                        currentNode.evDepartureTime = Parameter.equip_UAV_time;
                        takeoff_depot = true;  // 记录在当前的EV中，其所属的UAV从仓库起飞
                        updateUAVTripMetrics(evRoute.uavTrips.get(0), evRoute);  // 更新UAV的该程从仓库起飞航线的到达时间和服务时间等信息

                    } else {   //如果EV配备的无人机没有在在仓库起飞，则EV离开仓库时间为0
                        currentNode.evDepartureTime = 0;
                    }
                }

            } else {       // 对于其他节点
                if (i == 1) {  // EV从仓库出发到达的第一个客户节点
                    Node previousNode = evRoute.route.get(0);  // 获取上一个节点
                    // 计算从上一个节点到当前节点的行驶时间
                    double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.EVSpeed;
                    // 设置当前节点的到达时间
                    currentNode.evArrivalTime = previousNode.evDepartureTime + travelTime;  // 更新到达当前节点的时间，等于上一个节点的开始服务时间 + 服务时间 + 行驶时间
                } else {   // 对于其他节点,即中间节点（除去第一个服务客户节点）和最后一个节点（即虚拟终点）
                    Node previousNode = evRoute.route.get(i - 1);  // 获取上一个节点
                    // 计算从上一个节点到当前节点的行驶时间
                    double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.EVSpeed;
                    // 设置当前节点的到达时间
                    currentNode.evArrivalTime = previousNode.evDepartureTime + travelTime;  // 更新到达当前节点的时间，等于上一个节点的开始服务时间 + 服务时间 + 行驶时间
                }

                // 如果当前节点到达时间早于其最早服务时间，则EV需要等待，服务时间为ReadyTime
                if (currentNode.evArrivalTime < currentNode.ReadyTime) {
                    currentNode.evServiceTime = currentNode.ReadyTime;
                } else {
                    currentNode.evServiceTime = currentNode.evArrivalTime;  // 否则，立即开始服务
                }

                // 设置当前节点的离开时间
                if (currentNode.UAV_takeoff_from_here) {   // 如果当前节点是UAV的起飞节点,则EV的离开时间需要分情况讨论，可能需要等待UAV起飞才能离开
                    // 确定当前节点是UAV的第几程航线的起飞节点
                    int uavTripIndex = 0;
                    for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                        if (evRoute.uavTrips.get(j).get(0).NodeID == currentNode.NodeID) {
                            uavTripIndex = j;
                            break;
                        }
                    }
                    boolean delta = updateUAVTripMetrics(evRoute.uavTrips.get(uavTripIndex), evRoute);  // 更新UAV的该程航线的到达时间和服务时间等信息,并判断是否可以先进行无人机的准备工作
                    if (delta == true) {  //EV在当前节点处发射无人机，且在为客户开始服务前就完成了
                        // 设置当前节点的离开时间，等于当前节点的开始服务时间 + 服务时间
                        currentNode.evDepartureTime = currentNode.evServiceTime + currentNode.ServiceTime;
                    } else {           //EV在当前节点处发射无人机，但在为客户完成服务后才开始
                        // 设置当前节点的离开时间，等于当前节点的服务结束时间与无人机到达时间的最大值 + 装备无人机时间
                        currentNode.evDepartureTime = Math.max(currentNode.evServiceTime + currentNode.ServiceTime, currentNode.uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time;
                    }
                } else {  // 如果当前节点不是UAV的起飞节点
                    // 设置当前节点的离开时间，等于当前节点的服务结束时间与无人机到达时间的最大值
                    currentNode.evDepartureTime = Math.max(currentNode.evServiceTime + currentNode.ServiceTime, currentNode.uavArrivalTime + Parameter.UAV_landing_time);
                }

                // 设置BSV到达节点的最晚时间，等于当前节点的离开时间 - 换电服务时间
                 // 在实际实现时需要设定一个强假设！！即：t_b <=  t_e 恒成立
                currentNode.bsvArrivalTime_atlatest = currentNode.evDepartureTime - Parameter.exchange_battery_time;

                // 检查是否违反了时间窗约束
                if (currentNode.evServiceTime > currentNode.DueTime) {
                    evRoute.violationTime += currentNode.evServiceTime - currentNode.DueTime;  // 记录违反时间窗的时间
                    // 可以在这里处理超时的情况，例如记录日志或调整路径
                }

            }

        }

        // 计算EV路径的能耗，即EV的行驶能耗，首先需要计算的便是EV在路径上各节点上的载重，然后根据载重计算能耗，
        // 由于在我们的模型中考虑了无人机的重量，故当无人机被携带时，EV的载重需要加上无人机的重量
        ArrayList<Double> weight_ev = new ArrayList<>();  // 记录EV在路径上各节点上的载重

        // 首先计算EV离开仓库时的载重
        if (takeoff_depot) {  // 如果EV所属的UAV从仓库起飞，不需要加上无人机的重量，并减去此次行程所携带的包裹重量
            double temp_load = 0;
            for (int j = 1; j < evRoute.route.size() - 1; j++) {  // 加和EV路径中的每个节点的需求量
                temp_load += evRoute.route.get(j).Demand;
            }
            if (evRoute.uavTrips.size() > 1) {  // 如果EV配备的无人机的航线不止一程
                for (int j = 1; j < evRoute.uavTrips.size(); j++) {  // 加和每程无人机的载重量，除了第一程，因为从仓库起飞的无人机的载重量不需要计算
                    for (int k = 1; k < evRoute.uavTrips.get(j).size() - 1; k++) {  // 剔除无人机的起飞和降落节点
                        temp_load += evRoute.uavTrips.get(j).get(k).Demand;
                    }
                }
            }
            weight_ev.add(temp_load);  // 记录EV在路径上各节点上的载重
            evRoute.total_load = temp_load;  // EV路径的总载重量
        } else {    // 无人机不从仓库发射的情况，则需要加上无人机的重量
            double temp_load = 0;
            for (int j = 1; j < evRoute.route.size() - 1; j++) {  // 加和EV路径中的每个节点的需求量
                temp_load += evRoute.route.get(j).Demand;
            }
            if (evRoute.uavTrips.size() > 0) {  // 如果EV配备的无人机的航线不为空
                for (int j = 0; j < evRoute.uavTrips.size(); j++) {  // 加和每程无人机的载重量
                    for (int k = 1; k < evRoute.uavTrips.get(j).size() - 1; k++) {  // 剔除无人机的起飞和降落节点
                        temp_load += evRoute.uavTrips.get(j).get(k).Demand;
                    }
                }
            }
            temp_load = temp_load + Parameter.UAV_weight;  // 加上无人机的重量
            weight_ev.add(temp_load);  // 记录EV在路径上各节点上的载重
            evRoute.total_load = temp_load; // 记录EV路径的总载重量
        }
        // 计算EV在路径上各节点上的载重
        for (int i = 1; i < evRoute.route.size(); i++) {
            Node currentNode = evRoute.route.get(i);  // 获取当前节点
            double temp_load = weight_ev.get(i - 1) - currentNode.Demand;  // 更新当前节点的载重量, 减去当前节点的需求量
            // 微调载重量，根据当前节点的情况，可能需要加上无人机的重量或减去无人机的载重量，以及无人机的载重量
            if (currentNode.UAV_takeoff_from_here) {  // 如果当前节点是UAV的起飞节点
                // 确定当前节点是UAV的第几程航线的起飞节点
                int uavTripIndex = 0;
                for (int j = 0; j < evRoute.uavTrips.size(); j++) {
                    if (evRoute.uavTrips.get(j).get(0).NodeID == currentNode.NodeID) {
                        uavTripIndex = j;
                        break;
                    }
                }
                double trip_load = 0;
                for (int j = 1; j < evRoute.uavTrips.get(uavTripIndex).size() - 1; j++) {  // 加和无人机的载重量，除了起飞和降落节点
                    trip_load += evRoute.uavTrips.get(uavTripIndex).get(j).Demand;
                }
                // 更新当前节点的载重量, 减去无人机的载重量、无人机的重量
                temp_load = temp_load - trip_load - Parameter.UAV_weight;
            }
            if (currentNode.UAV_landing_to_here) {  // 如果当前节点是UAV的降落节点
                // 更新当前节点的载重量, 加上无人机的重量
                temp_load = temp_load + Parameter.UAV_weight;
            }
            weight_ev.add(temp_load);  // 记录EV在路径上各节点上的载重
        }
        evRoute.weight_travel = weight_ev;  // 记录EV在路径上各节点上的载重

        // 计算EV在路径上各节点上的能耗
        ArrayList<Double> energy_ev = new ArrayList<>();  // 记录EV在路径上各节点上的能耗
//        ArrayList<Integer>  energy_exhaust_index = new ArrayList<>();  // 记录EV在路径上能量耗尽的节点的索引

        for (int i = 0; i < evRoute.route.size(); i++) {
            Node currentNode = evRoute.route.get(i);  // 获取当前节点
            if (i == 0) {  // 对于起始节点（即起飞节点），不需要计算能耗
                continue;
            }
            Node previousNode = evRoute.route.get(i - 1);  // 获取上一个节点
            // 计算从上一个节点到当前节点的行驶时间
            double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.EVSpeed;
            // 计算EV的行驶能耗
            double travelEnergy = Calculate_EV_Travel_Energy(weight_ev.get(i - 1) + Parameter.EV_weight, travelTime);
            if (travelEnergy > Parameter.EVEnergy) {  // EV的满能量不足以到达下一个节点
                evRoute.energy_violated = true;
            }
            energy_ev.add(travelEnergy);  // 记录EV在路径上各节点上的能耗
            evRoute.energyConsumption += travelEnergy;  // 更新EV路径的能耗
            evRoute.distance += Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID];  // 更新EV路径的距离
        }
        evRoute.energy_consum_travel = energy_ev;  // 记录EV在路径上各节点上的能耗

        //计算UAV航程的能耗
        for (List<Node> uavTrip : evRoute.uavTrips) {
            double energy_uav = 0;
            energy_uav = Calculate_Tool.calculate_uavtrip_energy(uavTrip);
            evRoute.energy_consum_uavtrip.add(energy_uav);  // 记录UAV的能耗
            evRoute.energyConsumption_uav += energy_uav;  // 更新EV路径的UAV的能耗
        }

        // 预估换电次数
        if(!evRoute.energy_violated){
            if (evRoute.energyConsumption > Parameter.EVEnergy) {  // 如果EV的能量消耗大于EVEnergy，说明EV的能量不足，需要换电
                // 计算EV的换电次数，从尾遍历evRoute.energy_consum_travel到头，加和数值直到大于EVEnergy，则换电次数加一，前移一位，重置加和数值，继续遍历
                double sum = 0;
                int battery_change_times = 0;
                for (int j = evRoute.energy_consum_travel.size() - 1; j >= 0; j--) {
                    sum += evRoute.energy_consum_travel.get(j);
                    if (sum > Parameter.EVEnergy) {
                        j++;  // 由于此时j位置的能量消耗已经大于EVEnergy，所以需要将j前移一位，即j+1位置的能量消耗小于EVEnergy，需要换电，
                        battery_change_times++;
                        sum = 0;
                    }
                }
                evRoute.battery_change_times = battery_change_times;
            }
        }
    }


    //更新EV所属的UAV的航线的到达时间和服务时间等信息
    public static boolean updateUAVTripMetrics(List<Node> uavTrip, EV_Route evRoute) {
        boolean delta = false;  // 用于判断是否可以先进行无人机的准备工作
        for (int j = 0; j < uavTrip.size(); j++) {
            Node currentNode = uavTrip.get(j);  // 获取当前节点

            if (j == 0) {  // 对于起始节点（即起飞节点），该节点由EV服务，故UAV的服务时间默认设置为0，而UAV的到达时间则分情况讨论
                currentNode.uavServiceTime = 0;
                if (currentNode.uavArrivalTime == 0) {  // 如果当前节点的UAV到达时间不为0，则直接使用该时间，表示UAV飞回该节点；否则，使用EV的到达时间，表示UAV被EV携带到该节点
                    currentNode.uavArrivalTime = currentNode.evArrivalTime - Parameter.UAV_landing_time;  // (因为到达时间没包括降落时间，但这种情形下不需要降落回收，所以提前进行“处理”)
                }
                // 如果起飞节点是仓库节点，这种情形下本身就不需要降落回收，所以需要进行“处理”
                if (currentNode.NodeID == 0) {
                    currentNode.uavArrivalTime = - Parameter.UAV_landing_time;
                }

            } else if (j == 1) { // 对于第二个节点（即服务客户节点），需要判断UAV在起飞节点的可以开始新航线的时间，即确定是否可以先进行无人机的准备工作
                Node previousNode = uavTrip.get(0);  // 获取上一个节点，此时上一个节点就为起飞节点
                if (previousNode.NodeID == 0) {     //无人机从仓库出发的情况
                    // 计算从上一个节点到当前节点的行驶时间
                    double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                    // 设置当前节点的到达时间,等于上一个节点的到达时间+无人机准备时间+无人机起飞时间+两点之间的距离/无人机速度 ； 不包含降落时间
                    currentNode.uavArrivalTime =  Parameter.equip_UAV_time + Parameter.UAV_takeoff_time + travelTime;
                } else {   //无人机从客户节点出发的情况, 需要确定是否可以先进行无人机的准备工作
                    double temp = previousNode.ReadyTime - Math.max(previousNode.evArrivalTime, previousNode.uavArrivalTime + Parameter.UAV_landing_time) - Parameter.equip_UAV_time;
                    delta = temp >= 0;  // 判断是否可以先进行无人机的准备工作,值为true表示可以，值为false表示不可以
                    if (delta) {  // 可以先进行无人机的准备工作
                        // 计算从上一个节点到当前节点的行驶时间
                        double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                        // 计算从起飞节点起飞的时间，等于EV到达时间和无人机到达时间的最大值+无人机准备时间
                        double takeoffTime = Math.max(previousNode.evArrivalTime, previousNode.uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time;
                        // 设置当前节点的到达时间, 等于起飞时间+无人机起飞时间+两点之间的距离/无人机速度 ； 不包含降落时间
                        currentNode.uavArrivalTime = takeoffTime + Parameter.UAV_takeoff_time + travelTime;

                    } else {   // 不能先进行无人机的准备工作，即EV先服务客户，再装备UAV
                        double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                        // 计算从起飞节点起飞的时间，等于EV服务结束时间和无人机到达时间的最大值+无人机准备时间
                        double takeoffTime = Math.max(previousNode.evServiceTime + previousNode.ServiceTime, previousNode.uavArrivalTime + Parameter.UAV_landing_time) + Parameter.equip_UAV_time;
                        // 设置当前节点的到达时间, 等于起飞时间+无人机起飞时间+两点之间的距离/无人机速度 ； 不包含降落时间
                        currentNode.uavArrivalTime = takeoffTime + Parameter.UAV_takeoff_time + travelTime;
                    }
                }
            } else {  // 对于其他节点，即中间节点（除去第一个服务客户节点）和降落节点
                Node previousNode = uavTrip.get(j - 1);  // 获取上一个节点
                // 计算从上一个节点到当前节点的行驶时间
                double travelTime = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID] / Parameter.UAVSpeed;
                // 设置到达当前节点的时间，等于上一个节点的开始服务时间 + 服务时间 + 无人机起飞时间 + 行驶时间 , 不包含降落时间
                currentNode.uavArrivalTime = previousNode.uavServiceTime + previousNode.ServiceTime + Parameter.UAV_takeoff_time + travelTime;

            }
            // 如果当前节点到达时间早于其最早服务时间，则UAV需要等待，服务时间为ReadyTime
            if (currentNode.uavArrivalTime + Parameter.UAV_landing_time < currentNode.ReadyTime) {
                currentNode.uavServiceTime = currentNode.ReadyTime;
            } else {
                currentNode.uavServiceTime = currentNode.uavArrivalTime + Parameter.UAV_landing_time;  // 否则，立即开始服务
            }
            // 设置当前节点的离开时间
            currentNode.uavDepartureTime = currentNode.uavServiceTime + currentNode.ServiceTime;  // 设置当前节点的离开时间，等于当前节点的开始服务时间 + 服务时间

            // 检查是否违反了时间窗约束
            if (currentNode.UAV_service && currentNode.uavServiceTime > currentNode.DueTime) {
                evRoute.violationTime += currentNode.uavServiceTime - currentNode.DueTime;  // 记录违反时间窗的时间
                // 可以在这里处理超时的情况，例如记录日志或调整路径
            }
        }
        return delta;
    }

    // 计算UAV航程的能耗,包括起飞、降落和飞行的能耗
    public static double calculate_uavtrip_energy(List<Node> uavTrip) {
        double temp_load = 0;
        for (int j = 1; j < uavTrip.size() - 1; j++) {  // 加和UAV航程中的每个节点的需求量
            temp_load += uavTrip.get(j).Demand;
        }
        double energy = 0;
        for (int i = 0; i < uavTrip.size(); i++) {
            Node currentNode = uavTrip.get(i);  // 获取当前节点
            if (i == 0) {  // 对于起始节点（即起飞节点），不需要计算能耗
                continue;
            }
            Node previousNode = uavTrip.get(i - 1);  // 获取上一个节点
            // 起飞能耗，载重量为当前航线的总载重量加上无人机的重量
            double takeoff_Energy = Calculate_Tool.Calculate_UAV_Takeoff_Energy(temp_load + Parameter.UAV_weight);
            // 计算从上一个节点到当前节点的行驶时间
            double travelDistance = Parameter.DisMatrix[previousNode.NodeID][currentNode.NodeID];
            // 计算UAV的行驶能耗
            double travelEnergy = Calculate_UAV_Travel_Energy(temp_load + Parameter.UAV_weight, travelDistance);
            // 降落能耗，载重量为当前航线的总载重量加上无人机的重量
            double landing_Energy = Calculate_Tool.Calculate_UAV_Landing_Energy(temp_load + Parameter.UAV_weight);
            temp_load = temp_load - currentNode.Demand;  // 更新当前节点的载重量
            energy += travelEnergy + takeoff_Energy + landing_Energy;  // 计算UAV航程的能耗
        }
        return energy;
    }

    // 输入一个EV路径，返回该路径的总成本
    public static double calculateEVrouteCost(EV_Route ev_route) {
        double cost = 0;
        // 更新EV路径的信息
        updateEVRoutesMetrics(ev_route);

        // 使用成本
        cost += Parameter.EV_cost;
        //能耗成本
        cost += ev_route.energyConsumption ;
        cost += ev_route.energyConsumption_uav ;
        //惩罚项
        // 超载惩罚
        if (ev_route.total_load > Parameter.EVCapacity) {
            cost += (ev_route.total_load - Parameter.EVCapacity) * Parameter.Alpha ;
        }
        // 超时惩罚
        cost += ev_route.violationTime * Parameter.Beta;
        // 超能量惩罚
        if (ev_route.energy_violated) {
            cost += 1000000;
        }
        return cost;
    }


    public static int IntRandom(int min, int max) {  // 生成[min,max)之间的随机整数
        Random r = new Random();
        int a = r.nextInt(max - min) + min;
        return a;
    }

    // 判断两个解是否相同
    public static Boolean CompareRoute(Solution solution_1, Solution solution_2) {
        // 比较两个解的EV路径的数量是否相同
        if (solution_1.evPaths.length != solution_2.evPaths.length) {
            return false;
        }
        for (int i = 0; i < solution_1.evPaths.length; i++) {
            EV_Route evRoute_1 = solution_1.evPaths[i];
            EV_Route evRoute_2 = solution_2.evPaths[i];
            if (evRoute_1.route.size() != evRoute_2.route.size()) {
                return false;
            }
            // 比较两个EV路径的节点是否相同
            for (int j = 0; j < evRoute_1.route.size(); j++) {
                if (evRoute_1.route.get(j).NodeID != evRoute_2.route.get(j).NodeID) {
                    return false;
                }
            }
            // 比较两个EV路径的UAV航线是否相同
            if (evRoute_1.uavTrips.size() != evRoute_2.uavTrips.size()) {
                return false;
            }
            for (int j = 0; j < evRoute_1.uavTrips.size(); j++) {
                List<Node> uavTrip_1 = evRoute_1.uavTrips.get(j);
                List<Node> uavTrip_2 = evRoute_2.uavTrips.get(j);
                if (uavTrip_1.size() != uavTrip_2.size()) {
                    return false;
                }
                for (int k = 0; k < uavTrip_1.size(); k++) {
                    if (uavTrip_1.get(k).NodeID != uavTrip_2.get(k).NodeID) {
                        return false;
                    }
                }
            }
        }
        // 比较两个解的BSV路径是否相同
        if (solution_1.bsvPaths.length != solution_2.bsvPaths.length) {
            return false;
        }
        for (int i = 0; i < solution_1.bsvPaths.length; i++) {
            BSV_Route bsvRoute_1 = solution_1.bsvPaths[i];
            BSV_Route bsvRoute_2 = solution_2.bsvPaths[i];
            if (bsvRoute_1.route.size() != bsvRoute_2.route.size()) {
                return false;
            }
            // 比较两个BSV路径的节点是否相同
            for (int j = 0; j < bsvRoute_1.route.size(); j++) {
                if (bsvRoute_1.route.get(j).NodeID != bsvRoute_2.route.get(j).NodeID) {
                    return false;
                }
            }
        }

        return true;
    }

    // 清空解
    public static void clearSolution(Solution solution) {
        for (EV_Route evRoute : solution.evPaths) {
            evRoute.energy_consum_travel.clear();
            evRoute.energy_consum_uavtrip.clear();
            evRoute.weight_travel.clear();
            evRoute.energy_violated = false;
            evRoute.total_load = 0;
            evRoute.energyConsumption = 0;
            evRoute.distance = 0;
            evRoute.violationTime = 0;
            evRoute.energyConsumption_uav = 0;
            evRoute.battery_change_times = 0;
            evRoute.route.clear();
            evRoute.uavTrips.clear();
        }
        for (BSV_Route bsvRoute : solution.bsvPaths) {
            bsvRoute.route.clear();
            bsvRoute.distance = 0;
            bsvRoute.energyConsumption = 0;
            bsvRoute.violationTime = 0;
            bsvRoute.total_load = 0;
            bsvRoute.weight_travel.clear();
            bsvRoute.energy_consum_travel.clear();
            bsvRoute.energy_violated = false;
        }
        solution.solution_overcapicity_all = 0;
        solution.solution_overtime_all = 0;
        solution.isFeasible = false;
        solution.totalEnergy = 0;
        solution.totalCost = 0;
        solution.solution_energy_violated = false;
        solution.cost_EVandUAV = 0;
        solution.cost_BSV = 0;
        solution.solution_battery_change_times = 0;
    }

    // 克隆解 将solution_2的解克隆到solution_1
    public static void cloneSolution(Solution solution_1, Solution solution_2) {
        // 克隆EV路径部分
        for (int i = 0; i < solution_2.evPaths.length; i++) {
            EV_Route evRoute_2 = solution_2.evPaths[i];
            EV_Route evRoute_1 = solution_1.evPaths[i];
            for (int j = 0; j < evRoute_2.route.size(); j++) {
                evRoute_1.route.add(evRoute_2.route.get(j));
            }
            // 克隆UAV航线部分
            for (int j = 0; j < evRoute_2.uavTrips.size(); j++) {
                List<Node> uavTrip_2 = evRoute_2.uavTrips.get(j);
                List<Node> uavTrip_1 = new ArrayList<>();
                for (int k = 0; k < uavTrip_2.size(); k++) {
                    uavTrip_1.add(uavTrip_2.get(k));
                }
                evRoute_1.uavTrips.add(uavTrip_1);
            }
            evRoute_1.energy_consum_travel = new ArrayList<>(evRoute_2.energy_consum_travel);
            evRoute_1.energy_consum_uavtrip = new ArrayList<>(evRoute_2.energy_consum_uavtrip);
            evRoute_1.weight_travel = new ArrayList<>(evRoute_2.weight_travel);
            evRoute_1.energy_violated = evRoute_2.energy_violated;
            evRoute_1.total_load = evRoute_2.total_load;
            evRoute_1.energyConsumption = evRoute_2.energyConsumption;
            evRoute_1.distance = evRoute_2.distance;
            evRoute_1.violationTime = evRoute_2.violationTime;
            evRoute_1.battery_change_times = evRoute_2.battery_change_times;
            evRoute_1.energyConsumption_uav = evRoute_2.energyConsumption_uav;

        }
        // 克隆BSV路径部分
        for (int i = 0; i < solution_2.bsvPaths.length; i++) {
            BSV_Route bsvRoute_2 = solution_2.bsvPaths[i];
            BSV_Route bsvRoute_1 = solution_1.bsvPaths[i];
            for (int j = 0; j < bsvRoute_2.route.size(); j++) {
                bsvRoute_1.route.add(bsvRoute_2.route.get(j));
            }
            bsvRoute_1.distance = bsvRoute_2.distance;
            bsvRoute_1.energyConsumption = bsvRoute_2.energyConsumption;
            bsvRoute_1.violationTime = bsvRoute_2.violationTime;
            bsvRoute_1.total_load = bsvRoute_2.total_load;
            bsvRoute_1.weight_travel = new ArrayList<>(bsvRoute_2.weight_travel);
            bsvRoute_1.energy_consum_travel = new ArrayList<>(bsvRoute_2.energy_consum_travel);
            bsvRoute_1.energy_violated = bsvRoute_2.energy_violated;
        }
        // 克隆solution_2的其他信息
        solution_1.solution_overcapicity_all = solution_2.solution_overcapicity_all;
        solution_1.solution_overtime_all = solution_2.solution_overtime_all;
        solution_1.isFeasible = solution_2.isFeasible;
        solution_1.totalEnergy = solution_2.totalEnergy;
        solution_1.totalCost = solution_2.totalCost;
        solution_1.solution_energy_violated = solution_2.solution_energy_violated;
        solution_1.cost_EVandUAV = solution_2.cost_EVandUAV;
        solution_1.cost_BSV = solution_2.cost_BSV;
        solution_1.solution_battery_change_times = solution_2.solution_battery_change_times;

        // 克隆是否成功
        if (!CompareRoute(solution_1, solution_2)) {
            System.out.println("克隆失败");
        }
        // 克隆是否成功
        if (!CompareRoute(solution_2, solution_1)) {
            System.out.println("克隆失败");
        }
    }

    // 判断solution中的bsv是否有问题，即需要换电，但最后没有换电路径
    public static boolean checkBSV(Solution solution) {
        boolean flag = true;  // 标记是否有问题
        if(solution.solution_battery_change_times>0){
            flag = false;  // 有换电次数，但是没有换电路径
            for (BSV_Route bsvRoute : solution.bsvPaths) {
                if (bsvRoute.route.size() > 0) {
                    flag = true;
                    break;
                }
            }
        }
        if(!flag){
            System.out.println("BSV路径有问题");
        }
        return flag;
    }


}
