﻿# Bigscale 10-runs Progress Status

- Generated at: 2026-03-10 00:49:01
- Progress file: E:\组会\2024-08\code\EVRPTW-D-BSS\result\bigscale_10runs_large_params_progress.tsv
- Issues file: E:\组会\2024-08\code\EVRPTW-D-BSS\result\bigscale_10runs_large_params_issues.log
- Completed cases: 20/24
- Completed runs: 206/240

## Case Progress

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 10/10 | Done |
| C2-25 | 10/10 | Done |
| R1-25 | 10/10 | Done |
| R2-25 | 10/10 | Done |
| RC1-25 | 10/10 | Done |
| RC2-25 | 10/10 | Done |
| C1-50 | 10/10 | Done |
| C2-50 | 10/10 | Done |
| R1-50 | 10/10 | Done |
| R2-50 | 10/10 | Done |
| RC1-50 | 10/10 | Done |
| RC2-50 | 10/10 | Done |
| C1-75 | 10/10 | Done |
| C2-75 | 10/10 | Done |
| R1-75 | 10/10 | Done |
| R2-75 | 10/10 | Done |
| RC1-75 | 10/10 | Done |
| RC2-75 | 10/10 | Done |
| C1-100 | 10/10 | Done |
| C2-100 | 10/10 | Done |
| R1-100 | 6/10 | Pending |
| R2-100 | 0/10 | Pending |
| RC1-100 | 0/10 | Pending |
| RC2-100 | 0/10 | Pending |

## Recent Issues

- 2026-03-09 17:12:03	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 17:53:10	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 17:56:14	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 18:36:29	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 19:16:43	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 19:56:50	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 20:37:08	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 21:17:22	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 22:07:31	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 22:47:41	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 23:27:53	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-10 00:08:36	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
