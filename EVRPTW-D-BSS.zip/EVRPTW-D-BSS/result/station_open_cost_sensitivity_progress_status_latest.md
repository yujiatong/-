﻿# Station Open Cost Sensitivity Progress Status

- Generated at: 2026-03-15 05:25:51
- Progress file: E:\组会\2024-08\code\EVRPTW-D-BSS\result\station_open_cost_sensitivity_progress.tsv
- Issues file: E:\组会\2024-08\code\EVRPTW-D-BSS\result\station_open_cost_sensitivity_issues.log
- Summary report: E:\组会\2024-08\code\EVRPTW-D-BSS\result\station_open_cost_sensitivity_summary.md
- Completed runs: 480/480

## Active State

- status: running updated=2026-03-14 19:33:23
- pid: 25396
- note: Watchdog monitoring progress at 453/480

## Cost Summary

| stationOpenCost | CompletedCases | CompletedRuns | Status |
|---:|---:|---:|---|
| 1500 | 24/24 | 96/96 | Done |
| 4500 | 24/24 | 96/96 | Done |
| 6000 | 24/24 | 96/96 | Done |
| 7500 | 24/24 | 96/96 | Done |
| 9000 | 24/24 | 96/96 | Done |

## Case Progress: stationOpenCost=1500

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 4/4 | Done |
| C2-25 | 4/4 | Done |
| R1-25 | 4/4 | Done |
| R2-25 | 4/4 | Done |
| RC1-25 | 4/4 | Done |
| RC2-25 | 4/4 | Done |
| C1-50 | 4/4 | Done |
| C2-50 | 4/4 | Done |
| R1-50 | 4/4 | Done |
| R2-50 | 4/4 | Done |
| RC1-50 | 4/4 | Done |
| RC2-50 | 4/4 | Done |
| C1-75 | 4/4 | Done |
| C2-75 | 4/4 | Done |
| R1-75 | 4/4 | Done |
| R2-75 | 4/4 | Done |
| RC1-75 | 4/4 | Done |
| RC2-75 | 4/4 | Done |
| C1-100 | 4/4 | Done |
| C2-100 | 4/4 | Done |
| R1-100 | 4/4 | Done |
| R2-100 | 4/4 | Done |
| RC1-100 | 4/4 | Done |
| RC2-100 | 4/4 | Done |

## Case Progress: stationOpenCost=4500

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 4/4 | Done |
| C2-25 | 4/4 | Done |
| R1-25 | 4/4 | Done |
| R2-25 | 4/4 | Done |
| RC1-25 | 4/4 | Done |
| RC2-25 | 4/4 | Done |
| C1-50 | 4/4 | Done |
| C2-50 | 4/4 | Done |
| R1-50 | 4/4 | Done |
| R2-50 | 4/4 | Done |
| RC1-50 | 4/4 | Done |
| RC2-50 | 4/4 | Done |
| C1-75 | 4/4 | Done |
| C2-75 | 4/4 | Done |
| R1-75 | 4/4 | Done |
| R2-75 | 4/4 | Done |
| RC1-75 | 4/4 | Done |
| RC2-75 | 4/4 | Done |
| C1-100 | 4/4 | Done |
| C2-100 | 4/4 | Done |
| R1-100 | 4/4 | Done |
| R2-100 | 4/4 | Done |
| RC1-100 | 4/4 | Done |
| RC2-100 | 4/4 | Done |

## Case Progress: stationOpenCost=6000

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 4/4 | Done |
| C2-25 | 4/4 | Done |
| R1-25 | 4/4 | Done |
| R2-25 | 4/4 | Done |
| RC1-25 | 4/4 | Done |
| RC2-25 | 4/4 | Done |
| C1-50 | 4/4 | Done |
| C2-50 | 4/4 | Done |
| R1-50 | 4/4 | Done |
| R2-50 | 4/4 | Done |
| RC1-50 | 4/4 | Done |
| RC2-50 | 4/4 | Done |
| C1-75 | 4/4 | Done |
| C2-75 | 4/4 | Done |
| R1-75 | 4/4 | Done |
| R2-75 | 4/4 | Done |
| RC1-75 | 4/4 | Done |
| RC2-75 | 4/4 | Done |
| C1-100 | 4/4 | Done |
| C2-100 | 4/4 | Done |
| R1-100 | 4/4 | Done |
| R2-100 | 4/4 | Done |
| RC1-100 | 4/4 | Done |
| RC2-100 | 4/4 | Done |

## Case Progress: stationOpenCost=7500

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 4/4 | Done |
| C2-25 | 4/4 | Done |
| R1-25 | 4/4 | Done |
| R2-25 | 4/4 | Done |
| RC1-25 | 4/4 | Done |
| RC2-25 | 4/4 | Done |
| C1-50 | 4/4 | Done |
| C2-50 | 4/4 | Done |
| R1-50 | 4/4 | Done |
| R2-50 | 4/4 | Done |
| RC1-50 | 4/4 | Done |
| RC2-50 | 4/4 | Done |
| C1-75 | 4/4 | Done |
| C2-75 | 4/4 | Done |
| R1-75 | 4/4 | Done |
| R2-75 | 4/4 | Done |
| RC1-75 | 4/4 | Done |
| RC2-75 | 4/4 | Done |
| C1-100 | 4/4 | Done |
| C2-100 | 4/4 | Done |
| R1-100 | 4/4 | Done |
| R2-100 | 4/4 | Done |
| RC1-100 | 4/4 | Done |
| RC2-100 | 4/4 | Done |

## Case Progress: stationOpenCost=9000

| Case | DoneRuns | Status |
|---|---:|---|
| C1-25 | 4/4 | Done |
| C2-25 | 4/4 | Done |
| R1-25 | 4/4 | Done |
| R2-25 | 4/4 | Done |
| RC1-25 | 4/4 | Done |
| RC2-25 | 4/4 | Done |
| C1-50 | 4/4 | Done |
| C2-50 | 4/4 | Done |
| R1-50 | 4/4 | Done |
| R2-50 | 4/4 | Done |
| RC1-50 | 4/4 | Done |
| RC2-50 | 4/4 | Done |
| C1-75 | 4/4 | Done |
| C2-75 | 4/4 | Done |
| R1-75 | 4/4 | Done |
| R2-75 | 4/4 | Done |
| RC1-75 | 4/4 | Done |
| RC2-75 | 4/4 | Done |
| C1-100 | 4/4 | Done |
| C2-100 | 4/4 | Done |
| R1-100 | 4/4 | Done |
| R2-100 | 4/4 | Done |
| RC1-100 | 4/4 | Done |
| RC2-100 | 4/4 | Done |

## Recent Issues

- 2026-03-14 14:13:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:14:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:15:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:16:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:17:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:18:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:19:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:20:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:21:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:22:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:23:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:25:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.


