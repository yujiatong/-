﻿# Station-Focus ALNS Evaluation (Small-scale 6x10)

- Baseline report: result/smallscale_10runs_report_20260307_154050.md
- New run raw TSV: E:/组会/2024-08/code/EVRPTW-D-BSS/result/station_focus_eval_20260307_171258.tsv

## Summary Comparison

| CASE | Best(old) | Best(new) | ΔBest | Avg(old) | Avg(new) | ΔAvg | Gap%(old) | Gap%(new) | ΔGap | Time(old,s) | Time(new,s) | ΔTime | Feasible(new) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C1 | 6,783.1 | 6,783.3 | 0.2 | 6,786.1 | 6,783.3 | -2.8 | 0.03 | 0.00 | -0.03 | 3.1 | 6.8 | 3.7 | 10/10 |
| C2 | 12,135.1 | 12,134.5 | -0.6 | 12,135.1 | 12,134.5 | -0.6 | 0.00 | 0.00 | 0.00 | 4.1 | 5.2 | 1.1 | 10/10 |
| R1 | 18,549.1 | 18,515.6 | -33.5 | 19,863.1 | 19,561.1 | -302.0 | 7.09 | 5.65 | -1.44 | 3.1 | 5.2 | 2.1 | 10/10 |
| R2 | 16,830.1 | 16,829.9 | -0.2 | 16,830.1 | 16,838.3 | 8.2 | 0.00 | 0.05 | 0.05 | 3.1 | 4.8 | 1.7 | 10/10 |
| RC1 | 16,465.1 | 16,485.6 | 20.5 | 16,483.1 | 16,485.6 | 2.5 | 0.11 | 0.00 | -0.11 | 4.1 | 5.4 | 1.3 | 10/10 |
| RC2 | 1,007,731.1 | 1,009,079.3 | 1,348.2 | 1,010,440.1 | 1,010,415.6 | -24.5 | 0.27 | 0.13 | -0.14 | 3.1 | 7.6 | 4.5 | 0/10 |

## Global-Search Judgment

- BestCost improved cases: 3, degraded cases: 3.
- AvgCost improved cases: 4, degraded cases: 2.
- Key case R1: best improved from 18549.1 to 18515.6, avg improved from 19863.1 to 19561.1, gap 7.09% -> 5.65%.
- RC2 remains energy-infeasible (0/10) in both settings; station perturbation alone did not remove this bottleneck.
- Runtime increased because station-focused perturbation plus repair is heavier.

