﻿# Station-Focus ALNS Round2 Exact Comparison (Small-scale 6x10)

- Baseline raw: result/smallscale_10runs_progress.tsv
- Round2 raw: E:\组会\2024-08\code\EVRPTW-D-BSS\result\station_focus_eval_round2_20260307_173410.tsv

| CASE | Best(base) | Best(new) | ΔBest | Avg(base) | Avg(new) | ΔAvg | Gap%(base) | Gap%(new) | ΔGap | Time(base,s) | Time(new,s) | ΔTime | Feasible(new) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C1 | 6,783.3281 | 6,783.3281 | 0.0000 | 6,785.5036 | 6,783.3281 | -2.1754 | 0.0321 | 0.0000 | -0.0321 | 3.006 | 3.709 | 0.704 | 10/10 |
| C2 | 12,134.5335 | 12,134.5335 | 0.0000 | 12,134.5335 | 12,134.5335 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 3.612 | 4.219 | 0.607 | 10/10 |
| R1 | 18,548.6215 | 18,515.5673 | -33.0542 | 19,863.1711 | 19,419.0225 | -444.1486 | 7.0870 | 4.8794 | -2.2076 | 3.470 | 3.908 | 0.438 | 10/10 |
| R2 | 16,829.8910 | 16,829.8910 | 0.0000 | 16,829.8910 | 16,829.8910 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 2.826 | 3.605 | 0.779 | 10/10 |
| RC1 | 16,464.5851 | 16,464.5851 | 0.0000 | 16,483.4754 | 16,481.3765 | -2.0989 | 0.1147 | 0.1020 | -0.0127 | 3.548 | 4.140 | 0.592 | 10/10 |
| RC2 | 1,007,731.3330 | 1,007,454.4827 | -276.8503 | 1,010,439.5079 | 1,010,020.2307 | -419.2772 | 0.2687 | 0.2547 | -0.0141 | 3.068 | 3.757 | 0.689 | 0/10 |

## Judgment
- Best: improved=2, equal=4, degraded=0.
- Avg: improved=4, equal=2, degraded=0.
- R1 shows significant global-search enhancement and stability gain.
- RC2 remains infeasible, but objective quality improved versus baseline.

