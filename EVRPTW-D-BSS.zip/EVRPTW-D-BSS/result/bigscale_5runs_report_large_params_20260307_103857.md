# Large-Scale Instances Report (5 runs each)

- Generated at: 2026-03-07T10:38:57.673
- Cases: 24
- Runs per case: 5
- Parameter set label: LargeScaleParamSet-UserUpdated

## Large-Scale Parameter Set (Current)

- evCount: 15
- evCapacity: 200.0
- evEnergy: 800.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 30.0
- uavEnergy: 30.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 5
- evFixedCost: 1500.0
- stationOpenCost: 3000.0
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 500
- alnsRestarts: 4
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1-25 | 10432.1 | 10432.1 | 0.00 | 41.1 |
| C2-25 | 12231.1 | 12231.1 | 0.00 | 31.1 |
| R1-25 | 16356.1 | 16356.1 | 0.00 | 20.1 |
| R2-25 | 12471.1 | 12471.1 | 0.00 | 25.1 |
| RC1-25 | 19416.1 | 19458.1 | 0.22 | 31.1 |
| RC2-25 | 18732.1 | 18828.1 | 0.52 | 31.1 |
| C1-50 | 18997.1 | 19171.1 | 0.92 | 129.1 |
| C2-50 | 21907.1 | 22209.1 | 1.38 | 187.1 |
| R1-50 | 27024.1 | 27645.1 | 2.30 | 96.1 |
| R2-50 | 24618.1 | 24618.1 | 0.00 | 126.1 |
| RC1-50 | 37241.1 | 37627.1 | 1.04 | 171.1 |
| RC2-50 | 34243.1 | 35167.1 | 2.70 | 223.1 |
| C1-75 | 33670.1 | 33846.1 | 0.52 | 369.1 |
| C2-75 | 33913.1 | 34887.1 | 2.87 | 824.1 |
| R1-75 | 45573.1 | 48200.1 | 5.76 | 532.1 |
| R2-75 | 34387.1 | 34916.1 | 1.54 | 579.1 |
| RC1-75 | 51879.1 | 53493.1 | 3.11 | 491.1 |
| RC2-75 | 46570.1 | 46878.1 | 0.66 | 498.1 |
| C1-100 | 47741.1 | 49668.1 | 4.04 | 1033.1 |
| C2-100 | 44892.1 | 46628.1 | 3.87 | 1095.1 |
| R1-100 | 322346.1 | 447558.1 | 38.84 | 1307.1 |
| R2-100 | 43246.1 | 43819.1 | 1.32 | 1204.1 |
| RC1-100 | 217127.1 | 268457.1 | 23.64 | 714.1 |
| RC2-100 | 54163.1 | 57775.1 | 6.67 | 916.1 |

## Best Routes And Run Logs

### C1-25

- Instance: `./instances_bss_bigscal/c101_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 10432.1
- Avg cost: 10432.1
- Avg time(s): 41.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 10432.1 | true | 50.1 |
| 2 | 2 | 10432.1 | true | 48.1 |
| 3 | 3 | 10432.1 | true | 48.1 |
| 4 | 4 | 10432.1 | true | 34.1 |
| 5 | 5 | 10432.1 | true | 23.1 |

#### Best Route Plan

```text
totalCost=10432.313973254404, evUavCost=10432.313973254404, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 23 -> 22 -> 
EV Route-5: 0(DEPOT) -> 17(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 15 -> 
EV Route-7: 0(DEPOT) -> 10(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 14 -> 12 -> 
EV Route-11: 0(DEPOT) -> 13(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 19 -> 16 -> 
```

### C2-25

- Instance: `./instances_bss_bigscal/c201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 12231.1
- Avg cost: 12231.1
- Avg time(s): 31.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12231.1 | true | 33.1 |
| 2 | 2 | 12231.1 | true | 30.1 |
| 3 | 3 | 12231.1 | true | 29.1 |
| 4 | 4 | 12231.1 | true | 31.1 |
| 5 | 5 | 12231.1 | true | 31.1 |

#### Best Route Plan

```text
totalCost=12231.071409643479, evUavCost=9231.071409643479, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-1: 0(DEPOT) -> 31(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 9(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 18 -> 19 -> 16 -> 
  UAV Trip 2: 14 -> 12 -> 15 -> 
EV Route-2: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 23(CUSTOMER) -> 17(CUSTOMER) -> 31(STATION) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 6 -> 23 -> 
  UAV Trip 2: 31 -> 11 -> 10 -> 
EV Route-7: 0(DEPOT) -> 25(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 8 -> 21 -> 
```

### R1-25

- Instance: `./instances_bss_bigscal/r101_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 16356.1
- Avg cost: 16356.1
- Avg time(s): 20.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16356.1 | true | 20.1 |
| 2 | 2 | 16356.1 | true | 19.1 |
| 3 | 3 | 16356.1 | true | 18.1 |
| 4 | 4 | 16356.1 | true | 21.1 |
| 5 | 5 | 16356.1 | true | 22.1 |

#### Best Route Plan

```text
totalCost=16355.841347544178, evUavCost=16355.841347544178, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 13 -> 
EV Route-2: 0(DEPOT) -> 21(CUSTOMER) -> 3(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 24 -> 25 -> 
EV Route-3: 0(DEPOT) -> 23(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 22 -> 4 -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 20 -> 1 -> 
EV Route-7: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 18 -> 6 -> 
EV Route-12: 0(DEPOT) -> 5(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 
```

### R2-25

- Instance: `./instances_bss_bigscal/r201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 12471.1
- Avg cost: 12471.1
- Avg time(s): 25.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12471.1 | true | 28.1 |
| 2 | 2 | 12471.1 | true | 26.1 |
| 3 | 3 | 12471.1 | true | 23.1 |
| 4 | 4 | 12471.1 | true | 21.1 |
| 5 | 5 | 12471.1 | true | 25.1 |

#### Best Route Plan

```text
totalCost=12470.980485816235, evUavCost=12470.980485816235, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 15(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 14 -> 6 -> 
EV Route-2: 0(DEPOT) -> 12(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 3 -> 24 -> 4 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 13 -> 
EV Route-4: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 7 -> 8 -> 18 -> 
EV Route-5: 0(DEPOT) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 10 -> 1 -> 
EV Route-6: 0(DEPOT) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC1-25

- Instance: `./instances_bss_bigscal/rc101_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 19416.1
- Avg cost: 19458.1
- Avg time(s): 31.1
- Gap%: 0.22
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19467.1 | true | 32.1 |
| 2 | 2 | 19416.1 | true | 35.1 |
| 3 | 3 | 19469.1 | true | 29.1 |
| 4 | 4 | 19469.1 | true | 28.1 |
| 5 | 5 | 19469.1 | true | 30.1 |

#### Best Route Plan

```text
totalCost=19416.126843712816, evUavCost=16416.126843712816, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 30(STATION) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 16 -> 15 -> 
EV Route-1: 0(DEPOT) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 6 -> 
EV Route-2: 0(DEPOT) -> 23(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 20 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 
EV Route-4: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 30(STATION) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 9 -> 10 -> 
EV Route-7: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 25 -> 24 -> 
```

### RC2-25

- Instance: `./instances_bss_bigscal/rc201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 18732.1
- Avg cost: 18828.1
- Avg time(s): 31.1
- Gap%: 0.52
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 18888.1 | true | 35.1 |
| 2 | 2 | 18985.1 | true | 29.1 |
| 3 | 3 | 18732.1 | true | 29.1 |
| 4 | 4 | 18757.1 | true | 31.1 |
| 5 | 5 | 18780.1 | true | 29.1 |

#### Best Route Plan

```text
totalCost=18731.514353077764, evUavCost=12731.514353077766, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 27(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 9 -> 8 -> 
  UAV Trip 2: 27 -> 14 -> 15 -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 4 -> 
EV Route-2: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 27(STATION) -> 13(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 17 -> 13 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 5 -> 3 -> 1 -> 
EV Route-9: 0(DEPOT) -> 29(STATION) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 18 -> 22 -> 
```

### C1-50

- Instance: `./instances_bss_bigscal/c101_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 4
- Best cost: 18997.1
- Avg cost: 19171.1
- Avg time(s): 129.1
- Gap%: 0.92
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19210.1 | true | 126.1 |
| 2 | 2 | 19218.1 | true | 122.1 |
| 3 | 3 | 19210.1 | true | 121.1 |
| 4 | 4 | 18997.1 | true | 148.1 |
| 5 | 5 | 19218.1 | true | 129.1 |

#### Best Route Plan

```text
totalCost=18996.710847566203, evUavCost=15996.7108475662, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 50 -> 49 -> 47 -> 
EV Route-1: 0(DEPOT) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 10 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-3: 0(DEPOT) -> 18(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 19 -> 16 -> 
EV Route-6: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 36 -> 34 -> 
EV Route-8: 0(DEPOT) -> 13(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 17 -> 15 -> 
EV Route-9: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 31(CUSTOMER) -> 51(STATION) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 51 -> 
```

### C2-50

- Instance: `./instances_bss_bigscal/c201_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 21907.1
- Avg cost: 22209.1
- Avg time(s): 187.1
- Gap%: 1.38
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 21911.1 | true | 156.1 |
| 2 | 2 | 22650.1 | true | 173.1 |
| 3 | 3 | 21907.1 | true | 161.1 |
| 4 | 4 | 21914.1 | true | 187.1 |
| 5 | 5 | 22662.1 | true | 261.1 |

#### Best Route Plan

```text
totalCost=21907.33851315447, evUavCost=18907.33851315447, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 51(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 31 -> 35 -> 51 -> 
EV Route-2: 0(DEPOT) -> 22(CUSTOMER) -> 34(CUSTOMER) -> 51(STATION) -> 26(CUSTOMER) -> 18(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 34 -> 
  UAV Trip 2: 51 -> 28 -> 26 -> 
  UAV Trip 3: 18 -> 19 -> 15 -> 
EV Route-3: 0(DEPOT) -> 45(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 50 -> 47 -> 43 -> 42 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 29(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 39(CUSTOMER) -> 51(STATION) -> 17(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 36 -> 23 -> 17 -> 
  UAV Trip 2: 37 -> 38 -> 39 -> 
  UAV Trip 3: 20 -> 24 -> 29 -> 
EV Route-5: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-8: 0(DEPOT) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 40 -> 44 -> 46 -> 
```

### R1-50

- Instance: `./instances_bss_bigscal/r101_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 27024.1
- Avg cost: 27645.1
- Avg time(s): 96.1
- Gap%: 2.30
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 27049.1 | true | 132.1 |
| 2 | 2 | 27024.1 | true | 88.1 |
| 3 | 3 | 28529.1 | true | 81.1 |
| 4 | 4 | 27049.1 | true | 84.1 |
| 5 | 5 | 28571.1 | true | 94.1 |

#### Best Route Plan

```text
totalCost=27023.597729145287, evUavCost=27023.597729145287, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 20 -> 32 -> 
EV Route-1: 0(DEPOT) -> 28(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 29 -> 3 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 22 -> 4 -> 
EV Route-3: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 42(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 43 -> 13 -> 
EV Route-5: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 37 -> 
EV Route-6: 0(DEPOT) -> 39(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 41 -> 
EV Route-7: 0(DEPOT) -> 27(CUSTOMER) -> 7(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 10 -> 48 -> 
EV Route-9: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-10: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-11: 0(DEPOT) -> 12(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 40 -> 50 -> 
EV Route-13: 0(DEPOT) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 6 -> 
EV Route-14: 0(DEPOT) -> 45(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 8 -> 46 -> 17 -> 
```

### R2-50

- Instance: `./instances_bss_bigscal/r201_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 24618.1
- Avg cost: 24618.1
- Avg time(s): 126.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 24618.1 | true | 132.1 |
| 2 | 2 | 24618.1 | true | 137.1 |
| 3 | 3 | 24618.1 | true | 121.1 |
| 4 | 4 | 24618.1 | true | 115.1 |
| 5 | 5 | 24618.1 | true | 126.1 |

#### Best Route Plan

```text
totalCost=24618.498803528855, evUavCost=24618.498803528855, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 26(CUSTOMER) -> 4(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 4 -> 25 -> 24 -> 
EV Route-1: 0(DEPOT) -> 47(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 49 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 22 -> 41 -> 13 -> 
EV Route-3: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-4: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 43 -> 37 -> 
EV Route-5: 0(DEPOT) -> 16(CUSTOMER) -> 44(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 6 -> 
EV Route-7: 0(DEPOT) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 7 -> 8 -> 46 -> 48 -> 
EV Route-8: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 3 -> 
EV Route-9: 0(DEPOT) -> 39(CUSTOMER) -> 21(CUSTOMER) -> 40(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 21 -> 
EV Route-10: 0(DEPOT) -> 31(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 19 -> 11 -> 
EV Route-12: 0(DEPOT) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 32 -> 1 -> 
EV Route-14: 0(DEPOT) -> 5(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 45 -> 17 -> 
```

### RC1-50

- Instance: `./instances_bss_bigscal/rc101_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 37241.1
- Avg cost: 37627.1
- Avg time(s): 171.1
- Gap%: 1.04
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 37722.1 | true | 137.1 |
| 2 | 2 | 37241.1 | true | 144.1 |
| 3 | 3 | 37718.1 | true | 161.1 |
| 4 | 4 | 37722.1 | true | 182.1 |
| 5 | 5 | 37731.1 | true | 230.1 |

#### Best Route Plan

```text
totalCost=37241.412192880685, evUavCost=34241.412192880685, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 44 -> 38 -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 31(CUSTOMER) -> 55(STATION) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 34 -> 50 -> 
EV Route-4: 0(DEPOT) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 33(CUSTOMER) -> 55(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 30 -> 28 -> 55 -> 
EV Route-6: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 49 -> 20 -> 24 -> 
EV Route-7: 0(DEPOT) -> 14(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 17 -> 
EV Route-8: 0(DEPOT) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 8 -> 46 -> 4 -> 
EV Route-9: 0(DEPOT) -> 41(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 40 -> 43 -> 
EV Route-10: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-11: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-12: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-13: 0(DEPOT) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 55(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 26 -> 55 -> 
EV Route-14: 0(DEPOT) -> 12(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 13 -> 
```

### RC2-50

- Instance: `./instances_bss_bigscal/rc201_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 34243.1
- Avg cost: 35167.1
- Avg time(s): 223.1
- Gap%: 2.70
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 35191.1 | true | 308.1 |
| 2 | 2 | 34243.1 | true | 242.1 |
| 3 | 3 | 35511.1 | true | 256.1 |
| 4 | 4 | 35383.1 | true | 202.1 |
| 5 | 5 | 35509.1 | true | 107.1 |

#### Best Route Plan

```text
totalCost=34242.55636550898, evUavCost=25242.556365508983, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 16 -> 15 -> 
EV Route-1: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-2: 0(DEPOT) -> 22(CUSTOMER) -> 51(STATION) -> 49(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 18 -> 49 -> 
EV Route-4: 0(DEPOT) -> 39(CUSTOMER) -> 55(STATION) -> 36(CUSTOMER) -> 38(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 40 -> 38 -> 
EV Route-5: 0(DEPOT) -> 33(CUSTOMER) -> 53(STATION) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 34 -> 50 -> 
EV Route-6: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 55(STATION) -> 43(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 37 -> 35 -> 43 -> 
EV Route-7: 0(DEPOT) -> 19(CUSTOMER) -> 51(STATION) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 20 -> 24 -> 25 -> 
EV Route-9: 0(DEPOT) -> 53(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 27 -> 30 -> 28 -> 
EV Route-10: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-13: 0(DEPOT) -> 11(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 12 -> 17 -> 
```

### C1-75

- Instance: `./instances_bss_bigscal/c101_n75_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 33670.1
- Avg cost: 33846.1
- Avg time(s): 369.1
- Gap%: 0.52
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 33670.1 | true | 424.1 |
| 2 | 2 | 33913.1 | true | 435.1 |
| 3 | 3 | 33929.1 | true | 354.1 |
| 4 | 4 | 33804.1 | true | 332.1 |
| 5 | 5 | 33913.1 | true | 299.1 |

#### Best Route Plan

```text
totalCost=33670.019985897554, evUavCost=27670.01998589755, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 43(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
EV Route-2: 0(DEPOT) -> 57(CUSTOMER) -> 54(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 55(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 53 -> 56 -> 
EV Route-5: 0(DEPOT) -> 31(CUSTOMER) -> 84(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 84 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 34 -> 
EV Route-6: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-7: 0(DEPOT) -> 63(CUSTOMER) -> 71(CUSTOMER) -> 83(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 70 -> 73 -> 
EV Route-8: 0(DEPOT) -> 41(CUSTOMER) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 40 -> 58 -> 
EV Route-9: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 84(STATION) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-11: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-12: 0(DEPOT) -> 10(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-13: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 
```

### C2-75

- Instance: `./instances_bss_bigscal/c201_n75_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 33913.1
- Avg cost: 34887.1
- Avg time(s): 824.1
- Gap%: 2.87
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 36216.1 | true | 356.1 |
| 2 | 2 | 34542.1 | true | 1869.1 |
| 3 | 3 | 33913.1 | true | 749.1 |
| 4 | 4 | 35667.1 | true | 588.1 |
| 5 | 5 | 34096.1 | true | 559.1 |

#### Best Route Plan

```text
totalCost=33912.982749897434, evUavCost=27912.982749897434, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 22(CUSTOMER) -> 30(CUSTOMER) -> 85(STATION) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 26 -> 23 -> 18 -> 
  UAV Trip 2: 22 -> 27 -> 30 -> 
  UAV Trip 3: 16 -> 14 -> 12 -> 
EV Route-1: 0(DEPOT) -> 69(CUSTOMER) -> 68(CUSTOMER) -> 46(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 45 -> 47 -> 43 -> 42 -> 
EV Route-2: 0(DEPOT) -> 20(CUSTOMER) -> 6(CUSTOMER) -> 37(CUSTOMER) -> 28(CUSTOMER) -> 85(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 31 -> 35 -> 37 -> 
EV Route-3: 0(DEPOT) -> 24(CUSTOMER) -> 29(CUSTOMER) -> 38(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 36 -> 
EV Route-4: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 78(STATION) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 78 -> 
EV Route-5: 0(DEPOT) -> 67(CUSTOMER) -> 78(STATION) -> 64(CUSTOMER) -> 54(CUSTOMER) -> 57(CUSTOMER) -> 44(CUSTOMER) -> 78(STATION) -> 73(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 62 -> 78 -> 
  UAV Trip 2: 64 -> 65 -> 55 -> 54 -> 
  UAV Trip 3: 57 -> 40 -> 44 -> 
EV Route-6: 0(DEPOT) -> 66(CUSTOMER) -> 78(STATION) -> 49(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
EV Route-7: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 75(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-9: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 85(STATION) -> 50(CUSTOMER) -> 52(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 51 -> 50 -> 
EV Route-11: 0(DEPOT) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
```

### R1-75

- Instance: `./instances_bss_bigscal/r101_n75_bss.txt`
- Feasible runs: 4/5
- Best run seed: 4
- Best cost: 45573.1
- Avg cost: 48200.1
- Avg time(s): 532.1
- Gap%: 5.76
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 52382.1 | true | 566.1 |
| 2 | 2 | 49451.1 | true | 516.1 |
| 3 | 3 | 49156.1 | true | 547.1 |
| 4 | 4 | 45573.1 | true | 501.1 |
| 5 | 5 | 44438.1 | false | 528.1 |

#### Best Route Plan

```text
totalCost=45573.01017323806, evUavCost=33573.01017323806, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 54 -> 68 -> 
EV Route-1: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 82(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 19 -> 82 -> 
EV Route-2: 0(DEPOT) -> 77(STATION) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 67 -> 
  UAV Trip 2: 55 -> 4 -> 25 -> 
EV Route-3: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 9(CUSTOMER) -> 34(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 9 -> 
EV Route-4: 0(DEPOT) -> 33(CUSTOMER) -> 51(CUSTOMER) -> 20(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 29 -> 51 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 26 -> 58 -> 
EV Route-6: 0(DEPOT) -> 14(CUSTOMER) -> 80(STATION) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 43 -> 
EV Route-7: 0(DEPOT) -> 36(CUSTOMER) -> 49(CUSTOMER) -> 82(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 64 -> 49 -> 
EV Route-8: 0(DEPOT) -> 31(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 18 -> 50 -> 
EV Route-9: 0(DEPOT) -> 42(CUSTOMER) -> 22(CUSTOMER) -> 56(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 41 -> 22 -> 
EV Route-10: 0(DEPOT) -> 63(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 62 -> 11 -> 
EV Route-11: 0(DEPOT) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 85(STATION) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 66 -> 35 -> 
EV Route-12: 0(DEPOT) -> 72(CUSTOMER) -> 73(CUSTOMER) -> 57(CUSTOMER) -> 80(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 37 -> 17 -> 80 -> 
  UAV Trip 2: 72 -> 75 -> 73 -> 
EV Route-13: 0(DEPOT) -> 52(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 7 -> 8 -> 46 -> 48 -> 
EV Route-14: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 16(CUSTOMER) -> 6(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 61 -> 16 -> 
```

### R2-75

- Instance: `./instances_bss_bigscal/r201_n75_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 34387.1
- Avg cost: 34916.1
- Avg time(s): 579.1
- Gap%: 1.54
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 34920.1 | true | 470.1 |
| 2 | 2 | 34387.1 | true | 611.1 |
| 3 | 3 | 35466.1 | true | 647.1 |
| 4 | 4 | 34497.1 | true | 577.1 |
| 5 | 5 | 35309.1 | true | 592.1 |

#### Best Route Plan

```text
totalCost=34386.784608007416, evUavCost=28386.784608007416, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 79(STATION) -> 65(CUSTOMER) -> 33(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 45 -> 79 -> 
EV Route-1: 0(DEPOT) -> 52(CUSTOMER) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 7 -> 8 -> 48 -> 
EV Route-2: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 29(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 34 -> 3 -> 
EV Route-4: 0(DEPOT) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 4(CUSTOMER) -> 55(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 75 -> 56 -> 4 -> 
  UAV Trip 2: 55 -> 25 -> 24 -> 
EV Route-5: 0(DEPOT) -> 31(CUSTOMER) -> 79(STATION) -> 30(CUSTOMER) -> 79(STATION) -> 10(CUSTOMER) -> 32(CUSTOMER) -> 66(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 63 -> 79 -> 
  UAV Trip 2: 66 -> 35 -> 1 -> 
EV Route-6: 0(DEPOT) -> 59(CUSTOMER) -> 61(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 61 -> 16 -> 37 -> 13 -> 
EV Route-7: 0(DEPOT) -> 27(CUSTOMER) -> 79(STATION) -> 11(CUSTOMER) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 64 -> 49 -> 
  UAV Trip 2: 46 -> 17 -> 60 -> 
  UAV Trip 3: 27 -> 69 -> 79 -> 
EV Route-8: 0(DEPOT) -> 79(STATION) -> 62(CUSTOMER) -> 47(CUSTOMER) -> 36(CUSTOMER) -> 19(CUSTOMER) -> 79(STATION) -> 71(CUSTOMER) -> 20(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 9 -> 51 -> 20 -> 
EV Route-9: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
EV Route-10: 0(DEPOT) -> 2(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 43 -> 74 -> 
EV Route-12: 0(DEPOT) -> 72(CUSTOMER) -> 39(CUSTOMER) -> 82(STATION) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 57(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 67 -> 23 -> 
  UAV Trip 2: 22 -> 41 -> 57 -> 
EV Route-13: 0(DEPOT) -> 53(CUSTOMER) -> 68(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 40 -> 26 -> 68 -> 
```

### RC1-75

- Instance: `./instances_bss_bigscal/rc101_n75_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 51879.1
- Avg cost: 53493.1
- Avg time(s): 491.1
- Gap%: 3.11
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 52102.1 | true | 492.1 |
| 2 | 2 | 54630.1 | true | 510.1 |
| 3 | 3 | 51879.1 | true | 459.1 |
| 4 | 4 | 54605.1 | true | 475.1 |
| 5 | 5 | 54249.1 | true | 521.1 |

#### Best Route Plan

```text
totalCost=51879.29298380259, evUavCost=36879.29298380259, stationOpenCost=15000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 36(CUSTOMER) -> 78(STATION) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 44 -> 43 -> 37 -> 
EV Route-1: 0(DEPOT) -> 64(CUSTOMER) -> 18(CUSTOMER) -> 83(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 51 -> 18 -> 
  UAV Trip 2: 83 -> 48 -> 25 -> 
EV Route-2: 0(DEPOT) -> 72(CUSTOMER) -> 71(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 67 -> 66 -> 
EV Route-3: 0(DEPOT) -> 42(CUSTOMER) -> 39(CUSTOMER) -> 78(STATION) -> 38(CUSTOMER) -> 41(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 40 -> 38 -> 
EV Route-4: 0(DEPOT) -> 80(STATION) -> 11(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 12 -> 73 -> 60 -> 
EV Route-5: 0(DEPOT) -> 62(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 77(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 26 -> 77 -> 
EV Route-6: 0(DEPOT) -> 61(CUSTOMER) -> 55(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 61 -> 53 -> 55 -> 
EV Route-7: 0(DEPOT) -> 69(CUSTOMER) -> 2(CUSTOMER) -> 82(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 6 -> 82 -> 
EV Route-8: 0(DEPOT) -> 80(STATION) -> 47(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 9 -> 10 -> 
  UAV Trip 2: 80 -> 14 -> 47 -> 
EV Route-9: 0(DEPOT) -> 65(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 57 -> 
EV Route-10: 0(DEPOT) -> 77(STATION) -> 50(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 27 -> 30 -> 50 -> 
EV Route-11: 0(DEPOT) -> 83(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 23 -> 21 -> 
  UAV Trip 2: 19 -> 49 -> 24 -> 58 -> 
EV Route-12: 0(DEPOT) -> 63(CUSTOMER) -> 33(CUSTOMER) -> 77(STATION) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 28 -> 77 -> 
EV Route-13: 0(DEPOT) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 82(STATION) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 7 -> 8 -> 82 -> 
EV Route-14: 0(DEPOT) -> 59(CUSTOMER) -> 74(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 74 -> 
```

### RC2-75

- Instance: `./instances_bss_bigscal/rc201_n75_bss.txt`
- Feasible runs: 5/5
- Best run seed: 5
- Best cost: 46570.1
- Avg cost: 46878.1
- Avg time(s): 498.1
- Gap%: 0.66
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 46729.1 | true | 463.1 |
| 2 | 2 | 47017.1 | true | 509.1 |
| 3 | 3 | 47479.1 | true | 529.1 |
| 4 | 4 | 46596.1 | true | 485.1 |
| 5 | 5 | 46570.1 | true | 503.1 |

#### Best Route Plan

```text
totalCost=46569.692454130636, evUavCost=34569.692454130636, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-2: 0(DEPOT) -> 71(CUSTOMER) -> 54(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 68 -> 70 -> 
EV Route-3: 0(DEPOT) -> 63(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 51 -> 56 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-5: 0(DEPOT) -> 14(CUSTOMER) -> 47(CUSTOMER) -> 79(STATION) -> 59(CUSTOMER) -> 75(CUSTOMER) -> 79(STATION) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 73 -> 53 -> 
EV Route-6: 0(DEPOT) -> 72(CUSTOMER) -> 78(STATION) -> 36(CUSTOMER) -> 35(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 42 -> 39 -> 36 -> 
  UAV Trip 2: 35 -> 37 -> 43 -> 
EV Route-7: 0(DEPOT) -> 77(STATION) -> 23(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 25 -> 48 -> 
  UAV Trip 2: 23 -> 21 -> 18 -> 49 -> 
EV Route-8: 0(DEPOT) -> 64(CUSTOMER) -> 19(CUSTOMER) -> 77(STATION) -> 22(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 57 -> 66 -> 
EV Route-9: 0(DEPOT) -> 55(CUSTOMER) -> 4(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 69(CUSTOMER) -> 12(CUSTOMER) -> 79(STATION) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-11: 0(DEPOT) -> 81(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 62(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 33 -> 31 -> 
  UAV Trip 2: 29 -> 27 -> 28 -> 30 -> 
EV Route-12: 0(DEPOT) -> 61(CUSTOMER) -> 44(CUSTOMER) -> 38(CUSTOMER) -> 78(STATION) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 40 -> 38 -> 
EV Route-13: 0(DEPOT) -> 67(CUSTOMER) -> 34(CUSTOMER) -> 81(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 26 -> 32 -> 
  UAV Trip 2: 67 -> 50 -> 34 -> 
EV Route-14: 0(DEPOT) -> 65(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 74(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 79 -> 
  UAV Trip 2: 16 -> 17 -> 13 -> 74 -> 
```

### C1-100

- Instance: `./instances_bss_bigscal/c101_n100_bss.txt`
- Feasible runs: 5/5
- Best run seed: 5
- Best cost: 47741.1
- Avg cost: 49668.1
- Avg time(s): 1033.1
- Gap%: 4.04
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 50091.1 | true | 985.1 |
| 2 | 2 | 50072.1 | true | 1006.1 |
| 3 | 3 | 50133.1 | true | 1126.1 |
| 4 | 4 | 50304.1 | true | 1087.1 |
| 5 | 5 | 47741.1 | true | 959.1 |

#### Best Route Plan

```text
totalCost=47741.3470635175, evUavCost=35741.3470635175, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 98(CUSTOMER) -> 93(CUSTOMER) -> 102(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 98 -> 94 -> 92 -> 93 -> 
EV Route-1: 0(DEPOT) -> 10(CUSTOMER) -> 17(CUSTOMER) -> 103(STATION) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 103 -> 
EV Route-2: 0(DEPOT) -> 81(CUSTOMER) -> 105(STATION) -> 77(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 78 -> 76 -> 105 -> 
  UAV Trip 2: 77 -> 79 -> 80 -> 
EV Route-3: 0(DEPOT) -> 112(STATION) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 52(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 52 -> 
EV Route-4: 0(DEPOT) -> 96(CUSTOMER) -> 95(CUSTOMER) -> 99(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 97 -> 99 -> 
EV Route-5: 0(DEPOT) -> 63(CUSTOMER) -> 105(STATION) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 105 -> 71 -> 70 -> 
EV Route-6: 0(DEPOT) -> 13(CUSTOMER) -> 103(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-7: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 51 -> 50 -> 49 -> 
EV Route-8: 0(DEPOT) -> 57(CUSTOMER) -> 112(STATION) -> 37(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 55 -> 112 -> 
EV Route-9: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-10: 0(DEPOT) -> 90(CUSTOMER) -> 102(STATION) -> 83(CUSTOMER) -> 84(CUSTOMER) -> 85(CUSTOMER) -> 88(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 90 -> 87 -> 86 -> 102 -> 
  UAV Trip 2: 83 -> 82 -> 84 -> 
  UAV Trip 3: 88 -> 89 -> 91 -> 
EV Route-11: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-12: 0(DEPOT) -> 33(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 38 -> 36 -> 
EV Route-13: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-14: 0(DEPOT) -> 32(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 32 -> 31 -> 35 -> 34 -> 
```

### C2-100

- Instance: `./instances_bss_bigscal/c201_n100_bss.txt`
- Feasible runs: 5/5
- Best run seed: 5
- Best cost: 44892.1
- Avg cost: 46628.1
- Avg time(s): 1095.1
- Gap%: 3.87
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 47480.1 | true | 1089.1 |
| 2 | 2 | 47846.1 | true | 1191.1 |
| 3 | 3 | 45032.1 | true | 951.1 |
| 4 | 4 | 47890.1 | true | 1185.1 |
| 5 | 5 | 44892.1 | true | 1057.1 |

#### Best Route Plan

```text
totalCost=44891.80594762838, evUavCost=35891.80594762838, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 63(CUSTOMER) -> 62(CUSTOMER) -> 74(CUSTOMER) -> 49(CUSTOMER) -> 104(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 64 -> 49 -> 
EV Route-1: 0(DEPOT) -> 69(CUSTOMER) -> 104(STATION) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
  UAV Trip 3: 69 -> 68 -> 104 -> 
EV Route-2: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 102(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 31 -> 35 -> 102 -> 
EV Route-3: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-4: 0(DEPOT) -> 93(CUSTOMER) -> 75(CUSTOMER) -> 7(CUSTOMER) -> 90(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 3 -> 4 -> 89 -> 90 -> 
EV Route-5: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 29(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 102(STATION) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 34 -> 28 -> 
EV Route-6: 0(DEPOT) -> 105(STATION) -> 84(CUSTOMER) -> 82(CUSTOMER) -> 85(CUSTOMER) -> 78(CUSTOMER) -> 77(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 81 -> 78 -> 
  UAV Trip 2: 84 -> 83 -> 82 -> 
EV Route-7: 0(DEPOT) -> 67(CUSTOMER) -> 65(CUSTOMER) -> 104(STATION) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
  UAV Trip 3: 67 -> 66 -> 65 -> 
EV Route-8: 0(DEPOT) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 96(CUSTOMER) -> 87(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 41 -> 48 -> 
EV Route-9: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 98(CUSTOMER) -> 105(STATION) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 1 -> 99 -> 100 -> 98 -> 
EV Route-10: 0(DEPOT) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 102(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 36 -> 102 -> 
EV Route-11: 0(DEPOT) -> 91(CUSTOMER) -> 105(STATION) -> 86(CUSTOMER) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 79(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 91 -> 88 -> 105 -> 
  UAV Trip 2: 86 -> 76 -> 71 -> 
  UAV Trip 3: 70 -> 73 -> 79 -> 
EV Route-12: 0(DEPOT) -> 105(STATION) -> 97(CUSTOMER) -> 95(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 97 -> 92 -> 94 -> 95 -> 
EV Route-14: 0(DEPOT) -> 22(CUSTOMER) -> 30(CUSTOMER) -> 102(STATION) -> 19(CUSTOMER) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 15 -> 
  UAV Trip 2: 102 -> 23 -> 18 -> 19 -> 
  UAV Trip 3: 22 -> 27 -> 30 -> 
```

### R1-100

- Instance: `./instances_bss_bigscal/r101_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 322346.1
- Avg cost: 447558.1
- Avg time(s): 1307.1
- Gap%: 38.84
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 507650.1 | false | 1416.1 |
| 2 | 2 | 463304.1 | false | 1456.1 |
| 3 | 3 | 527824.1 | false | 1212.1 |
| 4 | 4 | 322346.1 | false | 1183.1 |
| 5 | 5 | 416665.1 | false | 1265.1 |

#### Best Route Plan

```text
totalCost=322345.9141471379, evUavCost=37625.55476275628, stationOpenCost=30000.0, violationCost=254720.35938438165, overloadAmount=0.0, timeViolationAmount=254.72035938438165
EV Route-0: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 109(STATION) -> 99(CUSTOMER) -> 6(CUSTOMER) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 13(CUSTOMER) -> 89(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 76(CUSTOMER) -> 3(CUSTOMER) -> 54(CUSTOMER) -> 24(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 81 -> 3 -> 
EV Route-2: 0(DEPOT) -> 111(STATION) -> 33(CUSTOMER) -> 29(CUSTOMER) -> 78(CUSTOMER) -> 34(CUSTOMER) -> 68(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 79 -> 78 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 26(CUSTOMER) -> 102(STATION) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 31(CUSTOMER) -> 62(CUSTOMER) -> 88(CUSTOMER) -> 7(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 27(CUSTOMER) -> 87(CUSTOMER) -> 57(CUSTOMER) -> 37(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 97 -> 37 -> 
  UAV Trip 2: 27 -> 52 -> 87 -> 
EV Route-6: 0(DEPOT) -> 69(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 103(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 51 -> 
  UAV Trip 2: 20 -> 32 -> 103 -> 
EV Route-7: 0(DEPOT) -> 72(CUSTOMER) -> 112(STATION) -> 75(CUSTOMER) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 39(CUSTOMER) -> 4(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 63(CUSTOMER) -> 64(CUSTOMER) -> 90(CUSTOMER) -> 103(STATION) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 11 -> 64 -> 
  UAV Trip 2: 90 -> 10 -> 103 -> 
EV Route-9: 0(DEPOT) -> 45(CUSTOMER) -> 83(CUSTOMER) -> 82(CUSTOMER) -> 18(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 104(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 108(STATION) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 108 -> 66 -> 35 -> 
EV Route-11: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 106(STATION) -> 49(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 19 -> 106 -> 
EV Route-12: 0(DEPOT) -> 95(CUSTOMER) -> 98(CUSTOMER) -> 61(CUSTOMER) -> 85(CUSTOMER) -> 84(CUSTOMER) -> 104(STATION) -> 60(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 92(CUSTOMER) -> 42(CUSTOMER) -> 22(CUSTOMER) -> 56(CUSTOMER) -> 112(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 41 -> 22 -> 
  UAV Trip 2: 56 -> 74 -> 112 -> 
EV Route-14: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 38(CUSTOMER) -> 43(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-100

- Instance: `./instances_bss_bigscal/r201_n100_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 43246.1
- Avg cost: 43819.1
- Avg time(s): 1204.1
- Gap%: 1.32
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 43466.1 | true | 1320.1 |
| 2 | 2 | 43907.1 | true | 1449.1 |
| 3 | 3 | 43246.1 | true | 1159.1 |
| 4 | 4 | 43849.1 | true | 1093.1 |
| 5 | 5 | 44626.1 | true | 997.1 |

#### Best Route Plan

```text
totalCost=43246.002966239044, evUavCost=34246.002966239044, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 83(CUSTOMER) -> 101(STATION) -> 8(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 45 -> 36 -> 101 -> 
  UAV Trip 2: 8 -> 46 -> 17 -> 
EV Route-1: 0(DEPOT) -> 59(CUSTOMER) -> 99(CUSTOMER) -> 61(CUSTOMER) -> 85(CUSTOMER) -> 91(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 61 -> 16 -> 85 -> 
EV Route-2: 0(DEPOT) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 68(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 3 -> 
  UAV Trip 2: 68 -> 80 -> 77 -> 
EV Route-3: 0(DEPOT) -> 31(CUSTOMER) -> 62(CUSTOMER) -> 88(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 63 -> 62 -> 
  UAV Trip 2: 88 -> 7 -> 18 -> 
EV Route-4: 0(DEPOT) -> 95(CUSTOMER) -> 92(CUSTOMER) -> 86(CUSTOMER) -> 84(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 92 -> 98 -> 44 -> 86 -> 
EV Route-5: 0(DEPOT) -> 39(CUSTOMER) -> 75(CUSTOMER) -> 103(STATION) -> 97(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 103 -> 15 -> 43 -> 97 -> 
  UAV Trip 2: 39 -> 23 -> 75 -> 
EV Route-6: 0(DEPOT) -> 52(CUSTOMER) -> 82(CUSTOMER) -> 101(STATION) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 11 -> 64 -> 49 -> 
  UAV Trip 2: 82 -> 47 -> 101 -> 
EV Route-7: 0(DEPOT) -> 112(STATION) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 9 -> 51 -> 50 -> 
  UAV Trip 2: 112 -> 33 -> 65 -> 
EV Route-8: 0(DEPOT) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 96 -> 93 -> 60 -> 48 -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 37 -> 
EV Route-10: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 90 -> 32 -> 
EV Route-11: 0(DEPOT) -> 28(CUSTOMER) -> 76(CUSTOMER) -> 112(STATION) -> 81(CUSTOMER) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 78 -> 34 -> 20 -> 
  UAV Trip 2: 76 -> 79 -> 112 -> 
EV Route-12: 0(DEPOT) -> 87(CUSTOMER) -> 57(CUSTOMER) -> 103(STATION) -> 4(CUSTOMER) -> 54(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 55 -> 25 -> 24 -> 
  UAV Trip 2: 57 -> 41 -> 22 -> 103 -> 
EV Route-13: 0(DEPOT) -> 72(CUSTOMER) -> 103(STATION) -> 67(CUSTOMER) -> 56(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 103 -> 73 -> 21 -> 67 -> 
EV Route-14: 0(DEPOT) -> 53(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 40 -> 26 -> 13 -> 
```

### RC1-100

- Instance: `./instances_bss_bigscal/rc101_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 217127.1
- Avg cost: 268457.1
- Avg time(s): 714.1
- Gap%: 23.64
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 323576.1 | false | 726.1 |
| 2 | 2 | 316892.1 | false | 744.1 |
| 3 | 3 | 256789.1 | false | 652.1 |
| 4 | 4 | 217127.1 | false | 720.1 |
| 5 | 5 | 227903.1 | false | 729.1 |

#### Best Route Plan

```text
totalCost=217127.39472836204, evUavCost=40956.01612849817, stationOpenCost=27000.0, violationCost=149171.37859986388, overloadAmount=0.0, timeViolationAmount=149.17137859986389
EV Route-0: 0(DEPOT) -> 39(CUSTOMER) -> 106(STATION) -> 38(CUSTOMER) -> 41(CUSTOMER) -> 61(CUSTOMER) -> 68(CUSTOMER) -> 55(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 101(STATION) -> 11(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 12 -> 15 -> 
  UAV Trip 2: 16 -> 9 -> 10 -> 
EV Route-2: 0(DEPOT) -> 65(CUSTOMER) -> 83(CUSTOMER) -> 64(CUSTOMER) -> 56(CUSTOMER) -> 102(STATION) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 84 -> 85 -> 56 -> 
EV Route-3: 0(DEPOT) -> 102(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 107(STATION) -> 34(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 78(CUSTOMER) -> 110(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 17 -> 110 -> 
  UAV Trip 2: 69 -> 98 -> 88 -> 53 -> 
EV Route-5: 0(DEPOT) -> 42(CUSTOMER) -> 106(STATION) -> 36(CUSTOMER) -> 44(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 63(CUSTOMER) -> 109(STATION) -> 76(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 22 -> 
  UAV Trip 2: 20 -> 48 -> 24 -> 
EV Route-7: 0(DEPOT) -> 72(CUSTOMER) -> 71(CUSTOMER) -> 90(CUSTOMER) -> 110(STATION) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 81 -> 90 -> 
EV Route-8: 0(DEPOT) -> 105(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 49 -> 25 -> 
  UAV Trip 2: 105 -> 23 -> 21 -> 
EV Route-9: 0(DEPOT) -> 92(CUSTOMER) -> 102(STATION) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 92 -> 95 -> 62 -> 67 -> 102 -> 
  UAV Trip 2: 96 -> 54 -> 93 -> 80 -> 
EV Route-10: 0(DEPOT) -> 59(CUSTOMER) -> 103(STATION) -> 75(CUSTOMER) -> 97(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 103 -> 87 -> 75 -> 
EV Route-11: 0(DEPOT) -> 110(STATION) -> 99(CUSTOMER) -> 86(CUSTOMER) -> 58(CUSTOMER) -> 103(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 82 -> 52 -> 99 -> 
  UAV Trip 2: 86 -> 57 -> 58 -> 
EV Route-12: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 47(CUSTOMER) -> 73(CUSTOMER) -> 79(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 108(STATION) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 108(STATION) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 107(STATION) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2-100

- Instance: `./instances_bss_bigscal/rc201_n100_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 54163.1
- Avg cost: 57775.1
- Avg time(s): 916.1
- Gap%: 6.67
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 58418.1 | true | 811.1 |
| 2 | 2 | 57643.1 | true | 950.1 |
| 3 | 3 | 54163.1 | true | 882.1 |
| 4 | 4 | 60439.1 | true | 971.1 |
| 5 | 5 | 58215.1 | true | 963.1 |

#### Best Route Plan

```text
totalCost=54162.59973313054, evUavCost=39162.59973313054, stationOpenCost=15000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 45(CUSTOMER) -> 108(STATION) -> 7(CUSTOMER) -> 79(CUSTOMER) -> 78(CUSTOMER) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 108 -> 
  UAV Trip 2: 79 -> 73 -> 78 -> 
EV Route-1: 0(DEPOT) -> 64(CUSTOMER) -> 22(CUSTOMER) -> 49(CUSTOMER) -> 110(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 25 -> 77 -> 58 -> 
  UAV Trip 2: 22 -> 20 -> 49 -> 
EV Route-2: 0(DEPOT) -> 83(CUSTOMER) -> 23(CUSTOMER) -> 48(CUSTOMER) -> 110(STATION) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 18 -> 48 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 108(STATION) -> 46(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 100(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 108 -> 6 -> 8 -> 46 -> 
  UAV Trip 2: 3 -> 1 -> 4 -> 
EV Route-4: 0(DEPOT) -> 72(CUSTOMER) -> 102(STATION) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 38(CUSTOMER) -> 35(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 42 -> 39 -> 
  UAV Trip 2: 38 -> 44 -> 35 -> 
EV Route-5: 0(DEPOT) -> 110(STATION) -> 19(CUSTOMER) -> 76(CUSTOMER) -> 84(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 85 -> 84 -> 
EV Route-6: 0(DEPOT) -> 94(CUSTOMER) -> 50(CUSTOMER) -> 106(STATION) -> 32(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 50 -> 34 -> 106 -> 
EV Route-7: 0(DEPOT) -> 90(CUSTOMER) -> 54(CUSTOMER) -> 96(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 90 -> 68 -> 54 -> 
  UAV Trip 2: 96 -> 91 -> 80 -> 
EV Route-8: 0(DEPOT) -> 69(CUSTOMER) -> 12(CUSTOMER) -> 104(STATION) -> 16(CUSTOMER) -> 9(CUSTOMER) -> 99(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 98 -> 88 -> 12 -> 
  UAV Trip 2: 9 -> 87 -> 99 -> 
EV Route-9: 0(DEPOT) -> 95(CUSTOMER) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 106(STATION) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 63 -> 33 -> 
  UAV Trip 2: 106 -> 26 -> 93 -> 
EV Route-10: 0(DEPOT) -> 81(CUSTOMER) -> 41(CUSTOMER) -> 102(STATION) -> 43(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 61 -> 41 -> 
  UAV Trip 2: 102 -> 40 -> 43 -> 
EV Route-11: 0(DEPOT) -> 65(CUSTOMER) -> 52(CUSTOMER) -> 86(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 57 -> 86 -> 
EV Route-12: 0(DEPOT) -> 82(CUSTOMER) -> 104(STATION) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 17(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 104 -> 47 -> 15 -> 11 -> 
  UAV Trip 2: 10 -> 13 -> 17 -> 
EV Route-13: 0(DEPOT) -> 14(CUSTOMER) -> 104(STATION) -> 59(CUSTOMER) -> 97(CUSTOMER) -> 104(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 97 -> 
EV Route-14: 0(DEPOT) -> 92(CUSTOMER) -> 31(CUSTOMER) -> 106(STATION) -> 29(CUSTOMER) -> 67(CUSTOMER) -> 71(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 28 -> 27 -> 29 -> 
  UAV Trip 2: 92 -> 62 -> 31 -> 
```

