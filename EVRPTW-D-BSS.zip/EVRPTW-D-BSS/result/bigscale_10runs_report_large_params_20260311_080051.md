# Large-Scale Instances Report (10 runs each)

- Generated at: 2026-03-11T08:00:51.088
- Status: Finished
- Completed cases: 24/24
- Runs per case: 10
- Parameter set label: LargeScaleParamSet-UserUpdated

## Large-Scale Parameter Set (Current)

- evCount: 15
- evCapacity: 200.0
- evEnergy: 800.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 30.0
- uavEnergy: 30.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 5
- evFixedCost: 1500.0
- stationOpenCost: 3000.0
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 700
- alnsRestarts: 4
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1-25 | 10432.1 | 10432.1 | 0.00 | 48.1 |
| C2-25 | 12186.1 | 12207.1 | 0.17 | 75.1 |
| R1-25 | 16356.1 | 16356.1 | -0.00 | 53.1 |
| R2-25 | 12471.1 | 12471.1 | 0.00 | 49.1 |
| RC1-25 | 19467.1 | 19468.1 | 0.01 | 62.1 |
| RC2-25 | 17889.1 | 18772.1 | 4.93 | 67.1 |
| C1-50 | 18763.1 | 19138.1 | 2.00 | 284.1 |
| C2-50 | 21665.1 | 22104.1 | 2.03 | 414.1 |
| R1-50 | 27024.1 | 27720.1 | 2.58 | 275.1 |
| R2-50 | 23129.1 | 23637.1 | 2.19 | 272.1 |
| RC1-50 | 37091.1 | 37604.1 | 1.38 | 293.1 |
| RC2-50 | 34909.1 | 35412.1 | 1.44 | 238.1 |
| C1-75 | 33544.1 | 33851.1 | 0.92 | 452.1 |
| C2-75 | 33096.1 | 34104.1 | 3.04 | 654.1 |
| R1-75 | 45277.1 | 47883.1 | 5.76 | 574.1 |
| R2-75 | 33580.1 | 34675.1 | 3.26 | 527.1 |
| RC1-75 | 51137.1 | 52619.1 | 2.90 | 451.1 |
| RC2-75 | 45623.1 | 46268.1 | 1.41 | 470.1 |
| C1-100 | 44794.1 | 48413.1 | 8.08 | 1169.1 |
| C2-100 | 45437.1 | 47218.1 | 3.92 | 1262.1 |
| R1-100 | 369149.1 | 436135.1 | 18.15 | 1512.1 |
| R2-100 | 41175.1 | 43184.1 | 4.88 | 2951.1 |
| RC1-100 | 179848.1 | 254185.1 | 41.33 | 960.1 |
| RC2-100 | 55252.1 | 56887.1 | 2.96 | 1189.1 |

## Issues During Run

- 2026-03-08 12:53:09	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 13:11:08	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 13:41:25	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 14:11:34	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 14:41:44	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 15:11:53	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 16:04:48	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 16:16:43	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 16:46:54	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 17:17:02	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 17:55:00	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 18:25:13	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 18:55:24	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 19:25:34	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 19:55:45	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 20:25:56	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 20:56:44	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 21:30:12	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 22:00:22	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 22:30:34	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 23:00:49	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-08 23:30:57	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 00:01:13	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 01:01:29	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 02:01:38	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 03:01:47	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 04:01:56	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 05:02:09	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 06:02:19	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 07:02:31	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 14:09:26	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 15:09:39	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 16:10:30	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 16:41:48	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 17:12:03	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 17:53:10	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 17:56:14	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 18:36:29	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 19:16:43	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 19:56:50	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 20:37:08	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 21:17:22	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 22:07:31	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 22:47:41	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-09 23:27:53	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-10 00:08:36	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-10 14:49:50	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-10 14:58:42	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.
- 2026-03-10 16:25:08	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for large-scale 10-run experiment.

## Best Routes And Run Logs

### C1-25

- Instance: `./instances_bss_bigscal/c101_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 10432.1
- Avg cost: 10432.1
- Avg time(s): 48.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 10432.1 | true | 28.1 |
| 2 | 2 | 10432.1 | true | 34.1 |
| 3 | 3 | 10432.1 | true | 39.1 |
| 4 | 4 | 10432.1 | true | 48.1 |
| 5 | 5 | 10432.1 | true | 53.1 |
| 6 | 6 | 10432.1 | true | 48.1 |
| 7 | 7 | 10432.1 | true | 57.1 |
| 8 | 8 | 10432.1 | true | 56.1 |
| 9 | 9 | 10432.1 | true | 59.1 |
| 10 | 10 | 10432.1 | true | 60.1 |

#### Best Route Plan

```text
totalCost=10432.313973254404, evUavCost=10432.313973254404, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 17(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 15 -> 
EV Route-1: 0(DEPOT) -> 13(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 19 -> 16 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-3: 0(DEPOT) -> 10(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 14 -> 12 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 23 -> 22 -> 
```

### C2-25

- Instance: `./instances_bss_bigscal/c201_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 2
- Best cost: 12186.1
- Avg cost: 12207.1
- Avg time(s): 75.1
- Gap%: 0.17
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12231.1 | true | 76.1 |
| 2 | 2 | 12186.1 | true | 69.1 |
| 3 | 3 | 12231.1 | true | 81.1 |
| 4 | 4 | 12214.1 | true | 70.1 |
| 5 | 5 | 12186.1 | true | 70.1 |
| 6 | 6 | 12231.1 | true | 74.1 |
| 7 | 7 | 12231.1 | true | 84.1 |
| 8 | 8 | 12186.1 | true | 78.1 |
| 9 | 9 | 12186.1 | true | 75.1 |
| 10 | 10 | 12186.1 | true | 70.1 |

#### Best Route Plan

```text
totalCost=12185.880964266915, evUavCost=9185.880964266915, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-1: 0(DEPOT) -> 23(CUSTOMER) -> 17(CUSTOMER) -> 31(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 19 -> 17 -> 
EV Route-2: 0(DEPOT) -> 31(STATION) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 31(STATION) -> 9(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 13 -> 9 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 15 -> 
EV Route-13: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 6 -> 21 -> 
```

### R1-25

- Instance: `./instances_bss_bigscal/r101_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 16356.1
- Avg cost: 16356.1
- Avg time(s): 53.1
- Gap%: -0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16356.1 | true | 96.1 |
| 2 | 2 | 16356.1 | true | 49.1 |
| 3 | 3 | 16356.1 | true | 49.1 |
| 4 | 4 | 16356.1 | true | 49.1 |
| 5 | 5 | 16356.1 | true | 47.1 |
| 6 | 6 | 16356.1 | true | 47.1 |
| 7 | 7 | 16356.1 | true | 51.1 |
| 8 | 8 | 16356.1 | true | 45.1 |
| 9 | 9 | 16356.1 | true | 49.1 |
| 10 | 10 | 16356.1 | true | 46.1 |

#### Best Route Plan

```text
totalCost=16355.841347544178, evUavCost=16355.841347544178, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 23(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 22 -> 4 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 
EV Route-4: 0(DEPOT) -> 21(CUSTOMER) -> 3(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 24 -> 25 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 18 -> 6 -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 20 -> 1 -> 
EV Route-9: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 13 -> 
EV Route-14: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-25

- Instance: `./instances_bss_bigscal/r201_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 12471.1
- Avg cost: 12471.1
- Avg time(s): 49.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12471.1 | true | 57.1 |
| 2 | 2 | 12471.1 | true | 53.1 |
| 3 | 3 | 12471.1 | true | 54.1 |
| 4 | 4 | 12471.1 | true | 54.1 |
| 5 | 5 | 12471.1 | true | 51.1 |
| 6 | 6 | 12471.1 | true | 42.1 |
| 7 | 7 | 12471.1 | true | 45.1 |
| 8 | 8 | 12471.1 | true | 46.1 |
| 9 | 9 | 12471.1 | true | 47.1 |
| 10 | 10 | 12471.1 | true | 43.1 |

#### Best Route Plan

```text
totalCost=12470.980485816235, evUavCost=12470.980485816235, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 13 -> 
EV Route-2: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 7 -> 8 -> 18 -> 
EV Route-3: 0(DEPOT) -> 12(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 3 -> 24 -> 4 -> 
EV Route-4: 0(DEPOT) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 10 -> 1 -> 
EV Route-5: 0(DEPOT) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 15(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 14 -> 6 -> 
```

### RC1-25

- Instance: `./instances_bss_bigscal/rc101_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 3
- Best cost: 19467.1
- Avg cost: 19468.1
- Avg time(s): 62.1
- Gap%: 0.01
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19469.1 | true | 54.1 |
| 2 | 2 | 19469.1 | true | 54.1 |
| 3 | 3 | 19467.1 | true | 54.1 |
| 4 | 4 | 19469.1 | true | 58.1 |
| 5 | 5 | 19469.1 | true | 65.1 |
| 6 | 6 | 19467.1 | true | 67.1 |
| 7 | 7 | 19469.1 | true | 66.1 |
| 8 | 8 | 19469.1 | true | 67.1 |
| 9 | 9 | 19467.1 | true | 65.1 |
| 10 | 10 | 19467.1 | true | 67.1 |

#### Best Route Plan

```text
totalCost=19466.76302787241, evUavCost=19466.76302787241, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 6(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 17 -> 13 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 8 -> 4 -> 
EV Route-7: 0(DEPOT) -> 12(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 15 -> 16 -> 
EV Route-10: 0(DEPOT) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 
EV Route-11: 0(DEPOT) -> 19(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 21 -> 24 -> 
EV Route-13: 0(DEPOT) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 18 -> 20 -> 
```

### RC2-25

- Instance: `./instances_bss_bigscal/rc201_n25_bss.txt`
- Feasible runs: 10/10
- Best run seed: 7
- Best cost: 17889.1
- Avg cost: 18772.1
- Avg time(s): 67.1
- Gap%: 4.93
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 18983.1 | true | 64.1 |
| 2 | 2 | 18762.1 | true | 63.1 |
| 3 | 3 | 18762.1 | true | 73.1 |
| 4 | 4 | 18858.1 | true | 67.1 |
| 5 | 5 | 18771.1 | true | 64.1 |
| 6 | 6 | 18686.1 | true | 64.1 |
| 7 | 7 | 17889.1 | true | 67.1 |
| 8 | 8 | 18943.1 | true | 70.1 |
| 9 | 9 | 19055.1 | true | 69.1 |
| 10 | 10 | 19010.1 | true | 66.1 |

#### Best Route Plan

```text
totalCost=17889.11024640328, evUavCost=14889.110246403283, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 27(STATION) -> 11(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 27(STATION) -> 17(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 16 -> 9 -> 
  UAV Trip 2: 27 -> 13 -> 17 -> 
EV Route-4: 0(DEPOT) -> 22(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 24 -> 25 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 5 -> 3 -> 1 -> 
EV Route-6: 0(DEPOT) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 27(STATION) -> 23(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 12 -> 
  UAV Trip 2: 23 -> 21 -> 20 -> 
EV Route-11: 0(DEPOT) -> 6(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 
```

### C1-50

- Instance: `./instances_bss_bigscal/c101_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 2
- Best cost: 18763.1
- Avg cost: 19138.1
- Avg time(s): 284.1
- Gap%: 2.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19214.1 | true | 262.1 |
| 2 | 2 | 18763.1 | true | 287.1 |
| 3 | 3 | 18933.1 | true | 303.1 |
| 4 | 4 | 19218.1 | true | 293.1 |
| 5 | 5 | 19210.1 | true | 280.1 |
| 6 | 6 | 19201.1 | true | 275.1 |
| 7 | 7 | 19218.1 | true | 274.1 |
| 8 | 8 | 19191.1 | true | 282.1 |
| 9 | 9 | 19210.1 | true | 294.1 |
| 10 | 10 | 19225.1 | true | 287.1 |

#### Best Route Plan

```text
totalCost=18762.821516534266, evUavCost=15762.821516534266, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-2: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 36 -> 34 -> 
EV Route-5: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 
EV Route-6: 0(DEPOT) -> 54(STATION) -> 31(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 37 -> 38 -> 
EV Route-7: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 50 -> 49 -> 47 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 10 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-9: 0(DEPOT) -> 25(CUSTOMER) -> 54(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
```

### C2-50

- Instance: `./instances_bss_bigscal/c201_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 5
- Best cost: 21665.1
- Avg cost: 22104.1
- Avg time(s): 414.1
- Gap%: 2.03
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 22671.1 | true | 329.1 |
| 2 | 2 | 21968.1 | true | 329.1 |
| 3 | 3 | 22040.1 | true | 357.1 |
| 4 | 4 | 22662.1 | true | 333.1 |
| 5 | 5 | 21665.1 | true | 326.1 |
| 6 | 6 | 22650.1 | true | 376.1 |
| 7 | 7 | 21926.1 | true | 447.1 |
| 8 | 8 | 21741.1 | true | 450.1 |
| 9 | 9 | 21856.1 | true | 558.1 |
| 10 | 10 | 21864.1 | true | 638.1 |

#### Best Route Plan

```text
totalCost=21664.505798389455, evUavCost=18664.505798389455, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 31 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 34 -> 
EV Route-2: 0(DEPOT) -> 22(CUSTOMER) -> 27(CUSTOMER) -> 51(STATION) -> 33(CUSTOMER) -> 36(CUSTOMER) -> 28(CUSTOMER) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 30 -> 51 -> 
  UAV Trip 2: 28 -> 26 -> 23 -> 18 -> 
EV Route-3: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 29 -> 50 -> 47 -> 
  UAV Trip 2: 43 -> 42 -> 41 -> 48 -> 
EV Route-4: 0(DEPOT) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 40 -> 44 -> 46 -> 
EV Route-5: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-6: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-13: 0(DEPOT) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
```

### R1-50

- Instance: `./instances_bss_bigscal/r101_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 2
- Best cost: 27024.1
- Avg cost: 27720.1
- Avg time(s): 275.1
- Gap%: 2.58
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 28467.1 | true | 209.1 |
| 2 | 2 | 27024.1 | true | 223.1 |
| 3 | 3 | 28457.1 | true | 214.1 |
| 4 | 4 | 27475.1 | true | 217.1 |
| 5 | 5 | 27334.1 | true | 209.1 |
| 6 | 6 | 27119.1 | true | 715.1 |
| 7 | 7 | 28483.1 | true | 272.1 |
| 8 | 8 | 28551.1 | true | 245.1 |
| 9 | 9 | 27051.1 | true | 225.1 |
| 10 | 10 | 27243.1 | true | 223.1 |

#### Best Route Plan

```text
totalCost=27023.597729145287, evUavCost=27023.597729145287, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 43 -> 13 -> 
EV Route-1: 0(DEPOT) -> 12(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 40 -> 50 -> 
EV Route-2: 0(DEPOT) -> 27(CUSTOMER) -> 7(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 10 -> 48 -> 
EV Route-3: 0(DEPOT) -> 39(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 41 -> 
EV Route-4: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 37 -> 
EV Route-5: 0(DEPOT) -> 45(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 8 -> 46 -> 17 -> 
EV Route-6: 0(DEPOT) -> 28(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 29 -> 3 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 6 -> 
EV Route-9: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-10: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 22 -> 4 -> 
EV Route-11: 0(DEPOT) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 20 -> 32 -> 
EV Route-12: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-50

- Instance: `./instances_bss_bigscal/r201_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 2
- Best cost: 23129.1
- Avg cost: 23637.1
- Avg time(s): 272.1
- Gap%: 2.19
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 24618.1 | true | 248.1 |
| 2 | 2 | 23129.1 | true | 294.1 |
| 3 | 3 | 23172.1 | true | 285.1 |
| 4 | 4 | 23378.1 | true | 259.1 |
| 5 | 5 | 23173.1 | true | 304.1 |
| 6 | 6 | 23270.1 | true | 270.1 |
| 7 | 7 | 23196.1 | true | 258.1 |
| 8 | 8 | 23196.1 | true | 308.1 |
| 9 | 9 | 24618.1 | true | 247.1 |
| 10 | 10 | 24618.1 | true | 249.1 |

#### Best Route Plan

```text
totalCost=23129.399052949695, evUavCost=23129.399052949695, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-1: 0(DEPOT) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 8 -> 46 -> 48 -> 
EV Route-2: 0(DEPOT) -> 40(CUSTOMER) -> 22(CUSTOMER) -> 4(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 41 -> 22 -> 
  UAV Trip 2: 4 -> 25 -> 24 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 16(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 45 -> 16 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 43 -> 13 -> 
EV Route-5: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 3 -> 
EV Route-6: 0(DEPOT) -> 47(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 49 -> 
EV Route-7: 0(DEPOT) -> 39(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 21 -> 
EV Route-8: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 19 -> 7 -> 10 -> 
EV Route-9: 0(DEPOT) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 32 -> 1 -> 
  UAV Trip 2: 27 -> 31 -> 30 -> 
EV Route-10: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
```

### RC1-50

- Instance: `./instances_bss_bigscal/rc101_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 8
- Best cost: 37091.1
- Avg cost: 37604.1
- Avg time(s): 293.1
- Gap%: 1.38
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 38293.1 | true | 298.1 |
| 2 | 2 | 37711.1 | true | 280.1 |
| 3 | 3 | 37753.1 | true | 300.1 |
| 4 | 4 | 37718.1 | true | 296.1 |
| 5 | 5 | 37096.1 | true | 314.1 |
| 6 | 6 | 37694.1 | true | 290.1 |
| 7 | 7 | 37241.1 | true | 283.1 |
| 8 | 8 | 37091.1 | true | 301.1 |
| 9 | 9 | 37718.1 | true | 278.1 |
| 10 | 10 | 37722.1 | true | 293.1 |

#### Best Route Plan

```text
totalCost=37090.64033760703, evUavCost=34090.64033760703, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-1: 0(DEPOT) -> 14(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 17 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 57(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 33 -> 25 -> 
EV Route-4: 0(DEPOT) -> 57(STATION) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 31 -> 28 -> 
  UAV Trip 2: 30 -> 34 -> 50 -> 
EV Route-5: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 40 -> 43 -> 
EV Route-6: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 12(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 13 -> 
EV Route-9: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 49 -> 20 -> 24 -> 
EV Route-10: 0(DEPOT) -> 7(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 46 -> 4 -> 
EV Route-11: 0(DEPOT) -> 57(STATION) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 26 -> 32 -> 
EV Route-12: 0(DEPOT) -> 38(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 37 -> 35 -> 
EV Route-13: 0(DEPOT) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
```

### RC2-50

- Instance: `./instances_bss_bigscal/rc201_n50_bss.txt`
- Feasible runs: 10/10
- Best run seed: 2
- Best cost: 34909.1
- Avg cost: 35412.1
- Avg time(s): 238.1
- Gap%: 1.44
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 35082.1 | true | 251.1 |
| 2 | 2 | 34909.1 | true | 257.1 |
| 3 | 3 | 35343.1 | true | 256.1 |
| 4 | 4 | 35373.1 | true | 218.1 |
| 5 | 5 | 35847.1 | true | 231.1 |
| 6 | 6 | 35600.1 | true | 230.1 |
| 7 | 7 | 35571.1 | true | 223.1 |
| 8 | 8 | 35600.1 | true | 235.1 |
| 9 | 9 | 35132.1 | true | 242.1 |
| 10 | 10 | 35662.1 | true | 237.1 |

#### Best Route Plan

```text
totalCost=34909.127439309756, evUavCost=28909.127439309756, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-1: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 20 -> 49 -> 24 -> 
EV Route-2: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-3: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 55(STATION) -> 38(CUSTOMER) -> 41(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 40 -> 38 -> 
EV Route-4: 0(DEPOT) -> 39(CUSTOMER) -> 55(STATION) -> 36(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 35 -> 37 -> 43 -> 
EV Route-5: 0(DEPOT) -> 53(STATION) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 28(CUSTOMER) -> 32(CUSTOMER) -> 53(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 26 -> 32 -> 
EV Route-6: 0(DEPOT) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 14(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 16 -> 17 -> 
EV Route-9: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-10: 0(DEPOT) -> 53(STATION) -> 31(CUSTOMER) -> 34(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 29 -> 27 -> 34 -> 
EV Route-11: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 12(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 15 -> 13 -> 
```

### C1-75

- Instance: `./instances_bss_bigscal/c101_n75_bss.txt`
- Feasible runs: 10/10
- Best run seed: 8
- Best cost: 33544.1
- Avg cost: 33851.1
- Avg time(s): 452.1
- Gap%: 0.92
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 33935.1 | true | 459.1 |
| 2 | 2 | 33896.1 | true | 386.1 |
| 3 | 3 | 33913.1 | true | 413.1 |
| 4 | 4 | 33926.1 | true | 411.1 |
| 5 | 5 | 33906.1 | true | 402.1 |
| 6 | 6 | 33643.1 | true | 433.1 |
| 7 | 7 | 33959.1 | true | 393.1 |
| 8 | 8 | 33544.1 | true | 465.1 |
| 9 | 9 | 33848.1 | true | 601.1 |
| 10 | 10 | 33943.1 | true | 557.1 |

#### Best Route Plan

```text
totalCost=33544.26348417594, evUavCost=27544.263484175943, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 57(CUSTOMER) -> 54(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-2: 0(DEPOT) -> 41(CUSTOMER) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 40 -> 58 -> 
EV Route-3: 0(DEPOT) -> 43(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
EV Route-4: 0(DEPOT) -> 31(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 37 -> 39 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-6: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 36 -> 34 -> 
EV Route-7: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-8: 0(DEPOT) -> 55(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 53 -> 56 -> 
EV Route-11: 0(DEPOT) -> 10(CUSTOMER) -> 79(STATION) -> 38(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 17 -> 79 -> 
EV Route-13: 0(DEPOT) -> 13(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 18 -> 19 -> 15 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 
EV Route-14: 0(DEPOT) -> 63(CUSTOMER) -> 71(CUSTOMER) -> 83(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 70 -> 73 -> 
```

### C2-75

- Instance: `./instances_bss_bigscal/c201_n75_bss.txt`
- Feasible runs: 10/10
- Best run seed: 3
- Best cost: 33096.1
- Avg cost: 34104.1
- Avg time(s): 654.1
- Gap%: 3.04
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 35957.1 | true | 571.1 |
| 2 | 2 | 34915.1 | true | 495.1 |
| 3 | 3 | 33096.1 | true | 458.1 |
| 4 | 4 | 34525.1 | true | 678.1 |
| 5 | 5 | 34609.1 | true | 781.1 |
| 6 | 6 | 34599.1 | true | 633.1 |
| 7 | 7 | 33401.1 | true | 726.1 |
| 8 | 8 | 33264.1 | true | 726.1 |
| 9 | 9 | 33441.1 | true | 748.1 |
| 10 | 10 | 33230.1 | true | 719.1 |

#### Best Route Plan

```text
totalCost=33096.344407150325, evUavCost=27096.344407150325, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
EV Route-1: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-2: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 43 -> 42 -> 41 -> 48 -> 
EV Route-3: 0(DEPOT) -> 67(CUSTOMER) -> 78(STATION) -> 64(CUSTOMER) -> 54(CUSTOMER) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 62 -> 78 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
  UAV Trip 3: 64 -> 49 -> 54 -> 
EV Route-4: 0(DEPOT) -> 66(CUSTOMER) -> 78(STATION) -> 65(CUSTOMER) -> 55(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 53 -> 56 -> 
  UAV Trip 2: 66 -> 69 -> 78 -> 
  UAV Trip 3: 58 -> 60 -> 59 -> 
EV Route-5: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 78(STATION) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 68 -> 78 -> 
EV Route-6: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 75(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-10: 0(DEPOT) -> 20(CUSTOMER) -> 33(CUSTOMER) -> 76(STATION) -> 34(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 29 -> 33 -> 
  UAV Trip 2: 34 -> 28 -> 26 -> 
  UAV Trip 3: 23 -> 18 -> 19 -> 
EV Route-11: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 76(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 78(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 31 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 78 -> 
EV Route-12: 0(DEPOT) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 21 -> 
```

### R1-75

- Instance: `./instances_bss_bigscal/r101_n75_bss.txt`
- Feasible runs: 9/10
- Best run seed: 7
- Best cost: 45277.1
- Avg cost: 47883.1
- Avg time(s): 574.1
- Gap%: 5.76
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 48928.1 | true | 701.1 |
| 2 | 2 | 48930.1 | true | 635.1 |
| 3 | 3 | 49250.1 | true | 586.1 |
| 4 | 4 | 48256.1 | true | 524.1 |
| 5 | 5 | 45698.1 | true | 507.1 |
| 6 | 6 | 48582.1 | true | 597.1 |
| 7 | 7 | 45277.1 | true | 446.1 |
| 8 | 8 | 48536.1 | true | 518.1 |
| 9 | 9 | 46313.1 | true | 615.1 |
| 10 | 10 | 49063.1 | false | 614.1 |

#### Best Route Plan

```text
totalCost=45277.384450220685, evUavCost=33277.384450220685, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 53(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 73 -> 40 -> 53 -> 
EV Route-1: 0(DEPOT) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 51 -> 9 -> 34 -> 
EV Route-2: 0(DEPOT) -> 36(CUSTOMER) -> 49(CUSTOMER) -> 82(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 64 -> 49 -> 
EV Route-3: 0(DEPOT) -> 52(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 18 -> 6 -> 13 -> 
EV Route-4: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 50(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 50 -> 
EV Route-5: 0(DEPOT) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 85(STATION) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 66 -> 20 -> 
EV Route-6: 0(DEPOT) -> 42(CUSTOMER) -> 57(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 41 -> 57 -> 
EV Route-7: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 79(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 8 -> 46 -> 17 -> 79 -> 
EV Route-8: 0(DEPOT) -> 72(CUSTOMER) -> 22(CUSTOMER) -> 56(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 21 -> 75 -> 22 -> 
EV Route-9: 0(DEPOT) -> 77(STATION) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 67 -> 
  UAV Trip 2: 55 -> 4 -> 25 -> 
EV Route-10: 0(DEPOT) -> 31(CUSTOMER) -> 10(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 7 -> 10 -> 
EV Route-11: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 60(CUSTOMER) -> 79(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 37 -> 
EV Route-12: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 61(CUSTOMER) -> 79(STATION) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 61 -> 
EV Route-13: 0(DEPOT) -> 63(CUSTOMER) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 82(STATION) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 62 -> 11 -> 
EV Route-14: 0(DEPOT) -> 28(CUSTOMER) -> 29(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 12 -> 29 -> 
  UAV Trip 2: 3 -> 54 -> 24 -> 
```

### R2-75

- Instance: `./instances_bss_bigscal/r201_n75_bss.txt`
- Feasible runs: 10/10
- Best run seed: 9
- Best cost: 33580.1
- Avg cost: 34675.1
- Avg time(s): 527.1
- Gap%: 3.26
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 33912.1 | true | 588.1 |
| 2 | 2 | 34168.1 | true | 538.1 |
| 3 | 3 | 34790.1 | true | 487.1 |
| 4 | 4 | 35433.1 | true | 555.1 |
| 5 | 5 | 35088.1 | true | 524.1 |
| 6 | 6 | 34960.1 | true | 528.1 |
| 7 | 7 | 34367.1 | true | 481.1 |
| 8 | 8 | 35242.1 | true | 504.1 |
| 9 | 9 | 33580.1 | true | 516.1 |
| 10 | 10 | 35207.1 | true | 547.1 |

#### Best Route Plan

```text
totalCost=33580.083953708185, evUavCost=30580.083953708185, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 43 -> 13 -> 
EV Route-3: 0(DEPOT) -> 33(CUSTOMER) -> 3(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 50 -> 3 -> 
EV Route-4: 0(DEPOT) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 57(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 22 -> 41 -> 57 -> 
EV Route-5: 0(DEPOT) -> 28(CUSTOMER) -> 29(CUSTOMER) -> 34(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 34 -> 35 -> 1 -> 
  UAV Trip 2: 28 -> 12 -> 29 -> 
EV Route-6: 0(DEPOT) -> 31(CUSTOMER) -> 79(STATION) -> 62(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 11 -> 79 -> 
  UAV Trip 2: 19 -> 64 -> 49 -> 
EV Route-7: 0(DEPOT) -> 52(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 18 -> 8 -> 48 -> 
EV Route-8: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 7 -> 
EV Route-9: 0(DEPOT) -> 63(CUSTOMER) -> 79(STATION) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 51(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 9 -> 51 -> 
EV Route-10: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 61(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 61 -> 16 -> 17 -> 60 -> 
EV Route-11: 0(DEPOT) -> 53(CUSTOMER) -> 26(CUSTOMER) -> 54(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 4 -> 55 -> 24 -> 
  UAV Trip 2: 53 -> 40 -> 26 -> 
EV Route-12: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 56(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 23 -> 56 -> 
EV Route-13: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 79(STATION) -> 10(CUSTOMER) -> 20(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 79 -> 
  UAV Trip 2: 20 -> 66 -> 32 -> 
EV Route-14: 0(DEPOT) -> 39(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 67 -> 25 -> 
```

### RC1-75

- Instance: `./instances_bss_bigscal/rc101_n75_bss.txt`
- Feasible runs: 10/10
- Best run seed: 3
- Best cost: 51137.1
- Avg cost: 52619.1
- Avg time(s): 451.1
- Gap%: 2.90
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 54098.1 | true | 450.1 |
| 2 | 2 | 51842.1 | true | 462.1 |
| 3 | 3 | 51137.1 | true | 476.1 |
| 4 | 4 | 54003.1 | true | 400.1 |
| 5 | 5 | 51792.1 | true | 461.1 |
| 6 | 6 | 51793.1 | true | 511.1 |
| 7 | 7 | 54585.1 | true | 448.1 |
| 8 | 8 | 51147.1 | true | 423.1 |
| 9 | 9 | 54391.1 | true | 435.1 |
| 10 | 10 | 51406.1 | true | 444.1 |

#### Best Route Plan

```text
totalCost=51137.31402023209, evUavCost=36137.31402023209, stationOpenCost=15000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 61 -> 
EV Route-1: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 80(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 10 -> 80 -> 
EV Route-2: 0(DEPOT) -> 63(CUSTOMER) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 28 -> 30 -> 
EV Route-3: 0(DEPOT) -> 78(STATION) -> 36(CUSTOMER) -> 38(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 41 -> 54 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 82(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 3 -> 1 -> 4 -> 
EV Route-5: 0(DEPOT) -> 39(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 42 -> 44 -> 78 -> 
  UAV Trip 2: 40 -> 43 -> 37 -> 35 -> 
EV Route-6: 0(DEPOT) -> 64(CUSTOMER) -> 56(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 51 -> 56 -> 
EV Route-7: 0(DEPOT) -> 45(CUSTOMER) -> 82(STATION) -> 8(CUSTOMER) -> 7(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 82 -> 
  UAV Trip 2: 7 -> 6 -> 60 -> 
EV Route-8: 0(DEPOT) -> 62(CUSTOMER) -> 31(CUSTOMER) -> 26(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 62 -> 67 -> 31 -> 
EV Route-9: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 73 -> 53 -> 
EV Route-10: 0(DEPOT) -> 14(CUSTOMER) -> 16(CUSTOMER) -> 80(STATION) -> 9(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 15 -> 16 -> 
  UAV Trip 2: 9 -> 74 -> 58 -> 
EV Route-11: 0(DEPOT) -> 83(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 48 -> 25 -> 
  UAV Trip 2: 83 -> 23 -> 21 -> 
EV Route-12: 0(DEPOT) -> 59(CUSTOMER) -> 13(CUSTOMER) -> 80(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 13 -> 
EV Route-13: 0(DEPOT) -> 77(STATION) -> 29(CUSTOMER) -> 34(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 27 -> 29 -> 
EV Route-14: 0(DEPOT) -> 65(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 57 -> 
  UAV Trip 2: 20 -> 24 -> 83 -> 
```

### RC2-75

- Instance: `./instances_bss_bigscal/rc201_n75_bss.txt`
- Feasible runs: 10/10
- Best run seed: 9
- Best cost: 45623.1
- Avg cost: 46268.1
- Avg time(s): 470.1
- Gap%: 1.41
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 46387.1 | true | 443.1 |
| 2 | 2 | 46066.1 | true | 455.1 |
| 3 | 3 | 46272.1 | true | 511.1 |
| 4 | 4 | 45673.1 | true | 492.1 |
| 5 | 5 | 46057.1 | true | 443.1 |
| 6 | 6 | 47165.1 | true | 458.1 |
| 7 | 7 | 46520.1 | true | 487.1 |
| 8 | 8 | 46555.1 | true | 495.1 |
| 9 | 9 | 45623.1 | true | 455.1 |
| 10 | 10 | 46360.1 | true | 463.1 |

#### Best Route Plan

```text
totalCost=45623.27008719493, evUavCost=33623.27008719493, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 72(CUSTOMER) -> 78(STATION) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 42 -> 44 -> 43 -> 
EV Route-1: 0(DEPOT) -> 67(CUSTOMER) -> 34(CUSTOMER) -> 81(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 26 -> 32 -> 
  UAV Trip 2: 67 -> 50 -> 34 -> 
EV Route-3: 0(DEPOT) -> 65(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 77(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 57 -> 
  UAV Trip 2: 77 -> 74 -> 58 -> 
EV Route-4: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-5: 0(DEPOT) -> 69(CUSTOMER) -> 60(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 53 -> 73 -> 60 -> 
EV Route-6: 0(DEPOT) -> 31(CUSTOMER) -> 81(STATION) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 71(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 29 -> 27 -> 28 -> 
  UAV Trip 2: 30 -> 62 -> 71 -> 
EV Route-7: 0(DEPOT) -> 14(CUSTOMER) -> 79(STATION) -> 59(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 9 -> 13 -> 
  UAV Trip 2: 14 -> 47 -> 79 -> 
EV Route-8: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-9: 0(DEPOT) -> 81(STATION) -> 51(CUSTOMER) -> 77(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 18 -> 48 -> 25 -> 
  UAV Trip 2: 81 -> 33 -> 63 -> 51 -> 
EV Route-10: 0(DEPOT) -> 64(CUSTOMER) -> 19(CUSTOMER) -> 77(STATION) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 75(CUSTOMER) -> 77(STATION) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 49 -> 20 -> 
EV Route-11: 0(DEPOT) -> 61(CUSTOMER) -> 41(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 38 -> 78 -> 
  UAV Trip 2: 40 -> 35 -> 37 -> 54 -> 
EV Route-12: 0(DEPOT) -> 68(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 11(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 10(CUSTOMER) -> 66(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 12 -> 10 -> 
```

### C1-100

- Instance: `./instances_bss_bigscal/c101_n100_bss.txt`
- Feasible runs: 10/10
- Best run seed: 4
- Best cost: 44794.1
- Avg cost: 48413.1
- Avg time(s): 1169.1
- Gap%: 8.08
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 48499.1 | true | 1015.1 |
| 2 | 2 | 50070.1 | true | 939.1 |
| 3 | 3 | 47604.1 | true | 1039.1 |
| 4 | 4 | 44794.1 | true | 949.1 |
| 5 | 5 | 50100.1 | true | 934.1 |
| 6 | 6 | 47560.1 | true | 992.1 |
| 7 | 7 | 47608.1 | true | 1519.1 |
| 8 | 8 | 50143.1 | true | 1178.1 |
| 9 | 9 | 48257.1 | true | 1554.1 |
| 10 | 10 | 49492.1 | true | 1576.1 |

#### Best Route Plan

```text
totalCost=44794.02372855071, evUavCost=35794.02372855071, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 31(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 37 -> 39 -> 
EV Route-1: 0(DEPOT) -> 98(CUSTOMER) -> 100(CUSTOMER) -> 99(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 98 -> 97 -> 100 -> 
EV Route-2: 0(DEPOT) -> 41(CUSTOMER) -> 40(CUSTOMER) -> 58(CUSTOMER) -> 112(STATION) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 58 -> 60 -> 112 -> 
EV Route-3: 0(DEPOT) -> 43(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
EV Route-4: 0(DEPOT) -> 67(CUSTOMER) -> 65(CUSTOMER) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 63 -> 62 -> 74 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-6: 0(DEPOT) -> 10(CUSTOMER) -> 103(STATION) -> 38(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 17 -> 103 -> 
EV Route-7: 0(DEPOT) -> 102(STATION) -> 95(CUSTOMER) -> 94(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 96 -> 95 -> 
  UAV Trip 2: 94 -> 92 -> 93 -> 
EV Route-8: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-9: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 36 -> 34 -> 
EV Route-10: 0(DEPOT) -> 87(CUSTOMER) -> 86(CUSTOMER) -> 102(STATION) -> 84(CUSTOMER) -> 85(CUSTOMER) -> 88(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 83 -> 82 -> 84 -> 
  UAV Trip 2: 88 -> 89 -> 91 -> 
EV Route-11: 0(DEPOT) -> 57(CUSTOMER) -> 112(STATION) -> 54(CUSTOMER) -> 53(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 112 -> 55 -> 54 -> 
  UAV Trip 2: 53 -> 56 -> 69 -> 
EV Route-12: 0(DEPOT) -> 13(CUSTOMER) -> 103(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 103 -> 18 -> 19 -> 15 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 
EV Route-13: 0(DEPOT) -> 90(CUSTOMER) -> 102(STATION) -> 76(CUSTOMER) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 102(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 71 -> 70 -> 
EV Route-14: 0(DEPOT) -> 102(STATION) -> 81(CUSTOMER) -> 78(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 77 -> 79 -> 80 -> 
```

### C2-100

- Instance: `./instances_bss_bigscal/c201_n100_bss.txt`
- Feasible runs: 10/10
- Best run seed: 4
- Best cost: 45437.1
- Avg cost: 47218.1
- Avg time(s): 1262.1
- Gap%: 3.92
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 46764.1 | true | 1418.1 |
| 2 | 2 | 47354.1 | true | 1578.1 |
| 3 | 3 | 48134.1 | true | 1931.1 |
| 4 | 4 | 45437.1 | true | 1092.1 |
| 5 | 5 | 49706.1 | true | 1070.1 |
| 6 | 6 | 47107.1 | true | 1073.1 |
| 7 | 7 | 45460.1 | true | 1005.1 |
| 8 | 8 | 47286.1 | true | 1196.1 |
| 9 | 9 | 45828.1 | true | 1069.1 |
| 10 | 10 | 49106.1 | true | 1187.1 |

#### Best Route Plan

```text
totalCost=45437.46001023015, evUavCost=33437.46001023015, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 6(CUSTOMER) -> 33(CUSTOMER) -> 107(STATION) -> 52(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 41 -> 48 -> 
  UAV Trip 2: 107 -> 31 -> 52 -> 
  UAV Trip 3: 6 -> 32 -> 33 -> 
EV Route-1: 0(DEPOT) -> 20(CUSTOMER) -> 29(CUSTOMER) -> 107(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 107 -> 35 -> 37 -> 
  UAV Trip 2: 39 -> 36 -> 34 -> 28 -> 
  UAV Trip 3: 20 -> 24 -> 29 -> 
EV Route-2: 0(DEPOT) -> 93(CUSTOMER) -> 75(CUSTOMER) -> 7(CUSTOMER) -> 89(CUSTOMER) -> 105(STATION) -> 90(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 105 -> 87 -> 90 -> 
  UAV Trip 2: 7 -> 3 -> 4 -> 89 -> 
EV Route-4: 0(DEPOT) -> 69(CUSTOMER) -> 65(CUSTOMER) -> 104(STATION) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 49 -> 104 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
  UAV Trip 3: 45 -> 51 -> 50 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 98(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 1 -> 99 -> 100 -> 98 -> 
EV Route-6: 0(DEPOT) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
EV Route-7: 0(DEPOT) -> 67(CUSTOMER) -> 63(CUSTOMER) -> 62(CUSTOMER) -> 74(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 64 -> 66 -> 
EV Route-8: 0(DEPOT) -> 22(CUSTOMER) -> 30(CUSTOMER) -> 102(STATION) -> 23(CUSTOMER) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 19 -> 16 -> 
  UAV Trip 2: 22 -> 27 -> 30 -> 
EV Route-9: 0(DEPOT) -> 105(STATION) -> 97(CUSTOMER) -> 95(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 97 -> 92 -> 94 -> 95 -> 
EV Route-10: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-11: 0(DEPOT) -> 68(CUSTOMER) -> 104(STATION) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 104(STATION) -> 80(CUSTOMER) -> 96(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
EV Route-12: 0(DEPOT) -> 91(CUSTOMER) -> 105(STATION) -> 86(CUSTOMER) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 79(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 91 -> 88 -> 105 -> 
  UAV Trip 2: 86 -> 76 -> 71 -> 
  UAV Trip 3: 70 -> 73 -> 79 -> 
EV Route-13: 0(DEPOT) -> 105(STATION) -> 84(CUSTOMER) -> 82(CUSTOMER) -> 85(CUSTOMER) -> 78(CUSTOMER) -> 77(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 81 -> 78 -> 
  UAV Trip 2: 84 -> 83 -> 82 -> 
```

### R1-100

- Instance: `./instances_bss_bigscal/r101_n100_bss.txt`
- Feasible runs: 0/10
- Best run seed: 5
- Best cost: 369149.1
- Avg cost: 436135.1
- Avg time(s): 1512.1
- Gap%: 18.15
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 410678.1 | false | 1252.1 |
| 2 | 2 | 444074.1 | false | 1217.1 |
| 3 | 3 | 474410.1 | false | 1444.1 |
| 4 | 4 | 445335.1 | false | 1244.1 |
| 5 | 5 | 369149.1 | false | 1723.1 |
| 6 | 6 | 406222.1 | false | 1212.1 |
| 7 | 7 | 529531.1 | false | 1886.1 |
| 8 | 8 | 439076.1 | false | 1787.1 |
| 9 | 9 | 424754.1 | false | 1893.1 |
| 10 | 10 | 418116.1 | false | 1465.1 |

#### Best Route Plan

```text
totalCost=369148.803830773, evUavCost=38467.74669010486, stationOpenCost=24000.0, violationCost=306681.0571406681, overloadAmount=0.0, timeViolationAmount=306.6810571406681
EV Route-0: 0(DEPOT) -> 45(CUSTOMER) -> 109(STATION) -> 87(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 109 -> 99 -> 84 -> 87 -> 
EV Route-1: 0(DEPOT) -> 112(STATION) -> 39(CUSTOMER) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 22(CUSTOMER) -> 112(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 21 -> 73 -> 75 -> 
  UAV Trip 2: 112 -> 4 -> 25 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 38(CUSTOMER) -> 43(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 111(STATION) -> 33(CUSTOMER) -> 29(CUSTOMER) -> 78(CUSTOMER) -> 50(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 79 -> 78 -> 
  UAV Trip 2: 50 -> 1 -> 77 -> 
EV Route-5: 0(DEPOT) -> 27(CUSTOMER) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 51(CUSTOMER) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 111(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 69(CUSTOMER) -> 52(CUSTOMER) -> 53(CUSTOMER) -> 40(CUSTOMER) -> 26(CUSTOMER) -> 74(CUSTOMER) -> 112(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 83(CUSTOMER) -> 82(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 17(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 103(STATION) -> 62(CUSTOMER) -> 88(CUSTOMER) -> 18(CUSTOMER) -> 6(CUSTOMER) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 60(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 106(STATION) -> 90(CUSTOMER) -> 10(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 65(CUSTOMER) -> 108(STATION) -> 71(CUSTOMER) -> 9(CUSTOMER) -> 34(CUSTOMER) -> 35(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-11: 0(DEPOT) -> 103(STATION) -> 63(CUSTOMER) -> 11(CUSTOMER) -> 64(CUSTOMER) -> 49(CUSTOMER) -> 106(STATION) -> 19(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-12: 0(DEPOT) -> 59(CUSTOMER) -> 92(CUSTOMER) -> 95(CUSTOMER) -> 98(CUSTOMER) -> 61(CUSTOMER) -> 85(CUSTOMER) -> 109(STATION) -> 97(CUSTOMER) -> 37(CUSTOMER) -> 91(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 42(CUSTOMER) -> 2(CUSTOMER) -> 15(CUSTOMER) -> 41(CUSTOMER) -> 57(CUSTOMER) -> 56(CUSTOMER) -> 112(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 76(CUSTOMER) -> 3(CUSTOMER) -> 68(CUSTOMER) -> 24(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 81 -> 3 -> 
```

### R2-100

- Instance: `./instances_bss_bigscal/r201_n100_bss.txt`
- Feasible runs: 10/10
- Best run seed: 3
- Best cost: 41175.1
- Avg cost: 43184.1
- Avg time(s): 2951.1
- Gap%: 4.88
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 42970.1 | true | 1441.1 |
| 2 | 2 | 43044.1 | true | 1340.1 |
| 3 | 3 | 41175.1 | true | 1456.1 |
| 4 | 4 | 43242.1 | true | 1486.1 |
| 5 | 5 | 43660.1 | true | 16906.1 |
| 6 | 6 | 43685.1 | true | 1501.1 |
| 7 | 7 | 43811.1 | true | 1339.1 |
| 8 | 8 | 43595.1 | true | 1402.1 |
| 9 | 9 | 43648.1 | true | 1318.1 |
| 10 | 10 | 43013.1 | true | 1319.1 |

#### Best Route Plan

```text
totalCost=41175.156252893205, evUavCost=35175.156252893205, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 63(CUSTOMER) -> 102(STATION) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 9(CUSTOMER) -> 102(STATION) -> 34(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 90 -> 78 -> 34 -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 93(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 96 -> 37 -> 100 -> 91 -> 93 -> 
EV Route-2: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 56(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 23 -> 56 -> 
EV Route-3: 0(DEPOT) -> 82(CUSTOMER) -> 47(CUSTOMER) -> 18(CUSTOMER) -> 111(STATION) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 111 -> 46 -> 60 -> 
  UAV Trip 2: 47 -> 36 -> 7 -> 18 -> 
EV Route-4: 0(DEPOT) -> 53(CUSTOMER) -> 40(CUSTOMER) -> 26(CUSTOMER) -> 68(CUSTOMER) -> 80(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 26 -> 54 -> 68 -> 
EV Route-5: 0(DEPOT) -> 59(CUSTOMER) -> 99(CUSTOMER) -> 85(CUSTOMER) -> 97(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 87 -> 97 -> 
EV Route-6: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 30(CUSTOMER) -> 20(CUSTOMER) -> 102(STATION) -> 66(CUSTOMER) -> 70(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 51 -> 20 -> 
  UAV Trip 2: 102 -> 32 -> 66 -> 
EV Route-7: 0(DEPOT) -> 12(CUSTOMER) -> 76(CUSTOMER) -> 79(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 81 -> 79 -> 
EV Route-8: 0(DEPOT) -> 83(CUSTOMER) -> 111(STATION) -> 61(CUSTOMER) -> 16(CUSTOMER) -> 44(CUSTOMER) -> 86(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 45 -> 111 -> 
  UAV Trip 2: 44 -> 38 -> 86 -> 
EV Route-9: 0(DEPOT) -> 95(CUSTOMER) -> 5(CUSTOMER) -> 84(CUSTOMER) -> 111(STATION) -> 8(CUSTOMER) -> 49(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 92 -> 98 -> 5 -> 
EV Route-10: 0(DEPOT) -> 52(CUSTOMER) -> 62(CUSTOMER) -> 11(CUSTOMER) -> 102(STATION) -> 19(CUSTOMER) -> 88(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 64 -> 19 -> 
  UAV Trip 2: 52 -> 31 -> 62 -> 
EV Route-11: 0(DEPOT) -> 39(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 67 -> 25 -> 
EV Route-12: 0(DEPOT) -> 2(CUSTOMER) -> 42(CUSTOMER) -> 15(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 14 -> 15 -> 
EV Route-13: 0(DEPOT) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 22(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 41 -> 57 -> 58 -> 
EV Route-14: 0(DEPOT) -> 28(CUSTOMER) -> 29(CUSTOMER) -> 24(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 33 -> 29 -> 
  UAV Trip 2: 24 -> 55 -> 4 -> 
```

### RC1-100

- Instance: `./instances_bss_bigscal/rc101_n100_bss.txt`
- Feasible runs: 0/10
- Best run seed: 1
- Best cost: 179848.1
- Avg cost: 254185.1
- Avg time(s): 960.1
- Gap%: 41.33
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 179848.1 | false | 901.1 |
| 2 | 2 | 253512.1 | false | 1067.1 |
| 3 | 3 | 218016.1 | false | 963.1 |
| 4 | 4 | 244015.1 | false | 972.1 |
| 5 | 5 | 336457.1 | false | 982.1 |
| 6 | 6 | 272074.1 | false | 1021.1 |
| 7 | 7 | 217689.1 | false | 919.1 |
| 8 | 8 | 297886.1 | false | 825.1 |
| 9 | 9 | 295957.1 | false | 930.1 |
| 10 | 10 | 226394.1 | false | 1021.1 |

#### Best Route Plan

```text
totalCost=179847.85174134927, evUavCost=41162.77160238898, stationOpenCost=30000.0, violationCost=108685.08013896029, overloadAmount=0.0, timeViolationAmount=108.68508013896029
EV Route-0: 0(DEPOT) -> 104(STATION) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 90(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 61 -> 
EV Route-1: 0(DEPOT) -> 82(CUSTOMER) -> 57(CUSTOMER) -> 86(CUSTOMER) -> 103(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 52 -> 99 -> 57 -> 
EV Route-2: 0(DEPOT) -> 107(STATION) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 107 -> 27 -> 28 -> 
  UAV Trip 2: 30 -> 34 -> 50 -> 
EV Route-3: 0(DEPOT) -> 105(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 49 -> 
  UAV Trip 2: 105 -> 23 -> 21 -> 
  UAV Trip 3: 20 -> 24 -> 77 -> 
EV Route-4: 0(DEPOT) -> 39(CUSTOMER) -> 106(STATION) -> 38(CUSTOMER) -> 81(CUSTOMER) -> 54(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 41 -> 81 -> 
  UAV Trip 2: 54 -> 96 -> 80 -> 
EV Route-5: 0(DEPOT) -> 101(STATION) -> 79(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 108(STATION) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 101 -> 12 -> 73 -> 79 -> 
  UAV Trip 2: 6 -> 46 -> 4 -> 
EV Route-6: 0(DEPOT) -> 102(STATION) -> 33(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 107(STATION) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 65(CUSTOMER) -> 83(CUSTOMER) -> 64(CUSTOMER) -> 89(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 84 -> 85 -> 89 -> 
EV Route-8: 0(DEPOT) -> 63(CUSTOMER) -> 109(STATION) -> 76(CUSTOMER) -> 22(CUSTOMER) -> 48(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 22 -> 
EV Route-9: 0(DEPOT) -> 69(CUSTOMER) -> 98(CUSTOMER) -> 88(CUSTOMER) -> 53(CUSTOMER) -> 78(CUSTOMER) -> 112(STATION) -> 60(CUSTOMER) -> 55(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 42(CUSTOMER) -> 106(STATION) -> 36(CUSTOMER) -> 44(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-11: 0(DEPOT) -> 45(CUSTOMER) -> 108(STATION) -> 2(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 108 -> 
  UAV Trip 2: 2 -> 7 -> 8 -> 3 -> 
EV Route-12: 0(DEPOT) -> 101(STATION) -> 11(CUSTOMER) -> 59(CUSTOMER) -> 87(CUSTOMER) -> 97(CUSTOMER) -> 75(CUSTOMER) -> 74(CUSTOMER) -> 103(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 47(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 92(CUSTOMER) -> 94(CUSTOMER) -> 102(STATION) -> 56(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 92 -> 95 -> 62 -> 67 -> 94 -> 
  UAV Trip 2: 56 -> 66 -> 91 -> 
```

### RC2-100

- Instance: `./instances_bss_bigscal/rc201_n100_bss.txt`
- Feasible runs: 10/10
- Best run seed: 6
- Best cost: 55252.1
- Avg cost: 56887.1
- Avg time(s): 1189.1
- Gap%: 2.96
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 57358.1 | true | 1116.1 |
| 2 | 2 | 57953.1 | true | 1164.1 |
| 3 | 3 | 57479.1 | true | 1155.1 |
| 4 | 4 | 56448.1 | true | 1217.1 |
| 5 | 5 | 56469.1 | true | 1326.1 |
| 6 | 6 | 55252.1 | true | 1146.1 |
| 7 | 7 | 57623.1 | true | 1139.1 |
| 8 | 8 | 55252.1 | true | 1222.1 |
| 9 | 9 | 57567.1 | true | 1234.1 |
| 10 | 10 | 57472.1 | true | 1170.1 |

#### Best Route Plan

```text
totalCost=55251.63302191245, evUavCost=40251.63302191245, stationOpenCost=15000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 102(STATION) -> 36(CUSTOMER) -> 38(CUSTOMER) -> 54(CUSTOMER) -> 96(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 44 -> 54 -> 
  UAV Trip 2: 102 -> 39 -> 36 -> 
EV Route-1: 0(DEPOT) -> 82(CUSTOMER) -> 104(STATION) -> 11(CUSTOMER) -> 97(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 10 -> 97 -> 
  UAV Trip 2: 82 -> 12 -> 104 -> 
EV Route-2: 0(DEPOT) -> 64(CUSTOMER) -> 19(CUSTOMER) -> 110(STATION) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 23 -> 21 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 104(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 74(CUSTOMER) -> 25(CUSTOMER) -> 110(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 17 -> 13 -> 74 -> 
  UAV Trip 2: 104 -> 47 -> 15 -> 
EV Route-4: 0(DEPOT) -> 63(CUSTOMER) -> 110(STATION) -> 59(CUSTOMER) -> 52(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 52 -> 
EV Route-5: 0(DEPOT) -> 72(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 106(STATION) -> 85(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 31 -> 
  UAV Trip 2: 106 -> 30 -> 85 -> 
EV Route-6: 0(DEPOT) -> 83(CUSTOMER) -> 110(STATION) -> 76(CUSTOMER) -> 51(CUSTOMER) -> 56(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 18 -> 76 -> 
  UAV Trip 2: 51 -> 84 -> 56 -> 
EV Route-7: 0(DEPOT) -> 69(CUSTOMER) -> 78(CUSTOMER) -> 73(CUSTOMER) -> 104(STATION) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 79 -> 104 -> 
  UAV Trip 2: 69 -> 98 -> 78 -> 
EV Route-8: 0(DEPOT) -> 90(CUSTOMER) -> 99(CUSTOMER) -> 87(CUSTOMER) -> 9(CUSTOMER) -> 104(STATION) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 99 -> 86 -> 87 -> 
EV Route-9: 0(DEPOT) -> 65(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 49(CUSTOMER) -> 110(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 24 -> 77 -> 58 -> 
  UAV Trip 2: 65 -> 57 -> 22 -> 
EV Route-10: 0(DEPOT) -> 81(CUSTOMER) -> 41(CUSTOMER) -> 102(STATION) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 35 -> 37 -> 43 -> 
  UAV Trip 2: 81 -> 61 -> 41 -> 
EV Route-11: 0(DEPOT) -> 88(CUSTOMER) -> 6(CUSTOMER) -> 108(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 108 -> 
EV Route-12: 0(DEPOT) -> 45(CUSTOMER) -> 108(STATION) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 70(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 108 -> 2 -> 5 -> 
  UAV Trip 2: 3 -> 1 -> 70 -> 
EV Route-13: 0(DEPOT) -> 62(CUSTOMER) -> 34(CUSTOMER) -> 106(STATION) -> 32(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 26 -> 32 -> 
  UAV Trip 2: 62 -> 50 -> 34 -> 
EV Route-14: 0(DEPOT) -> 92(CUSTOMER) -> 33(CUSTOMER) -> 106(STATION) -> 67(CUSTOMER) -> 94(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 28 -> 27 -> 67 -> 
  UAV Trip 2: 92 -> 95 -> 33 -> 
```

