# Large-Scale Instances Report (5 runs each)

- Generated at: 2026-03-06T18:11:17.512
- Cases: 24
- Runs per case: 5

## Batch Parameters

- evCount: 5
- evCapacity: 200.0
- evEnergy: 800.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 25.0
- uavEnergy: 25.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 3
- evFixedCost: 1500.0
- stationOpenCost: 3000.0
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 120
- alnsRestarts: 1
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1-25 | 10465.1 | 10485.1 | 0.19 | 2.1 |
| C2-25 | 12273.1 | 12312.1 | 0.31 | 3.1 |
| R1-25 | 158298.1 | 215065.1 | 35.86 | 2.1 |
| R2-25 | 14810.1 | 16375.1 | 10.57 | 3.1 |
| RC1-25 | 21586.1 | 21895.1 | 1.43 | 3.1 |
| RC2-25 | 18820.1 | 20258.1 | 7.64 | 2.1 |
| C1-50 | 87688.1 | 399369.1 | 355.44 | 13.1 |
| C2-50 | 28254.1 | 30550.1 | 8.13 | 12.1 |
| R1-50 | 3228943.1 | 3439228.1 | 6.51 | 14.1 |
| R2-50 | 31316.1 | 33517.1 | 7.03 | 13.1 |
| RC1-50 | 4198218.1 | 4488682.1 | 6.92 | 3.1 |
| RC2-50 | 2924508.1 | 3722872.1 | 27.30 | 2.1 |
| C1-75 | 23045541.1 | 25251044.1 | 9.57 | 33.1 |
| C2-75 | 3909961.1 | 5971023.1 | 52.71 | 17.1 |
| R1-75 | 10144650.1 | 11794803.1 | 16.27 | 20.1 |
| R2-75 | 2968645.1 | 3772819.1 | 27.09 | 25.1 |
| RC1-75 | 11866762.1 | 13101209.1 | 10.40 | 8.1 |
| RC2-75 | 9088005.1 | 10886679.1 | 19.79 | 11.1 |
| C1-100 | 69866993.1 | 76621858.1 | 9.67 | 17.1 |
| C2-100 | 24146248.1 | 35796014.1 | 48.25 | 17.1 |
| R1-100 | 22803719.1 | 23326717.1 | 2.29 | 16.1 |
| R2-100 | 13355675.1 | 14409379.1 | 7.89 | 26.1 |
| RC1-100 | 22958220.1 | 25736209.1 | 12.10 | 15.1 |
| RC2-100 | 22100995.1 | 23234499.1 | 5.13 | 13.1 |

## Best Routes And Run Logs

### C1-25

- Instance: `./instances_bss_bigscal/c101_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 4
- Best cost: 10465.1
- Avg cost: 10485.1
- Avg time(s): 2.1
- Gap%: 0.19
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 10485.1 | true | 3.1 |
| 2 | 2 | 10492.1 | true | 2.1 |
| 3 | 3 | 10492.1 | true | 2.1 |
| 4 | 4 | 10465.1 | true | 2.1 |
| 5 | 5 | 10492.1 | true | 2.1 |

#### Best Route Plan

```text
totalCost=10464.743839952005, evUavCost=10464.743839952005, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 17(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 15 -> 
EV Route-1: 0(DEPOT) -> 13(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 19 -> 16 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 9 -> 6 -> 
  UAV Trip 2: 5 -> 3 -> 7 -> 
EV Route-3: 0(DEPOT) -> 10(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 14 -> 12 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 23 -> 22 -> 
```

### C2-25

- Instance: `./instances_bss_bigscal/c201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 1
- Best cost: 12273.1
- Avg cost: 12312.1
- Avg time(s): 3.1
- Gap%: 0.31
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12273.1 | true | 3.1 |
| 2 | 2 | 12273.1 | true | 2.1 |
| 3 | 3 | 12327.1 | true | 2.1 |
| 4 | 4 | 12359.1 | true | 3.1 |
| 5 | 5 | 12327.1 | true | 3.1 |

#### Best Route Plan

```text
totalCost=12273.015861375567, evUavCost=9273.015861375567, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-1: 0(DEPOT) -> 23(CUSTOMER) -> 17(CUSTOMER) -> 31(STATION) -> 13(CUSTOMER) -> 9(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 17 -> 
  UAV Trip 2: 9 -> 11 -> 10 -> 8 -> 
EV Route-2: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 6 -> 21 -> 
EV Route-3: 0(DEPOT) -> 31(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 19 -> 16 -> 
  UAV Trip 2: 14 -> 12 -> 15 -> 
```

### R1-25

- Instance: `./instances_bss_bigscal/r101_n25_bss.txt`
- Feasible runs: 0/5
- Best run seed: 3
- Best cost: 158298.1
- Avg cost: 215065.1
- Avg time(s): 2.1
- Gap%: 35.86
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 200631.1 | false | 2.1 |
| 2 | 2 | 316287.1 | false | 2.1 |
| 3 | 3 | 158298.1 | false | 2.1 |
| 4 | 4 | 215210.1 | false | 2.1 |
| 5 | 5 | 184900.1 | false | 2.1 |

#### Best Route Plan

```text
totalCost=158297.80529028026, evUavCost=12367.80314669963, stationOpenCost=6000.0, violationCost=139930.0021435806, overloadAmount=0.0, timeViolationAmount=139.93000214358062
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 22(CUSTOMER) -> 23(CUSTOMER) -> 4(CUSTOMER) -> 26(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 3(CUSTOMER) -> 26(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 24 -> 25 -> 26 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 16(CUSTOMER) -> 8(CUSTOMER) -> 27(STATION) -> 13(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 6(CUSTOMER) -> 18(CUSTOMER) -> 27(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 27(STATION) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 7(CUSTOMER) -> 10(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-25

- Instance: `./instances_bss_bigscal/r201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 14810.1
- Avg cost: 16375.1
- Avg time(s): 3.1
- Gap%: 10.57
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 17286.1 | true | 4.1 |
| 2 | 2 | 14810.1 | true | 2.1 |
| 3 | 3 | 17035.1 | true | 4.1 |
| 4 | 4 | 14861.1 | true | 2.1 |
| 5 | 5 | 17883.1 | true | 2.1 |

#### Best Route Plan

```text
totalCost=14809.866435953683, evUavCost=11809.866435953683, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 14(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 14 -> 
EV Route-1: 0(DEPOT) -> 18(CUSTOMER) -> 13(CUSTOMER) -> 28(STATION) -> 4(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 8 -> 6 -> 13 -> 
  UAV Trip 2: 4 -> 25 -> 24 -> 
EV Route-2: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 20 -> 10 -> 
EV Route-3: 0(DEPOT) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 28(STATION) -> 3(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 1 -> 17 -> 
  UAV Trip 2: 23 -> 22 -> 28 -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 19(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 11 -> 7 -> 
```

### RC1-25

- Instance: `./instances_bss_bigscal/rc101_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 21586.1
- Avg cost: 21895.1
- Avg time(s): 3.1
- Gap%: 1.43
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 22056.1 | true | 2.1 |
| 2 | 2 | 21586.1 | true | 3.1 |
| 3 | 3 | 22475.1 | true | 4.1 |
| 4 | 4 | 21673.1 | true | 3.1 |
| 5 | 5 | 21685.1 | true | 2.1 |

#### Best Route Plan

```text
totalCost=21585.946378935765, evUavCost=12585.946378935765, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 30(STATION) -> 10(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 9 -> 10 -> 
EV Route-1: 0(DEPOT) -> 28(STATION) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 1 -> 4 -> 
EV Route-2: 0(DEPOT) -> 31(STATION) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 18 -> 19 -> 
  UAV Trip 2: 22 -> 20 -> 24 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 13(CUSTOMER) -> 30(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 17 -> 13 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 6 -> 
```

### RC2-25

- Instance: `./instances_bss_bigscal/rc201_n25_bss.txt`
- Feasible runs: 5/5
- Best run seed: 5
- Best cost: 18820.1
- Avg cost: 20258.1
- Avg time(s): 2.1
- Gap%: 7.64
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 20712.1 | true | 3.1 |
| 2 | 2 | 19559.1 | true | 3.1 |
| 3 | 3 | 21469.1 | true | 2.1 |
| 4 | 4 | 20729.1 | true | 3.1 |
| 5 | 5 | 18820.1 | true | 2.1 |

#### Best Route Plan

```text
totalCost=18820.31551669735, evUavCost=12820.315516697348, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 4 -> 
EV Route-1: 0(DEPOT) -> 29(STATION) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 18 -> 22 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 5 -> 3 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 27(STATION) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 9 -> 27 -> 
EV Route-4: 0(DEPOT) -> 12(CUSTOMER) -> 27(STATION) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 25(CUSTOMER) -> 29(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 17 -> 13 -> 
```

### C1-50

- Instance: `./instances_bss_bigscal/c101_n50_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 87688.1
- Avg cost: 399369.1
- Avg time(s): 13.1
- Gap%: 355.44
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 707163.1 | false | 11.1 |
| 2 | 2 | 341955.1 | false | 12.1 |
| 3 | 3 | 697300.1 | false | 11.1 |
| 4 | 4 | 87688.1 | false | 16.1 |
| 5 | 5 | 162738.1 | false | 15.1 |

#### Best Route Plan

```text
totalCost=87688.1922403917, evUavCost=12868.587095029608, stationOpenCost=15000.0, violationCost=59819.60514536209, overloadAmount=0.0, timeViolationAmount=59.81960514536209
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 9(CUSTOMER) -> 6(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 10 -> 11 -> 9 -> 
  UAV Trip 2: 5 -> 3 -> 7 -> 
  UAV Trip 3: 6 -> 4 -> 2 -> 
EV Route-1: 0(DEPOT) -> 20(CUSTOMER) -> 25(CUSTOMER) -> 27(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 20 -> 24 -> 25 -> 
  UAV Trip 3: 26 -> 23 -> 22 -> 
EV Route-2: 0(DEPOT) -> 58(STATION) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 15(CUSTOMER) -> 56(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 54(STATION) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 31(CUSTOMER) -> 35(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 51(STATION) -> 36(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 53(STATION) -> 46(CUSTOMER) -> 39(CUSTOMER) -> 34(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 45 -> 48 -> 39 -> 
  UAV Trip 2: 42 -> 41 -> 40 -> 44 -> 
  UAV Trip 3: 34 -> 49 -> 47 -> 
```

### C2-50

- Instance: `./instances_bss_bigscal/c201_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 3
- Best cost: 28254.1
- Avg cost: 30550.1
- Avg time(s): 12.1
- Gap%: 8.13
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 32588.1 | true | 13.1 |
| 2 | 2 | 29327.1 | true | 11.1 |
| 3 | 3 | 28254.1 | true | 13.1 |
| 4 | 4 | 30932.1 | true | 12.1 |
| 5 | 5 | 31648.1 | true | 10.1 |

#### Best Route Plan

```text
totalCost=28253.775129948528, evUavCost=16253.775129948528, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 56(STATION) -> 29(CUSTOMER) -> 51(STATION) -> 36(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 54(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 9(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 56 -> 27 -> 30 -> 29 -> 
  UAV Trip 2: 36 -> 34 -> 26 -> 
  UAV Trip 3: 54 -> 19 -> 16 -> 
  UAV Trip 4: 9 -> 11 -> 10 -> 8 -> 
EV Route-1: 0(DEPOT) -> 20(CUSTOMER) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 31(CUSTOMER) -> 51(STATION) -> 49(CUSTOMER) -> 40(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 35 -> 51 -> 
  UAV Trip 2: 40 -> 44 -> 41 -> 
  UAV Trip 3: 20 -> 24 -> 6 -> 
EV Route-2: 0(DEPOT) -> 22(CUSTOMER) -> 56(STATION) -> 33(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 51(STATION) -> 46(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 51 -> 
  UAV Trip 2: 46 -> 45 -> 50 -> 47 -> 
EV Route-3: 0(DEPOT) -> 54(STATION) -> 18(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 25(CUSTOMER) -> 56(STATION) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
  UAV Trip 2: 43 -> 42 -> 48 -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 55(STATION) -> 7(CUSTOMER) -> 56(STATION) -> 28(CUSTOMER) -> 54(STATION) -> 12(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 3 -> 4 -> 56 -> 
  UAV Trip 2: 2 -> 1 -> 55 -> 
```

### R1-50

- Instance: `./instances_bss_bigscal/r101_n50_bss.txt`
- Feasible runs: 0/5
- Best run seed: 2
- Best cost: 3228943.1
- Avg cost: 3439228.1
- Avg time(s): 14.1
- Gap%: 6.51
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 3349420.1 | false | 11.1 |
| 2 | 2 | 3228943.1 | false | 16.1 |
| 3 | 3 | 3262609.1 | false | 12.1 |
| 4 | 4 | 3968695.1 | false | 18.1 |
| 5 | 5 | 3386471.1 | false | 11.1 |

#### Best Route Plan

```text
totalCost=3228943.4242980825, evUavCost=16066.3681075306, stationOpenCost=18000.0, violationCost=3194877.0561905517, overloadAmount=0.0, timeViolationAmount=3194.8770561905517
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 55(STATION) -> 45(CUSTOMER) -> 8(CUSTOMER) -> 7(CUSTOMER) -> 10(CUSTOMER) -> 58(STATION) -> 32(CUSTOMER) -> 20(CUSTOMER) -> 30(CUSTOMER) -> 50(CUSTOMER) -> 3(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 31(CUSTOMER) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 51(STATION) -> 47(CUSTOMER) -> 49(CUSTOMER) -> 36(CUSTOMER) -> 46(CUSTOMER) -> 6(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 52(STATION) -> 39(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 15(CUSTOMER) -> 43(CUSTOMER) -> 53(STATION) -> 37(CUSTOMER) -> 40(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 27(CUSTOMER) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 56(STATION) -> 35(CUSTOMER) -> 34(CUSTOMER) -> 29(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 42(CUSTOMER) -> 53(STATION) -> 14(CUSTOMER) -> 38(CUSTOMER) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 17(CUSTOMER) -> 55(STATION) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-50

- Instance: `./instances_bss_bigscal/r201_n50_bss.txt`
- Feasible runs: 5/5
- Best run seed: 2
- Best cost: 31316.1
- Avg cost: 33517.1
- Avg time(s): 13.1
- Gap%: 7.03
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 32934.1 | true | 15.1 |
| 2 | 2 | 31316.1 | true | 13.1 |
| 3 | 3 | 34552.1 | true | 12.1 |
| 4 | 4 | 31572.1 | true | 14.1 |
| 5 | 5 | 37213.1 | true | 11.1 |

#### Best Route Plan

```text
totalCost=31315.71767823502, evUavCost=19315.71767823502, stationOpenCost=12000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 27(CUSTOMER) -> 33(CUSTOMER) -> 54(STATION) -> 31(CUSTOMER) -> 19(CUSTOMER) -> 55(STATION) -> 16(CUSTOMER) -> 55(STATION) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 37(CUSTOMER) -> 53(STATION) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 7 -> 49 -> 
  UAV Trip 2: 31 -> 11 -> 19 -> 
EV Route-1: 0(DEPOT) -> 55(STATION) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 53(STATION) -> 15(CUSTOMER) -> 56(STATION) -> 12(CUSTOMER) -> 54(STATION) -> 30(CUSTOMER) -> 20(CUSTOMER) -> 32(CUSTOMER) -> 55(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 9 -> 20 -> 
  UAV Trip 2: 15 -> 2 -> 56 -> 
EV Route-2: 0(DEPOT) -> 42(CUSTOMER) -> 53(STATION) -> 14(CUSTOMER) -> 38(CUSTOMER) -> 44(CUSTOMER) -> 53(STATION) -> 22(CUSTOMER) -> 40(CUSTOMER) -> 26(CUSTOMER) -> 56(STATION) -> 13(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 41 -> 22 -> 
EV Route-3: 0(DEPOT) -> 55(STATION) -> 47(CUSTOMER) -> 36(CUSTOMER) -> 55(STATION) -> 6(CUSTOMER) -> 50(CUSTOMER) -> 54(STATION) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 8 -> 18 -> 6 -> 
  UAV Trip 2: 54 -> 10 -> 48 -> 
EV Route-4: 0(DEPOT) -> 28(CUSTOMER) -> 56(STATION) -> 39(CUSTOMER) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 56(STATION) -> 3(CUSTOMER) -> 34(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 56 -> 29 -> 3 -> 
  UAV Trip 2: 34 -> 35 -> 1 -> 
```

### RC1-50

- Instance: `./instances_bss_bigscal/rc101_n50_bss.txt`
- Feasible runs: 0/5
- Best run seed: 2
- Best cost: 4198218.1
- Avg cost: 4488682.1
- Avg time(s): 3.1
- Gap%: 6.92
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 4206240.1 | false | 3.1 |
| 2 | 2 | 4198218.1 | false | 2.1 |
| 3 | 3 | 4207664.1 | false | 3.1 |
| 4 | 4 | 4769457.1 | false | 2.1 |
| 5 | 5 | 5061831.1 | false | 3.1 |

#### Best Route Plan

```text
totalCost=4198217.976718052, evUavCost=20861.973141202867, stationOpenCost=0.0, violationCost=4177356.0035768496, overloadAmount=25.0, timeViolationAmount=2927.3560035768496
EV Route-0: 0(DEPOT) -> 12(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 47(CUSTOMER) -> 17(CUSTOMER) -> 13(CUSTOMER) -> 9(CUSTOMER) -> 24(CUSTOMER) -> 48(CUSTOMER) -> 25(CUSTOMER) -> 2(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 34(CUSTOMER) -> 33(CUSTOMER) -> 18(CUSTOMER) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 39(CUSTOMER) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 40(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 43(CUSTOMER) -> 36(CUSTOMER) -> 35(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 26(CUSTOMER) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 10(CUSTOMER) -> 11(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2-50

- Instance: `./instances_bss_bigscal/rc201_n50_bss.txt`
- Feasible runs: 0/5
- Best run seed: 1
- Best cost: 2924508.1
- Avg cost: 3722872.1
- Avg time(s): 2.1
- Gap%: 27.30
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 2924508.1 | false | 2.1 |
| 2 | 2 | 3788899.1 | false | 2.1 |
| 3 | 3 | 4309940.1 | false | 3.1 |
| 4 | 4 | 4273472.1 | false | 3.1 |
| 5 | 5 | 3317543.1 | false | 2.1 |

#### Best Route Plan

```text
totalCost=2924507.7573584104, evUavCost=27449.407420291423, stationOpenCost=0.0, violationCost=2897058.349938119, overloadAmount=30.0, timeViolationAmount=1597.0583499381191
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 44(CUSTOMER) -> 33(CUSTOMER) -> 27(CUSTOMER) -> 28(CUSTOMER) -> 29(CUSTOMER) -> 31(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 15(CUSTOMER) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 18(CUSTOMER) -> 49(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 38(CUSTOMER) -> 40(CUSTOMER) -> 8(CUSTOMER) -> 7(CUSTOMER) -> 10(CUSTOMER) -> 9(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 50(CUSTOMER) -> 32(CUSTOMER) -> 30(CUSTOMER) -> 26(CUSTOMER) -> 20(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 41(CUSTOMER) -> 37(CUSTOMER) -> 43(CUSTOMER) -> 35(CUSTOMER) -> 1(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 47(CUSTOMER) -> 17(CUSTOMER) -> 25(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### C1-75

- Instance: `./instances_bss_bigscal/c101_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 1
- Best cost: 23045541.1
- Avg cost: 25251044.1
- Avg time(s): 33.1
- Gap%: 9.57
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 23045541.1 | false | 37.1 |
| 2 | 2 | 25357377.1 | false | 25.1 |
| 3 | 3 | 24763619.1 | false | 28.1 |
| 4 | 4 | 25434517.1 | false | 35.1 |
| 5 | 5 | 27654165.1 | false | 42.1 |

#### Best Route Plan

```text
totalCost=2.3045541248506468E7, evUavCost=19968.081641667202, stationOpenCost=12000.0, violationCost=2.30135731668648E7, overloadAmount=385.0, timeViolationAmount=18163.5731668648
EV Route-0: 0(DEPOT) -> 67(CUSTOMER) -> 65(CUSTOMER) -> 63(CUSTOMER) -> 62(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 64(CUSTOMER) -> 85(STATION) -> 68(CUSTOMER) -> 51(CUSTOMER) -> 31(CUSTOMER) -> 35(CUSTOMER) -> 84(STATION) -> 36(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 40(CUSTOMER) -> 44(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 25(CUSTOMER) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 85(STATION) -> 57(CUSTOMER) -> 55(CUSTOMER) -> 81(STATION) -> 54(CUSTOMER) -> 53(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 59(CUSTOMER) -> 82(STATION) -> 48(CUSTOMER) -> 50(CUSTOMER) -> 52(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 15(CUSTOMER) -> 14(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 66(CUSTOMER) -> 73(CUSTOMER) -> 70(CUSTOMER) -> 71(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 29(CUSTOMER) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 11(CUSTOMER) -> 9(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### C2-75

- Instance: `./instances_bss_bigscal/c201_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 2
- Best cost: 3909961.1
- Avg cost: 5971023.1
- Avg time(s): 17.1
- Gap%: 52.71
- Best feasible: false
- Best violations: overload=true, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 8074101.1 | false | 12.1 |
| 2 | 2 | 3909961.1 | false | 20.1 |
| 3 | 3 | 4884215.1 | false | 19.1 |
| 4 | 4 | 5330727.1 | false | 15.1 |
| 5 | 5 | 7656113.1 | false | 18.1 |

#### Best Route Plan

```text
totalCost=3909960.9967562375, evUavCost=29613.00325368465, stationOpenCost=24000.0, violationCost=3856347.9935025526, overloadAmount=385.0, timeViolationAmount=6.3479935025525265
EV Route-0: 0(DEPOT) -> 84(STATION) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 84(STATION) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 29(CUSTOMER) -> 82(STATION) -> 69(CUSTOMER) -> 78(STATION) -> 68(CUSTOMER) -> 82(STATION) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 82(STATION) -> 45(CUSTOMER) -> 78(STATION) -> 71(CUSTOMER) -> 77(STATION) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 78(STATION) -> 63(CUSTOMER) -> 82(STATION) -> 75(CUSTOMER) -> 83(STATION) -> 1(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 83(STATION) -> 12(CUSTOMER) -> 15(CUSTOMER) -> 17(CUSTOMER) -> 82(STATION) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 82(STATION) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 76(STATION) -> 31(CUSTOMER) -> 35(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 76(STATION) -> 36(CUSTOMER) -> 28(CUSTOMER) -> 19(CUSTOMER) -> 16(CUSTOMER) -> 79(STATION) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 66(CUSTOMER) -> 78(STATION) -> 65(CUSTOMER) -> 55(CUSTOMER) -> 81(STATION) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 59(CUSTOMER) -> 81(STATION) -> 57(CUSTOMER) -> 40(CUSTOMER) -> 46(CUSTOMER) -> 78(STATION) -> 52(CUSTOMER) -> 82(STATION) -> 13(CUSTOMER) -> 79(STATION) -> 25(CUSTOMER) -> 9(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 67(CUSTOMER) -> 78(STATION) -> 62(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 78(STATION) -> 64(CUSTOMER) -> 49(CUSTOMER) -> 81(STATION) -> 54(CUSTOMER) -> 53(CUSTOMER) -> 56(CUSTOMER) -> 81(STATION) -> 34(CUSTOMER) -> 76(STATION) -> 18(CUSTOMER) -> 82(STATION) -> 44(CUSTOMER) -> 82(STATION) -> 14(CUSTOMER) -> 82(STATION) -> 51(CUSTOMER) -> 50(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R1-75

- Instance: `./instances_bss_bigscal/r101_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 10144650.1
- Avg cost: 11794803.1
- Avg time(s): 20.1
- Gap%: 16.27
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12028923.1 | false | 22.1 |
| 2 | 2 | 13007049.1 | false | 20.1 |
| 3 | 3 | 11724528.1 | false | 20.1 |
| 4 | 4 | 10144650.1 | false | 22.1 |
| 5 | 5 | 12068863.1 | false | 15.1 |

#### Best Route Plan

```text
totalCost=1.0144650130334677E7, evUavCost=22769.867185768657, stationOpenCost=0.0, violationCost=1.012188026314891E7, overloadAmount=120.0, timeViolationAmount=7921.88026314891
EV Route-0: 0(DEPOT) -> 59(CUSTOMER) -> 14(CUSTOMER) -> 38(CUSTOMER) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 61(CUSTOMER) -> 17(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 36(CUSTOMER) -> 49(CUSTOMER) -> 64(CUSTOMER) -> 63(CUSTOMER) -> 32(CUSTOMER) -> 65(CUSTOMER) -> 35(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 5(CUSTOMER) -> 52(CUSTOMER) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 51(CUSTOMER) -> 33(CUSTOMER) -> 68(CUSTOMER) -> 29(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 4(CUSTOMER) -> 72(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 39(CUSTOMER) -> 56(CUSTOMER) -> 75(CUSTOMER) -> 74(CUSTOMER) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 57(CUSTOMER) -> 15(CUSTOMER) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 37(CUSTOMER) -> 53(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 62(CUSTOMER) -> 19(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 27(CUSTOMER) -> 28(CUSTOMER) -> 69(CUSTOMER) -> 48(CUSTOMER) -> 46(CUSTOMER) -> 8(CUSTOMER) -> 18(CUSTOMER) -> 60(CUSTOMER) -> 6(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 40(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 70(CUSTOMER) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 71(CUSTOMER) -> 9(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-75

- Instance: `./instances_bss_bigscal/r201_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 2
- Best cost: 2968645.1
- Avg cost: 3772819.1
- Avg time(s): 25.1
- Gap%: 27.09
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 3007524.1 | false | 52.1 |
| 2 | 2 | 2968645.1 | false | 18.1 |
| 3 | 3 | 3328661.1 | false | 20.1 |
| 4 | 4 | 5888918.1 | false | 10.1 |
| 5 | 5 | 3670349.1 | false | 25.1 |

#### Best Route Plan

```text
totalCost=2968645.100224259, evUavCost=33085.5743060198, stationOpenCost=21000.0, violationCost=2914559.5259182393, overloadAmount=104.0, timeViolationAmount=874.5595259182394
EV Route-0: 0(DEPOT) -> 45(CUSTOMER) -> 42(CUSTOMER) -> 2(CUSTOMER) -> 72(CUSTOMER) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 29(CUSTOMER) -> 33(CUSTOMER) -> 12(CUSTOMER) -> 40(CUSTOMER) -> 44(CUSTOMER) -> 38(CUSTOMER) -> 46(CUSTOMER) -> 16(CUSTOMER) -> 43(CUSTOMER) -> 74(CUSTOMER) -> 25(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 27(CUSTOMER) -> 47(CUSTOMER) -> 36(CUSTOMER) -> 64(CUSTOMER) -> 11(CUSTOMER) -> 30(CUSTOMER) -> 51(CUSTOMER) -> 71(CUSTOMER) -> 65(CUSTOMER) -> 9(CUSTOMER) -> 6(CUSTOMER) -> 41(CUSTOMER) -> 57(CUSTOMER) -> 13(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 79(STATION) -> 63(CUSTOMER) -> 79(STATION) -> 31(CUSTOMER) -> 83(STATION) -> 5(CUSTOMER) -> 61(CUSTOMER) -> 81(STATION) -> 75(CUSTOMER) -> 80(STATION) -> 73(CUSTOMER) -> 81(STATION) -> 8(CUSTOMER) -> 76(STATION) -> 49(CUSTOMER) -> 76(STATION) -> 10(CUSTOMER) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 32(CUSTOMER) -> 84(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 52(CUSTOMER) -> 79(STATION) -> 62(CUSTOMER) -> 19(CUSTOMER) -> 76(STATION) -> 7(CUSTOMER) -> 83(STATION) -> 18(CUSTOMER) -> 81(STATION) -> 53(CUSTOMER) -> 80(STATION) -> 22(CUSTOMER) -> 85(STATION) -> 3(CUSTOMER) -> 34(CUSTOMER) -> 50(CUSTOMER) -> 84(STATION) -> 37(CUSTOMER) -> 17(CUSTOMER) -> 83(STATION) -> 48(CUSTOMER) -> 60(CUSTOMER) -> 58(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 28(CUSTOMER) -> 69(CUSTOMER) -> 59(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 26(CUSTOMER) -> 68(CUSTOMER) -> 54(CUSTOMER) -> 4(CUSTOMER) -> 56(CUSTOMER) -> 55(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC1-75

- Instance: `./instances_bss_bigscal/rc101_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 11866762.1
- Avg cost: 13101209.1
- Avg time(s): 8.1
- Gap%: 10.40
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 13079572.1 | false | 11.1 |
| 2 | 2 | 14557647.1 | false | 7.1 |
| 3 | 3 | 12999303.1 | false | 7.1 |
| 4 | 4 | 11866762.1 | false | 6.1 |
| 5 | 5 | 13002760.1 | false | 9.1 |

#### Best Route Plan

```text
totalCost=1.186676177437315E7, evUavCost=21023.436908762866, stationOpenCost=0.0, violationCost=1.1845738337464387E7, overloadAmount=350.0, timeViolationAmount=7345.738337464387
EV Route-0: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 12(CUSTOMER) -> 14(CUSTOMER) -> 47(CUSTOMER) -> 17(CUSTOMER) -> 73(CUSTOMER) -> 60(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 70(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 52(CUSTOMER) -> 74(CUSTOMER) -> 58(CUSTOMER) -> 75(CUSTOMER) -> 59(CUSTOMER) -> 9(CUSTOMER) -> 13(CUSTOMER) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 64(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 49(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 24(CUSTOMER) -> 57(CUSTOMER) -> 65(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 61(CUSTOMER) -> 44(CUSTOMER) -> 39(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 36(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 72(CUSTOMER) -> 71(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 67(CUSTOMER) -> 62(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 63(CUSTOMER) -> 51(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2-75

- Instance: `./instances_bss_bigscal/rc201_n75_bss.txt`
- Feasible runs: 0/5
- Best run seed: 5
- Best cost: 9088005.1
- Avg cost: 10886679.1
- Avg time(s): 11.1
- Gap%: 19.79
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 11436702.1 | false | 12.1 |
| 2 | 2 | 12842027.1 | false | 7.1 |
| 3 | 3 | 9155765.1 | false | 14.1 |
| 4 | 4 | 11910896.1 | false | 14.1 |
| 5 | 5 | 9088005.1 | false | 10.1 |

#### Best Route Plan

```text
totalCost=9088005.358279578, evUavCost=38981.62968937367, stationOpenCost=0.0, violationCost=9049023.728590205, overloadAmount=351.0, timeViolationAmount=4539.023728590207
EV Route-0: 0(DEPOT) -> 64(CUSTOMER) -> 11(CUSTOMER) -> 14(CUSTOMER) -> 7(CUSTOMER) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 53(CUSTOMER) -> 3(CUSTOMER) -> 46(CUSTOMER) -> 72(CUSTOMER) -> 68(CUSTOMER) -> 70(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 65(CUSTOMER) -> 52(CUSTOMER) -> 12(CUSTOMER) -> 61(CUSTOMER) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 6(CUSTOMER) -> 8(CUSTOMER) -> 47(CUSTOMER) -> 15(CUSTOMER) -> 10(CUSTOMER) -> 66(CUSTOMER) -> 24(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 69(CUSTOMER) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 59(CUSTOMER) -> 75(CUSTOMER) -> 18(CUSTOMER) -> 49(CUSTOMER) -> 9(CUSTOMER) -> 73(CUSTOMER) -> 55(CUSTOMER) -> 20(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 71(CUSTOMER) -> 56(CUSTOMER) -> 54(CUSTOMER) -> 39(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 36(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 1(CUSTOMER) -> 2(CUSTOMER) -> 60(CUSTOMER) -> 17(CUSTOMER) -> 16(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 62(CUSTOMER) -> 33(CUSTOMER) -> 28(CUSTOMER) -> 31(CUSTOMER) -> 27(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 63(CUSTOMER) -> 67(CUSTOMER) -> 57(CUSTOMER) -> 51(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### C1-100

- Instance: `./instances_bss_bigscal/c101_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 5
- Best cost: 69866993.1
- Avg cost: 76621858.1
- Avg time(s): 17.1
- Gap%: 9.67
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 86440564.1 | false | 18.1 |
| 2 | 2 | 78266407.1 | false | 18.1 |
| 3 | 3 | 73033431.1 | false | 15.1 |
| 4 | 4 | 75501894.1 | false | 19.1 |
| 5 | 5 | 69866993.1 | false | 15.1 |

#### Best Route Plan

```text
totalCost=6.986699332006532E7, evUavCost=32698.99075148897, stationOpenCost=0.0, violationCost=6.983429432931383E7, overloadAmount=835.0, timeViolationAmount=60484.29432931383
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 8(CUSTOMER) -> 7(CUSTOMER) -> 75(CUSTOMER) -> 89(CUSTOMER) -> 87(CUSTOMER) -> 86(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 65(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 11(CUSTOMER) -> 9(CUSTOMER) -> 100(CUSTOMER) -> 99(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 27(CUSTOMER) -> 49(CUSTOMER) -> 62(CUSTOMER) -> 69(CUSTOMER) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 51(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 98(CUSTOMER) -> 96(CUSTOMER) -> 95(CUSTOMER) -> 94(CUSTOMER) -> 92(CUSTOMER) -> 93(CUSTOMER) -> 97(CUSTOMER) -> 85(CUSTOMER) -> 88(CUSTOMER) -> 90(CUSTOMER) -> 67(CUSTOMER) -> 47(CUSTOMER) -> 52(CUSTOMER) -> 31(CUSTOMER) -> 60(CUSTOMER) -> 58(CUSTOMER) -> 56(CUSTOMER) -> 53(CUSTOMER) -> 64(CUSTOMER) -> 61(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 57(CUSTOMER) -> 59(CUSTOMER) -> 40(CUSTOMER) -> 63(CUSTOMER) -> 84(CUSTOMER) -> 83(CUSTOMER) -> 82(CUSTOMER) -> 80(CUSTOMER) -> 79(CUSTOMER) -> 77(CUSTOMER) -> 73(CUSTOMER) -> 70(CUSTOMER) -> 71(CUSTOMER) -> 76(CUSTOMER) -> 78(CUSTOMER) -> 81(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 10(CUSTOMER) -> 3(CUSTOMER) -> 25(CUSTOMER) -> 43(CUSTOMER) -> 41(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 36(CUSTOMER) -> 39(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 48(CUSTOMER) -> 45(CUSTOMER) -> 44(CUSTOMER) -> 91(CUSTOMER) -> 4(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### C2-100

- Instance: `./instances_bss_bigscal/c201_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 5
- Best cost: 24146248.1
- Avg cost: 35796014.1
- Avg time(s): 17.1
- Gap%: 48.25
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 57204967.1 | false | 12.1 |
| 2 | 2 | 34999861.1 | false | 18.1 |
| 3 | 3 | 32411124.1 | false | 20.1 |
| 4 | 4 | 30217867.1 | false | 17.1 |
| 5 | 5 | 24146248.1 | false | 17.1 |

#### Best Route Plan

```text
totalCost=2.414624841174851E7, evUavCost=31026.89265054222, stationOpenCost=0.0, violationCost=2.411522151909797E7, overloadAmount=835.0, timeViolationAmount=14765.221519097971
EV Route-0: 0(DEPOT) -> 20(CUSTOMER) -> 5(CUSTOMER) -> 75(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 99(CUSTOMER) -> 100(CUSTOMER) -> 97(CUSTOMER) -> 92(CUSTOMER) -> 98(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 43(CUSTOMER) -> 45(CUSTOMER) -> 41(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 22(CUSTOMER) -> 29(CUSTOMER) -> 31(CUSTOMER) -> 35(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 34(CUSTOMER) -> 23(CUSTOMER) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 17(CUSTOMER) -> 13(CUSTOMER) -> 25(CUSTOMER) -> 9(CUSTOMER) -> 11(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 36(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 12(CUSTOMER) -> 88(CUSTOMER) -> 84(CUSTOMER) -> 82(CUSTOMER) -> 85(CUSTOMER) -> 76(CUSTOMER) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 80(CUSTOMER) -> 79(CUSTOMER) -> 81(CUSTOMER) -> 78(CUSTOMER) -> 77(CUSTOMER) -> 96(CUSTOMER) -> 69(CUSTOMER) -> 42(CUSTOMER) -> 50(CUSTOMER) -> 52(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 93(CUSTOMER) -> 30(CUSTOMER) -> 27(CUSTOMER) -> 24(CUSTOMER) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 64(CUSTOMER) -> 94(CUSTOMER) -> 95(CUSTOMER) -> 7(CUSTOMER) -> 89(CUSTOMER) -> 91(CUSTOMER) -> 86(CUSTOMER) -> 83(CUSTOMER) -> 87(CUSTOMER) -> 90(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 67(CUSTOMER) -> 63(CUSTOMER) -> 62(CUSTOMER) -> 74(CUSTOMER) -> 66(CUSTOMER) -> 68(CUSTOMER) -> 65(CUSTOMER) -> 49(CUSTOMER) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 53(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 59(CUSTOMER) -> 57(CUSTOMER) -> 40(CUSTOMER) -> 44(CUSTOMER) -> 46(CUSTOMER) -> 51(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R1-100

- Instance: `./instances_bss_bigscal/r101_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 5
- Best cost: 22803719.1
- Avg cost: 23326717.1
- Avg time(s): 16.1
- Gap%: 2.29
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 22988617.1 | false | 19.1 |
| 2 | 2 | 23020510.1 | false | 21.1 |
| 3 | 3 | 23444244.1 | false | 11.1 |
| 4 | 4 | 24376494.1 | false | 14.1 |
| 5 | 5 | 22803719.1 | false | 16.1 |

#### Best Route Plan

```text
totalCost=2.2803718749192473E7, evUavCost=29158.349430243008, stationOpenCost=0.0, violationCost=2.2774560399762228E7, overloadAmount=483.0, timeViolationAmount=16944.560399762227
EV Route-0: 0(DEPOT) -> 59(CUSTOMER) -> 95(CUSTOMER) -> 98(CUSTOMER) -> 5(CUSTOMER) -> 83(CUSTOMER) -> 8(CUSTOMER) -> 82(CUSTOMER) -> 89(CUSTOMER) -> 40(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 93(CUSTOMER) -> 91(CUSTOMER) -> 100(CUSTOMER) -> 42(CUSTOMER) -> 43(CUSTOMER) -> 15(CUSTOMER) -> 57(CUSTOMER) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 27(CUSTOMER) -> 31(CUSTOMER) -> 69(CUSTOMER) -> 52(CUSTOMER) -> 99(CUSTOMER) -> 84(CUSTOMER) -> 17(CUSTOMER) -> 45(CUSTOMER) -> 46(CUSTOMER) -> 47(CUSTOMER) -> 36(CUSTOMER) -> 49(CUSTOMER) -> 64(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 50(CUSTOMER) -> 26(CUSTOMER) -> 58(CUSTOMER) -> 97(CUSTOMER) -> 37(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 12(CUSTOMER) -> 68(CUSTOMER) -> 29(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 39(CUSTOMER) -> 56(CUSTOMER) -> 75(CUSTOMER) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 4(CUSTOMER) -> 54(CUSTOMER) -> 80(CUSTOMER) -> 1(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 90(CUSTOMER) -> 63(CUSTOMER) -> 62(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 92(CUSTOMER) -> 14(CUSTOMER) -> 38(CUSTOMER) -> 44(CUSTOMER) -> 60(CUSTOMER) -> 18(CUSTOMER) -> 7(CUSTOMER) -> 88(CUSTOMER) -> 48(CUSTOMER) -> 19(CUSTOMER) -> 70(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 35(CUSTOMER) -> 34(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 87(CUSTOMER) -> 85(CUSTOMER) -> 61(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 96(CUSTOMER) -> 28(CUSTOMER) -> 76(CUSTOMER) -> 3(CUSTOMER) -> 79(CUSTOMER) -> 78(CUSTOMER) -> 81(CUSTOMER) -> 33(CUSTOMER) -> 77(CUSTOMER) -> 72(CUSTOMER) -> 74(CUSTOMER) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 94(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-100

- Instance: `./instances_bss_bigscal/r201_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 4
- Best cost: 13355675.1
- Avg cost: 14409379.1
- Avg time(s): 26.1
- Gap%: 7.89
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 15084052.1 | false | 25.1 |
| 2 | 2 | 13576348.1 | false | 23.1 |
| 3 | 3 | 15834214.1 | false | 24.1 |
| 4 | 4 | 13355675.1 | false | 32.1 |
| 5 | 5 | 14196607.1 | false | 25.1 |

#### Best Route Plan

```text
totalCost=1.3355675111586552E7, evUavCost=47838.45430780228, stationOpenCost=0.0, violationCost=1.330783665727875E7, overloadAmount=483.0, timeViolationAmount=7477.836657278751
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 92(CUSTOMER) -> 45(CUSTOMER) -> 11(CUSTOMER) -> 63(CUSTOMER) -> 72(CUSTOMER) -> 5(CUSTOMER) -> 91(CUSTOMER) -> 17(CUSTOMER) -> 48(CUSTOMER) -> 89(CUSTOMER) -> 77(CUSTOMER) -> 25(CUSTOMER) -> 100(CUSTOMER) -> 59(CUSTOMER) -> 70(CUSTOMER) -> 80(CUSTOMER) -> 94(CUSTOMER) -> 93(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 28(CUSTOMER) -> 31(CUSTOMER) -> 62(CUSTOMER) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 82(CUSTOMER) -> 83(CUSTOMER) -> 95(CUSTOMER) -> 98(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 57(CUSTOMER) -> 2(CUSTOMER) -> 99(CUSTOMER) -> 84(CUSTOMER) -> 52(CUSTOMER) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 79(CUSTOMER) -> 81(CUSTOMER) -> 66(CUSTOMER) -> 20(CUSTOMER) -> 30(CUSTOMER) -> 96(CUSTOMER) -> 13(CUSTOMER) -> 74(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 29(CUSTOMER) -> 23(CUSTOMER) -> 75(CUSTOMER) -> 21(CUSTOMER) -> 12(CUSTOMER) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 9(CUSTOMER) -> 33(CUSTOMER) -> 76(CUSTOMER) -> 6(CUSTOMER) -> 55(CUSTOMER) -> 68(CUSTOMER) -> 4(CUSTOMER) -> 78(CUSTOMER) -> 35(CUSTOMER) -> 34(CUSTOMER) -> 24(CUSTOMER) -> 1(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 19(CUSTOMER) -> 88(CUSTOMER) -> 73(CUSTOMER) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 38(CUSTOMER) -> 44(CUSTOMER) -> 61(CUSTOMER) -> 7(CUSTOMER) -> 18(CUSTOMER) -> 40(CUSTOMER) -> 87(CUSTOMER) -> 49(CUSTOMER) -> 64(CUSTOMER) -> 32(CUSTOMER) -> 51(CUSTOMER) -> 3(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 85(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 8(CUSTOMER) -> 90(CUSTOMER) -> 53(CUSTOMER) -> 46(CUSTOMER) -> 10(CUSTOMER) -> 50(CUSTOMER) -> 26(CUSTOMER) -> 97(CUSTOMER) -> 37(CUSTOMER) -> 43(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC1-100

- Instance: `./instances_bss_bigscal/rc101_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 2
- Best cost: 22958220.1
- Avg cost: 25736209.1
- Avg time(s): 15.1
- Gap%: 12.10
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 25140979.1 | false | 12.1 |
| 2 | 2 | 22958220.1 | false | 13.1 |
| 3 | 3 | 29253056.1 | false | 21.1 |
| 4 | 4 | 25576301.1 | false | 16.1 |
| 5 | 5 | 25752488.1 | false | 15.1 |

#### Best Route Plan

```text
totalCost=2.2958219619585548E7, evUavCost=31804.66916937004, stationOpenCost=0.0, violationCost=2.2926414950416178E7, overloadAmount=749.0, timeViolationAmount=14436.41495041618
EV Route-0: 0(DEPOT) -> 41(CUSTOMER) -> 39(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 36(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 44(CUSTOMER) -> 42(CUSTOMER) -> 1(CUSTOMER) -> 3(CUSTOMER) -> 5(CUSTOMER) -> 45(CUSTOMER) -> 4(CUSTOMER) -> 6(CUSTOMER) -> 2(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 65(CUSTOMER) -> 63(CUSTOMER) -> 85(CUSTOMER) -> 84(CUSTOMER) -> 51(CUSTOMER) -> 56(CUSTOMER) -> 91(CUSTOMER) -> 94(CUSTOMER) -> 93(CUSTOMER) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 68(CUSTOMER) -> 100(CUSTOMER) -> 55(CUSTOMER) -> 53(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 92(CUSTOMER) -> 67(CUSTOMER) -> 62(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 89(CUSTOMER) -> 76(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 18(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 95(CUSTOMER) -> 71(CUSTOMER) -> 54(CUSTOMER) -> 96(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 88(CUSTOMER) -> 79(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 70(CUSTOMER) -> 81(CUSTOMER) -> 66(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 57(CUSTOMER) -> 99(CUSTOMER) -> 11(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 13(CUSTOMER) -> 82(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 64(CUSTOMER) -> 83(CUSTOMER) -> 52(CUSTOMER) -> 86(CUSTOMER) -> 74(CUSTOMER) -> 58(CUSTOMER) -> 77(CUSTOMER) -> 75(CUSTOMER) -> 97(CUSTOMER) -> 59(CUSTOMER) -> 87(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 14(CUSTOMER) -> 47(CUSTOMER) -> 17(CUSTOMER) -> 73(CUSTOMER) -> 78(CUSTOMER) -> 60(CUSTOMER) -> 98(CUSTOMER) -> 69(CUSTOMER) -> 90(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2-100

- Instance: `./instances_bss_bigscal/rc201_n100_bss.txt`
- Feasible runs: 0/5
- Best run seed: 5
- Best cost: 22100995.1
- Avg cost: 23234499.1
- Avg time(s): 13.1
- Gap%: 5.13
- Best feasible: false
- Best violations: overload=true, tw=true, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 22200766.1 | false | 13.1 |
| 2 | 2 | 23949385.1 | false | 14.1 |
| 3 | 3 | 23068003.1 | false | 14.1 |
| 4 | 4 | 24853345.1 | false | 12.1 |
| 5 | 5 | 22100995.1 | false | 11.1 |

#### Best Route Plan

```text
totalCost=2.2100994682569467E7, evUavCost=62177.01567322349, stationOpenCost=0.0, violationCost=2.2038817666896243E7, overloadAmount=749.0, timeViolationAmount=13548.817666896242
EV Route-0: 0(DEPOT) -> 65(CUSTOMER) -> 92(CUSTOMER) -> 42(CUSTOMER) -> 88(CUSTOMER) -> 14(CUSTOMER) -> 78(CUSTOMER) -> 36(CUSTOMER) -> 37(CUSTOMER) -> 72(CUSTOMER) -> 39(CUSTOMER) -> 1(CUSTOMER) -> 3(CUSTOMER) -> 5(CUSTOMER) -> 45(CUSTOMER) -> 4(CUSTOMER) -> 46(CUSTOMER) -> 47(CUSTOMER) -> 12(CUSTOMER) -> 93(CUSTOMER) -> 70(CUSTOMER) -> 100(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 83(CUSTOMER) -> 2(CUSTOMER) -> 98(CUSTOMER) -> 82(CUSTOMER) -> 69(CUSTOMER) -> 52(CUSTOMER) -> 64(CUSTOMER) -> 95(CUSTOMER) -> 62(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 28(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 89(CUSTOMER) -> 74(CUSTOMER) -> 59(CUSTOMER) -> 97(CUSTOMER) -> 87(CUSTOMER) -> 13(CUSTOMER) -> 61(CUSTOMER) -> 35(CUSTOMER) -> 40(CUSTOMER) -> 24(CUSTOMER) -> 17(CUSTOMER) -> 10(CUSTOMER) -> 91(CUSTOMER) -> 48(CUSTOMER) -> 77(CUSTOMER) -> 58(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 11(CUSTOMER) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 75(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 94(CUSTOMER) -> 84(CUSTOMER) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 56(CUSTOMER) -> 96(CUSTOMER) -> 66(CUSTOMER) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 54(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 67(CUSTOMER) -> 71(CUSTOMER) -> 38(CUSTOMER) -> 73(CUSTOMER) -> 7(CUSTOMER) -> 53(CUSTOMER) -> 99(CUSTOMER) -> 41(CUSTOMER) -> 6(CUSTOMER) -> 57(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 18(CUSTOMER) -> 76(CUSTOMER) -> 63(CUSTOMER) -> 85(CUSTOMER) -> 51(CUSTOMER) -> 86(CUSTOMER) -> 79(CUSTOMER) -> 81(CUSTOMER) -> 90(CUSTOMER) -> 55(CUSTOMER) -> 8(CUSTOMER) -> 60(CUSTOMER) -> 9(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

