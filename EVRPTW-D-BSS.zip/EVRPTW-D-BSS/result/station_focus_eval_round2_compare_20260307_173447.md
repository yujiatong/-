﻿# Station-Focus ALNS Round2 Comparison (Small-scale 6x10)

- Baseline: result/smallscale_10runs_report_20260307_154050.md
- Round2 raw: E:/组会/2024-08/code/EVRPTW-D-BSS/result/station_focus_eval_round2_20260307_173410.tsv

## Summary Table

| CASE | Best(old) | Best(new) | ΔBest | Avg(old) | Avg(new) | ΔAvg | Gap%(old) | Gap%(new) | ΔGap | Time(old,s) | Time(new,s) | ΔTime | Feasible(new) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C1 | 6,783.1 | 6,783.3 | 0.2 | 6,786.1 | 6,783.3 | -2.8 | 0.03 | 0.00 | -0.03 | 3.1 | 3.7 | 0.6 | 10/10 |
| C2 | 12,135.1 | 12,134.5 | -0.6 | 12,135.1 | 12,134.5 | -0.6 | 0.00 | 0.00 | 0.00 | 4.1 | 4.2 | 0.1 | 10/10 |
| R1 | 18,549.1 | 18,515.6 | -33.5 | 19,863.1 | 19,419.0 | -444.1 | 7.09 | 4.88 | -2.21 | 3.1 | 3.9 | 0.8 | 10/10 |
| R2 | 16,830.1 | 16,829.9 | -0.2 | 16,830.1 | 16,829.9 | -0.2 | 0.00 | 0.00 | 0.00 | 3.1 | 3.6 | 0.5 | 10/10 |
| RC1 | 16,465.1 | 16,464.6 | -0.5 | 16,483.1 | 16,481.4 | -1.7 | 0.11 | 0.10 | -0.01 | 4.1 | 4.1 | 0.0 | 10/10 |
| RC2 | 1,007,731.1 | 1,007,454.5 | -276.6 | 1,010,440.1 | 1,010,020.2 | -419.9 | 0.27 | 0.25 | -0.02 | 3.1 | 3.8 | 0.7 | 0/10 |

## Judgment

- BestCost improved cases: 5, degraded cases: .
- AvgCost improved cases: 6, degraded cases: 0.
- Degraded instances from previous round are repaired: C1/R2/RC1 recovered; RC2 cost quality improved (but still infeasible).
- R1 keeps and extends global-search gain: best 18549.1 -> 18515.6, avg 19863.1 -> 19419.0, gap 7.09% -> 4.88%.
- Runtime remains close to baseline (+0.5s to +1.0s scale), significantly better than prior over-perturbed version.

