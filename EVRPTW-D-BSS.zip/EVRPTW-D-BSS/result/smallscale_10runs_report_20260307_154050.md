# Small-Scale Instances Report (10 runs each)

- Generated at: 2026-03-07T15:40:50.947
- Cases: 6
- Runs per case: 10
- Parameter set label: SmallScaleParamSet-UserUpdated

## Small-Scale Parameter Set (Current)

- evCount: 15
- evCapacity: 100.0
- evEnergy: 300.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 25.0
- uavEnergy: 25.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 5
- evFixedCost: 1500.0
- stationOpenCost: 3000.0
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 500
- alnsRestarts: 4
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1 | 6783.1 | 6786.1 | 0.03 | 3.1 |
| C2 | 12135.1 | 12135.1 | 0.00 | 4.1 |
| R1 | 18549.1 | 19863.1 | 7.09 | 3.1 |
| R2 | 16830.1 | 16830.1 | -0.00 | 3.1 |
| RC1 | 16465.1 | 16483.1 | 0.11 | 4.1 |
| RC2 | 1007731.1 | 1010440.1 | 0.27 | 3.1 |

## Best Routes And Run Logs

### C1

- Instance: `./instances/c101_bss_for_current_parser.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 6783.1
- Avg cost: 6786.1
- Avg time(s): 3.1
- Gap%: 0.03
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 6783.1 | true | 3.1 |
| 2 | 2 | 6805.1 | true | 3.1 |
| 3 | 3 | 6783.1 | true | 3.1 |
| 4 | 4 | 6783.1 | true | 3.1 |
| 5 | 5 | 6783.1 | true | 3.1 |
| 6 | 6 | 6783.1 | true | 3.1 |
| 7 | 7 | 6783.1 | true | 3.1 |
| 8 | 8 | 6783.1 | true | 3.1 |
| 9 | 9 | 6783.1 | true | 3.1 |
| 10 | 10 | 6783.1 | true | 3.1 |

#### Best Route Plan

```text
totalCost=6783.328142216229, evUavCost=3783.328142216229, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 14(STATION) -> 4(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 7 -> 14 -> 
EV Route-3: 0(DEPOT) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 14(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 9 -> 6 -> 
```

### C2

- Instance: `./instances/c201_bss_for_current_parser.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 12135.1
- Avg cost: 12135.1
- Avg time(s): 4.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12135.1 | true | 3.1 |
| 2 | 2 | 12135.1 | true | 3.1 |
| 3 | 3 | 12135.1 | true | 3.1 |
| 4 | 4 | 12135.1 | true | 3.1 |
| 5 | 5 | 12135.1 | true | 4.1 |
| 6 | 6 | 12135.1 | true | 4.1 |
| 7 | 7 | 12135.1 | true | 4.1 |
| 8 | 8 | 12135.1 | true | 4.1 |
| 9 | 9 | 12135.1 | true | 4.1 |
| 10 | 10 | 12135.1 | true | 4.1 |

#### Best Route Plan

```text
totalCost=12134.533473429994, evUavCost=6134.533473429993, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 11(STATION) -> 6(CUSTOMER) -> 11(STATION) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 14(STATION) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-12: 0(DEPOT) -> 14(STATION) -> 7(CUSTOMER) -> 4(CUSTOMER) -> 14(STATION) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 3 -> 4 -> 
```

### R1

- Instance: `./instances/r101_bss_for_current_parser.txt`
- Feasible runs: 10/10
- Best run seed: 8
- Best cost: 18549.1
- Avg cost: 19863.1
- Avg time(s): 3.1
- Gap%: 7.09
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 20009.1 | true | 3.1 |
| 2 | 2 | 20009.1 | true | 3.1 |
| 3 | 3 | 20009.1 | true | 3.1 |
| 4 | 4 | 20009.1 | true | 3.1 |
| 5 | 5 | 20009.1 | true | 4.1 |
| 6 | 6 | 20009.1 | true | 4.1 |
| 7 | 7 | 20009.1 | true | 4.1 |
| 8 | 8 | 18549.1 | true | 4.1 |
| 9 | 9 | 20009.1 | true | 3.1 |
| 10 | 10 | 20009.1 | true | 4.1 |

#### Best Route Plan

```text
totalCost=18548.621530537494, evUavCost=9548.621530537495, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 14(STATION) -> 9(CUSTOMER) -> 3(CUSTOMER) -> 14(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 12(STATION) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 8(CUSTOMER) -> 13(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 7(CUSTOMER) -> 13(STATION) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 10 -> 1 -> 
EV Route-13: 0(DEPOT) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2

- Instance: `./instances/r201_bss_for_current_parser.txt`
- Feasible runs: 10/10
- Best run seed: 1
- Best cost: 16830.1
- Avg cost: 16830.1
- Avg time(s): 3.1
- Gap%: -0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16830.1 | true | 3.1 |
| 2 | 2 | 16830.1 | true | 3.1 |
| 3 | 3 | 16830.1 | true | 3.1 |
| 4 | 4 | 16830.1 | true | 3.1 |
| 5 | 5 | 16830.1 | true | 3.1 |
| 6 | 6 | 16830.1 | true | 3.1 |
| 7 | 7 | 16830.1 | true | 3.1 |
| 8 | 8 | 16830.1 | true | 3.1 |
| 9 | 9 | 16830.1 | true | 3.1 |
| 10 | 10 | 16830.1 | true | 3.1 |

#### Best Route Plan

```text
totalCost=16829.89103175354, evUavCost=7829.891031753543, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 14(STATION) -> 3(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 9 -> 3 -> 
EV Route-2: 0(DEPOT) -> 7(CUSTOMER) -> 13(STATION) -> 8(CUSTOMER) -> 13(STATION) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 10 -> 1 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 12(STATION) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC1

- Instance: `./instances/rc101_bss_for_current_parser.txt`
- Feasible runs: 10/10
- Best run seed: 9
- Best cost: 16465.1
- Avg cost: 16483.1
- Avg time(s): 4.1
- Gap%: 0.11
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16486.1 | true | 3.1 |
| 2 | 2 | 16486.1 | true | 3.1 |
| 3 | 3 | 16486.1 | true | 3.1 |
| 4 | 4 | 16486.1 | true | 3.1 |
| 5 | 5 | 16486.1 | true | 3.1 |
| 6 | 6 | 16486.1 | true | 4.1 |
| 7 | 7 | 16486.1 | true | 4.1 |
| 8 | 8 | 16486.1 | true | 5.1 |
| 9 | 9 | 16465.1 | true | 4.1 |
| 10 | 10 | 16486.1 | true | 3.1 |

#### Best Route Plan

```text
totalCost=16464.585105301067, evUavCost=10464.585105301067, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 11(STATION) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 11(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 13(STATION) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 7 -> 6 -> 
EV Route-4: 0(DEPOT) -> 13(STATION) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 13(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 
EV Route-7: 0(DEPOT) -> 13(STATION) -> 8(CUSTOMER) -> 4(CUSTOMER) -> 13(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 13(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2

- Instance: `./instances/rc201_bss_for_current_parser.txt`
- Feasible runs: 0/10
- Best run seed: 5
- Best cost: 1007731.1
- Avg cost: 1010440.1
- Avg time(s): 3.1
- Gap%: 0.27
- Best feasible: false
- Best violations: overload=false, tw=false, energy=true, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 1009079.1 | false | 3.1 |
| 2 | 2 | 1012262.1 | false | 3.1 |
| 3 | 3 | 1012721.1 | false | 3.1 |
| 4 | 4 | 1014483.1 | false | 3.1 |
| 5 | 5 | 1007731.1 | false | 3.1 |
| 6 | 6 | 1007731.1 | false | 3.1 |
| 7 | 7 | 1007731.1 | false | 3.1 |
| 8 | 8 | 1007731.1 | false | 3.1 |
| 9 | 9 | 1012100.1 | false | 3.1 |
| 10 | 10 | 1012824.1 | false | 3.1 |

#### Best Route Plan

```text
totalCost=1007731.3330494785, evUavCost=7731.3330494784195, stationOpenCost=0.0, violationCost=1000000.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 9(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 6(CUSTOMER) -> 10(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

