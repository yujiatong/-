# Large-Scale Instances Report (4 runs each)

- Generated at: 2026-03-15T11:37:25.081
- Status: Finished
- Completed cases: 24/24
- Runs per case: 4
- Parameter set label: StationOpenCostSensitivity-4Runs
- stationOpenCost parameter: 1500

## Large-Scale Parameter Set (Current)

- evCount: 15
- evCapacity: 200.0
- evEnergy: 800.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 30.0
- uavEnergy: 30.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 5
- evFixedCost: 1500.0
- stationOpenCost: 1500
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 700
- alnsRestarts: 4
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1-25 | 8814.1 | 8822.1 | 0.09 | 30.1 |
| C2-25 | 10686.1 | 10703.1 | 0.16 | 44.1 |
| R1-25 | 16356.1 | 16356.1 | 0.00 | 31.1 |
| R2-25 | 12471.1 | 12471.1 | 0.00 | 41.1 |
| RC1-25 | 17524.1 | 18210.1 | 3.91 | 44.1 |
| RC2-25 | 15433.1 | 15450.1 | 0.11 | 31.1 |
| C1-50 | 17055.1 | 17068.1 | 0.08 | 220.1 |
| C2-50 | 19648.1 | 19654.1 | 0.03 | 238.1 |
| R1-50 | 27051.1 | 27456.1 | 1.50 | 162.1 |
| R2-50 | 22556.1 | 23227.1 | 2.97 | 218.1 |
| RC1-50 | 33847.1 | 33868.1 | 0.06 | 185.1 |
| RC2-50 | 29153.1 | 29615.1 | 1.58 | 167.1 |
| C1-75 | 28758.1 | 29647.1 | 3.09 | 531.1 |
| C2-75 | 29969.1 | 30636.1 | 2.23 | 633.1 |
| R1-75 | 39605.1 | 40478.1 | 2.20 | 639.1 |
| R2-75 | 31672.1 | 31855.1 | 0.58 | 610.1 |
| RC1-75 | 43838.1 | 45009.1 | 2.67 | 584.1 |
| RC2-75 | 38471.1 | 39118.1 | 1.68 | 613.1 |
| C1-100 | 41596.1 | 42207.1 | 1.47 | 1206.1 |
| C2-100 | 39525.1 | 40097.1 | 1.45 | 939.1 |
| R1-100 | 384971.1 | 416443.1 | 8.18 | 1119.1 |
| R2-100 | 37442.1 | 38071.1 | 1.68 | 1289.1 |
| RC1-100 | 173293.1 | 207757.1 | 19.89 | 887.1 |
| RC2-100 | 47593.1 | 48236.1 | 1.35 | 979.1 |

## Issues During Run

- 2026-03-11 18:05:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:08:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:51:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:53:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 19:17:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-12 19:09:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:22:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:23:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:24:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:25:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:26:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:27:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:28:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:29:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:30:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:31:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:32:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:33:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:34:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:35:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:36:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:37:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:38:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:39:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:40:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:41:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:42:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:43:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:44:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:45:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:46:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:47:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:48:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:49:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:50:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:51:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:52:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:53:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:54:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:55:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:56:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:57:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:58:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:59:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:00:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:01:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:02:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:03:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:04:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:05:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:06:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:07:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:08:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:09:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:10:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:11:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:12:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:13:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:14:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:15:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:16:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:17:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:18:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:19:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:20:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:21:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:22:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:23:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:24:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:25:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:26:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:27:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:28:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:29:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:30:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:31:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:32:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:33:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:34:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:35:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:36:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:37:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:38:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:39:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:40:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:41:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:42:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:43:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:44:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:45:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:46:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:47:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:48:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:49:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:50:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:51:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:52:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:53:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:54:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:55:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:56:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:57:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:58:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:59:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:00:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:01:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:02:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:03:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:04:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:05:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:06:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:07:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:08:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:09:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:10:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:11:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:12:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:13:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:14:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:15:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:16:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:17:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:18:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:19:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:20:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:21:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:22:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:23:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:24:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:25:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:26:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:27:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:28:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:29:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:30:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:31:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:32:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:33:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:34:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:35:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:36:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:37:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:38:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:39:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:40:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:41:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:42:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:43:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:44:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:45:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:46:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:47:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:48:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:49:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:50:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:51:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:52:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:53:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:54:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:55:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:56:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:57:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:58:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:59:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:00:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:01:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:02:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:03:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:04:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:05:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:06:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:07:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:08:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:09:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:10:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:11:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:12:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:13:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:14:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:15:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:16:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:17:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:18:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:19:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:20:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:21:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:22:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:23:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:24:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:25:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:26:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:27:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:28:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:29:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:30:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:31:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:32:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:33:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:34:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:35:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:36:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:37:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:38:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:39:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:40:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:41:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:42:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:43:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:44:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:45:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:46:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:47:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:48:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:49:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:50:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:51:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:52:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:53:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:54:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:55:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:56:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:57:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:58:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:59:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:00:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:01:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:02:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:03:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:04:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:05:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:06:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:07:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:08:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:09:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:11:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:12:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:13:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:14:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:15:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:16:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:17:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:18:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:19:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:20:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:21:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:22:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:23:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:24:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:25:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:26:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:27:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:28:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:29:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:30:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:31:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:32:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:33:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:34:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:35:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:36:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:37:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:38:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:39:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:40:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:41:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:42:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:43:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:44:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:45:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:46:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:47:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:48:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:49:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:50:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:51:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:52:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:53:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:54:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:55:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:56:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:57:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:58:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:59:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:00:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:01:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:02:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:03:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:04:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:05:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:06:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:07:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:08:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:09:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:10:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:11:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:12:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:13:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:14:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:15:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:16:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:17:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:18:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:19:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:20:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:21:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:22:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:23:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:24:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:25:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:26:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:27:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:28:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:29:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:30:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:31:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:32:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:33:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:34:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:35:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:36:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:37:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:38:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:39:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:40:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:41:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:42:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:43:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:44:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:45:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:46:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:47:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:48:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:49:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:50:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:51:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:52:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:53:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:54:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:55:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:56:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:57:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:58:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:59:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:00:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:01:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:02:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:03:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:04:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:05:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:06:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:07:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:08:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:09:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:10:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:11:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:12:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:13:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:14:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:15:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:16:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:17:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:18:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:19:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:20:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:21:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:22:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:23:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:24:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:25:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:26:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:27:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:28:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:29:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:30:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:31:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:32:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:33:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:34:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:35:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:36:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:37:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:38:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:39:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:40:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:41:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:42:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:43:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:44:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:45:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:46:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:47:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:48:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:49:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:50:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:51:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:52:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:53:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:54:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:55:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:56:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:57:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:58:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:59:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:00:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:01:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:02:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:03:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:04:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:05:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:06:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:07:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:08:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:09:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:10:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:11:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:12:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:13:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:14:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:15:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:16:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:17:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:18:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:19:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:20:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:21:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:22:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:23:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:24:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:25:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:26:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:27:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:28:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:29:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:30:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:31:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:32:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:33:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:34:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:35:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:36:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:37:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:38:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:39:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:40:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:41:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:42:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:43:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:44:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:45:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:46:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:47:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:48:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:49:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:50:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:51:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:52:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:53:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:54:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:55:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:56:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:57:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:58:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:59:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:00:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:01:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:02:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:03:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:04:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:05:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:06:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:07:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:08:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:09:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:10:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:11:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:12:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:13:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:14:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:15:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:16:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:17:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:18:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:19:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:20:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:21:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:22:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:23:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:24:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:25:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:26:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:27:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:28:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:29:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:30:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:31:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:32:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:33:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:34:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:35:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:36:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:37:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:38:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:39:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:40:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:41:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:42:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:43:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:44:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:45:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:46:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:47:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:48:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:49:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:50:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:51:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:52:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:53:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:54:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:55:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:56:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:57:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:58:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:59:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:00:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:01:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:02:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:03:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:04:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:05:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:06:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:07:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:08:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:09:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:10:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:11:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:12:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:13:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:14:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:15:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:16:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:17:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:18:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:19:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:20:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:21:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:22:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:23:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:24:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:25:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:26:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:27:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:28:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:29:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:30:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:31:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:32:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:33:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:34:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:35:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:36:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:37:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:38:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:39:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:40:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:41:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:42:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:43:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:44:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:45:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:46:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:47:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:48:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:49:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:50:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:51:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:52:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:53:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:54:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:55:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:56:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:57:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:58:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:59:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:00:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:01:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:02:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:03:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:04:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:05:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:06:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:07:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:08:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:09:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:10:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:11:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:12:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:13:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:14:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:15:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:16:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:17:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:18:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:19:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:20:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:21:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:22:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:23:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:24:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:25:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:26:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:27:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:28:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:29:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:30:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:31:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:32:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:33:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:34:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:35:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:36:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:37:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:38:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:39:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:40:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:41:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:42:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:43:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:44:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:45:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:46:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:47:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:48:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:49:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:50:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:51:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:52:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:53:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:54:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:55:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:56:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:57:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:58:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:59:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:00:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:01:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:02:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:03:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:04:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:05:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:06:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:07:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:08:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:09:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:10:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:11:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:12:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:13:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:14:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:15:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:16:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:17:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:18:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:19:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:20:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:21:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:22:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:23:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:24:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:25:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:26:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:27:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:28:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:29:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:30:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:31:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:32:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:33:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:34:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:35:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:36:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:37:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:38:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:39:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:40:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:41:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:42:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:43:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:44:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:45:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:46:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:47:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:48:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:49:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:50:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:51:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:52:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:53:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:54:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:55:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:56:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:12:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:13:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:14:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:15:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:16:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:17:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:18:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:19:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:20:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:21:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:22:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:23:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:25:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-15 11:36:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-15 11:37:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.

## Best Routes And Run Logs

### C1-25

- Instance: `./instances_bss_bigscal/c101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 8814.1
- Avg cost: 8822.1
- Avg time(s): 30.1
- Gap%: 0.09
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 8845.1 | true | 31.1 |
| 2 | 2 | 8814.1 | true | 30.1 |
| 3 | 3 | 8814.1 | true | 30.1 |
| 4 | 4 | 8814.1 | true | 30.1 |

#### Best Route Plan

```text
totalCost=8813.697671031849, evUavCost=7313.6976710318495, stationOpenCost=1500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 25(CUSTOMER) -> 31(STATION) -> 15(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 25 -> 
  UAV Trip 2: 15 -> 23 -> 22 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 10 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-12: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 31(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 18 -> 19 -> 16 -> 
```

### C2-25

- Instance: `./instances_bss_bigscal/c201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 10686.1
- Avg cost: 10703.1
- Avg time(s): 44.1
- Gap%: 0.16
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 10721.1 | true | 45.1 |
| 2 | 2 | 10686.1 | true | 41.1 |
| 3 | 3 | 10718.1 | true | 46.1 |
| 4 | 4 | 10686.1 | true | 45.1 |

#### Best Route Plan

```text
totalCost=10685.880964266915, evUavCost=9185.880964266915, stationOpenCost=1500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-2: 0(DEPOT) -> 23(CUSTOMER) -> 17(CUSTOMER) -> 31(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 19 -> 17 -> 
EV Route-3: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 6 -> 21 -> 
EV Route-4: 0(DEPOT) -> 31(STATION) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 31(STATION) -> 9(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 13 -> 9 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 15 -> 
```

### R1-25

- Instance: `./instances_bss_bigscal/r101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 16356.1
- Avg cost: 16356.1
- Avg time(s): 31.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16356.1 | true | 33.1 |
| 2 | 2 | 16356.1 | true | 30.1 |
| 3 | 3 | 16356.1 | true | 31.1 |
| 4 | 4 | 16356.1 | true | 30.1 |

#### Best Route Plan

```text
totalCost=16355.841347544178, evUavCost=16355.841347544178, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 23(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 22 -> 4 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 
EV Route-4: 0(DEPOT) -> 21(CUSTOMER) -> 3(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 24 -> 25 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 18 -> 6 -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 20 -> 1 -> 
EV Route-9: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 13 -> 
EV Route-14: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-25

- Instance: `./instances_bss_bigscal/r201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 12471.1
- Avg cost: 12471.1
- Avg time(s): 41.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12471.1 | true | 36.1 |
| 2 | 2 | 12471.1 | true | 36.1 |
| 3 | 3 | 12471.1 | true | 41.1 |
| 4 | 4 | 12471.1 | true | 50.1 |

#### Best Route Plan

```text
totalCost=12470.980485816235, evUavCost=12470.980485816235, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 13 -> 
EV Route-1: 0(DEPOT) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 7 -> 8 -> 18 -> 
EV Route-3: 0(DEPOT) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 10 -> 1 -> 
EV Route-7: 0(DEPOT) -> 12(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 3 -> 24 -> 4 -> 
EV Route-12: 0(DEPOT) -> 2(CUSTOMER) -> 15(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 14 -> 6 -> 
```

### RC1-25

- Instance: `./instances_bss_bigscal/rc101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 17524.1
- Avg cost: 18210.1
- Avg time(s): 44.1
- Gap%: 3.91
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 18433.1 | true | 46.1 |
| 2 | 2 | 17524.1 | true | 47.1 |
| 3 | 3 | 18434.1 | true | 45.1 |
| 4 | 4 | 18447.1 | true | 40.1 |

#### Best Route Plan

```text
totalCost=17524.146083899832, evUavCost=14524.146083899832, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 30(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 13 -> 17 -> 
EV Route-1: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 20 -> 24 -> 
EV Route-2: 0(DEPOT) -> 14(CUSTOMER) -> 16(CUSTOMER) -> 30(STATION) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 9 -> 4 -> 
  UAV Trip 2: 14 -> 15 -> 16 -> 
EV Route-3: 0(DEPOT) -> 31(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 25 -> 
  UAV Trip 2: 31 -> 23 -> 21 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 
EV Route-7: 0(DEPOT) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 6 -> 
```

### RC2-25

- Instance: `./instances_bss_bigscal/rc201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 15433.1
- Avg cost: 15450.1
- Avg time(s): 31.1
- Gap%: 0.11
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 15460.1 | true | 34.1 |
| 2 | 2 | 15460.1 | true | 30.1 |
| 3 | 3 | 15448.1 | true | 30.1 |
| 4 | 4 | 15433.1 | true | 32.1 |

#### Best Route Plan

```text
totalCost=15433.294088464676, evUavCost=10933.294088464676, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 29(STATION) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 18 -> 22 -> 
EV Route-3: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-4: 0(DEPOT) -> 26(STATION) -> 2(CUSTOMER) -> 8(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 26(STATION) -> 1(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 5 -> 8 -> 
  UAV Trip 2: 26 -> 3 -> 1 -> 
EV Route-5: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 31(STATION) -> 16(CUSTOMER) -> 13(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 17 -> 13 -> 
  UAV Trip 2: 14 -> 12 -> 15 -> 
```

### C1-50

- Instance: `./instances_bss_bigscal/c101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 17055.1
- Avg cost: 17068.1
- Avg time(s): 220.1
- Gap%: 0.08
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 17072.1 | true | 239.1 |
| 2 | 2 | 17055.1 | true | 215.1 |
| 3 | 3 | 17072.1 | true | 200.1 |
| 4 | 4 | 17072.1 | true | 229.1 |

#### Best Route Plan

```text
totalCost=17054.646694103933, evUavCost=14054.64669410393, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 36 -> 34 -> 
EV Route-1: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 50 -> 49 -> 47 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-6: 0(DEPOT) -> 13(CUSTOMER) -> 51(STATION) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 31 -> 35 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 10 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-9: 0(DEPOT) -> 17(CUSTOMER) -> 55(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 18 -> 19 -> 15 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 
```

### C2-50

- Instance: `./instances_bss_bigscal/c201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 19648.1
- Avg cost: 19654.1
- Avg time(s): 238.1
- Gap%: 0.03
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19661.1 | true | 214.1 |
| 2 | 2 | 19656.1 | true | 228.1 |
| 3 | 3 | 19650.1 | true | 232.1 |
| 4 | 4 | 19648.1 | true | 278.1 |

#### Best Route Plan

```text
totalCost=19648.276518543098, evUavCost=16648.276518543098, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 6(CUSTOMER) -> 33(CUSTOMER) -> 51(STATION) -> 34(CUSTOMER) -> 28(CUSTOMER) -> 23(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 31 -> 34 -> 
  UAV Trip 2: 6 -> 32 -> 33 -> 
  UAV Trip 3: 28 -> 26 -> 23 -> 
EV Route-1: 0(DEPOT) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 40 -> 44 -> 46 -> 
EV Route-2: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-3: 0(DEPOT) -> 54(STATION) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 17(CUSTOMER) -> 13(CUSTOMER) -> 54(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 15 -> 
EV Route-4: 0(DEPOT) -> 45(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 50 -> 47 -> 43 -> 42 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-7: 0(DEPOT) -> 20(CUSTOMER) -> 22(CUSTOMER) -> 29(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 24 -> 27 -> 30 -> 29 -> 
  UAV Trip 2: 51 -> 35 -> 37 -> 
  UAV Trip 3: 38 -> 39 -> 36 -> 
```

### R1-50

- Instance: `./instances_bss_bigscal/r101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 27051.1
- Avg cost: 27456.1
- Avg time(s): 162.1
- Gap%: 1.50
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 27051.1 | true | 163.1 |
| 2 | 2 | 27136.1 | true | 157.1 |
| 3 | 3 | 28502.1 | true | 158.1 |
| 4 | 4 | 27136.1 | true | 172.1 |

#### Best Route Plan

```text
totalCost=27050.58085364481, evUavCost=27050.58085364481, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 22 -> 26 -> 
EV Route-1: 0(DEPOT) -> 45(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 18 -> 6 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 37(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 37 -> 
EV Route-3: 0(DEPOT) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 20 -> 32 -> 
EV Route-4: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 39(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 4 -> 
EV Route-6: 0(DEPOT) -> 42(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 41 -> 43 -> 
EV Route-7: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-8: 0(DEPOT) -> 28(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 29 -> 3 -> 
EV Route-9: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 17 -> 
EV Route-11: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 27(CUSTOMER) -> 7(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 46 -> 48 -> 
EV Route-14: 0(DEPOT) -> 12(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 40 -> 50 -> 
```

### R2-50

- Instance: `./instances_bss_bigscal/r201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 22556.1
- Avg cost: 23227.1
- Avg time(s): 218.1
- Gap%: 2.97
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 23476.1 | true | 265.1 |
| 2 | 2 | 23436.1 | true | 197.1 |
| 3 | 3 | 23440.1 | true | 176.1 |
| 4 | 4 | 22556.1 | true | 234.1 |

#### Best Route Plan

```text
totalCost=22555.95429393198, evUavCost=19555.95429393198, stationOpenCost=3000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 55(STATION) -> 47(CUSTOMER) -> 19(CUSTOMER) -> 11(CUSTOMER) -> 55(STATION) -> 38(CUSTOMER) -> 43(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 19 -> 
  UAV Trip 2: 5 -> 45 -> 55 -> 
EV Route-1: 0(DEPOT) -> 39(CUSTOMER) -> 52(STATION) -> 21(CUSTOMER) -> 26(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 40 -> 6 -> 26 -> 
  UAV Trip 2: 39 -> 23 -> 52 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 22(CUSTOMER) -> 52(STATION) -> 3(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 41 -> 22 -> 
  UAV Trip 2: 3 -> 34 -> 35 -> 
EV Route-4: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 14 -> 44 -> 
EV Route-5: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 24 -> 4 -> 
EV Route-6: 0(DEPOT) -> 27(CUSTOMER) -> 31(CUSTOMER) -> 10(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 30 -> 10 -> 
EV Route-7: 0(DEPOT) -> 33(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 9 -> 20 -> 50 -> 
EV Route-8: 0(DEPOT) -> 18(CUSTOMER) -> 55(STATION) -> 49(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 7 -> 8 -> 55 -> 
  UAV Trip 2: 49 -> 46 -> 48 -> 
```

### RC1-50

- Instance: `./instances_bss_bigscal/rc101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 33847.1
- Avg cost: 33868.1
- Avg time(s): 185.1
- Gap%: 0.06
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 33847.1 | true | 164.1 |
| 2 | 2 | 33854.1 | true | 153.1 |
| 3 | 3 | 33921.1 | true | 223.1 |
| 4 | 4 | 33850.1 | true | 200.1 |

#### Best Route Plan

```text
totalCost=33847.43982901392, evUavCost=26347.43982901392, stationOpenCost=7500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 52(STATION) -> 40(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 43 -> 37 -> 35 -> 
  UAV Trip 2: 42 -> 44 -> 52 -> 
EV Route-1: 0(DEPOT) -> 55(STATION) -> 28(CUSTOMER) -> 27(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 26 -> 34 -> 
EV Route-3: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 52(STATION) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 38 -> 52 -> 
EV Route-4: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 54(STATION) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 9 -> 10 -> 
EV Route-6: 0(DEPOT) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 54(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 17 -> 13 -> 54 -> 
  UAV Trip 2: 14 -> 47 -> 15 -> 
EV Route-8: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 51(STATION) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 8 -> 7 -> 6 -> 
EV Route-11: 0(DEPOT) -> 56(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 56 -> 23 -> 21 -> 
  UAV Trip 2: 19 -> 18 -> 48 -> 25 -> 
EV Route-12: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 49 -> 20 -> 24 -> 
EV Route-13: 0(DEPOT) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 55(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 31 -> 29 -> 30 -> 
```

### RC2-50

- Instance: `./instances_bss_bigscal/rc201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 29153.1
- Avg cost: 29615.1
- Avg time(s): 167.1
- Gap%: 1.58
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 30476.1 | true | 193.1 |
| 2 | 2 | 29330.1 | true | 158.1 |
| 3 | 3 | 29502.1 | true | 164.1 |
| 4 | 4 | 29153.1 | true | 154.1 |

#### Best Route Plan

```text
totalCost=29153.47404075737, evUavCost=21653.47404075737, stationOpenCost=7500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 55(STATION) -> 38(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 40 -> 55 -> 
EV Route-1: 0(DEPOT) -> 22(CUSTOMER) -> 51(STATION) -> 20(CUSTOMER) -> 50(CUSTOMER) -> 53(STATION) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 18 -> 20 -> 
  UAV Trip 2: 53 -> 32 -> 26 -> 
EV Route-2: 0(DEPOT) -> 2(CUSTOMER) -> 58(STATION) -> 6(CUSTOMER) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 3 -> 1 -> 4 -> 
  UAV Trip 2: 6 -> 7 -> 8 -> 
EV Route-4: 0(DEPOT) -> 45(CUSTOMER) -> 58(STATION) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 58 -> 
  UAV Trip 2: 14 -> 47 -> 17 -> 13 -> 
EV Route-5: 0(DEPOT) -> 53(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 33 -> 31 -> 
  UAV Trip 2: 29 -> 27 -> 28 -> 30 -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 54(STATION) -> 15(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
  UAV Trip 2: 54 -> 16 -> 15 -> 
EV Route-7: 0(DEPOT) -> 19(CUSTOMER) -> 51(STATION) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 49 -> 24 -> 25 -> 
EV Route-8: 0(DEPOT) -> 39(CUSTOMER) -> 55(STATION) -> 36(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 35 -> 37 -> 43 -> 
```

### C1-75

- Instance: `./instances_bss_bigscal/c101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 28758.1
- Avg cost: 29647.1
- Avg time(s): 531.1
- Gap%: 3.09
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 29708.1 | true | 582.1 |
| 2 | 2 | 30294.1 | true | 458.1 |
| 3 | 3 | 29828.1 | true | 511.1 |
| 4 | 4 | 28758.1 | true | 575.1 |

#### Best Route Plan

```text
totalCost=28757.9958133752, evUavCost=24257.9958133752, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 10(CUSTOMER) -> 79(STATION) -> 18(CUSTOMER) -> 38(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 17 -> 79 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 
EV Route-1: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-2: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 31 -> 47 -> 
EV Route-3: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 63 -> 62 -> 74 -> 
EV Route-4: 0(DEPOT) -> 57(CUSTOMER) -> 81(STATION) -> 35(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 35 -> 37 -> 34 -> 
EV Route-5: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
EV Route-6: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
  UAV Trip 3: 5 -> 3 -> 7 -> 
EV Route-7: 0(DEPOT) -> 67(CUSTOMER) -> 71(CUSTOMER) -> 83(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 70 -> 73 -> 
  UAV Trip 2: 67 -> 65 -> 71 -> 
EV Route-10: 0(DEPOT) -> 13(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 19 -> 15 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 
EV Route-11: 0(DEPOT) -> 55(CUSTOMER) -> 81(STATION) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
```

### C2-75

- Instance: `./instances_bss_bigscal/c201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 29969.1
- Avg cost: 30636.1
- Avg time(s): 633.1
- Gap%: 2.23
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 29969.1 | true | 631.1 |
| 2 | 2 | 30888.1 | true | 577.1 |
| 3 | 3 | 30927.1 | true | 648.1 |
| 4 | 4 | 30762.1 | true | 677.1 |

#### Best Route Plan

```text
totalCost=29968.92519420423, evUavCost=25468.92519420423, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 78(STATION) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 64 -> 78 -> 
EV Route-1: 0(DEPOT) -> 79(STATION) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 15 -> 
EV Route-2: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 43 -> 42 -> 41 -> 48 -> 
EV Route-3: 0(DEPOT) -> 69(CUSTOMER) -> 78(STATION) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 57(CUSTOMER) -> 44(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 68 -> 65 -> 55 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 
EV Route-4: 0(DEPOT) -> 67(CUSTOMER) -> 78(STATION) -> 49(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 62 -> 66 -> 78 -> 
  UAV Trip 2: 49 -> 53 -> 56 -> 
  UAV Trip 3: 58 -> 60 -> 59 -> 
EV Route-5: 0(DEPOT) -> 22(CUSTOMER) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 18(CUSTOMER) -> 19(CUSTOMER) -> 79(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 26 -> 23 -> 18 -> 
EV Route-6: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 75(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-9: 0(DEPOT) -> 20(CUSTOMER) -> 33(CUSTOMER) -> 76(STATION) -> 46(CUSTOMER) -> 78(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 31 -> 35 -> 46 -> 
  UAV Trip 2: 20 -> 24 -> 29 -> 33 -> 
EV Route-10: 0(DEPOT) -> 6(CUSTOMER) -> 76(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 28(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 36 -> 34 -> 28 -> 
  UAV Trip 2: 6 -> 32 -> 76 -> 
```

### R1-75

- Instance: `./instances_bss_bigscal/r101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 39605.1
- Avg cost: 40478.1
- Avg time(s): 639.1
- Gap%: 2.20
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 39605.1 | true | 717.1 |
| 2 | 2 | 40347.1 | true | 671.1 |
| 3 | 3 | 41078.1 | true | 617.1 |
| 4 | 4 | 40882.1 | true | 549.1 |

#### Best Route Plan

```text
totalCost=39604.92984056829, evUavCost=33604.92984056829, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 52(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 18 -> 8 -> 46 -> 48 -> 
EV Route-1: 0(DEPOT) -> 28(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 12 -> 40 -> 
  UAV Trip 2: 53 -> 26 -> 13 -> 
EV Route-2: 0(DEPOT) -> 59(CUSTOMER) -> 42(CUSTOMER) -> 37(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 57 -> 37 -> 
EV Route-3: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 22 -> 54 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 74(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 41 -> 56 -> 74 -> 
EV Route-5: 0(DEPOT) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 66(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 20 -> 66 -> 
EV Route-6: 0(DEPOT) -> 14(CUSTOMER) -> 61(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 16 -> 61 -> 
EV Route-7: 0(DEPOT) -> 36(CUSTOMER) -> 82(STATION) -> 49(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 64 -> 82 -> 
EV Route-8: 0(DEPOT) -> 65(CUSTOMER) -> 35(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 71 -> 35 -> 
EV Route-9: 0(DEPOT) -> 33(CUSTOMER) -> 29(CUSTOMER) -> 83(STATION) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 3 -> 50 -> 68 -> 
EV Route-10: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 7(CUSTOMER) -> 79(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 19 -> 7 -> 
EV Route-11: 0(DEPOT) -> 63(CUSTOMER) -> 11(CUSTOMER) -> 82(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 62 -> 11 -> 
  UAV Trip 2: 82 -> 10 -> 32 -> 
EV Route-12: 0(DEPOT) -> 5(CUSTOMER) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 43 -> 
EV Route-13: 0(DEPOT) -> 77(STATION) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 67 -> 
  UAV Trip 2: 55 -> 4 -> 25 -> 
EV Route-14: 0(DEPOT) -> 27(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 24 -> 83 -> 
  UAV Trip 2: 27 -> 69 -> 51 -> 
```

### R2-75

- Instance: `./instances_bss_bigscal/r201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 31672.1
- Avg cost: 31855.1
- Avg time(s): 610.1
- Gap%: 0.58
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 31978.1 | true | 633.1 |
| 2 | 2 | 31860.1 | true | 691.1 |
| 3 | 3 | 31910.1 | true | 575.1 |
| 4 | 4 | 31672.1 | true | 542.1 |

#### Best Route Plan

```text
totalCost=31671.590036284462, evUavCost=25671.590036284462, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 52(CUSTOMER) -> 7(CUSTOMER) -> 76(STATION) -> 48(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 49 -> 48 -> 
  UAV Trip 2: 52 -> 18 -> 7 -> 
EV Route-1: 0(DEPOT) -> 53(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 40 -> 26 -> 13 -> 
EV Route-2: 0(DEPOT) -> 59(CUSTOMER) -> 78(STATION) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
  UAV Trip 2: 16 -> 61 -> 8 -> 6 -> 
EV Route-3: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 68(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 68 -> 24 -> 54 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 42(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 43 -> 37 -> 
EV Route-5: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 77(STATION) -> 20(CUSTOMER) -> 66(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 34 -> 20 -> 
  UAV Trip 2: 69 -> 30 -> 51 -> 
EV Route-6: 0(DEPOT) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 75(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 22 -> 41 -> 57 -> 74 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 76(STATION) -> 63(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 64 -> 46 -> 17 -> 
  UAV Trip 2: 47 -> 36 -> 76 -> 
EV Route-8: 0(DEPOT) -> 31(CUSTOMER) -> 19(CUSTOMER) -> 76(STATION) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 70(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 32 -> 70 -> 
  UAV Trip 2: 31 -> 62 -> 19 -> 
EV Route-9: 0(DEPOT) -> 33(CUSTOMER) -> 77(STATION) -> 71(CUSTOMER) -> 29(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 65 -> 71 -> 
  UAV Trip 2: 29 -> 3 -> 50 -> 
EV Route-10: 0(DEPOT) -> 72(CUSTOMER) -> 39(CUSTOMER) -> 82(STATION) -> 23(CUSTOMER) -> 56(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 67 -> 23 -> 
  UAV Trip 2: 56 -> 4 -> 55 -> 25 -> 
```

### RC1-75

- Instance: `./instances_bss_bigscal/rc101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 43838.1
- Avg cost: 45009.1
- Avg time(s): 584.1
- Gap%: 2.67
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 45291.1 | true | 441.1 |
| 2 | 2 | 45638.1 | true | 450.1 |
| 3 | 3 | 45270.1 | true | 645.1 |
| 4 | 4 | 43838.1 | true | 801.1 |

#### Best Route Plan

```text
totalCost=43838.327580176396, evUavCost=36338.327580176396, stationOpenCost=7500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 45(CUSTOMER) -> 82(STATION) -> 7(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 3 -> 55 -> 
  UAV Trip 2: 45 -> 5 -> 82 -> 
EV Route-1: 0(DEPOT) -> 72(CUSTOMER) -> 61(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 61 -> 
EV Route-2: 0(DEPOT) -> 77(STATION) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 31 -> 29 -> 27 -> 
EV Route-3: 0(DEPOT) -> 80(STATION) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 17 -> 60 -> 
  UAV Trip 2: 80 -> 14 -> 12 -> 11 -> 
EV Route-4: 0(DEPOT) -> 65(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 83(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 57 -> 
  UAV Trip 2: 83 -> 24 -> 25 -> 
EV Route-5: 0(DEPOT) -> 80(STATION) -> 15(CUSTOMER) -> 9(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 80 -> 47 -> 16 -> 15 -> 
  UAV Trip 2: 9 -> 74 -> 58 -> 
EV Route-6: 0(DEPOT) -> 59(CUSTOMER) -> 13(CUSTOMER) -> 80(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 13 -> 
EV Route-7: 0(DEPOT) -> 62(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 62 -> 67 -> 50 -> 
EV Route-8: 0(DEPOT) -> 64(CUSTOMER) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 51 -> 18 -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 82(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 4 -> 1 -> 70 -> 
  UAV Trip 2: 2 -> 6 -> 82 -> 
EV Route-10: 0(DEPOT) -> 36(CUSTOMER) -> 78(STATION) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 78 -> 44 -> 41 -> 37 -> 
EV Route-11: 0(DEPOT) -> 83(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 23 -> 21 -> 
  UAV Trip 2: 19 -> 49 -> 20 -> 56 -> 
EV Route-12: 0(DEPOT) -> 42(CUSTOMER) -> 39(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 43 -> 54 -> 
  UAV Trip 2: 39 -> 38 -> 78 -> 
EV Route-13: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 73 -> 53 -> 
EV Route-14: 0(DEPOT) -> 63(CUSTOMER) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 28 -> 30 -> 
```

### RC2-75

- Instance: `./instances_bss_bigscal/rc201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 38471.1
- Avg cost: 39118.1
- Avg time(s): 613.1
- Gap%: 1.68
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 39785.1 | true | 610.1 |
| 2 | 2 | 38639.1 | true | 686.1 |
| 3 | 3 | 39578.1 | true | 699.1 |
| 4 | 4 | 38471.1 | true | 455.1 |

#### Best Route Plan

```text
totalCost=38471.202073906876, evUavCost=30971.202073906876, stationOpenCost=7500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 72(CUSTOMER) -> 78(STATION) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 35(CUSTOMER) -> 37(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 42 -> 44 -> 35 -> 
EV Route-1: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 76(STATION) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 60 -> 55 -> 
  UAV Trip 2: 6 -> 7 -> 8 -> 46 -> 
EV Route-2: 0(DEPOT) -> 64(CUSTOMER) -> 19(CUSTOMER) -> 77(STATION) -> 21(CUSTOMER) -> 18(CUSTOMER) -> 51(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 23 -> 21 -> 
EV Route-4: 0(DEPOT) -> 65(CUSTOMER) -> 22(CUSTOMER) -> 77(STATION) -> 25(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 49 -> 20 -> 24 -> 25 -> 
  UAV Trip 2: 65 -> 57 -> 22 -> 
EV Route-5: 0(DEPOT) -> 14(CUSTOMER) -> 79(STATION) -> 59(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 58 -> 
  UAV Trip 2: 14 -> 47 -> 79 -> 
EV Route-6: 0(DEPOT) -> 67(CUSTOMER) -> 34(CUSTOMER) -> 81(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 26 -> 32 -> 
  UAV Trip 2: 67 -> 50 -> 34 -> 
EV Route-7: 0(DEPOT) -> 63(CUSTOMER) -> 33(CUSTOMER) -> 81(STATION) -> 30(CUSTOMER) -> 62(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 27 -> 28 -> 30 -> 
EV Route-8: 0(DEPOT) -> 52(CUSTOMER) -> 10(CUSTOMER) -> 79(STATION) -> 13(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 17 -> 13 -> 
  UAV Trip 2: 52 -> 9 -> 10 -> 
EV Route-10: 0(DEPOT) -> 69(CUSTOMER) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 73 -> 53 -> 
EV Route-11: 0(DEPOT) -> 71(CUSTOMER) -> 31(CUSTOMER) -> 81(STATION) -> 56(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 29 -> 81 -> 
EV Route-12: 0(DEPOT) -> 76(STATION) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 4 -> 
EV Route-13: 0(DEPOT) -> 61(CUSTOMER) -> 41(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 38 -> 78 -> 
  UAV Trip 2: 40 -> 43 -> 68 -> 
```

### C1-100

- Instance: `./instances_bss_bigscal/c101_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 41596.1
- Avg cost: 42207.1
- Avg time(s): 1206.1
- Gap%: 1.47
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 42665.1 | true | 1143.1 |
| 2 | 2 | 41596.1 | true | 1683.1 |
| 3 | 3 | 42861.1 | true | 1050.1 |
| 4 | 4 | 41708.1 | true | 949.1 |

#### Best Route Plan

```text
totalCost=41595.516729970805, evUavCost=35595.516729970805, stationOpenCost=6000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 98(CUSTOMER) -> 82(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 98 -> 83 -> 82 -> 
EV Route-1: 0(DEPOT) -> 10(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-2: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 30(CUSTOMER) -> 111(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 30 -> 
EV Route-3: 0(DEPOT) -> 112(STATION) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
EV Route-4: 0(DEPOT) -> 81(CUSTOMER) -> 105(STATION) -> 76(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 71 -> 89 -> 
  UAV Trip 2: 81 -> 78 -> 105 -> 
EV Route-5: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 111(STATION) -> 23(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 31 -> 29 -> 111 -> 
EV Route-6: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 111(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 27 -> 111 -> 
  UAV Trip 2: 16 -> 14 -> 12 -> 
EV Route-7: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-8: 0(DEPOT) -> 57(CUSTOMER) -> 40(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 57 -> 55 -> 40 -> 
EV Route-9: 0(DEPOT) -> 111(STATION) -> 25(CUSTOMER) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 34(CUSTOMER) -> 111(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 34 -> 
EV Route-10: 0(DEPOT) -> 63(CUSTOMER) -> 105(STATION) -> 73(CUSTOMER) -> 77(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 105 -> 70 -> 73 -> 
  UAV Trip 2: 77 -> 79 -> 80 -> 
EV Route-11: 0(DEPOT) -> 108(STATION) -> 96(CUSTOMER) -> 95(CUSTOMER) -> 93(CUSTOMER) -> 97(CUSTOMER) -> 99(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 94 -> 92 -> 93 -> 
  UAV Trip 2: 97 -> 100 -> 99 -> 
EV Route-12: 0(DEPOT) -> 5(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 26(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 28 -> 26 -> 
  UAV Trip 2: 5 -> 3 -> 7 -> 
EV Route-13: 0(DEPOT) -> 90(CUSTOMER) -> 87(CUSTOMER) -> 85(CUSTOMER) -> 88(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 87 -> 86 -> 84 -> 85 -> 
EV Route-14: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
```

### C2-100

- Instance: `./instances_bss_bigscal/c201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 39525.1
- Avg cost: 40097.1
- Avg time(s): 939.1
- Gap%: 1.45
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 39650.1 | true | 1162.1 |
| 2 | 2 | 40576.1 | true | 833.1 |
| 3 | 3 | 40635.1 | true | 855.1 |
| 4 | 4 | 39525.1 | true | 908.1 |

#### Best Route Plan

```text
totalCost=39525.21713238886, evUavCost=32025.21713238886, stationOpenCost=7500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 64(CUSTOMER) -> 104(STATION) -> 96(CUSTOMER) -> 87(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 62 -> 74 -> 
  UAV Trip 2: 104 -> 49 -> 96 -> 
  UAV Trip 3: 72 -> 61 -> 64 -> 
EV Route-1: 0(DEPOT) -> 67(CUSTOMER) -> 104(STATION) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 104(STATION) -> 80(CUSTOMER) -> 79(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 66 -> 69 -> 65 -> 104 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
EV Route-2: 0(DEPOT) -> 22(CUSTOMER) -> 25(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 25 -> 
EV Route-3: 0(DEPOT) -> 88(CUSTOMER) -> 105(STATION) -> 86(CUSTOMER) -> 85(CUSTOMER) -> 78(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 88 -> 84 -> 105 -> 
  UAV Trip 2: 85 -> 81 -> 78 -> 
EV Route-5: 0(DEPOT) -> 89(CUSTOMER) -> 105(STATION) -> 83(CUSTOMER) -> 82(CUSTOMER) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 76 -> 71 -> 
  UAV Trip 2: 89 -> 91 -> 105 -> 
EV Route-6: 0(DEPOT) -> 109(STATION) -> 16(CUSTOMER) -> 14(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
  UAV Trip 2: 9 -> 11 -> 10 -> 
EV Route-8: 0(DEPOT) -> 68(CUSTOMER) -> 104(STATION) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
EV Route-9: 0(DEPOT) -> 93(CUSTOMER) -> 75(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 90(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 98 -> 7 -> 
  UAV Trip 2: 3 -> 4 -> 90 -> 
EV Route-11: 0(DEPOT) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 99(CUSTOMER) -> 112(STATION) -> 97(CUSTOMER) -> 92(CUSTOMER) -> 95(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 112 -> 100 -> 97 -> 
  UAV Trip 2: 5 -> 2 -> 1 -> 
  UAV Trip 3: 92 -> 94 -> 95 -> 
EV Route-12: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 107(STATION) -> 34(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 107 -> 31 -> 35 -> 34 -> 
  UAV Trip 2: 23 -> 18 -> 19 -> 109 -> 
EV Route-13: 0(DEPOT) -> 20(CUSTOMER) -> 33(CUSTOMER) -> 107(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 39 -> 36 -> 12 -> 
  UAV Trip 2: 20 -> 24 -> 29 -> 33 -> 
EV Route-14: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 43 -> 42 -> 41 -> 48 -> 
```

### R1-100

- Instance: `./instances_bss_bigscal/r101_n100_bss.txt`
- Feasible runs: 0/4
- Best run seed: 2
- Best cost: 384971.1
- Avg cost: 416443.1
- Avg time(s): 1119.1
- Gap%: 8.18
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 474530.1 | false | 1238.1 |
| 2 | 2 | 384971.1 | false | 985.1 |
| 3 | 3 | 394653.1 | false | 1131.1 |
| 4 | 4 | 411616.1 | false | 1121.1 |

#### Best Route Plan

```text
totalCost=384970.97653013794, evUavCost=38611.67836838599, stationOpenCost=12000.0, violationCost=334359.29816175194, overloadAmount=0.0, timeViolationAmount=334.35929816175195
EV Route-0: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 83(CUSTOMER) -> 104(STATION) -> 18(CUSTOMER) -> 84(CUSTOMER) -> 85(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 111(STATION) -> 33(CUSTOMER) -> 29(CUSTOMER) -> 78(CUSTOMER) -> 3(CUSTOMER) -> 68(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 79 -> 78 -> 
EV Route-2: 0(DEPOT) -> 65(CUSTOMER) -> 108(STATION) -> 71(CUSTOMER) -> 9(CUSTOMER) -> 34(CUSTOMER) -> 35(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 42(CUSTOMER) -> 75(CUSTOMER) -> 112(STATION) -> 22(CUSTOMER) -> 41(CUSTOMER) -> 56(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 72(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 26(CUSTOMER) -> 74(CUSTOMER) -> 112(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 92(CUSTOMER) -> 95(CUSTOMER) -> 98(CUSTOMER) -> 61(CUSTOMER) -> 99(CUSTOMER) -> 94(CUSTOMER) -> 6(CUSTOMER) -> 96(CUSTOMER) -> 91(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 2(CUSTOMER) -> 87(CUSTOMER) -> 57(CUSTOMER) -> 15(CUSTOMER) -> 43(CUSTOMER) -> 109(STATION) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 28(CUSTOMER) -> 76(CUSTOMER) -> 81(CUSTOMER) -> 66(CUSTOMER) -> 108(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 20 -> 66 -> 
  UAV Trip 2: 28 -> 12 -> 76 -> 
EV Route-8: 0(DEPOT) -> 36(CUSTOMER) -> 106(STATION) -> 11(CUSTOMER) -> 64(CUSTOMER) -> 49(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 27(CUSTOMER) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 52 -> 88 -> 7 -> 
  UAV Trip 2: 8 -> 46 -> 60 -> 89 -> 
EV Route-10: 0(DEPOT) -> 112(STATION) -> 39(CUSTOMER) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-11: 0(DEPOT) -> 63(CUSTOMER) -> 103(STATION) -> 90(CUSTOMER) -> 10(CUSTOMER) -> 1(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 32 -> 1 -> 
  UAV Trip 2: 63 -> 62 -> 103 -> 
EV Route-12: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 19(CUSTOMER) -> 106(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 82 -> 47 -> 
EV Route-13: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 44(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 38(CUSTOMER) -> 37(CUSTOMER) -> 97(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 69(CUSTOMER) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 51(CUSTOMER) -> 50(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-100

- Instance: `./instances_bss_bigscal/r201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 37442.1
- Avg cost: 38071.1
- Avg time(s): 1289.1
- Gap%: 1.68
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 38106.1 | true | 1330.1 |
| 2 | 2 | 37958.1 | true | 1283.1 |
| 3 | 3 | 37442.1 | true | 1284.1 |
| 4 | 4 | 38780.1 | true | 1261.1 |

#### Best Route Plan

```text
totalCost=37441.719348146464, evUavCost=32941.719348146464, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 47(CUSTOMER) -> 101(STATION) -> 63(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 101 -> 
  UAV Trip 2: 63 -> 90 -> 10 -> 32 -> 
EV Route-1: 0(DEPOT) -> 52(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 18 -> 8 -> 48 -> 
EV Route-2: 0(DEPOT) -> 112(STATION) -> 65(CUSTOMER) -> 71(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 35 -> 1 -> 
  UAV Trip 2: 112 -> 33 -> 65 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 82(CUSTOMER) -> 7(CUSTOMER) -> 88(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 83 -> 45 -> 82 -> 
EV Route-4: 0(DEPOT) -> 31(CUSTOMER) -> 101(STATION) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 11 -> 64 -> 49 -> 
  UAV Trip 2: 31 -> 62 -> 101 -> 
EV Route-5: 0(DEPOT) -> 99(CUSTOMER) -> 16(CUSTOMER) -> 86(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 86 -> 84 -> 17 -> 60 -> 
  UAV Trip 2: 99 -> 61 -> 16 -> 
EV Route-6: 0(DEPOT) -> 103(STATION) -> 72(CUSTOMER) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 23(CUSTOMER) -> 56(CUSTOMER) -> 103(STATION) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 75 -> 56 -> 
EV Route-7: 0(DEPOT) -> 53(CUSTOMER) -> 94(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 94 -> 6 -> 96 -> 97 -> 13 -> 
EV Route-8: 0(DEPOT) -> 28(CUSTOMER) -> 76(CUSTOMER) -> 79(CUSTOMER) -> 112(STATION) -> 81(CUSTOMER) -> 51(CUSTOMER) -> 66(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 9 -> 78 -> 66 -> 
  UAV Trip 2: 28 -> 12 -> 76 -> 
EV Route-9: 0(DEPOT) -> 95(CUSTOMER) -> 92(CUSTOMER) -> 42(CUSTOMER) -> 57(CUSTOMER) -> 87(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 92 -> 14 -> 42 -> 
EV Route-10: 0(DEPOT) -> 21(CUSTOMER) -> 103(STATION) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 103(STATION) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 2 -> 15 -> 103 -> 
  UAV Trip 2: 44 -> 38 -> 43 -> 
EV Route-11: 0(DEPOT) -> 40(CUSTOMER) -> 73(CUSTOMER) -> 103(STATION) -> 74(CUSTOMER) -> 54(CUSTOMER) -> 68(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 22 -> 41 -> 103 -> 
  UAV Trip 2: 74 -> 4 -> 54 -> 
  UAV Trip 3: 68 -> 80 -> 77 -> 
EV Route-13: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 30(CUSTOMER) -> 3(CUSTOMER) -> 112(STATION) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 29 -> 3 -> 
  UAV Trip 2: 112 -> 34 -> 50 -> 
EV Route-14: 0(DEPOT) -> 59(CUSTOMER) -> 98(CUSTOMER) -> 85(CUSTOMER) -> 93(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 37 -> 100 -> 91 -> 93 -> 
```

### RC1-100

- Instance: `./instances_bss_bigscal/rc101_n100_bss.txt`
- Feasible runs: 0/4
- Best run seed: 3
- Best cost: 173293.1
- Avg cost: 207757.1
- Avg time(s): 887.1
- Gap%: 19.89
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 187350.1 | false | 843.1 |
| 2 | 2 | 249658.1 | false | 927.1 |
| 3 | 3 | 173293.1 | false | 858.1 |
| 4 | 4 | 220725.1 | false | 920.1 |

#### Best Route Plan

```text
totalCost=173292.76990839496, evUavCost=42121.08719631068, stationOpenCost=13500.0, violationCost=117671.68271208426, overloadAmount=0.0, timeViolationAmount=117.67168271208426
EV Route-0: 0(DEPOT) -> 61(CUSTOMER) -> 53(CUSTOMER) -> 10(CUSTOMER) -> 101(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 61 -> 81 -> 90 -> 53 -> 
EV Route-1: 0(DEPOT) -> 104(STATION) -> 36(CUSTOMER) -> 106(STATION) -> 41(CUSTOMER) -> 96(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 104 -> 72 -> 36 -> 
  UAV Trip 2: 96 -> 54 -> 70 -> 
EV Route-2: 0(DEPOT) -> 65(CUSTOMER) -> 64(CUSTOMER) -> 102(STATION) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 84 -> 50 -> 
  UAV Trip 2: 65 -> 83 -> 64 -> 
EV Route-3: 0(DEPOT) -> 63(CUSTOMER) -> 109(STATION) -> 76(CUSTOMER) -> 48(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 85 -> 48 -> 
EV Route-4: 0(DEPOT) -> 59(CUSTOMER) -> 103(STATION) -> 87(CUSTOMER) -> 9(CUSTOMER) -> 60(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 103 -> 86 -> 87 -> 
  UAV Trip 2: 9 -> 13 -> 60 -> 
EV Route-5: 0(DEPOT) -> 92(CUSTOMER) -> 33(CUSTOMER) -> 28(CUSTOMER) -> 107(STATION) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 30 -> 28 -> 
  UAV Trip 2: 107 -> 32 -> 89 -> 
EV Route-6: 0(DEPOT) -> 101(STATION) -> 11(CUSTOMER) -> 12(CUSTOMER) -> 78(CUSTOMER) -> 73(CUSTOMER) -> 79(CUSTOMER) -> 17(CUSTOMER) -> 101(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 95(CUSTOMER) -> 62(CUSTOMER) -> 104(STATION) -> 94(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 62 -> 67 -> 71 -> 104 -> 
  UAV Trip 2: 94 -> 56 -> 66 -> 
EV Route-8: 0(DEPOT) -> 82(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 105(STATION) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 52 -> 99 -> 57 -> 
EV Route-9: 0(DEPOT) -> 102(STATION) -> 31(CUSTOMER) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 107(STATION) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 29 -> 27 -> 
EV Route-10: 0(DEPOT) -> 42(CUSTOMER) -> 39(CUSTOMER) -> 106(STATION) -> 38(CUSTOMER) -> 40(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 44 -> 38 -> 
  UAV Trip 2: 40 -> 43 -> 37 -> 35 -> 
EV Route-11: 0(DEPOT) -> 105(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 49(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 20 -> 24 -> 74 -> 
  UAV Trip 2: 105 -> 23 -> 21 -> 
EV Route-12: 0(DEPOT) -> 69(CUSTOMER) -> 98(CUSTOMER) -> 88(CUSTOMER) -> 7(CUSTOMER) -> 46(CUSTOMER) -> 108(STATION) -> 55(CUSTOMER) -> 68(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 108(STATION) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 8(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 4(CUSTOMER) -> 108(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 101(STATION) -> 14(CUSTOMER) -> 47(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 97(CUSTOMER) -> 75(CUSTOMER) -> 58(CUSTOMER) -> 103(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
```

### RC2-100

- Instance: `./instances_bss_bigscal/rc201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 47593.1
- Avg cost: 48236.1
- Avg time(s): 979.1
- Gap%: 1.35
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 48717.1 | true | 1083.1 |
| 2 | 2 | 48121.1 | true | 973.1 |
| 3 | 3 | 47593.1 | true | 878.1 |
| 4 | 4 | 48512.1 | true | 981.1 |

#### Best Route Plan

```text
totalCost=47593.35525953995, evUavCost=37093.35525953995, stationOpenCost=10500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 102(STATION) -> 36(CUSTOMER) -> 72(CUSTOMER) -> 94(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 94 -> 
  UAV Trip 2: 102 -> 39 -> 36 -> 
EV Route-1: 0(DEPOT) -> 92(CUSTOMER) -> 95(CUSTOMER) -> 103(STATION) -> 33(CUSTOMER) -> 28(CUSTOMER) -> 106(STATION) -> 30(CUSTOMER) -> 67(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 27 -> 29 -> 106 -> 
  UAV Trip 2: 103 -> 63 -> 33 -> 
  UAV Trip 3: 30 -> 31 -> 67 -> 
EV Route-2: 0(DEPOT) -> 64(CUSTOMER) -> 103(STATION) -> 19(CUSTOMER) -> 110(STATION) -> 21(CUSTOMER) -> 18(CUSTOMER) -> 76(CUSTOMER) -> 84(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 85 -> 84 -> 
  UAV Trip 2: 110 -> 23 -> 21 -> 
EV Route-3: 0(DEPOT) -> 82(CUSTOMER) -> 104(STATION) -> 15(CUSTOMER) -> 11(CUSTOMER) -> 9(CUSTOMER) -> 97(CUSTOMER) -> 101(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 104 -> 47 -> 16 -> 15 -> 
  UAV Trip 2: 9 -> 87 -> 97 -> 
EV Route-4: 0(DEPOT) -> 61(CUSTOMER) -> 44(CUSTOMER) -> 102(STATION) -> 38(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 35 -> 37 -> 43 -> 
  UAV Trip 2: 102 -> 41 -> 38 -> 
EV Route-6: 0(DEPOT) -> 62(CUSTOMER) -> 34(CUSTOMER) -> 106(STATION) -> 32(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 26 -> 32 -> 
  UAV Trip 2: 62 -> 50 -> 34 -> 
EV Route-7: 0(DEPOT) -> 83(CUSTOMER) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 110(STATION) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 20 -> 49 -> 24 -> 
  UAV Trip 2: 110 -> 48 -> 89 -> 
EV Route-8: 0(DEPOT) -> 45(CUSTOMER) -> 108(STATION) -> 2(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 8 -> 3 -> 68 -> 
  UAV Trip 2: 45 -> 5 -> 108 -> 
EV Route-9: 0(DEPOT) -> 90(CUSTOMER) -> 99(CUSTOMER) -> 86(CUSTOMER) -> 74(CUSTOMER) -> 101(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 99 -> 57 -> 86 -> 
  UAV Trip 2: 101 -> 58 -> 77 -> 25 -> 
EV Route-10: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 10(CUSTOMER) -> 17(CUSTOMER) -> 104(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 98 -> 88 -> 53 -> 
  UAV Trip 2: 10 -> 13 -> 17 -> 
EV Route-11: 0(DEPOT) -> 65(CUSTOMER) -> 59(CUSTOMER) -> 101(STATION) -> 52(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 101 -> 
EV Route-12: 0(DEPOT) -> 81(CUSTOMER) -> 54(CUSTOMER) -> 96(CUSTOMER) -> 91(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 96 -> 56 -> 91 -> 
EV Route-13: 0(DEPOT) -> 14(CUSTOMER) -> 104(STATION) -> 78(CUSTOMER) -> 73(CUSTOMER) -> 60(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 79 -> 60 -> 
  UAV Trip 2: 104 -> 12 -> 78 -> 
EV Route-14: 0(DEPOT) -> 6(CUSTOMER) -> 108(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 4 -> 1 -> 70 -> 
  UAV Trip 2: 6 -> 7 -> 108 -> 
```

