# Large-Scale Instances Report (4 runs each)

- Generated at: 2026-03-15T11:37:25.082
- Status: Finished
- Completed cases: 24/24
- Runs per case: 4
- Parameter set label: StationOpenCostSensitivity-4Runs
- stationOpenCost parameter: 4500

## Large-Scale Parameter Set (Current)

- evCount: 15
- evCapacity: 200.0
- evEnergy: 800.0
- evSpeed: 1.0
- evWeight: 50.0
- evConsumeTravel: 0.1
- uavCapacity: 30.0
- uavEnergy: 30.0
- uavSpeed: 2.0
- uavWeight: 5.0
- uavConsumeTravel: 0.05
- uavConsumeTakeoff: 0.05
- uavConsumeLanding: 0.05
- uavMaxDelay: 200.0
- uavTripMaxCustomers: 5
- evFixedCost: 1500.0
- stationOpenCost: 4500
- alphaOverload: 10000.0
- betaTimeWindow: 1000.0
- gammaEnergy: 1000000.0
- gammaRouteStructure: 1000000.0
- maxIteration: 700
- alnsRestarts: 4
- removeNodeNumber: 3
- saInitTemp: 100.0
- saCooling: 0.995
- saAutoTune: false
- insertionCandidateK: 12
- alnsMaxInsertionCandidateK: 22
- alnsFeasibilityRescueIters: 90
- alnsFeasibilityRescueRounds: 2

## Summary Table

| CASE | BestCost | AvgCost | Gap% | Time(s) |
|---|---:|---:|---:|---:|
| C1-25 | 10432.1 | 10432.1 | 0.00 | 32.1 |
| C2-25 | 12569.1 | 12591.1 | 0.17 | 48.1 |
| R1-25 | 16356.1 | 16356.1 | 0.00 | 32.1 |
| R2-25 | 12471.1 | 12471.1 | 0.00 | 43.1 |
| RC1-25 | 19467.1 | 19469.1 | 0.01 | 70.1 |
| RC2-25 | 19271.1 | 19412.1 | 0.73 | 62.1 |
| C1-50 | 19210.1 | 19220.1 | 0.05 | 217.1 |
| C2-50 | 23421.1 | 23532.1 | 0.47 | 230.1 |
| R1-50 | 27024.1 | 27235.1 | 0.78 | 164.1 |
| R2-50 | 23141.1 | 23526.1 | 1.66 | 174.1 |
| RC1-50 | 38602.1 | 40194.1 | 4.13 | 156.1 |
| RC2-50 | 36573.1 | 36962.1 | 1.07 | 122.1 |
| C1-75 | 35396.1 | 35423.1 | 0.08 | 390.1 |
| C2-75 | 36096.1 | 37658.1 | 4.33 | 470.1 |
| R1-75 | 52065.1 | 54226.1 | 4.15 | 567.1 |
| R2-75 | 34458.1 | 35839.1 | 4.01 | 563.1 |
| RC1-75 | 58943.1 | 60312.1 | 2.32 | 511.1 |
| RC2-75 | 52553.1 | 53469.1 | 1.74 | 564.1 |
| C1-100 | 53552.1 | 54591.1 | 1.94 | 920.1 |
| C2-100 | 52823.1 | 53965.1 | 2.16 | 1038.1 |
| R1-100 | 427059.1 | 490860.1 | 14.94 | 1170.1 |
| R2-100 | 43860.1 | 45904.1 | 4.66 | 1314.1 |
| RC1-100 | 169234.1 | 209885.1 | 24.02 | 875.1 |
| RC2-100 | 61905.1 | 64355.1 | 3.96 | 1080.1 |

## Issues During Run

- 2026-03-11 18:05:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:08:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:51:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 18:53:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-11 19:17:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-12 19:09:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:22:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:23:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:24:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:25:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:26:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:27:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:28:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:29:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:30:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:31:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:32:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:33:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:34:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:35:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:36:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:37:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:38:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:39:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:40:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:41:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:42:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:43:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:44:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:45:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:46:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:47:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:48:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:49:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:50:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:51:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:52:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:53:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:54:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:55:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:56:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:57:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:58:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 02:59:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:00:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:01:43	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:02:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:03:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:04:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:05:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:06:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:07:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:08:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:09:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:10:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:11:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:12:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:13:44	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:14:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:15:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:16:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:17:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:18:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:19:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:20:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:21:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:22:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:23:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:24:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:25:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:26:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:27:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:28:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:29:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:30:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:31:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:32:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:33:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:34:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:35:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:36:46	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:37:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:38:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:39:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:40:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:41:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:42:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:43:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:44:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:45:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:46:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:47:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:48:47	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:49:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:50:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:51:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:52:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:53:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:54:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:55:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:56:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:57:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:58:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 03:59:48	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:00:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:01:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:02:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:03:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:04:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:05:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:06:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:07:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:08:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:09:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:10:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:11:49	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:12:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:13:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:14:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:15:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:16:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:17:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:18:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:19:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:20:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:21:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:22:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:23:50	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:24:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:25:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:26:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:27:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:28:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:29:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:30:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:31:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:32:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:33:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:34:51	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:35:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:36:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:37:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:38:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:39:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:40:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:41:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:42:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:43:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:44:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:45:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:46:52	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:47:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:48:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:49:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:50:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:51:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:52:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:53:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:54:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:55:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:56:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:57:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:58:53	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 04:59:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:00:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:01:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:02:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:03:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:04:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:05:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:06:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:07:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:08:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:09:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:10:54	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:11:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:12:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:13:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:14:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:15:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:16:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:17:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:18:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:19:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:20:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:21:55	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:22:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:23:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:24:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:25:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:26:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:27:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:28:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:29:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:30:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:31:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:32:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:33:56	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:34:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:35:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:36:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:37:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:38:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:39:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:40:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:41:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:42:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:43:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:44:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:45:57	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:46:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:47:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:48:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:49:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:50:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:51:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:52:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:53:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:54:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:55:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:56:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:57:58	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:58:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 05:59:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:00:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:01:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:02:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:03:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:04:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:05:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:06:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:07:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:08:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:09:59	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:11:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:12:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:13:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:14:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:15:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:16:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:17:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:18:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:19:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:20:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:21:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:22:00	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:23:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:24:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:25:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:26:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:27:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:28:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:29:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:30:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:31:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:32:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:33:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:34:01	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:35:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:36:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:37:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:38:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:39:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:40:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:41:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:42:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:43:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:44:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:45:02	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:46:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:47:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:48:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:49:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:50:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:51:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:52:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:53:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:54:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:55:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:56:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:57:03	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:58:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 06:59:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:00:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:01:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:02:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:03:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:04:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:05:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:06:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:07:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:08:04	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:09:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:10:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:11:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:12:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:13:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:14:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:15:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:16:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:17:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:18:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:19:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:20:05	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:21:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:22:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:23:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:24:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:25:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:26:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:27:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:28:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:29:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:30:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:31:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:32:06	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:33:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:34:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:35:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:36:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:37:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:38:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:39:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:40:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:41:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:42:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:43:07	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:44:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:45:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:46:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:47:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:48:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:49:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:50:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:51:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:52:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:53:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:54:08	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:55:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:56:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:57:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:58:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 07:59:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:00:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:01:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:02:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:03:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:04:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:05:09	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:06:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:07:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:08:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:09:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:10:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:11:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:12:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:13:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:14:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:15:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:16:10	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:17:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:18:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:19:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:20:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:21:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:22:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:23:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:24:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:25:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:26:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:27:11	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:28:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:29:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:30:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:31:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:32:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:33:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:34:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:35:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:36:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:37:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:38:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:39:12	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:40:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:41:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:42:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:43:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:44:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:45:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:46:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:47:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:48:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:49:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:50:13	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:51:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:52:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:53:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:54:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:55:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:56:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:57:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:58:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 08:59:14	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:00:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:01:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:02:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:03:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:04:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:05:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:06:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:07:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:08:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:09:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:10:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:11:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:12:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:13:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:14:15	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:15:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:16:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:17:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:18:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:19:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:20:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:21:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:22:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:23:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:24:16	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:25:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:26:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:27:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:28:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:29:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:30:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:31:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:32:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:33:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:34:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:35:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:36:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:37:17	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:38:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:39:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:40:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:41:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:42:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:43:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:44:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:45:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:46:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:47:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:48:18	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:49:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:50:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:51:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:52:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:53:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:54:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:55:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:56:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:57:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:58:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 09:59:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:00:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:01:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:02:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:03:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:04:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:05:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:06:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:07:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:08:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:09:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:10:20	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:11:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:12:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:13:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:14:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:15:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:16:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:17:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:18:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:19:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:20:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:21:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:22:21	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:23:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:24:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:25:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:26:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:27:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:28:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:29:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:30:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:31:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:32:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:33:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:34:22	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:35:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:36:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:37:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:38:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:39:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:40:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:41:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:42:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:43:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:44:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:45:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:46:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:47:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:48:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:49:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:50:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:51:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:52:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:53:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:54:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:55:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:56:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:57:24	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:58:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 10:59:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:00:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:01:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:02:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:03:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:04:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:05:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:06:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:07:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:08:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:09:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:10:25	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:11:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:12:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:13:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:14:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:15:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:16:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:17:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:18:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:19:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:20:26	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:21:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:22:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:23:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:24:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:25:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:26:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:27:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:28:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:29:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:30:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:31:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:32:27	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:33:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:34:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:35:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:36:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:37:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:38:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:39:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:40:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:41:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:42:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:43:28	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:44:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:45:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:46:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:47:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:48:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:49:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:50:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:51:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:52:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:53:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:54:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:55:29	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:56:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:57:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:58:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 11:59:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:00:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:01:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:02:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:03:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:04:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:05:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:06:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:07:30	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:08:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:09:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:10:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:11:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:12:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:13:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:14:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:15:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:16:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:17:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:18:31	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:19:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:20:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:21:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:22:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:23:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:24:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:25:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:26:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:27:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:28:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:29:32	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:30:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:31:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:32:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:33:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:34:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:35:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:36:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:37:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:38:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:39:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:40:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:41:33	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:42:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:43:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:44:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:45:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:46:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:47:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:48:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:49:34	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:50:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:51:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:52:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:53:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:54:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:55:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:56:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:57:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:58:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 12:59:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:00:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:01:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:02:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:03:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:04:35	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:05:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:06:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:07:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:08:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:09:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:10:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:11:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:12:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:13:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:14:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:15:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:16:36	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:17:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:18:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:19:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:20:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:21:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:22:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:23:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:24:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:25:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:26:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:27:37	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:28:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:29:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:30:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:31:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:32:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:33:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:34:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:35:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:36:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:37:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:38:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:39:38	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:40:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:41:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:42:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:43:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:44:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:45:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:46:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:47:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:48:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:49:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:50:39	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:51:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:52:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:53:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:54:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:55:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 13:56:40	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:12:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:13:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:14:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:15:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:16:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:17:41	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:18:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:19:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:20:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:21:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:22:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:23:42	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-14 14:25:45	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-15 11:36:19	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.
- 2026-03-15 11:37:23	cost=-1	case=SYSTEM	seed=-1	attempt=-1	msg=Parameter.maxIteration auto-upgraded from 500 to 700 for station open cost sensitivity experiment.

## Best Routes And Run Logs

### C1-25

- Instance: `./instances_bss_bigscal/c101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 10432.1
- Avg cost: 10432.1
- Avg time(s): 32.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 10432.1 | true | 31.1 |
| 2 | 2 | 10432.1 | true | 33.1 |
| 3 | 3 | 10432.1 | true | 33.1 |
| 4 | 4 | 10432.1 | true | 32.1 |

#### Best Route Plan

```text
totalCost=10432.313973254404, evUavCost=10432.313973254404, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 17(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 15 -> 
EV Route-1: 0(DEPOT) -> 13(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 13 -> 19 -> 16 -> 
EV Route-2: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-3: 0(DEPOT) -> 10(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 14 -> 12 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 23 -> 22 -> 
```

### C2-25

- Instance: `./instances_bss_bigscal/c201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 12569.1
- Avg cost: 12591.1
- Avg time(s): 48.1
- Gap%: 0.17
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12602.1 | true | 52.1 |
| 2 | 2 | 12569.1 | true | 48.1 |
| 3 | 3 | 12590.1 | true | 46.1 |
| 4 | 4 | 12602.1 | true | 45.1 |

#### Best Route Plan

```text
totalCost=12568.613238973576, evUavCost=12568.613238973576, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-1: 0(DEPOT) -> 15(CUSTOMER) -> 9(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 13 -> 9 -> 
EV Route-2: 0(DEPOT) -> 25(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 11 -> 10 -> 8 -> 
EV Route-5: 0(DEPOT) -> 22(CUSTOMER) -> 23(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 19 -> 17 -> 
EV Route-8: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-12: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 6 -> 21 -> 
```

### R1-25

- Instance: `./instances_bss_bigscal/r101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 16356.1
- Avg cost: 16356.1
- Avg time(s): 32.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 16356.1 | true | 34.1 |
| 2 | 2 | 16356.1 | true | 31.1 |
| 3 | 3 | 16356.1 | true | 32.1 |
| 4 | 4 | 16356.1 | true | 32.1 |

#### Best Route Plan

```text
totalCost=16355.841347544178, evUavCost=16355.841347544178, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-1: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 23(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 22 -> 4 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 
EV Route-4: 0(DEPOT) -> 21(CUSTOMER) -> 3(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 24 -> 25 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 18 -> 6 -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 9(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 20 -> 1 -> 
EV Route-9: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 13 -> 
EV Route-14: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-25

- Instance: `./instances_bss_bigscal/r201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 1
- Best cost: 12471.1
- Avg cost: 12471.1
- Avg time(s): 43.1
- Gap%: 0.00
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 12471.1 | true | 39.1 |
| 2 | 2 | 12471.1 | true | 37.1 |
| 3 | 3 | 12471.1 | true | 38.1 |
| 4 | 4 | 12471.1 | true | 59.1 |

#### Best Route Plan

```text
totalCost=12470.980485816235, evUavCost=12470.980485816235, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 5(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 17 -> 13 -> 
EV Route-2: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 7 -> 8 -> 18 -> 
EV Route-3: 0(DEPOT) -> 12(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 3 -> 24 -> 4 -> 
EV Route-4: 0(DEPOT) -> 9(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 10 -> 1 -> 
EV Route-5: 0(DEPOT) -> 21(CUSTOMER) -> 23(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 2(CUSTOMER) -> 15(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 14 -> 6 -> 
```

### RC1-25

- Instance: `./instances_bss_bigscal/rc101_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 19467.1
- Avg cost: 19469.1
- Avg time(s): 70.1
- Gap%: 0.01
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19469.1 | true | 85.1 |
| 2 | 2 | 19469.1 | true | 60.1 |
| 3 | 3 | 19467.1 | true | 66.1 |
| 4 | 4 | 19469.1 | true | 68.1 |

#### Best Route Plan

```text
totalCost=19466.76302787241, evUavCost=19466.76302787241, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 6(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 17 -> 13 -> 
EV Route-5: 0(DEPOT) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 8 -> 4 -> 
EV Route-7: 0(DEPOT) -> 12(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 15 -> 16 -> 
EV Route-10: 0(DEPOT) -> 5(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 1 -> 
EV Route-11: 0(DEPOT) -> 19(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 21 -> 24 -> 
EV Route-13: 0(DEPOT) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 18 -> 20 -> 
```

### RC2-25

- Instance: `./instances_bss_bigscal/rc201_n25_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 19271.1
- Avg cost: 19412.1
- Avg time(s): 62.1
- Gap%: 0.73
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19459.1 | true | 57.1 |
| 2 | 2 | 19459.1 | true | 62.1 |
| 3 | 3 | 19271.1 | true | 65.1 |
| 4 | 4 | 19459.1 | true | 65.1 |

#### Best Route Plan

```text
totalCost=19271.14688069069, evUavCost=14771.146880690689, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 
EV Route-1: 0(DEPOT) -> 19(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 21 -> 24 -> 
EV Route-2: 0(DEPOT) -> 27(STATION) -> 11(CUSTOMER) -> 27(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 10(CUSTOMER) -> 27(STATION) -> 17(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 13 -> 17 -> 
  UAV Trip 2: 16 -> 9 -> 10 -> 
EV Route-3: 0(DEPOT) -> 14(CUSTOMER) -> 27(STATION) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 12 -> 27 -> 
EV Route-4: 0(DEPOT) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 18 -> 20 -> 
EV Route-5: 0(DEPOT) -> 5(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 3 -> 4 -> 
```

### C1-50

- Instance: `./instances_bss_bigscal/c101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 19210.1
- Avg cost: 19220.1
- Avg time(s): 217.1
- Gap%: 0.05
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 19214.1 | true | 291.1 |
| 2 | 2 | 19236.1 | true | 238.1 |
| 3 | 3 | 19210.1 | true | 160.1 |
| 4 | 4 | 19218.1 | true | 178.1 |

#### Best Route Plan

```text
totalCost=19210.493113661123, evUavCost=19210.493113661123, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 10(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 32(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 32 -> 39 -> 36 -> 34 -> 
EV Route-4: 0(DEPOT) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-5: 0(DEPOT) -> 7(CUSTOMER) -> 8(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 8 -> 11 -> 14 -> 12 -> 
EV Route-8: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 2(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 9 -> 6 -> 4 -> 
EV Route-9: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 50 -> 49 -> 47 -> 
EV Route-12: 0(DEPOT) -> 33(CUSTOMER) -> 38(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 37 -> 38 -> 
EV Route-13: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 
EV Route-14: 0(DEPOT) -> 20(CUSTOMER) -> 31(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 31 -> 
```

### C2-50

- Instance: `./instances_bss_bigscal/c201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 23421.1
- Avg cost: 23532.1
- Avg time(s): 230.1
- Gap%: 0.47
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 23570.1 | true | 222.1 |
| 2 | 2 | 23581.1 | true | 251.1 |
| 3 | 3 | 23421.1 | true | 247.1 |
| 4 | 4 | 23557.1 | true | 198.1 |

#### Best Route Plan

```text
totalCost=23421.155104547583, evUavCost=18921.155104547583, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-1: 0(DEPOT) -> 49(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 40 -> 44 -> 46 -> 
EV Route-2: 0(DEPOT) -> 20(CUSTOMER) -> 33(CUSTOMER) -> 51(STATION) -> 23(CUSTOMER) -> 15(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 18 -> 19 -> 15 -> 
  UAV Trip 2: 20 -> 24 -> 29 -> 33 -> 
EV Route-3: 0(DEPOT) -> 22(CUSTOMER) -> 34(CUSTOMER) -> 51(STATION) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 34 -> 
  UAV Trip 2: 26 -> 17 -> 13 -> 
EV Route-5: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 51(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 51 -> 31 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 
EV Route-6: 0(DEPOT) -> 45(CUSTOMER) -> 42(CUSTOMER) -> 41(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 50 -> 47 -> 43 -> 42 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-8: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
```

### R1-50

- Instance: `./instances_bss_bigscal/r101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 27024.1
- Avg cost: 27235.1
- Avg time(s): 164.1
- Gap%: 0.78
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 27392.1 | true | 146.1 |
| 2 | 2 | 27024.1 | true | 175.1 |
| 3 | 3 | 27049.1 | true | 196.1 |
| 4 | 4 | 27475.1 | true | 140.1 |

#### Best Route Plan

```text
totalCost=27023.597729145287, evUavCost=27023.597729145287, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 42(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 43 -> 13 -> 
EV Route-1: 0(DEPOT) -> 12(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 40 -> 50 -> 
EV Route-2: 0(DEPOT) -> 27(CUSTOMER) -> 7(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 10 -> 48 -> 
EV Route-3: 0(DEPOT) -> 39(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 41 -> 
EV Route-4: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 37 -> 
EV Route-5: 0(DEPOT) -> 45(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 8 -> 46 -> 17 -> 
EV Route-6: 0(DEPOT) -> 28(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 29 -> 3 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 6(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 6 -> 
EV Route-9: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-10: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 22 -> 4 -> 
EV Route-11: 0(DEPOT) -> 31(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 20 -> 32 -> 
EV Route-12: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-13: 0(DEPOT) -> 11(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
```

### R2-50

- Instance: `./instances_bss_bigscal/r201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 23141.1
- Avg cost: 23526.1
- Avg time(s): 174.1
- Gap%: 1.66
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 24618.1 | true | 200.1 |
| 2 | 2 | 23173.1 | true | 181.1 |
| 3 | 3 | 23141.1 | true | 153.1 |
| 4 | 4 | 23173.1 | true | 162.1 |

#### Best Route Plan

```text
totalCost=23141.294275078573, evUavCost=23141.294275078573, stationOpenCost=0.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 21(CUSTOMER) -> 2(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 15 -> 43 -> 13 -> 
EV Route-1: 0(DEPOT) -> 40(CUSTOMER) -> 22(CUSTOMER) -> 4(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 41 -> 22 -> 
  UAV Trip 2: 4 -> 25 -> 24 -> 
EV Route-2: 0(DEPOT) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 8 -> 46 -> 48 -> 
EV Route-3: 0(DEPOT) -> 5(CUSTOMER) -> 16(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 45 -> 16 -> 
EV Route-4: 0(DEPOT) -> 33(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
EV Route-5: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 19 -> 7 -> 10 -> 
EV Route-7: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 3 -> 
EV Route-9: 0(DEPOT) -> 42(CUSTOMER) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
EV Route-10: 0(DEPOT) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 20(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 32 -> 1 -> 
  UAV Trip 2: 27 -> 31 -> 30 -> 
EV Route-13: 0(DEPOT) -> 47(CUSTOMER) -> 49(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 49 -> 
EV Route-14: 0(DEPOT) -> 39(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 26 -> 
```

### RC1-50

- Instance: `./instances_bss_bigscal/rc101_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 38602.1
- Avg cost: 40194.1
- Avg time(s): 156.1
- Gap%: 4.13
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 40713.1 | true | 166.1 |
| 2 | 2 | 40725.1 | true | 156.1 |
| 3 | 3 | 40738.1 | true | 144.1 |
| 4 | 4 | 38602.1 | true | 156.1 |

#### Best Route Plan

```text
totalCost=38602.134947289975, evUavCost=34102.134947289975, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 8 -> 46 -> 4 -> 
EV Route-1: 0(DEPOT) -> 50(CUSTOMER) -> 32(CUSTOMER) -> 55(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 50 -> 34 -> 32 -> 
EV Route-2: 0(DEPOT) -> 38(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 38 -> 37 -> 35 -> 
EV Route-3: 0(DEPOT) -> 19(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-4: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-5: 0(DEPOT) -> 23(CUSTOMER) -> 21(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 12(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 16 -> 13 -> 
EV Route-7: 0(DEPOT) -> 22(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 49 -> 20 -> 24 -> 
EV Route-8: 0(DEPOT) -> 6(CUSTOMER) -> 7(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-10: 0(DEPOT) -> 33(CUSTOMER) -> 28(CUSTOMER) -> 55(STATION) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 27 -> 55 -> 
EV Route-11: 0(DEPOT) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 55(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 30 -> 26 -> 55 -> 
EV Route-12: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-13: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 40 -> 43 -> 
EV Route-14: 0(DEPOT) -> 14(CUSTOMER) -> 47(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 15 -> 47 -> 
```

### RC2-50

- Instance: `./instances_bss_bigscal/rc201_n50_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 36573.1
- Avg cost: 36962.1
- Avg time(s): 122.1
- Gap%: 1.07
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 36633.1 | true | 119.1 |
| 2 | 2 | 38055.1 | true | 119.1 |
| 3 | 3 | 36590.1 | true | 126.1 |
| 4 | 4 | 36573.1 | true | 124.1 |

#### Best Route Plan

```text
totalCost=36572.75157621609, evUavCost=32072.751576216087, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 19(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-1: 0(DEPOT) -> 41(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 38 -> 37 -> 
EV Route-2: 0(DEPOT) -> 21(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 21 -> 18 -> 48 -> 24 -> 
EV Route-3: 0(DEPOT) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 9 -> 10 -> 
EV Route-4: 0(DEPOT) -> 42(CUSTOMER) -> 44(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 40 -> 43 -> 
EV Route-5: 0(DEPOT) -> 14(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 47 -> 17 -> 
EV Route-6: 0(DEPOT) -> 23(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-7: 0(DEPOT) -> 2(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-8: 0(DEPOT) -> 53(STATION) -> 34(CUSTOMER) -> 50(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 30 -> 34 -> 
EV Route-9: 0(DEPOT) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-10: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-12: 0(DEPOT) -> 53(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 33 -> 31 -> 
  UAV Trip 2: 29 -> 27 -> 28 -> 26 -> 
EV Route-13: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-14: 0(DEPOT) -> 12(CUSTOMER) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 13 -> 
```

### C1-75

- Instance: `./instances_bss_bigscal/c101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 35396.1
- Avg cost: 35423.1
- Avg time(s): 390.1
- Gap%: 0.08
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 35459.1 | true | 426.1 |
| 2 | 2 | 35396.1 | true | 361.1 |
| 3 | 3 | 35413.1 | true | 393.1 |
| 4 | 4 | 35422.1 | true | 379.1 |

#### Best Route Plan

```text
totalCost=35395.51751365132, evUavCost=30895.51751365132, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 37 -> 36 -> 34 -> 
EV Route-1: 0(DEPOT) -> 43(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 48(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 43 -> 42 -> 44 -> 46 -> 
  UAV Trip 2: 48 -> 51 -> 50 -> 52 -> 49 -> 
EV Route-2: 0(DEPOT) -> 13(CUSTOMER) -> 17(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 
EV Route-3: 0(DEPOT) -> 63(CUSTOMER) -> 71(CUSTOMER) -> 83(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 70 -> 73 -> 
EV Route-4: 0(DEPOT) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-5: 0(DEPOT) -> 57(CUSTOMER) -> 54(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-7: 0(DEPOT) -> 55(CUSTOMER) -> 56(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 53 -> 56 -> 
EV Route-8: 0(DEPOT) -> 41(CUSTOMER) -> 58(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 40 -> 58 -> 
EV Route-9: 0(DEPOT) -> 20(CUSTOMER) -> 38(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 29 -> 38 -> 
EV Route-10: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-11: 0(DEPOT) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-12: 0(DEPOT) -> 32(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 32 -> 31 -> 35 -> 
EV Route-13: 0(DEPOT) -> 10(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 11 -> 14 -> 12 -> 
```

### C2-75

- Instance: `./instances_bss_bigscal/c201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 36096.1
- Avg cost: 37658.1
- Avg time(s): 470.1
- Gap%: 4.33
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 38037.1 | true | 503.1 |
| 2 | 2 | 39704.1 | true | 496.1 |
| 3 | 3 | 36096.1 | true | 438.1 |
| 4 | 4 | 36795.1 | true | 444.1 |

#### Best Route Plan

```text
totalCost=36096.344407150325, evUavCost=27096.344407150325, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 15(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 17 -> 13 -> 
EV Route-1: 0(DEPOT) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-2: 0(DEPOT) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 43 -> 42 -> 41 -> 48 -> 
EV Route-3: 0(DEPOT) -> 67(CUSTOMER) -> 78(STATION) -> 64(CUSTOMER) -> 54(CUSTOMER) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 62 -> 78 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
  UAV Trip 3: 64 -> 49 -> 54 -> 
EV Route-4: 0(DEPOT) -> 66(CUSTOMER) -> 78(STATION) -> 65(CUSTOMER) -> 55(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 55 -> 53 -> 56 -> 
  UAV Trip 2: 66 -> 69 -> 78 -> 
  UAV Trip 3: 58 -> 60 -> 59 -> 
EV Route-5: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 78(STATION) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 74 -> 72 -> 61 -> 68 -> 78 -> 
EV Route-6: 0(DEPOT) -> 25(CUSTOMER) -> 10(CUSTOMER) -> 8(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 9 -> 11 -> 10 -> 
EV Route-7: 0(DEPOT) -> 5(CUSTOMER) -> 75(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 1 -> 7 -> 
EV Route-10: 0(DEPOT) -> 20(CUSTOMER) -> 33(CUSTOMER) -> 76(STATION) -> 34(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 24 -> 29 -> 33 -> 
  UAV Trip 2: 34 -> 28 -> 26 -> 
  UAV Trip 3: 23 -> 18 -> 19 -> 
EV Route-11: 0(DEPOT) -> 6(CUSTOMER) -> 32(CUSTOMER) -> 76(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 78(STATION) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 31 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 78 -> 
EV Route-12: 0(DEPOT) -> 22(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 21 -> 
```

### R1-75

- Instance: `./instances_bss_bigscal/r101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 52065.1
- Avg cost: 54226.1
- Avg time(s): 567.1
- Gap%: 4.15
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 56482.1 | true | 491.1 |
| 2 | 2 | 56128.1 | true | 479.1 |
| 3 | 3 | 52065.1 | true | 568.1 |
| 4 | 4 | 52230.1 | true | 730.1 |

#### Best Route Plan

```text
totalCost=52065.32981308796, evUavCost=34065.32981308796, stationOpenCost=18000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 33(CUSTOMER) -> 29(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 3 -> 50 -> 1 -> 
EV Route-1: 0(DEPOT) -> 65(CUSTOMER) -> 85(STATION) -> 9(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 71 -> 85 -> 
  UAV Trip 2: 9 -> 34 -> 24 -> 
EV Route-2: 0(DEPOT) -> 27(CUSTOMER) -> 69(CUSTOMER) -> 51(CUSTOMER) -> 20(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 20 -> 32 -> 70 -> 
  UAV Trip 2: 69 -> 30 -> 51 -> 
EV Route-3: 0(DEPOT) -> 2(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 41 -> 54 -> 
EV Route-4: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 74(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 22 -> 56 -> 74 -> 
EV Route-5: 0(DEPOT) -> 45(CUSTOMER) -> 18(CUSTOMER) -> 46(CUSTOMER) -> 79(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 52 -> 18 -> 
  UAV Trip 2: 46 -> 17 -> 79 -> 
EV Route-6: 0(DEPOT) -> 28(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 12 -> 40 -> 
EV Route-7: 0(DEPOT) -> 31(CUSTOMER) -> 19(CUSTOMER) -> 82(STATION) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 49 -> 82 -> 
EV Route-8: 0(DEPOT) -> 62(CUSTOMER) -> 11(CUSTOMER) -> 66(CUSTOMER) -> 85(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 66 -> 35 -> 85 -> 
EV Route-9: 0(DEPOT) -> 5(CUSTOMER) -> 61(CUSTOMER) -> 6(CUSTOMER) -> 26(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 16 -> 61 -> 
EV Route-10: 0(DEPOT) -> 77(STATION) -> 39(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 23 -> 67 -> 
  UAV Trip 2: 55 -> 4 -> 25 -> 
EV Route-11: 0(DEPOT) -> 59(CUSTOMER) -> 42(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 57 -> 43 -> 
EV Route-12: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 79(STATION) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 7 -> 8 -> 79 -> 
EV Route-13: 0(DEPOT) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 37 -> 
EV Route-14: 0(DEPOT) -> 63(CUSTOMER) -> 82(STATION) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 63 -> 64 -> 82 -> 
```

### R2-75

- Instance: `./instances_bss_bigscal/r201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 34458.1
- Avg cost: 35839.1
- Avg time(s): 563.1
- Gap%: 4.01
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 35768.1 | true | 666.1 |
| 2 | 2 | 34458.1 | true | 564.1 |
| 3 | 3 | 36881.1 | true | 495.1 |
| 4 | 4 | 36248.1 | true | 527.1 |

#### Best Route Plan

```text
totalCost=34457.684942540094, evUavCost=29957.684942540094, stationOpenCost=4500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 2(CUSTOMER) -> 57(CUSTOMER) -> 43(CUSTOMER) -> 37(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 42 -> 15 -> 57 -> 
EV Route-1: 0(DEPOT) -> 52(CUSTOMER) -> 18(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 18 -> 7 -> 8 -> 48 -> 
EV Route-2: 0(DEPOT) -> 39(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 67 -> 21 -> 
EV Route-3: 0(DEPOT) -> 40(CUSTOMER) -> 73(CUSTOMER) -> 74(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 22 -> 41 -> 74 -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 61(CUSTOMER) -> 16(CUSTOMER) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 5 -> 45 -> 61 -> 
EV Route-5: 0(DEPOT) -> 53(CUSTOMER) -> 68(CUSTOMER) -> 54(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 55 -> 25 -> 24 -> 
  UAV Trip 2: 53 -> 26 -> 68 -> 
EV Route-6: 0(DEPOT) -> 28(CUSTOMER) -> 12(CUSTOMER) -> 3(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 29 -> 3 -> 
EV Route-7: 0(DEPOT) -> 59(CUSTOMER) -> 14(CUSTOMER) -> 44(CUSTOMER) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 14 -> 38 -> 44 -> 
EV Route-9: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 56(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 23 -> 56 -> 
EV Route-10: 0(DEPOT) -> 27(CUSTOMER) -> 79(STATION) -> 30(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 9 -> 34 -> 35 -> 
  UAV Trip 2: 27 -> 69 -> 79 -> 
EV Route-12: 0(DEPOT) -> 79(STATION) -> 63(CUSTOMER) -> 64(CUSTOMER) -> 11(CUSTOMER) -> 79(STATION) -> 71(CUSTOMER) -> 66(CUSTOMER) -> 32(CUSTOMER) -> 79(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 66 -> 20 -> 32 -> 
EV Route-13: 0(DEPOT) -> 31(CUSTOMER) -> 79(STATION) -> 62(CUSTOMER) -> 47(CUSTOMER) -> 49(CUSTOMER) -> 10(CUSTOMER) -> 79(STATION) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 19 -> 49 -> 
EV Route-14: 0(DEPOT) -> 33(CUSTOMER) -> 65(CUSTOMER) -> 79(STATION) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 36 -> 46 -> 60 -> 
```

### RC1-75

- Instance: `./instances_bss_bigscal/rc101_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 58943.1
- Avg cost: 60312.1
- Avg time(s): 511.1
- Gap%: 2.32
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 59422.1 | true | 450.1 |
| 2 | 2 | 62954.1 | true | 456.1 |
| 3 | 3 | 58943.1 | true | 548.1 |
| 4 | 4 | 59930.1 | true | 589.1 |

#### Best Route Plan

```text
totalCost=58943.39261633964, evUavCost=36443.39261633964, stationOpenCost=22500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 71(CUSTOMER) -> 37(CUSTOMER) -> 35(CUSTOMER) -> 78(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 71 -> 61 -> 37 -> 
EV Route-1: 0(DEPOT) -> 80(STATION) -> 47(CUSTOMER) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 9 -> 13 -> 
  UAV Trip 2: 80 -> 14 -> 47 -> 
EV Route-2: 0(DEPOT) -> 63(CUSTOMER) -> 33(CUSTOMER) -> 30(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 28 -> 30 -> 
EV Route-3: 0(DEPOT) -> 72(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 42 -> 44 -> 78 -> 
  UAV Trip 2: 40 -> 43 -> 54 -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 45(CUSTOMER) -> 82(STATION) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 68(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 82 -> 8 -> 7 -> 
  UAV Trip 2: 6 -> 55 -> 68 -> 
EV Route-5: 0(DEPOT) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 78(STATION) -> 41(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 38 -> 78 -> 
EV Route-6: 0(DEPOT) -> 64(CUSTOMER) -> 56(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 51 -> 56 -> 
EV Route-7: 0(DEPOT) -> 2(CUSTOMER) -> 82(STATION) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 3 -> 1 -> 4 -> 
EV Route-8: 0(DEPOT) -> 62(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 77(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 62 -> 67 -> 50 -> 
EV Route-9: 0(DEPOT) -> 69(CUSTOMER) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 73 -> 53 -> 
EV Route-10: 0(DEPOT) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 80(STATION) -> 17(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 80 -> 10 -> 17 -> 
EV Route-11: 0(DEPOT) -> 83(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 48 -> 25 -> 
  UAV Trip 2: 83 -> 23 -> 21 -> 
EV Route-12: 0(DEPOT) -> 59(CUSTOMER) -> 74(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 74 -> 
EV Route-13: 0(DEPOT) -> 77(STATION) -> 27(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 77 -> 31 -> 29 -> 27 -> 
EV Route-14: 0(DEPOT) -> 65(CUSTOMER) -> 57(CUSTOMER) -> 22(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 83(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 65 -> 52 -> 57 -> 
  UAV Trip 2: 20 -> 24 -> 83 -> 
```

### RC2-75

- Instance: `./instances_bss_bigscal/rc201_n75_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 52553.1
- Avg cost: 53469.1
- Avg time(s): 564.1
- Gap%: 1.74
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 54729.1 | true | 601.1 |
| 2 | 2 | 52745.1 | true | 520.1 |
| 3 | 3 | 53848.1 | true | 491.1 |
| 4 | 4 | 52553.1 | true | 643.1 |

#### Best Route Plan

```text
totalCost=52553.286662007056, evUavCost=34553.286662007056, stationOpenCost=18000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 64(CUSTOMER) -> 22(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 64 -> 51 -> 22 -> 
EV Route-1: 0(DEPOT) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 81(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 34 -> 26 -> 81 -> 
EV Route-2: 0(DEPOT) -> 65(CUSTOMER) -> 80(STATION) -> 52(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 79(STATION) -> 17(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 52 -> 57 -> 9 -> 
  UAV Trip 2: 10 -> 13 -> 79 -> 
EV Route-3: 0(DEPOT) -> 45(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 5 -> 3 -> 1 -> 
EV Route-4: 0(DEPOT) -> 2(CUSTOMER) -> 6(CUSTOMER) -> 46(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 6 -> 7 -> 8 -> 46 -> 
EV Route-5: 0(DEPOT) -> 61(CUSTOMER) -> 41(CUSTOMER) -> 78(STATION) -> 40(CUSTOMER) -> 54(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 41 -> 38 -> 78 -> 
  UAV Trip 2: 40 -> 35 -> 37 -> 54 -> 
EV Route-6: 0(DEPOT) -> 62(CUSTOMER) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 81(STATION) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 29 -> 27 -> 28 -> 81 -> 
EV Route-7: 0(DEPOT) -> 63(CUSTOMER) -> 30(CUSTOMER) -> 81(STATION) -> 71(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 67 -> 71 -> 
  UAV Trip 2: 63 -> 33 -> 30 -> 
EV Route-8: 0(DEPOT) -> 56(CUSTOMER) -> 80(STATION) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 24 -> 48 -> 25 -> 
  UAV Trip 2: 56 -> 66 -> 80 -> 
EV Route-9: 0(DEPOT) -> 72(CUSTOMER) -> 78(STATION) -> 39(CUSTOMER) -> 36(CUSTOMER) -> 43(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 36 -> 42 -> 44 -> 43 -> 
EV Route-11: 0(DEPOT) -> 69(CUSTOMER) -> 12(CUSTOMER) -> 11(CUSTOMER) -> 79(STATION) -> 15(CUSTOMER) -> 53(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 73 -> 53 -> 
EV Route-12: 0(DEPOT) -> 80(STATION) -> 19(CUSTOMER) -> 23(CUSTOMER) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 80(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 23 -> 21 -> 18 -> 49 -> 
EV Route-13: 0(DEPOT) -> 68(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 68 -> 55 -> 4 -> 
EV Route-14: 0(DEPOT) -> 14(CUSTOMER) -> 79(STATION) -> 59(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 75 -> 74 -> 
  UAV Trip 2: 14 -> 47 -> 79 -> 
```

### C1-100

- Instance: `./instances_bss_bigscal/c101_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 53552.1
- Avg cost: 54591.1
- Avg time(s): 920.1
- Gap%: 1.94
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 53613.1 | true | 1047.1 |
| 2 | 2 | 57539.1 | true | 864.1 |
| 3 | 3 | 53660.1 | true | 894.1 |
| 4 | 4 | 53552.1 | true | 873.1 |

#### Best Route Plan

```text
totalCost=53552.23831448119, evUavCost=35552.23831448119, stationOpenCost=18000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 25(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 25 -> 27 -> 29 -> 30 -> 28 -> 
  UAV Trip 2: 26 -> 23 -> 22 -> 21 -> 
EV Route-1: 0(DEPOT) -> 102(STATION) -> 95(CUSTOMER) -> 94(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 96 -> 95 -> 
  UAV Trip 2: 94 -> 92 -> 93 -> 
EV Route-2: 0(DEPOT) -> 90(CUSTOMER) -> 102(STATION) -> 83(CUSTOMER) -> 84(CUSTOMER) -> 85(CUSTOMER) -> 88(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 90 -> 87 -> 86 -> 102 -> 
  UAV Trip 2: 83 -> 82 -> 84 -> 
  UAV Trip 3: 88 -> 89 -> 91 -> 
EV Route-3: 0(DEPOT) -> 112(STATION) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 59(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 
EV Route-4: 0(DEPOT) -> 5(CUSTOMER) -> 3(CUSTOMER) -> 7(CUSTOMER) -> 6(CUSTOMER) -> 4(CUSTOMER) -> 1(CUSTOMER) -> 75(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 7 -> 8 -> 9 -> 6 -> 
  UAV Trip 2: 4 -> 2 -> 1 -> 
EV Route-5: 0(DEPOT) -> 67(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 66(CUSTOMER) -> 69(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 68 -> 66 -> 
  UAV Trip 2: 67 -> 65 -> 62 -> 74 -> 
EV Route-6: 0(DEPOT) -> 10(CUSTOMER) -> 17(CUSTOMER) -> 11(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 17 -> 18 -> 19 -> 11 -> 
EV Route-7: 0(DEPOT) -> 31(CUSTOMER) -> 39(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 31 -> 38 -> 39 -> 
EV Route-8: 0(DEPOT) -> 32(CUSTOMER) -> 33(CUSTOMER) -> 34(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 36 -> 34 -> 
EV Route-9: 0(DEPOT) -> 43(CUSTOMER) -> 42(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 49(CUSTOMER) -> 47(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 41 -> 40 -> 44 -> 46 -> 
  UAV Trip 2: 45 -> 48 -> 51 -> 50 -> 49 -> 
EV Route-10: 0(DEPOT) -> 63(CUSTOMER) -> 105(STATION) -> 70(CUSTOMER) -> 73(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 105 -> 71 -> 70 -> 
EV Route-11: 0(DEPOT) -> 81(CUSTOMER) -> 105(STATION) -> 77(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 78 -> 76 -> 105 -> 
  UAV Trip 2: 77 -> 79 -> 80 -> 
EV Route-12: 0(DEPOT) -> 13(CUSTOMER) -> 103(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 12(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 
EV Route-13: 0(DEPOT) -> 98(CUSTOMER) -> 100(CUSTOMER) -> 99(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 98 -> 97 -> 100 -> 
EV Route-14: 0(DEPOT) -> 57(CUSTOMER) -> 112(STATION) -> 35(CUSTOMER) -> 52(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 35 -> 37 -> 52 -> 
  UAV Trip 2: 57 -> 55 -> 112 -> 
```

### C2-100

- Instance: `./instances_bss_bigscal/c201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 4
- Best cost: 52823.1
- Avg cost: 53965.1
- Avg time(s): 1038.1
- Gap%: 2.16
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 54421.1 | true | 1018.1 |
| 2 | 2 | 54590.1 | true | 1102.1 |
| 3 | 3 | 54026.1 | true | 1052.1 |
| 4 | 4 | 52823.1 | true | 979.1 |

#### Best Route Plan

```text
totalCost=52823.25815427263, evUavCost=34823.25815427263, stationOpenCost=18000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 22(CUSTOMER) -> 25(CUSTOMER) -> 9(CUSTOMER) -> 10(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 22 -> 27 -> 30 -> 25 -> 
  UAV Trip 2: 9 -> 11 -> 10 -> 
EV Route-1: 0(DEPOT) -> 8(CUSTOMER) -> 21(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-2: 0(DEPOT) -> 104(STATION) -> 55(CUSTOMER) -> 54(CUSTOMER) -> 56(CUSTOMER) -> 58(CUSTOMER) -> 42(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 54 -> 53 -> 56 -> 
  UAV Trip 2: 58 -> 60 -> 59 -> 42 -> 
EV Route-3: 0(DEPOT) -> 6(CUSTOMER) -> 33(CUSTOMER) -> 107(STATION) -> 34(CUSTOMER) -> 26(CUSTOMER) -> 23(CUSTOMER) -> 19(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 34 -> 28 -> 26 -> 
  UAV Trip 2: 23 -> 18 -> 19 -> 
  UAV Trip 3: 6 -> 32 -> 33 -> 
EV Route-4: 0(DEPOT) -> 20(CUSTOMER) -> 29(CUSTOMER) -> 107(STATION) -> 37(CUSTOMER) -> 38(CUSTOMER) -> 36(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 107 -> 31 -> 35 -> 37 -> 
  UAV Trip 2: 38 -> 39 -> 36 -> 
  UAV Trip 3: 20 -> 24 -> 29 -> 
EV Route-5: 0(DEPOT) -> 109(STATION) -> 16(CUSTOMER) -> 15(CUSTOMER) -> 17(CUSTOMER) -> 13(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 16 -> 14 -> 12 -> 15 -> 
EV Route-6: 0(DEPOT) -> 67(CUSTOMER) -> 66(CUSTOMER) -> 96(CUSTOMER) -> 87(CUSTOMER) -> 105(STATION) -> 90(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 66 -> 69 -> 49 -> 96 -> 
EV Route-7: 0(DEPOT) -> 68(CUSTOMER) -> 104(STATION) -> 57(CUSTOMER) -> 46(CUSTOMER) -> 45(CUSTOMER) -> 47(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 51 -> 50 -> 52 -> 47 -> 
  UAV Trip 2: 57 -> 40 -> 44 -> 46 -> 
  UAV Trip 3: 68 -> 65 -> 104 -> 
EV Route-9: 0(DEPOT) -> 92(CUSTOMER) -> 94(CUSTOMER) -> 105(STATION) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 94 -> 95 -> 105 -> 
EV Route-10: 0(DEPOT) -> 91(CUSTOMER) -> 105(STATION) -> 86(CUSTOMER) -> 71(CUSTOMER) -> 70(CUSTOMER) -> 79(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 91 -> 88 -> 105 -> 
  UAV Trip 2: 86 -> 76 -> 71 -> 
  UAV Trip 3: 70 -> 73 -> 79 -> 
EV Route-11: 0(DEPOT) -> 63(CUSTOMER) -> 74(CUSTOMER) -> 72(CUSTOMER) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 61 -> 64 -> 41 -> 48 -> 
  UAV Trip 2: 63 -> 62 -> 74 -> 
EV Route-12: 0(DEPOT) -> 5(CUSTOMER) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 3(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 2 -> 98 -> 7 -> 
  UAV Trip 2: 3 -> 4 -> 89 -> 
EV Route-13: 0(DEPOT) -> 93(CUSTOMER) -> 75(CUSTOMER) -> 1(CUSTOMER) -> 97(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 1 -> 99 -> 100 -> 97 -> 
EV Route-14: 0(DEPOT) -> 105(STATION) -> 84(CUSTOMER) -> 82(CUSTOMER) -> 85(CUSTOMER) -> 78(CUSTOMER) -> 77(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 81 -> 78 -> 
  UAV Trip 2: 84 -> 83 -> 82 -> 
```

### R1-100

- Instance: `./instances_bss_bigscal/r101_n100_bss.txt`
- Feasible runs: 0/4
- Best run seed: 3
- Best cost: 427059.1
- Avg cost: 490860.1
- Avg time(s): 1170.1
- Gap%: 14.94
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 546590.1 | false | 1151.1 |
| 2 | 2 | 496212.1 | false | 1211.1 |
| 3 | 3 | 427059.1 | false | 1150.1 |
| 4 | 4 | 493579.1 | false | 1166.1 |

#### Best Route Plan

```text
totalCost=427059.3301602892, evUavCost=36310.04632164349, stationOpenCost=40500.0, violationCost=350249.2838386457, overloadAmount=0.0, timeViolationAmount=350.2492838386457
EV Route-0: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 44(CUSTOMER) -> 86(CUSTOMER) -> 37(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 44 -> 38 -> 86 -> 
  UAV Trip 2: 37 -> 91 -> 100 -> 
EV Route-1: 0(DEPOT) -> 45(CUSTOMER) -> 82(CUSTOMER) -> 7(CUSTOMER) -> 106(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 45 -> 83 -> 82 -> 
  UAV Trip 2: 7 -> 8 -> 46 -> 106 -> 
EV Route-2: 0(DEPOT) -> 28(CUSTOMER) -> 81(CUSTOMER) -> 111(STATION) -> 68(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 28 -> 29 -> 78 -> 81 -> 
EV Route-3: 0(DEPOT) -> 92(CUSTOMER) -> 42(CUSTOMER) -> 22(CUSTOMER) -> 56(CUSTOMER) -> 112(STATION) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 15 -> 41 -> 22 -> 
  UAV Trip 2: 56 -> 74 -> 112 -> 
EV Route-4: 0(DEPOT) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 98(CUSTOMER) -> 61(CUSTOMER) -> 84(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 98 -> 16 -> 61 -> 
  UAV Trip 2: 84 -> 17 -> 109 -> 
EV Route-5: 0(DEPOT) -> 36(CUSTOMER) -> 47(CUSTOMER) -> 106(STATION) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 64(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 102(STATION) -> 76(CUSTOMER) -> 79(CUSTOMER) -> 3(CUSTOMER) -> 24(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 3 -> 54 -> 24 -> 
  UAV Trip 2: 102 -> 12 -> 76 -> 
EV Route-7: 0(DEPOT) -> 2(CUSTOMER) -> 40(CUSTOMER) -> 53(CUSTOMER) -> 50(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 53 -> 26 -> 50 -> 
EV Route-8: 0(DEPOT) -> 31(CUSTOMER) -> 62(CUSTOMER) -> 11(CUSTOMER) -> 63(CUSTOMER) -> 90(CUSTOMER) -> 10(CUSTOMER) -> 103(STATION) -> 48(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 112(STATION) -> 39(CUSTOMER) -> 23(CUSTOMER) -> 67(CUSTOMER) -> 55(CUSTOMER) -> 4(CUSTOMER) -> 25(CUSTOMER) -> 105(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 33(CUSTOMER) -> 108(STATION) -> 71(CUSTOMER) -> 65(CUSTOMER) -> 66(CUSTOMER) -> 20(CUSTOMER) -> 32(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-11: 0(DEPOT) -> 95(CUSTOMER) -> 109(STATION) -> 99(CUSTOMER) -> 85(CUSTOMER) -> 94(CUSTOMER) -> 97(CUSTOMER) -> 87(CUSTOMER) -> 13(CUSTOMER) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-12: 0(DEPOT) -> 27(CUSTOMER) -> 18(CUSTOMER) -> 6(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 27 -> 52 -> 88 -> 18 -> 
  UAV Trip 2: 6 -> 96 -> 60 -> 89 -> 
EV Route-13: 0(DEPOT) -> 72(CUSTOMER) -> 73(CUSTOMER) -> 57(CUSTOMER) -> 109(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 21 -> 75 -> 73 -> 
  UAV Trip 2: 57 -> 43 -> 109 -> 
EV Route-14: 0(DEPOT) -> 69(CUSTOMER) -> 51(CUSTOMER) -> 9(CUSTOMER) -> 34(CUSTOMER) -> 111(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 69 -> 30 -> 51 -> 
  UAV Trip 2: 34 -> 35 -> 111 -> 
```

### R2-100

- Instance: `./instances_bss_bigscal/r201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 3
- Best cost: 43860.1
- Avg cost: 45904.1
- Avg time(s): 1314.1
- Gap%: 4.66
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 47946.1 | true | 1347.1 |
| 2 | 2 | 44220.1 | true | 1375.1 |
| 3 | 3 | 43860.1 | true | 1329.1 |
| 4 | 4 | 47593.1 | true | 1204.1 |

#### Best Route Plan

```text
totalCost=43859.832954101745, evUavCost=34859.832954101745, stationOpenCost=9000.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 63(CUSTOMER) -> 102(STATION) -> 65(CUSTOMER) -> 33(CUSTOMER) -> 78(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 33 -> 29 -> 78 -> 
EV Route-1: 0(DEPOT) -> 94(CUSTOMER) -> 96(CUSTOMER) -> 93(CUSTOMER) -> 111(STATION) -> 48(CUSTOMER) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 96 -> 37 -> 100 -> 91 -> 93 -> 
EV Route-2: 0(DEPOT) -> 72(CUSTOMER) -> 75(CUSTOMER) -> 56(CUSTOMER) -> 4(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 75 -> 23 -> 56 -> 
EV Route-3: 0(DEPOT) -> 82(CUSTOMER) -> 47(CUSTOMER) -> 18(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 47 -> 36 -> 8 -> 18 -> 
EV Route-4: 0(DEPOT) -> 53(CUSTOMER) -> 40(CUSTOMER) -> 26(CUSTOMER) -> 68(CUSTOMER) -> 80(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 26 -> 54 -> 68 -> 
EV Route-5: 0(DEPOT) -> 99(CUSTOMER) -> 85(CUSTOMER) -> 97(CUSTOMER) -> 13(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 85 -> 87 -> 97 -> 
EV Route-6: 0(DEPOT) -> 52(CUSTOMER) -> 19(CUSTOMER) -> 49(CUSTOMER) -> 111(STATION) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 49 -> 46 -> 17 -> 111 -> 
  UAV Trip 2: 52 -> 7 -> 19 -> 
EV Route-7: 0(DEPOT) -> 27(CUSTOMER) -> 30(CUSTOMER) -> 102(STATION) -> 9(CUSTOMER) -> 51(CUSTOMER) -> 81(CUSTOMER) -> 50(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 71 -> 9 -> 
  UAV Trip 2: 81 -> 3 -> 50 -> 
  UAV Trip 3: 27 -> 69 -> 30 -> 
EV Route-8: 0(DEPOT) -> 83(CUSTOMER) -> 111(STATION) -> 61(CUSTOMER) -> 16(CUSTOMER) -> 44(CUSTOMER) -> 86(CUSTOMER) -> 84(CUSTOMER) -> 111(STATION) -> 6(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 45 -> 111 -> 
  UAV Trip 2: 44 -> 38 -> 86 -> 
EV Route-9: 0(DEPOT) -> 95(CUSTOMER) -> 59(CUSTOMER) -> 5(CUSTOMER) -> 111(STATION) -> 11(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 11 -> 64 -> 90 -> 70 -> 
  UAV Trip 2: 59 -> 92 -> 98 -> 5 -> 
EV Route-10: 0(DEPOT) -> 31(CUSTOMER) -> 10(CUSTOMER) -> 102(STATION) -> 32(CUSTOMER) -> 66(CUSTOMER) -> 1(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 102 -> 20 -> 32 -> 
  UAV Trip 2: 31 -> 88 -> 62 -> 10 -> 
  UAV Trip 3: 66 -> 35 -> 1 -> 
EV Route-11: 0(DEPOT) -> 39(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 39 -> 67 -> 74 -> 
EV Route-12: 0(DEPOT) -> 2(CUSTOMER) -> 42(CUSTOMER) -> 15(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 42 -> 14 -> 15 -> 
EV Route-13: 0(DEPOT) -> 12(CUSTOMER) -> 21(CUSTOMER) -> 73(CUSTOMER) -> 57(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 73 -> 22 -> 41 -> 57 -> 
EV Route-14: 0(DEPOT) -> 28(CUSTOMER) -> 76(CUSTOMER) -> 79(CUSTOMER) -> 55(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 79 -> 34 -> 24 -> 55 -> 
```

### RC1-100

- Instance: `./instances_bss_bigscal/rc101_n100_bss.txt`
- Feasible runs: 0/4
- Best run seed: 4
- Best cost: 169234.1
- Avg cost: 209885.1
- Avg time(s): 875.1
- Gap%: 24.02
- Best feasible: false
- Best violations: overload=false, tw=true, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 248763.1 | false | 831.1 |
| 2 | 2 | 201748.1 | false | 962.1 |
| 3 | 3 | 219797.1 | false | 838.1 |
| 4 | 4 | 169234.1 | false | 869.1 |

#### Best Route Plan

```text
totalCost=169233.55835942493, evUavCost=41095.06864153484, stationOpenCost=45000.0, violationCost=83138.48971789009, overloadAmount=0.0, timeViolationAmount=83.13848971789008
EV Route-0: 0(DEPOT) -> 104(STATION) -> 72(CUSTOMER) -> 71(CUSTOMER) -> 67(CUSTOMER) -> 96(CUSTOMER) -> 54(CUSTOMER) -> 104(STATION) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 67 -> 94 -> 96 -> 
EV Route-1: 0(DEPOT) -> 14(CUSTOMER) -> 101(STATION) -> 12(CUSTOMER) -> 53(CUSTOMER) -> 60(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 12 -> 78 -> 53 -> 
  UAV Trip 2: 14 -> 47 -> 101 -> 
EV Route-2: 0(DEPOT) -> 107(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 27(CUSTOMER) -> 28(CUSTOMER) -> 26(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-3: 0(DEPOT) -> 92(CUSTOMER) -> 95(CUSTOMER) -> 84(CUSTOMER) -> 85(CUSTOMER) -> 109(STATION) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 64 -> 84 -> 
EV Route-4: 0(DEPOT) -> 110(STATION) -> 69(CUSTOMER) -> 98(CUSTOMER) -> 66(CUSTOMER) -> 56(CUSTOMER) -> 102(STATION) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 82 -> 69 -> 
  UAV Trip 2: 98 -> 88 -> 90 -> 66 -> 
EV Route-5: 0(DEPOT) -> 106(STATION) -> 36(CUSTOMER) -> 38(CUSTOMER) -> 61(CUSTOMER) -> 81(CUSTOMER) -> 68(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-6: 0(DEPOT) -> 63(CUSTOMER) -> 109(STATION) -> 76(CUSTOMER) -> 22(CUSTOMER) -> 20(CUSTOMER) -> 24(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 76 -> 51 -> 22 -> 
EV Route-7: 0(DEPOT) -> 65(CUSTOMER) -> 83(CUSTOMER) -> 57(CUSTOMER) -> 86(CUSTOMER) -> 103(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 83 -> 52 -> 99 -> 57 -> 
  UAV Trip 2: 86 -> 74 -> 103 -> 
EV Route-8: 0(DEPOT) -> 101(STATION) -> 15(CUSTOMER) -> 16(CUSTOMER) -> 11(CUSTOMER) -> 9(CUSTOMER) -> 97(CUSTOMER) -> 17(CUSTOMER) -> 101(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-9: 0(DEPOT) -> 108(STATION) -> 2(CUSTOMER) -> 7(CUSTOMER) -> 79(CUSTOMER) -> 73(CUSTOMER) -> 10(CUSTOMER) -> 13(CUSTOMER) -> 101(STATION) -> 1000000(VIRTUAL_DEPOT) -> 
EV Route-10: 0(DEPOT) -> 102(STATION) -> 62(CUSTOMER) -> 30(CUSTOMER) -> 107(STATION) -> 50(CUSTOMER) -> 91(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 62 -> 33 -> 30 -> 
  UAV Trip 2: 107 -> 34 -> 50 -> 
EV Route-11: 0(DEPOT) -> 103(STATION) -> 59(CUSTOMER) -> 75(CUSTOMER) -> 58(CUSTOMER) -> 77(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 87 -> 75 -> 
EV Route-12: 0(DEPOT) -> 108(STATION) -> 5(CUSTOMER) -> 8(CUSTOMER) -> 3(CUSTOMER) -> 1(CUSTOMER) -> 4(CUSTOMER) -> 100(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 108 -> 45 -> 5 -> 
  UAV Trip 2: 8 -> 6 -> 46 -> 3 -> 
EV Route-13: 0(DEPOT) -> 42(CUSTOMER) -> 39(CUSTOMER) -> 106(STATION) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 35(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 44 -> 41 -> 40 -> 
  UAV Trip 2: 43 -> 37 -> 35 -> 
EV Route-14: 0(DEPOT) -> 105(STATION) -> 21(CUSTOMER) -> 19(CUSTOMER) -> 48(CUSTOMER) -> 25(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 19 -> 18 -> 49 -> 48 -> 
  UAV Trip 2: 105 -> 23 -> 21 -> 
```

### RC2-100

- Instance: `./instances_bss_bigscal/rc201_n100_bss.txt`
- Feasible runs: 4/4
- Best run seed: 2
- Best cost: 61905.1
- Avg cost: 64355.1
- Avg time(s): 1080.1
- Gap%: 3.96
- Best feasible: true
- Best violations: overload=false, tw=false, energy=false, structure=false

#### Run Log

| Run | Seed | Cost | Feasible | Time(s) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 66216.1 | true | 1058.1 |
| 2 | 2 | 61905.1 | true | 1074.1 |
| 3 | 3 | 66807.1 | true | 1140.1 |
| 4 | 4 | 62491.1 | true | 1048.1 |

#### Best Route Plan

```text
totalCost=61904.81921487262, evUavCost=39404.81921487262, stationOpenCost=22500.0, violationCost=0.0, overloadAmount=0.0, timeViolationAmount=0.0
EV Route-0: 0(DEPOT) -> 61(CUSTOMER) -> 44(CUSTOMER) -> 102(STATION) -> 38(CUSTOMER) -> 40(CUSTOMER) -> 43(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 40 -> 35 -> 37 -> 43 -> 
  UAV Trip 2: 102 -> 41 -> 38 -> 
EV Route-1: 0(DEPOT) -> 65(CUSTOMER) -> 83(CUSTOMER) -> 110(STATION) -> 23(CUSTOMER) -> 75(CUSTOMER) -> 74(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 21 -> 23 -> 
EV Route-2: 0(DEPOT) -> 90(CUSTOMER) -> 99(CUSTOMER) -> 57(CUSTOMER) -> 24(CUSTOMER) -> 110(STATION) -> 89(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 99 -> 86 -> 57 -> 
EV Route-3: 0(DEPOT) -> 94(CUSTOMER) -> 50(CUSTOMER) -> 34(CUSTOMER) -> 106(STATION) -> 93(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 26 -> 93 -> 
EV Route-4: 0(DEPOT) -> 95(CUSTOMER) -> 84(CUSTOMER) -> 91(CUSTOMER) -> 80(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 95 -> 63 -> 85 -> 84 -> 
EV Route-5: 0(DEPOT) -> 22(CUSTOMER) -> 110(STATION) -> 49(CUSTOMER) -> 20(CUSTOMER) -> 56(CUSTOMER) -> 66(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 51 -> 49 -> 
EV Route-6: 0(DEPOT) -> 81(CUSTOMER) -> 54(CUSTOMER) -> 68(CUSTOMER) -> 55(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 81 -> 96 -> 54 -> 
EV Route-7: 0(DEPOT) -> 42(CUSTOMER) -> 102(STATION) -> 36(CUSTOMER) -> 72(CUSTOMER) -> 62(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 72 -> 71 -> 67 -> 62 -> 
  UAV Trip 2: 102 -> 39 -> 36 -> 
EV Route-8: 0(DEPOT) -> 14(CUSTOMER) -> 104(STATION) -> 47(CUSTOMER) -> 59(CUSTOMER) -> 110(STATION) -> 76(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 59 -> 52 -> 110 -> 
EV Route-9: 0(DEPOT) -> 108(STATION) -> 45(CUSTOMER) -> 5(CUSTOMER) -> 108(STATION) -> 7(CUSTOMER) -> 79(CUSTOMER) -> 78(CUSTOMER) -> 53(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 108 -> 2 -> 7 -> 
  UAV Trip 2: 79 -> 73 -> 78 -> 
EV Route-10: 0(DEPOT) -> 69(CUSTOMER) -> 98(CUSTOMER) -> 104(STATION) -> 15(CUSTOMER) -> 9(CUSTOMER) -> 87(CUSTOMER) -> 97(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 15 -> 16 -> 9 -> 
  UAV Trip 2: 98 -> 12 -> 104 -> 
EV Route-11: 0(DEPOT) -> 64(CUSTOMER) -> 19(CUSTOMER) -> 110(STATION) -> 25(CUSTOMER) -> 77(CUSTOMER) -> 58(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 110 -> 18 -> 48 -> 25 -> 
EV Route-12: 0(DEPOT) -> 92(CUSTOMER) -> 106(STATION) -> 31(CUSTOMER) -> 29(CUSTOMER) -> 30(CUSTOMER) -> 32(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 106 -> 33 -> 31 -> 
  UAV Trip 2: 29 -> 27 -> 28 -> 30 -> 
EV Route-13: 0(DEPOT) -> 82(CUSTOMER) -> 11(CUSTOMER) -> 10(CUSTOMER) -> 104(STATION) -> 17(CUSTOMER) -> 60(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 10 -> 13 -> 104 -> 
EV Route-14: 0(DEPOT) -> 88(CUSTOMER) -> 108(STATION) -> 8(CUSTOMER) -> 46(CUSTOMER) -> 4(CUSTOMER) -> 100(CUSTOMER) -> 70(CUSTOMER) -> 1000000(VIRTUAL_DEPOT) -> 
  UAV Trip 1: 46 -> 3 -> 1 -> 4 -> 
  UAV Trip 2: 88 -> 6 -> 108 -> 
```

