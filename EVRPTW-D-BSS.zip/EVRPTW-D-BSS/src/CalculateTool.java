import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Random;

public class CalculateTool {
    private static Random rng = new Random();
    private static final IdentityHashMap<Node, Integer> nodeRefIndex = new IdentityHashMap<>();
    private static final HashMap<Integer, Integer> nodeIdIndex = new HashMap<>();
    private static List<Node> stationNodesCache = Collections.emptyList();

    public static void setRandomSeed(long seed) {
        rng = new Random(seed);
    }

    public static void generateDistanceMatrix() {
        int n = Parameter.allNodes.length;
        Parameter.distanceMatrix = new double[n][n];

        nodeRefIndex.clear();
        nodeIdIndex.clear();
        List<Node> stations = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Node node = Parameter.allNodes[i];
            nodeRefIndex.put(node, i);
            if (!nodeIdIndex.containsKey(node.id)) {
                nodeIdIndex.put(node.id, i);
            }
            if (node.type == NodeType.STATION) {
                stations.add(node);
            }
        }
        stationNodesCache = stations;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                double dx = Parameter.allNodes[i].x - Parameter.allNodes[j].x;
                double dy = Parameter.allNodes[i].y - Parameter.allNodes[j].y;
                Parameter.distanceMatrix[i][j] = Math.sqrt(dx * dx + dy * dy);
            }
        }
    }

    public static void updateSolutionMetrics(Solution s) {
        s.evUavCost = 0;
        s.violationCost = 0;
        s.overloadAmount = 0;
        s.timeViolationAmount = 0;
        s.energyViolated = false;
        s.timeWindowViolated = false;
        s.overloadViolated = false;
        s.structureViolated = false;

        int usedEv = 0;
        HashSet<Integer> openedPhysicalStations = new HashSet<>();

        for (EV_Route r : s.evRoutes) {
            updateEVRouteMetrics(r);

            if (r.route.size() > 2) {
                usedEv++;
            }
            s.evUavCost += r.energyConsumption + r.uavEnergyConsumption;

            if (r.overload > 0) {
                s.overloadViolated = true;
                s.overloadAmount += r.overload;
            }
            if (r.timeViolation > 0) {
                s.timeWindowViolated = true;
                s.timeViolationAmount += r.timeViolation;
            }
            if (r.energyViolated) {
                s.energyViolated = true;
            }
            if (r.structureViolated) {
                s.structureViolated = true;
            }

            for (Node n : r.route) {
                if (n.type == NodeType.STATION && n.physicalStationId >= 0) {
                    openedPhysicalStations.add(n.physicalStationId);
                }
            }
        }

        s.evUavCost += usedEv * Parameter.evFixedCost;
        s.stationOpenCost = openedPhysicalStations.size() * Parameter.stationOpenCost;

        // Align with EVRPTW-D-SMBS style: magnitude-based penalties.
        s.violationCost += Parameter.alphaOverload * s.overloadAmount;
        s.violationCost += Parameter.betaTimeWindow * s.timeViolationAmount;
        if (s.energyViolated) {
            s.violationCost += Parameter.gammaEnergy;
        }
        if (s.structureViolated) {
            s.violationCost += Parameter.gammaRouteStructure;
        }

        s.totalCost = s.evUavCost + s.stationOpenCost + s.violationCost;
        s.feasible = !s.overloadViolated && !s.timeWindowViolated && !s.energyViolated && !s.structureViolated;
    }

    public static void updateEVRouteMetrics(EV_Route r) {
        r.distance = 0;
        r.overload = 0;
        r.timeViolation = 0;
        r.energyConsumption = 0;
        r.uavEnergyConsumption = 0;
        r.energyViolated = false;
        r.structureViolated = false;
        r.swapCount = 0;

        if (r.route.size() < 2) {
            return;
        }

        for (int i = 1; i < r.route.size(); i++) {
            Node prev = r.route.get(i - 1);
            Node cur = r.route.get(i);
            if (prev.type == NodeType.STATION && cur.type == NodeType.STATION) {
                r.structureViolated = true;
            }
        }

        EvLoadContext loadContext = buildEvLoadContext(r);
        double maxDepartureLoad = computeMaxDepartureLoad(r.route, loadContext);
        if (maxDepartureLoad > Parameter.evCapacity) {
            r.overload = maxDepartureLoad - Parameter.evCapacity;
        }

        // 1) Base EV timeline/energy.
        EvStats base = propagateEvTimeline(r, loadContext, null);
        mergeEvStats(r, base);

        if (r.uavTrips.isEmpty()) {
            return;
        }

        // 2) Synchronize EV waiting for UAV at meeting customer nodes.
        boolean stabilized = false;
        for (int it = 0; it < 6; it++) {
            double[] forcedDeparture = copyDepartureTimes(r.route);
            UavEval eval = evaluateTripsWithSync(r, forcedDeparture);

            if (eval.changed) {
                EvStats synced = propagateEvTimeline(r, loadContext, forcedDeparture);
                mergeEvStats(r, synced);
                // Preserve hard flags while iterating.
                r.structureViolated = r.structureViolated || eval.structureViolated;
                r.energyViolated = r.energyViolated || eval.energyViolated;
                continue;
            }

            r.uavEnergyConsumption = eval.totalUavEnergy;
            r.timeViolation += eval.uavTimeViolation;
            r.structureViolated = r.structureViolated || eval.structureViolated;
            r.energyViolated = r.energyViolated || eval.energyViolated;
            stabilized = true;
            break;
        }

        if (!stabilized) {
            r.structureViolated = true;
        }
    }

    private static EvStats propagateEvTimeline(EV_Route route, EvLoadContext loadContext, double[] forcedDeparture) {
        EvStats stats = new EvStats();

        double currentTime = 0;
        double batteryRemaining = Parameter.evEnergy;
        double remainingGoods = loadContext.initialGoods;
        boolean uavOnboard = true;

        Node start = route.route.get(0);
        LoadState startLoad = departureLoadAtNode(start, remainingGoods, uavOnboard, loadContext);
        remainingGoods = startLoad.remainingGoods;
        uavOnboard = startLoad.uavOnboard;
        double prevLeavingLoad = startLoad.leavingLoad;

        start.evArrivalTime = 0;
        start.evServiceTime = Math.max(start.readyTime, 0);
        double depart = start.evServiceTime + start.serviceTime;
        if (forcedDeparture != null) {
            depart = Math.max(depart, forcedDeparture[0]);
        }
        start.evDepartureTime = depart;
        currentTime = depart;

        for (int i = 1; i < route.route.size(); i++) {
            Node prev = route.route.get(i - 1);
            Node cur = route.route.get(i);

            double d = Parameter.distanceMatrix[indexOf(prev)][indexOf(cur)];
            double travelTime = d / Math.max(Parameter.evSpeed, 1e-9);
            double energyNeed = computeEvTravelEnergy(prevLeavingLoad, d);

            if (energyNeed > batteryRemaining + 1e-9) {
                stats.energyViolated = true;
            } else {
                batteryRemaining -= energyNeed;
            }

            stats.distance += d;
            stats.energyConsumption += energyNeed;

            double arrival = currentTime + travelTime;
            double serviceStart = Math.max(arrival, cur.readyTime);
            if (serviceStart > cur.dueTime + 1e-9) {
                stats.timeViolation += (serviceStart - cur.dueTime);
            }

            double nodeDepart = serviceStart + cur.serviceTime;
            if (forcedDeparture != null) {
                nodeDepart = Math.max(nodeDepart, forcedDeparture[i]);
            }

            cur.evArrivalTime = arrival;
            cur.evServiceTime = serviceStart;
            cur.evDepartureTime = nodeDepart;

            if (cur.type == NodeType.STATION) {
                batteryRemaining = Parameter.evEnergy;
                stats.swapCount++;
            }
            if (cur.type == NodeType.DEPOT) {
                batteryRemaining = Parameter.evEnergy;
            }

            if (cur.type == NodeType.CUSTOMER) {
                // Load transition for next segment is handled uniformly by departureLoadAtNode.
            }

            LoadState curLoad = departureLoadAtNode(cur, remainingGoods, uavOnboard, loadContext);
            remainingGoods = curLoad.remainingGoods;
            uavOnboard = curLoad.uavOnboard;
            prevLeavingLoad = curLoad.leavingLoad;

            currentTime = nodeDepart;
        }

        return stats;
    }

    private static UavEval evaluateTripsWithSync(EV_Route route, double[] forcedDeparture) {
        UavEval eval = new UavEval();
        resetRouteUavTimes(route);

        for (List<Node> trip : route.uavTrips) {
            if (trip.size() < 3) {
                eval.structureViolated = true;
                continue;
            }

            Node start = trip.get(0);
            Node end = trip.get(trip.size() - 1);
            int startPos = indexInRoute(route.route, start);
            int endPos = indexInRoute(route.route, end);

            // Meeting points must be customer nodes and exist on EV route in order.
            if (startPos < 0 || endPos < 0 || startPos >= endPos) {
                eval.structureViolated = true;
                continue;
            }
            if (!isMeetingNode(start) || !isMeetingNode(end)) {
                eval.structureViolated = true;
                continue;
            }

            double payload = 0;
            for (int i = 1; i < trip.size() - 1; i++) {
                Node n = trip.get(i);
                if (n.type != NodeType.CUSTOMER) {
                    eval.structureViolated = true;
                    payload = -1;
                    break;
                }
                payload += n.demand;
            }
            if (payload < 0) {
                continue;
            }
            if (payload > Parameter.uavCapacity + 1e-9) {
                eval.structureViolated = true;
                continue;
            }

            // UAV prep cannot overlap with EV service at launch node.
            double launchReady = Math.max(start.evDepartureTime, start.evServiceTime + start.serviceTime);
            double currentTime = launchReady + Parameter.uavPrepTime;
            double remainPayload = payload;
            double tripEnergy = 0;

            for (int i = 1; i < trip.size(); i++) {
                Node prev = trip.get(i - 1);
                Node cur = trip.get(i);
                double d = Parameter.distanceMatrix[indexOf(prev)][indexOf(cur)];

                currentTime += Parameter.uavTakeoffTime;
                currentTime += d / Math.max(Parameter.uavSpeed, 1e-9);
                currentTime += Parameter.uavLandingTime;

                double segmentPayload = Math.max(remainPayload, 0);
                double segmentWeight = Parameter.uavWeight + segmentPayload;
                tripEnergy += computeUavTakeoffEnergy(segmentWeight);
                tripEnergy += computeUavTravelEnergy(segmentWeight, d);
                tripEnergy += computeUavLandingEnergy(segmentWeight);

                if (i < trip.size() - 1) {
                    cur.uavArrivalTime = currentTime;
                    cur.uavServiceTime = Math.max(cur.uavArrivalTime, cur.readyTime);
                    if (cur.uavServiceTime > cur.dueTime + 1e-9) {
                        eval.uavTimeViolation += (cur.uavServiceTime - cur.dueTime);
                    }
                    cur.uavDepartureTime = cur.uavServiceTime + cur.serviceTime;
                    currentTime = cur.uavDepartureTime;
                    remainPayload = Math.max(0, remainPayload - cur.demand);
                } else {
                    end.uavArrivalTime = Math.max(end.uavArrivalTime, currentTime);
                }
            }

            eval.totalUavEnergy += tripEnergy;
            if (tripEnergy > Parameter.uavEnergy + 1e-9) {
                eval.energyViolated = true;
            }

            double evReadyToLeaveAtEnd = end.evServiceTime + end.serviceTime;
            double waitForUav = Math.max(0, end.uavArrivalTime - evReadyToLeaveAtEnd);
            if (waitForUav > Parameter.uavMaxDelay + 1e-9) {
                eval.structureViolated = true;
            }

            if (end.uavArrivalTime > forcedDeparture[endPos] + 1e-9) {
                forcedDeparture[endPos] = end.uavArrivalTime;
                eval.changed = true;
            }
        }

        return eval;
    }

    private static void mergeEvStats(EV_Route route, EvStats stats) {
        route.distance = stats.distance;
        route.energyConsumption = stats.energyConsumption;
        route.timeViolation = stats.timeViolation;
        route.swapCount = stats.swapCount;
        route.energyViolated = stats.energyViolated;
    }

    private static double[] copyDepartureTimes(List<Node> route) {
        double[] dep = new double[route.size()];
        for (int i = 0; i < route.size(); i++) {
            dep[i] = route.get(i).evDepartureTime;
        }
        return dep;
    }

    private static void resetRouteUavTimes(EV_Route route) {
        for (Node n : route.route) {
            n.uavArrivalTime = 0;
            n.uavServiceTime = 0;
            n.uavDepartureTime = 0;
        }
        for (List<Node> trip : route.uavTrips) {
            for (Node n : trip) {
                n.uavArrivalTime = 0;
                n.uavServiceTime = 0;
                n.uavDepartureTime = 0;
            }
        }
    }

    private static int indexInRoute(List<Node> route, Node target) {
        for (int i = 0; i < route.size(); i++) {
            Node n = route.get(i);
            if (n == target || n.id == target.id) {
                return i;
            }
        }
        return -1;
    }

    // 会合点规则与 Repair 保持一致：客户点与换电站点均可。
    private static boolean isMeetingNode(Node n) {
        return n.type == NodeType.CUSTOMER || n.type == NodeType.STATION;
    }

    private static double routeCustomerDemand(List<Node> route) {
        double d = 0;
        for (Node n : route) {
            if (n.type == NodeType.CUSTOMER) {
                d += n.demand;
            }
        }
        return d;
    }

    public static double computeEvTravelEnergy(double evLeavingLoad, double distance) {
        double segmentWeight = Parameter.evWeight + Math.max(evLeavingLoad, 0);
        return Parameter.evConsumeTravel * segmentWeight * distance;
    }

    private static EvLoadContext buildEvLoadContext(EV_Route route) {
        EvLoadContext ctx = new EvLoadContext();
        ctx.initialGoods = routeCustomerDemand(route.route);
        for (List<Node> trip : route.uavTrips) {
            if (trip.size() < 3) {
                continue;
            }
            double payload = 0;
            for (int i = 1; i < trip.size() - 1; i++) {
                payload += trip.get(i).demand;
            }
            ctx.initialGoods += payload;

            int launchId = trip.get(0).id;
            int landingId = trip.get(trip.size() - 1).id;
            ctx.launchPayloadByNode.put(launchId, ctx.launchPayloadByNode.getOrDefault(launchId, 0.0) + payload);
            ctx.landingCountByNode.put(landingId, ctx.landingCountByNode.getOrDefault(landingId, 0) + 1);
        }
        return ctx;
    }

    private static double computeMaxDepartureLoad(List<Node> route, EvLoadContext ctx) {
        if (route.isEmpty()) {
            return 0;
        }
        double remainingGoods = ctx.initialGoods;
        boolean uavOnboard = true;
        double maxLoad = 0;
        for (Node n : route) {
            LoadState s = departureLoadAtNode(n, remainingGoods, uavOnboard, ctx);
            remainingGoods = s.remainingGoods;
            uavOnboard = s.uavOnboard;
            maxLoad = Math.max(maxLoad, s.leavingLoad);
        }
        return maxLoad;
    }

    private static LoadState departureLoadAtNode(Node node,
                                                 double remainingGoods,
                                                 boolean uavOnboard,
                                                 EvLoadContext ctx) {
        double goods = remainingGoods;
        boolean onboard = uavOnboard;

        if (node.type == NodeType.CUSTOMER) {
            goods = Math.max(0, goods - node.demand);
        }
        if (ctx.landingCountByNode.getOrDefault(node.id, 0) > 0) {
            onboard = true;
        }
        if (ctx.launchPayloadByNode.containsKey(node.id)) {
            goods = Math.max(0, goods - ctx.launchPayloadByNode.get(node.id));
            onboard = false;
        }

        LoadState s = new LoadState();
        s.remainingGoods = goods;
        s.uavOnboard = onboard;
        s.leavingLoad = goods + (onboard ? Parameter.uavWeight : 0);
        return s;
    }

    public static double computeUavTakeoffEnergy(double uavTakeoffWeight) {
        return Parameter.uavConsumeTakeoff * uavTakeoffWeight;
    }

    public static double computeUavLandingEnergy(double uavLandingWeight) {
        return Parameter.uavConsumeLanding * uavLandingWeight;
    }

    public static double computeUavTravelEnergy(double uavTravelWeight, double uavTravelDistance) {
        return Parameter.uavConsumeTravel * uavTravelWeight * uavTravelDistance;
    }

    public static List<Node> stationNodes() {
        return stationNodesCache;
    }

    private static int indexOf(Node node) {
        Integer byRef = nodeRefIndex.get(node);
        if (byRef != null) {
            return byRef;
        }
        Integer byId = nodeIdIndex.get(node.id);
        if (byId != null) {
            return byId;
        }
        throw new IllegalStateException("Node not found in allNodes: " + node.id);
    }

    public static int intRandom(int minInclusive, int maxExclusive) {
        if (maxExclusive <= minInclusive) {
            return minInclusive;
        }
        return rng.nextInt(maxExclusive - minInclusive) + minInclusive;
    }

    public static double randomDouble() {
        return rng.nextDouble();
    }

    public static <T> void shuffleList(List<T> list) {
        Collections.shuffle(list, rng);
    }

    public static void clearSolution(Solution s) {
        for (EV_Route r : s.evRoutes) {
            r.route.clear();
            r.uavTrips.clear();
            r.distance = 0;
            r.overload = 0;
            r.timeViolation = 0;
            r.energyConsumption = 0;
            r.uavEnergyConsumption = 0;
            r.energyViolated = false;
            r.structureViolated = false;
            r.swapCount = 0;
        }
        s.totalCost = 0;
        s.evUavCost = 0;
        s.stationOpenCost = 0;
        s.violationCost = 0;
        s.overloadAmount = 0;
        s.timeViolationAmount = 0;
        s.feasible = false;
        s.energyViolated = false;
        s.timeWindowViolated = false;
        s.overloadViolated = false;
        s.structureViolated = false;
    }

    public static void cloneSolution(Solution target, Solution src) {
        clearSolution(target);
        for (int i = 0; i < src.evRoutes.length; i++) {
            target.evRoutes[i].route.addAll(src.evRoutes[i].route);
            for (List<Node> t : src.evRoutes[i].uavTrips) {
                target.evRoutes[i].uavTrips.add(new ArrayList<>(t));
            }
            target.evRoutes[i].distance = src.evRoutes[i].distance;
            target.evRoutes[i].overload = src.evRoutes[i].overload;
            target.evRoutes[i].timeViolation = src.evRoutes[i].timeViolation;
            target.evRoutes[i].energyConsumption = src.evRoutes[i].energyConsumption;
            target.evRoutes[i].uavEnergyConsumption = src.evRoutes[i].uavEnergyConsumption;
            target.evRoutes[i].energyViolated = src.evRoutes[i].energyViolated;
            target.evRoutes[i].structureViolated = src.evRoutes[i].structureViolated;
            target.evRoutes[i].swapCount = src.evRoutes[i].swapCount;
        }
        target.totalCost = src.totalCost;
        target.evUavCost = src.evUavCost;
        target.stationOpenCost = src.stationOpenCost;
        target.violationCost = src.violationCost;
        target.overloadAmount = src.overloadAmount;
        target.timeViolationAmount = src.timeViolationAmount;
        target.feasible = src.feasible;
        target.energyViolated = src.energyViolated;
        target.timeWindowViolated = src.timeWindowViolated;
        target.overloadViolated = src.overloadViolated;
        target.structureViolated = src.structureViolated;
    }

    private static final class EvStats {
        double distance;
        double energyConsumption;
        double timeViolation;
        int swapCount;
        boolean energyViolated;
    }

    private static final class UavEval {
        boolean changed;
        boolean structureViolated;
        boolean energyViolated;
        double uavTimeViolation;
        double totalUavEnergy;
    }

    private static final class EvLoadContext {
        double initialGoods;
        HashMap<Integer, Double> launchPayloadByNode = new HashMap<>();
        HashMap<Integer, Integer> landingCountByNode = new HashMap<>();
    }

    private static final class LoadState {
        double remainingGoods;
        boolean uavOnboard;
        double leavingLoad;
    }
}
