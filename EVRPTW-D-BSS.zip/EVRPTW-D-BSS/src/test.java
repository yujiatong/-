import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class test {
    private static final int RUNS_PER_CASE = 10;
    private static final long[] SEEDS = new long[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    private static final int MIN_MAX_ITERATION = 700;

    // Label current user-updated parameters as large-scale parameter set.
    private static final String PARAM_SET_LABEL = "LargeScaleParamSet-UserUpdated";

    // Resume checkpoint file. If process interrupts, rerun `java -cp src test` to continue.
    private static final Path PROGRESS_FILE = Paths.get("result", "bigscale_10runs_large_params_progress.tsv");
    private static final Path ISSUE_FILE = Paths.get("result", "bigscale_10runs_large_params_issues.log");
    private static final Path SNAPSHOT_REPORT_FILE = Paths.get("result", "bigscale_10runs_report_large_params_inprogress.md");
    private static final long RETRY_WAIT_MS = 60_000L;

    private static final DecimalFormat COST_FMT = new DecimalFormat("0.1");
    private static final DecimalFormat GAP_FMT = new DecimalFormat("0.00");
    private static final DecimalFormat TIME_FMT = new DecimalFormat("0.1");

    public static void main(String[] args) throws Exception {
        RunOptions options = RunOptions.parse(args);

        if (Parameter.maxIteration < MIN_MAX_ITERATION) {
            logIssue("SYSTEM", -1, -1,
                    "Parameter.maxIteration auto-upgraded from " + Parameter.maxIteration
                            + " to " + MIN_MAX_ITERATION
                            + " for large-scale 10-run experiment.");
            Parameter.maxIteration = MIN_MAX_ITERATION;
        }

        List<CaseSpec> allCases = buildCaseList();
        List<CaseSpec> cases = filterCases(allCases, options.caseNames);
        if (cases.isEmpty()) {
            System.out.println("No runnable cases after filtering. Exit.");
            return;
        }
        Map<String, Map<Long, RunResult>> done = loadProgress(PROGRESS_FILE);
        List<CaseResult> results = new ArrayList<>();

        System.out.println("Batch started. cases=" + cases.size() + "/" + allCases.size()
                + ", runsPerCase=" + RUNS_PER_CASE
                + ", paramSet=" + PARAM_SET_LABEL);
        System.out.println("Progress file: " + PROGRESS_FILE.toAbsolutePath());
        if (options.workerMode) {
            System.out.println("Mode: worker (skip snapshot/final report writing)");
        }
        if (!options.caseNames.isEmpty()) {
            Set<String> selected = new HashSet<>();
            for (CaseSpec c : cases) {
                selected.add(c.caseName);
            }
            for (String name : options.caseNames) {
                if (!selected.contains(name)) {
                    System.out.println("Warning: case not found in list: " + name);
                }
            }
            System.out.println("Selected cases: " + String.join(",", options.caseNames));
        }

        int caseIdx = 0;
        for (CaseSpec spec : cases) {
            caseIdx++;
            System.out.println();
            System.out.println("[" + caseIdx + "/" + cases.size() + "] " + spec.caseName + " -> " + spec.path);
            CaseResult cr = runCase(spec, done);
            results.add(cr);
            if (!options.workerMode) {
                List<CaseResult> snapshotResults = options.caseNames.isEmpty()
                        ? results
                        : buildCompletedCaseResults(allCases, done);
                writeReport(SNAPSHOT_REPORT_FILE, buildMarkdown(snapshotResults, allCases.size(), false));
            }
            System.out.println("Completed " + spec.caseName
                    + " | best=" + COST_FMT.format(cr.bestRun.cost)
                    + " | avg=" + COST_FMT.format(cr.avgCost)
                    + " | gap%=" + GAP_FMT.format(cr.gapPercent)
                    + " | avgTime(s)=" + TIME_FMT.format(cr.avgTimeSec)
                    + " | feasibleRuns=" + cr.feasibleRuns + "/" + cr.runs.size());
        }

        if (options.workerMode) {
            System.out.println();
            System.out.println("Worker run finished.");
            return;
        }

        if (!allCasesCompleted(allCases, done)) {
            System.out.println();
            System.out.println("Not all 24 cases are completed yet. Final report skipped.");
            return;
        }

        if (results.size() != allCases.size()) {
            results = buildCompletedCaseResults(allCases, done);
        }

        Path resultDir = Paths.get("result");
        if (!Files.exists(resultDir)) {
            Files.createDirectories(resultDir);
        }
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path out = resultDir.resolve("bigscale_10runs_report_large_params_" + ts + ".md");
        writeReport(out, buildMarkdown(results, allCases.size(), true));

        System.out.println();
        System.out.println("Report written: " + out.toAbsolutePath());
    }

    private static CaseResult runCase(CaseSpec spec, Map<String, Map<Long, RunResult>> done) throws Exception {
        CaseResult cr = new CaseResult();
        cr.spec = spec;
        int reusedRuns = 0;

        for (int i = 0; i < RUNS_PER_CASE; i++) {
            long seed = SEEDS[i];
            RunResult rr = getDoneRun(done, spec.caseName, seed);
            if (rr != null) {
                reusedRuns++;
            } else {
                rr = runSingleWithRetry(spec, seed, i + 1);
                putDoneRun(done, spec.caseName, rr);
                appendProgress(PROGRESS_FILE, spec, rr);
            }
            cr.runs.add(rr);
        }
        if (reusedRuns > 0) {
            System.out.println("  reused from checkpoint: " + reusedRuns + "/" + RUNS_PER_CASE);
        }

        finalizeCaseStats(cr);
        return cr;
    }

    private static void finalizeCaseStats(CaseResult cr) {
        cr.bestRun = pickBestRun(cr.runs);
        double sumCost = 0;
        double sumTime = 0;
        int feasibleCnt = 0;
        for (RunResult rr : cr.runs) {
            sumCost += rr.cost;
            sumTime += rr.timeSec;
            if (rr.feasible) {
                feasibleCnt++;
            }
        }
        cr.avgCost = sumCost / cr.runs.size();
        cr.avgTimeSec = sumTime / cr.runs.size();
        cr.feasibleRuns = feasibleCnt;
        if (Math.abs(cr.bestRun.cost) <= 1e-9) {
            cr.gapPercent = 0;
        } else {
            cr.gapPercent = (cr.avgCost - cr.bestRun.cost) / cr.bestRun.cost * 100.0;
        }
    }

    private static RunResult runSingleWithRetry(CaseSpec spec, long seed, int runIndex) throws Exception {
        int maxRetry = 3;
        Exception last = null;
        for (int attempt = 1; attempt <= maxRetry; attempt++) {
            try {
                RunResult rr = runSingle(spec, seed);
                System.out.println("  run " + runIndex + "/" + RUNS_PER_CASE
                        + " seed=" + seed
                        + " attempt=" + attempt
                        + " cost=" + COST_FMT.format(rr.cost)
                        + " feasible=" + rr.feasible
                        + " time(s)=" + TIME_FMT.format(rr.timeSec));
                return rr;
            } catch (Exception ex) {
                last = ex;
                logIssue(spec.caseName, seed, attempt, ex.toString());
                System.out.println("  run " + runIndex + "/" + RUNS_PER_CASE
                        + " seed=" + seed
                        + " attempt=" + attempt
                        + " failed: " + ex.getMessage());
                if (attempt < maxRetry) {
                    try {
                        Thread.sleep(RETRY_WAIT_MS);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Retry wait interrupted", ie);
                    }
                }
            }
        }
        throw last;
    }

    private static RunResult runSingle(CaseSpec spec, long seed) throws Exception {
        // Use current Parameter combination directly (no internal override).
        CalculateTool.setRandomSeed(seed);

        long t0 = System.currentTimeMillis();

        ReadData.init();
        ReadData.importInfo(spec.path);
        BSSExpansion.expandStations();
        CalculateTool.generateDistanceMatrix();

        InitialSolutionBuilder.buildInitialSolution(Parameter.localSolution);
        CalculateTool.updateSolutionMetrics(Parameter.localSolution);
        ALNS.solve();

        long t1 = System.currentTimeMillis();

        Solution copy = new Solution();
        CalculateTool.cloneSolution(copy, Parameter.bestSolution);
        double cost = copy.getTotalCost();

        RunResult rr = new RunResult();
        rr.seed = seed;
        rr.timeSec = (t1 - t0) / 1000.0;
        rr.cost = cost;
        rr.feasible = copy.feasible;
        rr.overloadViolated = copy.overloadViolated;
        rr.timeWindowViolated = copy.timeWindowViolated;
        rr.energyViolated = copy.energyViolated;
        rr.structureViolated = copy.structureViolated;
        rr.totalCost = copy.totalCost;
        rr.evUavCost = copy.evUavCost;
        rr.stationOpenCost = copy.stationOpenCost;
        rr.violationCost = copy.violationCost;
        rr.overloadAmount = copy.overloadAmount;
        rr.timeViolationAmount = copy.timeViolationAmount;
        rr.solutionText = formatSolution(copy);
        return rr;
    }

    private static RunResult pickBestRun(List<RunResult> runs) {
        RunResult best = null;
        for (RunResult rr : runs) {
            if (best == null) {
                best = rr;
                continue;
            }
            if (rr.feasible && !best.feasible) {
                best = rr;
                continue;
            }
            if (!rr.feasible && best.feasible) {
                continue;
            }
            if (rr.cost < best.cost - 1e-9) {
                best = rr;
            }
        }
        return best;
    }

    private static void writeReport(Path out, String content) throws Exception {
        if (!Files.exists(out.getParent())) {
            Files.createDirectories(out.getParent());
        }
        Files.write(out, content.getBytes(StandardCharsets.UTF_8));
    }

    private static String buildMarkdown(List<CaseResult> results, int totalCases, boolean finished) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Large-Scale Instances Report (10 runs each)\n\n");
        sb.append("- Generated at: ").append(LocalDateTime.now()).append("\n");
        sb.append("- Status: ").append(finished ? "Finished" : "In progress").append("\n");
        sb.append("- Completed cases: ").append(results.size()).append("/").append(totalCases).append("\n");
        sb.append("- Runs per case: ").append(RUNS_PER_CASE).append("\n");
        sb.append("- Parameter set label: ").append(PARAM_SET_LABEL).append("\n\n");

        sb.append("## Large-Scale Parameter Set (Current)\n\n");
        Map<String, String> params = collectParameterSnapshot();
        for (Map.Entry<String, String> e : params.entrySet()) {
            sb.append("- ").append(e.getKey()).append(": ").append(e.getValue()).append("\n");
        }
        sb.append("\n");

        sb.append("## Summary Table\n\n");
        sb.append("| CASE | BestCost | AvgCost | Gap% | Time(s) |\n");
        sb.append("|---|---:|---:|---:|---:|\n");
        for (CaseResult cr : results) {
            sb.append("| ").append(cr.spec.caseName)
                    .append(" | ").append(COST_FMT.format(cr.bestRun.cost))
                    .append(" | ").append(COST_FMT.format(cr.avgCost))
                    .append(" | ").append(GAP_FMT.format(cr.gapPercent))
                    .append(" | ").append(TIME_FMT.format(cr.avgTimeSec))
                    .append(" |\n");
        }
        sb.append("\n");

        sb.append("## Issues During Run\n\n");
        List<String> issueLines = readIssueLines();
        if (issueLines.isEmpty()) {
            sb.append("- None.\n\n");
        } else {
            for (String line : issueLines) {
                sb.append("- ").append(line).append("\n");
            }
            sb.append("\n");
        }

        sb.append("## Best Routes And Run Logs\n\n");
        for (CaseResult cr : results) {
            sb.append("### ").append(cr.spec.caseName).append("\n\n");
            sb.append("- Instance: `").append(cr.spec.path).append("`\n");
            sb.append("- Feasible runs: ").append(cr.feasibleRuns).append("/").append(cr.runs.size()).append("\n");
            sb.append("- Best run seed: ").append(cr.bestRun.seed).append("\n");
            sb.append("- Best cost: ").append(COST_FMT.format(cr.bestRun.cost)).append("\n");
            sb.append("- Avg cost: ").append(COST_FMT.format(cr.avgCost)).append("\n");
            sb.append("- Avg time(s): ").append(TIME_FMT.format(cr.avgTimeSec)).append("\n");
            sb.append("- Gap%: ").append(GAP_FMT.format(cr.gapPercent)).append("\n");
            sb.append("- Best feasible: ").append(cr.bestRun.feasible).append("\n");
            sb.append("- Best violations: overload=").append(cr.bestRun.overloadViolated)
                    .append(", tw=").append(cr.bestRun.timeWindowViolated)
                    .append(", energy=").append(cr.bestRun.energyViolated)
                    .append(", structure=").append(cr.bestRun.structureViolated).append("\n\n");

            sb.append("#### Run Log\n\n");
            sb.append("| Run | Seed | Cost | Feasible | Time(s) |\n");
            sb.append("|---:|---:|---:|---:|---:|\n");
            for (int i = 0; i < cr.runs.size(); i++) {
                RunResult rr = cr.runs.get(i);
                sb.append("| ").append(i + 1)
                        .append(" | ").append(rr.seed)
                        .append(" | ").append(COST_FMT.format(rr.cost))
                        .append(" | ").append(rr.feasible)
                        .append(" | ").append(TIME_FMT.format(rr.timeSec))
                        .append(" |\n");
            }
            sb.append("\n");

            sb.append("#### Best Route Plan\n\n");
            sb.append("```text\n");
            sb.append(cr.bestRun.solutionText);
            sb.append("```\n\n");
        }

        return sb.toString();
    }

    private static void logIssue(String caseName, long seed, int attempt, String msg) throws Exception {
        if (!Files.exists(ISSUE_FILE.getParent())) {
            Files.createDirectories(ISSUE_FILE.getParent());
        }
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String line = ts + "\tcase=" + caseName
                + "\tseed=" + seed
                + "\tattempt=" + attempt
                + "\tmsg=" + msg + "\n";
        appendWithFileLock(ISSUE_FILE, line);
    }

    private static List<String> readIssueLines() {
        try {
            if (!Files.exists(ISSUE_FILE)) {
                return new ArrayList<>();
            }
            return Files.readAllLines(ISSUE_FILE, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            List<String> fallback = new ArrayList<>();
            fallback.add("Failed to read issue file: " + ex.getMessage());
            return fallback;
        }
    }

    private static Map<String, String> collectParameterSnapshot() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("evCount", String.valueOf(Parameter.evCount));
        m.put("evCapacity", String.valueOf(Parameter.evCapacity));
        m.put("evEnergy", String.valueOf(Parameter.evEnergy));
        m.put("evSpeed", String.valueOf(Parameter.evSpeed));
        m.put("evWeight", String.valueOf(Parameter.evWeight));
        m.put("evConsumeTravel", String.valueOf(Parameter.evConsumeTravel));

        m.put("uavCapacity", String.valueOf(Parameter.uavCapacity));
        m.put("uavEnergy", String.valueOf(Parameter.uavEnergy));
        m.put("uavSpeed", String.valueOf(Parameter.uavSpeed));
        m.put("uavWeight", String.valueOf(Parameter.uavWeight));
        m.put("uavConsumeTravel", String.valueOf(Parameter.uavConsumeTravel));
        m.put("uavConsumeTakeoff", String.valueOf(Parameter.uavConsumeTakeoff));
        m.put("uavConsumeLanding", String.valueOf(Parameter.uavConsumeLanding));
        m.put("uavMaxDelay", String.valueOf(Parameter.uavMaxDelay));
        m.put("uavTripMaxCustomers", String.valueOf(Parameter.uavTripMaxCustomers));

        m.put("evFixedCost", String.valueOf(Parameter.evFixedCost));
        m.put("stationOpenCost", String.valueOf(Parameter.stationOpenCost));
        m.put("alphaOverload", String.valueOf(Parameter.alphaOverload));
        m.put("betaTimeWindow", String.valueOf(Parameter.betaTimeWindow));
        m.put("gammaEnergy", String.valueOf(Parameter.gammaEnergy));
        m.put("gammaRouteStructure", String.valueOf(Parameter.gammaRouteStructure));

        m.put("maxIteration", String.valueOf(Parameter.maxIteration));
        m.put("alnsRestarts", String.valueOf(Parameter.alnsRestarts));
        m.put("removeNodeNumber", String.valueOf(Parameter.removeNodeNumber));
        m.put("saInitTemp", String.valueOf(Parameter.saInitTemp));
        m.put("saCooling", String.valueOf(Parameter.saCooling));
        m.put("saAutoTune", String.valueOf(Parameter.saAutoTune));
        m.put("insertionCandidateK", String.valueOf(Parameter.insertionCandidateK));
        m.put("alnsMaxInsertionCandidateK", String.valueOf(Parameter.alnsMaxInsertionCandidateK));
        m.put("alnsFeasibilityRescueIters", String.valueOf(Parameter.alnsFeasibilityRescueIters));
        m.put("alnsFeasibilityRescueRounds", String.valueOf(Parameter.alnsFeasibilityRescueRounds));
        return m;
    }

    private static String formatSolution(Solution s) {
        StringBuilder sb = new StringBuilder();
        sb.append("totalCost=").append(s.totalCost)
                .append(", evUavCost=").append(s.evUavCost)
                .append(", stationOpenCost=").append(s.stationOpenCost)
                .append(", violationCost=").append(s.violationCost)
                .append(", overloadAmount=").append(s.overloadAmount)
                .append(", timeViolationAmount=").append(s.timeViolationAmount).append("\n");

        int idx = 0;
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 2) {
                idx++;
                continue;
            }
            sb.append("EV Route-").append(idx).append(": ");
            for (Node n : r.route) {
                sb.append(n.id).append("(").append(n.type).append(") -> ");
            }
            sb.append("\n");
            int t = 1;
            for (List<Node> trip : r.uavTrips) {
                sb.append("  UAV Trip ").append(t++).append(": ");
                for (Node n : trip) {
                    sb.append(n.id).append(" -> ");
                }
                sb.append("\n");
            }
            idx++;
        }
        return sb.toString();
    }

    private static List<CaseSpec> buildCaseList() {
        List<CaseSpec> list = new ArrayList<>();

        Map<String, String> nameMap = new LinkedHashMap<>();
        nameMap.put("c101", "C1");
        nameMap.put("c201", "C2");
        nameMap.put("r101", "R1");
        nameMap.put("r201", "R2");
        nameMap.put("rc101", "RC1");
        nameMap.put("rc201", "RC2");

        List<Integer> scales = Arrays.asList(25, 50, 75, 100);
        for (int n : scales) {
            for (Map.Entry<String, String> e : nameMap.entrySet()) {
                String type = e.getKey();
                String caseName = e.getValue() + "-" + n;
                String path = "./instances_bss_bigscal/" + type + "_n" + n + "_bss.txt";
                list.add(new CaseSpec(caseName, type, n, path));
            }
        }
        return list;
    }

    private static List<CaseSpec> filterCases(List<CaseSpec> allCases, List<String> caseNames) {
        if (caseNames.isEmpty()) {
            return allCases;
        }
        Set<String> wanted = new HashSet<>(caseNames);
        List<CaseSpec> filtered = new ArrayList<>();
        for (CaseSpec c : allCases) {
            if (wanted.contains(c.caseName)) {
                filtered.add(c);
            }
        }
        return filtered;
    }

    private static boolean allCasesCompleted(List<CaseSpec> allCases, Map<String, Map<Long, RunResult>> done) {
        for (CaseSpec spec : allCases) {
            if (!isCaseCompleted(spec.caseName, done)) {
                return false;
            }
        }
        return true;
    }

    private static boolean isCaseCompleted(String caseName, Map<String, Map<Long, RunResult>> done) {
        Map<Long, RunResult> m = done.get(caseName);
        if (m == null) {
            return false;
        }
        for (long seed : SEEDS) {
            if (!m.containsKey(seed)) {
                return false;
            }
        }
        return true;
    }

    private static List<CaseResult> buildCompletedCaseResults(List<CaseSpec> allCases, Map<String, Map<Long, RunResult>> done) {
        List<CaseResult> out = new ArrayList<>();
        for (CaseSpec spec : allCases) {
            if (!isCaseCompleted(spec.caseName, done)) {
                continue;
            }
            Map<Long, RunResult> m = done.get(spec.caseName);
            CaseResult cr = new CaseResult();
            cr.spec = spec;
            for (long seed : SEEDS) {
                cr.runs.add(m.get(seed));
            }
            finalizeCaseStats(cr);
            out.add(cr);
        }
        return out;
    }

    private static Map<String, Map<Long, RunResult>> loadProgress(Path path) throws Exception {
        Map<String, Map<Long, RunResult>> map = new LinkedHashMap<>();
        if (!Files.exists(path)) {
            return map;
        }
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.isEmpty()) {
            return map;
        }
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line == null || line.trim().isEmpty()) {
                continue;
            }
            String[] sp = line.split("\t", -1);
            if (sp.length < 19) {
                continue;
            }
            RunResult rr = new RunResult();
            String caseName = sp[0];
            rr.seed = Long.parseLong(sp[4]);
            rr.cost = Double.parseDouble(sp[5]);
            rr.timeSec = Double.parseDouble(sp[6]);
            rr.feasible = Boolean.parseBoolean(sp[7]);
            rr.overloadViolated = Boolean.parseBoolean(sp[8]);
            rr.timeWindowViolated = Boolean.parseBoolean(sp[9]);
            rr.energyViolated = Boolean.parseBoolean(sp[10]);
            rr.structureViolated = Boolean.parseBoolean(sp[11]);
            rr.totalCost = Double.parseDouble(sp[12]);
            rr.evUavCost = Double.parseDouble(sp[13]);
            rr.stationOpenCost = Double.parseDouble(sp[14]);
            rr.violationCost = Double.parseDouble(sp[15]);
            rr.overloadAmount = Double.parseDouble(sp[16]);
            rr.timeViolationAmount = Double.parseDouble(sp[17]);
            rr.solutionText = new String(Base64.getDecoder().decode(sp[18]), StandardCharsets.UTF_8);
            putDoneRun(map, caseName, rr);
        }
        return map;
    }

    private static void appendProgress(Path path, CaseSpec spec, RunResult rr) throws Exception {
        if (!Files.exists(path.getParent())) {
            Files.createDirectories(path.getParent());
        }
        StringBuilder line = new StringBuilder();
        String solutionBase64 = Base64.getEncoder().encodeToString(rr.solutionText.getBytes(StandardCharsets.UTF_8));
        line.append(spec.caseName).append('\t')
                .append(spec.type).append('\t')
                .append(spec.n).append('\t')
                .append(spec.path).append('\t')
                .append(rr.seed).append('\t')
                .append(rr.cost).append('\t')
                .append(rr.timeSec).append('\t')
                .append(rr.feasible).append('\t')
                .append(rr.overloadViolated).append('\t')
                .append(rr.timeWindowViolated).append('\t')
                .append(rr.energyViolated).append('\t')
                .append(rr.structureViolated).append('\t')
                .append(rr.totalCost).append('\t')
                .append(rr.evUavCost).append('\t')
                .append(rr.stationOpenCost).append('\t')
                .append(rr.violationCost).append('\t')
                .append(rr.overloadAmount).append('\t')
                .append(rr.timeViolationAmount).append('\t')
                .append(solutionBase64).append('\n');
        String header = "caseName\ttype\tn\tpath\tseed\tcost\ttimeSec\tfeasible\toverloadViolated\ttimeWindowViolated\tenergyViolated\tstructureViolated\ttotalCost\tevUavCost\tstationOpenCost\tviolationCost\toverloadAmount\ttimeViolationAmount\tsolutionBase64\n";
        appendWithFileLock(path, header, line.toString());
    }

    private static void appendWithFileLock(Path path, String line) throws Exception {
        appendWithFileLock(path, "", line);
    }

    private static void appendWithFileLock(Path path, String header, String line) throws Exception {
        if (!Files.exists(path.getParent())) {
            Files.createDirectories(path.getParent());
        }
        try (java.nio.channels.FileChannel channel = java.nio.channels.FileChannel.open(path,
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.READ,
                java.nio.file.StandardOpenOption.WRITE)) {
            try (java.nio.channels.FileLock lock = channel.lock()) {
                long size = channel.size();
                channel.position(size);
                if (size == 0 && header != null && !header.isEmpty()) {
                    channel.write(StandardCharsets.UTF_8.encode(header));
                }
                channel.write(StandardCharsets.UTF_8.encode(line));
                channel.force(true);
            }
        }
    }

    private static RunResult getDoneRun(Map<String, Map<Long, RunResult>> done, String caseName, long seed) {
        Map<Long, RunResult> m = done.get(caseName);
        if (m == null) {
            return null;
        }
        return m.get(seed);
    }

    private static void putDoneRun(Map<String, Map<Long, RunResult>> done, String caseName, RunResult rr) {
        Map<Long, RunResult> m = done.get(caseName);
        if (m == null) {
            m = new LinkedHashMap<>();
            done.put(caseName, m);
        }
        m.put(rr.seed, rr);
    }

    private static final class CaseSpec {
        String caseName;
        String type;
        int n;
        String path;

        CaseSpec(String caseName, String type, int n, String path) {
            this.caseName = caseName;
            this.type = type;
            this.n = n;
            this.path = path;
        }
    }

    private static final class RunOptions {
        boolean workerMode;
        List<String> caseNames = new ArrayList<>();

        static RunOptions parse(String[] args) {
            RunOptions opt = new RunOptions();
            if (args == null) {
                return opt;
            }
            for (String arg : args) {
                if (arg == null) {
                    continue;
                }
                if ("--worker".equals(arg)) {
                    opt.workerMode = true;
                } else if (arg.startsWith("--cases=")) {
                    parseCaseNames(arg.substring("--cases=".length()), opt.caseNames);
                } else if (arg.startsWith("--case=")) {
                    parseCaseNames(arg.substring("--case=".length()), opt.caseNames);
                }
            }
            return opt;
        }

        private static void parseCaseNames(String raw, List<String> out) {
            if (raw == null || raw.trim().isEmpty()) {
                return;
            }
            for (String part : raw.split(",")) {
                String name = part.trim();
                if (!name.isEmpty()) {
                    out.add(name);
                }
            }
        }
    }

    private static final class RunResult {
        long seed;
        double cost;
        double timeSec;
        boolean feasible;

        boolean overloadViolated;
        boolean timeWindowViolated;
        boolean energyViolated;
        boolean structureViolated;

        double totalCost;
        double evUavCost;
        double stationOpenCost;
        double violationCost;
        double overloadAmount;
        double timeViolationAmount;
        String solutionText;
    }

    private static final class CaseResult {
        CaseSpec spec;
        List<RunResult> runs = new ArrayList<>();
        RunResult bestRun;
        int feasibleRuns;
        double avgCost;
        double avgTimeSec;
        double gapPercent;
    }
}
