import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class Output {
    // 输出当前生效参数（包含实例覆盖后的值）。
    public static void outputParameters() {
        System.out.println("===== Parameters =====");
        System.out.println("customerCount=" + Parameter.customerCount
                + ", stationCount=" + Parameter.stationCount
                + ", nodeCount=" + Parameter.nodeCount);

        System.out.println("evCount=" + Parameter.evCount
                + ", evCapacity=" + Parameter.evCapacity
                + ", evEnergy=" + Parameter.evEnergy
                + ", evSpeed=" + Parameter.evSpeed
                + ", evWeight=" + Parameter.evWeight
                + ", evConsumeTravel=" + Parameter.evConsumeTravel);

        System.out.println("uavCapacity=" + Parameter.uavCapacity
                + ", uavEnergy=" + Parameter.uavEnergy
                + ", uavSpeed=" + Parameter.uavSpeed
                + ", uavWeight=" + Parameter.uavWeight
                + ", uavConsumeTravel=" + Parameter.uavConsumeTravel
                + ", uavConsumeTakeoff=" + Parameter.uavConsumeTakeoff
                + ", uavConsumeLanding=" + Parameter.uavConsumeLanding
                + ", uavMaxDelay=" + Parameter.uavMaxDelay
                + ", uavTripMaxCustomers=" + Parameter.uavTripMaxCustomers);

        System.out.println("evFixedCost=" + Parameter.evFixedCost
                + ", stationOpenCost=" + Parameter.stationOpenCost);
        System.out.println("alphaOverload=" + Parameter.alphaOverload
                + ", betaTimeWindow=" + Parameter.betaTimeWindow
                + ", gammaEnergy=" + Parameter.gammaEnergy
                + ", gammaRouteStructure=" + Parameter.gammaRouteStructure);

        System.out.println("maxIteration=" + Parameter.maxIteration
                + ", alnsRestarts=" + Parameter.alnsRestarts
                + ", removeNodeNumber=" + Parameter.removeNodeNumber
                + ", saInitTemp=" + Parameter.saInitTemp
                + ", saCooling=" + Parameter.saCooling);

        System.out.println("alnsReactionFactor=" + Parameter.alnsReactionFactor
                + ", alnsRewardBest=" + Parameter.alnsRewardBest
                + ", alnsRewardImprove=" + Parameter.alnsRewardImprove
                + ", alnsRewardAccept=" + Parameter.alnsRewardAccept
                + ", alnsWeightFloor=" + Parameter.alnsWeightFloor);
        System.out.println("alnsNoImproveReheatIters=" + Parameter.alnsNoImproveReheatIters
                + ", alnsReheatFactor=" + Parameter.alnsReheatFactor
                + ", alnsMaxTempMultiplier=" + Parameter.alnsMaxTempMultiplier
                + ", alnsDiversifyIters=" + Parameter.alnsDiversifyIters
                + ", alnsDiversifyRounds=" + Parameter.alnsDiversifyRounds
                + ", alnsStagnationDestroyBoostIters=" + Parameter.alnsStagnationDestroyBoostIters
                + ", alnsMaxRemoveNodeNumber=" + Parameter.alnsMaxRemoveNodeNumber
                + ", insertionCandidateK=" + Parameter.insertionCandidateK
                + ", insertionPruneSlack=" + Parameter.insertionPruneSlack);
    }

    // 控制台输出当前解的路线结构与成本分解。
    public static void outputSolution(Solution s) {
        int idx = 0;
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 2) {
                idx++;
                continue;
            }
            System.out.println("EV Route- " + idx++);
            for (Node n : r.route) {
                System.out.print(n.id + "(" + n.type + ") -> ");
            }
            System.out.println();

            int t = 1;
            for (List<Node> trip : r.uavTrips) {
                System.out.print("UAV Trip " + t++ + ": ");
                for (Node n : trip) {
                    System.out.print(n.id + " -> ");
                }
                System.out.println();
            }
        }
        System.out.println("totalCost=" + s.totalCost
                + ", evUavCost=" + s.evUavCost
                + ", stationOpenCost=" + s.stationOpenCost
                + ", violationCost=" + s.violationCost
                + ", overloadAmount=" + s.overloadAmount
                + ", timeViolationAmount=" + s.timeViolationAmount);
    }

    public static void outputDetailedTrace(Solution s) {
        CalculateTool.updateSolutionMetrics(s);
        System.out.println("===== Detailed Energy Trace =====");

        int evIdx = 0;
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 2) {
                evIdx++;
                continue;
            }

            System.out.println();
            System.out.println("电动车辆" + evIdx + ":");
            printEvRouteTrace(r);

            int tripIdx = 0;
            for (List<Node> trip : r.uavTrips) {
                System.out.println();
                System.out.println("无人机" + evIdx + "的第" + tripIdx + "次行程:");
                printUavTripTrace(r, trip);
                tripIdx++;
            }
            evIdx++;
        }
    }

    private static void printEvRouteTrace(EV_Route r) {
        if (r.route.isEmpty()) {
            return;
        }

        Map<Integer, Double> launchPayloadByNode = new HashMap<>();
        Map<Integer, Integer> landingCountByNode = new HashMap<>();
        double totalUavPayload = 0;
        for (List<Node> trip : r.uavTrips) {
            if (trip.size() < 3) {
                continue;
            }
            int launchId = trip.get(0).id;
            int landingId = trip.get(trip.size() - 1).id;
            double payload = 0;
            for (int i = 1; i < trip.size() - 1; i++) {
                payload += trip.get(i).demand;
            }
            totalUavPayload += payload;
            launchPayloadByNode.put(launchId, launchPayloadByNode.getOrDefault(launchId, 0.0) + payload);
            landingCountByNode.put(landingId, landingCountByNode.getOrDefault(landingId, 0) + 1);
        }

        double remainingGoods = routeCustomerDemand(r.route) + totalUavPayload;
        boolean uavOnboard = true;
        double remainingBattery = Parameter.evEnergy;
        double traceEnergy = 0;

        Node first = r.route.get(0);
        LoadState dep0 = departureLoadAtNode(first, remainingGoods, uavOnboard, launchPayloadByNode, landingCountByNode);
        remainingGoods = dep0.remainingGoods;
        uavOnboard = dep0.uavOnboard;
        double currentLeavingLoad = dep0.leavingLoad;
        System.out.println("节点" + first.id + ": Ta_e=" + first.evArrivalTime
                + ", Ts_e=" + first.evServiceTime
                + ", Tg_e=" + first.evDepartureTime
                + ", 剩余电量Be=" + remainingBattery
                + ", 离开时载重Qe=" + dep0.leavingLoad);

        for (int i = 1; i < r.route.size(); i++) {
            Node prev = r.route.get(i - 1);
            Node cur = r.route.get(i);
            double d = distance(prev, cur);
            double segWeight = Parameter.evWeight + Math.max(currentLeavingLoad, 0);
            double e = Parameter.evConsumeTravel * segWeight * d;
            double batteryAfterTravel = remainingBattery - e;
            traceEnergy += e;

            System.out.println("节点" + prev.id + "-" + cur.id
                    + ": 距离=" + d
                    + ", 段载重W=" + segWeight
                    + ", EV能耗Ee=" + e
                    + ", 电量变化=" + remainingBattery + "->" + batteryAfterTravel);

            if (cur.type == NodeType.STATION || cur.type == NodeType.DEPOT) {
                remainingBattery = Parameter.evEnergy;
            } else {
                remainingBattery = batteryAfterTravel;
            }

            LoadState depCur = departureLoadAtNode(cur, remainingGoods, uavOnboard, launchPayloadByNode, landingCountByNode);
            remainingGoods = depCur.remainingGoods;
            uavOnboard = depCur.uavOnboard;
            currentLeavingLoad = depCur.leavingLoad;

            System.out.println("节点" + cur.id + ": Ta_e=" + cur.evArrivalTime
                    + ", Ts_e=" + cur.evServiceTime
                    + ", Tg_e=" + cur.evDepartureTime
                    + ", 剩余电量Be=" + remainingBattery
                    + ", 离开时载重Qe=" + depCur.leavingLoad);
        }

        System.out.println("EV汇总: distance=" + r.distance
                + ", EV能耗(明细重算)=" + traceEnergy
                + ", EV能耗(评价函数)=" + r.energyConsumption
                + ", UAV能耗=" + r.uavEnergyConsumption
                + ", timeViolation=" + r.timeViolation
                + ", overload=" + r.overload);
    }

    private static void printUavTripTrace(EV_Route route, List<Node> trip) {
        if (trip.size() < 3) {
            System.out.println("行程结构非法: 节点数<3");
            return;
        }

        Node start = trip.get(0);
        Node end = trip.get(trip.size() - 1);
        double launchReady = Math.max(start.evDepartureTime, start.evServiceTime + start.serviceTime);
        double currentTime = launchReady + Parameter.uavPrepTime;

        double payload = 0;
        for (int i = 1; i < trip.size() - 1; i++) {
            payload += trip.get(i).demand;
        }
        double remainPayload = payload;
        double remainBattery = Parameter.uavEnergy;
        double tripEnergy = 0;

        System.out.println("起飞点" + start.id + ": launchReady=" + launchReady
                + ", prepTime=" + Parameter.uavPrepTime
                + ", 起飞前载重Qf=" + remainPayload
                + ", 初始电量Bf=" + remainBattery);

        for (int i = 1; i < trip.size(); i++) {
            Node prev = trip.get(i - 1);
            Node cur = trip.get(i);
            double d = distance(prev, cur);
            double segWeight = Parameter.uavWeight + Math.max(remainPayload, 0);
            double ef1 = CalculateTool.computeUavTakeoffEnergy(segWeight);
            double ef3 = CalculateTool.computeUavTravelEnergy(segWeight, d);
            double ef2 = CalculateTool.computeUavLandingEnergy(segWeight);
            double segEnergy = ef1 + ef3 + ef2;

            currentTime += Parameter.uavTakeoffTime;
            currentTime += d / Math.max(Parameter.uavSpeed, 1e-9);
            currentTime += Parameter.uavLandingTime;

            double before = remainBattery;
            remainBattery -= segEnergy;
            tripEnergy += segEnergy;

            System.out.println("节点" + prev.id + "-" + cur.id
                    + ": 距离=" + d
                    + ", 段载重W=" + segWeight
                    + ", 起飞能耗Ef1=" + ef1
                    + ", 飞行能耗Ef3=" + ef3
                    + ", 降落能耗Ef2=" + ef2
                    + ", 段总能耗=" + segEnergy
                    + ", 电量变化=" + before + "->" + remainBattery);

            if (i < trip.size() - 1) {
                double serviceStart = Math.max(currentTime, cur.readyTime);
                double depart = serviceStart + cur.serviceTime;
                double late = Math.max(0, serviceStart - cur.dueTime);
                System.out.println("节点" + cur.id + ": Ta_f=" + currentTime
                        + ", Ts_f=" + serviceStart
                        + ", Tg_f=" + depart
                        + ", 时间窗超时=" + late
                        + ", 剩余载重Qf=" + Math.max(0, remainPayload - cur.demand));
                currentTime = depart;
                remainPayload = Math.max(0, remainPayload - cur.demand);
            } else {
                double evReadyToLeave = end.evServiceTime + end.serviceTime;
                double waitForUav = Math.max(0, currentTime - evReadyToLeave);
                System.out.println("节点" + end.id + ": Ta_f=" + currentTime
                        + ", EV可离开时刻=" + evReadyToLeave
                        + ", EV等待UAV=" + waitForUav);
            }
        }

        System.out.println("UAV行程汇总: tripEnergy=" + tripEnergy
                + ", 终止剩余电量Bf=" + remainBattery
                + ", 额定电量上限=" + Parameter.uavEnergy);
    }

    private static double routeCustomerDemand(List<Node> route) {
        double d = 0;
        for (Node n : route) {
            if (n.type == NodeType.CUSTOMER) {
                d += n.demand;
            }
        }
        return d;
    }

    private static double distance(Node a, Node b) {
        int ia = indexOfNode(a);
        int ib = indexOfNode(b);
        return Parameter.distanceMatrix[ia][ib];
    }

    private static LoadState departureLoadAtNode(Node node,
                                                 double remainingGoods,
                                                 boolean uavOnboard,
                                                 Map<Integer, Double> launchPayloadByNode,
                                                 Map<Integer, Integer> landingCountByNode) {
        double goods = remainingGoods;
        boolean onboard = uavOnboard;

        if (node.type == NodeType.CUSTOMER) {
            goods = Math.max(0, goods - node.demand);
        }
        if (landingCountByNode.getOrDefault(node.id, 0) > 0) {
            onboard = true;
        }
        if (launchPayloadByNode.containsKey(node.id)) {
            goods = Math.max(0, goods - launchPayloadByNode.get(node.id));
            onboard = false;
        }

        double leavingLoad = goods + (onboard ? Parameter.uavWeight : 0);
        LoadState s = new LoadState();
        s.remainingGoods = goods;
        s.uavOnboard = onboard;
        s.leavingLoad = leavingLoad;
        return s;
    }

    private static final class LoadState {
        double remainingGoods;
        boolean uavOnboard;
        double leavingLoad;
    }

    private static int indexOfNode(Node node) {
        for (int i = 0; i < Parameter.allNodes.length; i++) {
            if (Parameter.allNodes[i] == node || Parameter.allNodes[i].id == node.id) {
                return i;
            }
        }
        throw new IllegalStateException("Node not found in allNodes: " + node.id);
    }
}
