import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ALNS {
    private static Solution[] eliteSolutions = new Solution[0];
    private static double[] eliteValues = new double[0];
    private static int eliteCount = 0;

    private static double penaltyOverloadScale = 1.0;
    private static double penaltyTimeScale = 1.0;
    private static double penaltyEnergyScale = 1.0;
    private static double penaltyStructureScale = 1.0;
    private static int penaltyWindowSamples = 0;
    private static int penaltyWindowFeasible = 0;

    public static void solve() {
        Solution seed = new Solution();
        CalculateTool.cloneSolution(seed, Parameter.localSolution);
        double seedValue = seed.getTotalCost();

        Solution globalBest = new Solution();
        CalculateTool.cloneSolution(globalBest, seed);
        double globalBestValue = seedValue;

        initElitePool();
        tryAddElite(seed, seedValue);

        int restarts = Math.max(1, Parameter.alnsRestarts);
        for (int rs = 0; rs < restarts; rs++) {
            resetAdaptivePenaltyState();

            // restart initialization
            CalculateTool.clearSolution(Parameter.localSolution);
            CalculateTool.cloneSolution(Parameter.localSolution, seed);
            Parameter.localSolutionValue = Parameter.localSolution.getTotalCost();

            CalculateTool.clearSolution(Parameter.bestSolution);
            CalculateTool.cloneSolution(Parameter.bestSolution, Parameter.localSolution);
            Parameter.bestSolutionValue = Parameter.localSolutionValue;
            tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);

            // light perturbation for non-first restart
            if (rs > 0) {
                for (int k = 0; k < 2; k++) {
                    CalculateTool.clearSolution(Parameter.newSolution);
                    CalculateTool.cloneSolution(Parameter.newSolution, Parameter.localSolution);
                    Destroy.apply(Parameter.newSolution, 0);
                    Repair.apply(Parameter.newSolution, 0);
                    double v = Parameter.newSolution.getTotalCost();
                    if (isBetter(Parameter.newSolution, Parameter.localSolution)) {
                        CalculateTool.clearSolution(Parameter.localSolution);
                        CalculateTool.cloneSolution(Parameter.localSolution, Parameter.newSolution);
                        Parameter.localSolutionValue = v;
                        tryAddElite(Parameter.localSolution, v);
                    }
                }
                CalculateTool.clearSolution(Parameter.bestSolution);
                CalculateTool.cloneSolution(Parameter.bestSolution, Parameter.localSolution);
                Parameter.bestSolutionValue = Parameter.localSolutionValue;
            }

            resetOperatorWeights();
            double cooling = Parameter.saCooling;
            int noImproveIter = 0;
            int baseRemove = Math.max(1, Parameter.removeNodeNumber);
            int baseInsertK = Math.max(1, Parameter.insertionCandidateK);
            double T = Parameter.saAutoTune
                    ? autoTuneInitialTemperature(baseRemove, baseInsertK)
                    : Parameter.saInitTemp;

            for (int iter = 0; iter < Parameter.maxIteration; iter++) {
                CalculateTool.clearSolution(Parameter.newSolution);
                CalculateTool.cloneSolution(Parameter.newSolution, Parameter.localSolution);
                Parameter.removeNodeList.clear();

                Parameter.removeNodeNumber = adaptiveRemoveSize(baseRemove, noImproveIter);
                Parameter.insertionCandidateK = adaptiveInsertionCandidateK(baseInsertK, noImproveIter);
                selectOperators(noImproveIter);
                if (Parameter.destroySelection == 4) {
                    int boosted = Parameter.removeNodeNumber + 2;
                    Parameter.removeNodeNumber = Math.min(
                            Math.max(1, Parameter.alnsMaxRemoveNodeNumber), boosted);
                }

                Destroy.apply(Parameter.newSolution, Parameter.destroySelection);
                Repair.apply(Parameter.newSolution, Parameter.repairSelection);

                double newValue = Parameter.newSolution.getTotalCost();
                updateAdaptivePenaltyWindow(Parameter.newSolution.feasible);
                double newSearch = searchScore(Parameter.newSolution);
                AcceptResult result = acceptSolution(T, newValue, newSearch);
                updateOperatorWeights(result);
                tryAddElite(Parameter.newSolution, newValue);
                tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);

                if (result == AcceptResult.NEW_BEST) {
                    noImproveIter = 0;
                } else {
                    noImproveIter++;
                }

                if (shouldFeasibilityRescue(noImproveIter)) {
                    AcceptResult rescueResult = feasibilityRescue(baseRemove, baseInsertK, T, noImproveIter);
                    if (rescueResult == AcceptResult.NEW_BEST) {
                        noImproveIter = 0;
                    } else if (rescueResult != AcceptResult.REJECT) {
                        noImproveIter = Math.max(0, noImproveIter - 1);
                    }
                }

                if (shouldEliteInject(iter, noImproveIter)) {
                    AcceptResult eliteResult = eliteGuidedKick(baseRemove, T, noImproveIter);
                    if (eliteResult == AcceptResult.NEW_BEST) {
                        noImproveIter = 0;
                    } else if (eliteResult != AcceptResult.REJECT) {
                        noImproveIter = Math.max(0, noImproveIter - 1);
                    }
                }

                if (shouldPathRelinkInject(iter, noImproveIter)) {
                    AcceptResult relinkResult = pathRelinkingKick(T, noImproveIter);
                    if (relinkResult == AcceptResult.NEW_BEST) {
                        noImproveIter = 0;
                    } else if (relinkResult != AcceptResult.REJECT) {
                        noImproveIter = Math.max(0, noImproveIter - 1);
                    }
                }

                if (shouldDiversify(noImproveIter)) {
                    diversificationKick(baseRemove);
                    noImproveIter = 0;
                    T = Math.max(T, Parameter.saInitTemp);
                }

                if (shouldReheat(noImproveIter)) {
                    double tMax = Parameter.saInitTemp * Math.max(1.0, Parameter.alnsMaxTempMultiplier);
                    T = Math.min(T * Parameter.alnsReheatFactor, tMax);
                }
                T *= cooling;
            }
            Parameter.removeNodeNumber = baseRemove;
            Parameter.insertionCandidateK = baseInsertK;

            if (isBetter(Parameter.bestSolution, globalBest)) {
                CalculateTool.clearSolution(globalBest);
                CalculateTool.cloneSolution(globalBest, Parameter.bestSolution);
                globalBestValue = Parameter.bestSolutionValue;
                tryAddElite(globalBest, globalBestValue);
            }
        }

        CalculateTool.clearSolution(Parameter.bestSolution);
        CalculateTool.cloneSolution(Parameter.bestSolution, globalBest);
        Parameter.bestSolutionValue = globalBestValue;

        CalculateTool.clearSolution(Parameter.localSolution);
        CalculateTool.cloneSolution(Parameter.localSolution, globalBest);
        Parameter.localSolutionValue = globalBestValue;
    }

    private static void selectOperators(int noImproveIter) {
        if (noImproveIter >= Parameter.alnsStagnationDestroyBoostIters && CalculateTool.randomDouble() < 0.6) {
            double r = CalculateTool.randomDouble();
            // During stagnation, emphasize station-aware perturbation slightly more.
            if (r < 0.45) {
                Parameter.destroySelection = 3;
            } else if (r < 0.85) {
                Parameter.destroySelection = 4;
            } else {
                Parameter.destroySelection = 2;
            }
        } else {
            Parameter.destroySelection = rouletteSelect(Parameter.wDestroy);
        }
        Parameter.repairSelection = rouletteSelect(Parameter.wRepair);
    }

    private static int adaptiveRemoveSize(int baseRemove, int noImproveIter) {
        int boost = noImproveIter / Math.max(1, Parameter.alnsStagnationDestroyBoostIters);
        int val = baseRemove + boost;
        int ub = Math.max(baseRemove, Parameter.alnsMaxRemoveNodeNumber);
        return Math.max(1, Math.min(val, ub));
    }

    private static int adaptiveInsertionCandidateK(int baseK, int noImproveIter) {
        if (Parameter.localSolution.feasible) {
            return baseK;
        }
        int period = Math.max(1, Parameter.alnsInsertionBoostIters);
        int boost = (noImproveIter / period) * 2;
        int ub = Math.max(baseK, Parameter.alnsMaxInsertionCandidateK);
        return Math.max(1, Math.min(baseK + boost, ub));
    }

    private static double autoTuneInitialTemperature(int baseRemove, int baseInsertK) {
        int samples = Math.max(4, Parameter.saCalibrateSamples);
        double baseValue = Parameter.localSolutionValue;
        if (!Double.isFinite(baseValue) || baseValue <= 0) {
            return Parameter.saInitTemp;
        }

        int oldRemove = Parameter.removeNodeNumber;
        int oldDestroy = Parameter.destroySelection;
        int oldRepair = Parameter.repairSelection;
        int oldInsertK = Parameter.insertionCandidateK;

        Solution probe = new Solution();
        double uphillSum = 0;
        int uphillCount = 0;

        for (int i = 0; i < samples; i++) {
            CalculateTool.clearSolution(probe);
            CalculateTool.cloneSolution(probe, Parameter.localSolution);
            Parameter.removeNodeList.clear();

            Parameter.removeNodeNumber = Math.min(
                    adaptiveRemoveSize(baseRemove, i), Math.max(1, Parameter.alnsMaxRemoveNodeNumber));
            Parameter.insertionCandidateK = Math.min(
                    Math.max(1, Parameter.alnsMaxInsertionCandidateK),
                    Math.max(1, baseInsertK + 2));
            Parameter.destroySelection = i % Parameter.wDestroy.length;
            Parameter.repairSelection = (i + 1) % Parameter.wRepair.length;

            Destroy.apply(probe, Parameter.destroySelection);
            Repair.apply(probe, Parameter.repairSelection);

            double value = probe.getTotalCost();
            double delta = value - baseValue;
            if (delta > 1e-9 && Double.isFinite(delta)) {
                uphillSum += delta;
                uphillCount++;
            }
        }

        Parameter.removeNodeNumber = oldRemove;
        Parameter.destroySelection = oldDestroy;
        Parameter.repairSelection = oldRepair;
        Parameter.insertionCandidateK = oldInsertK;

        if (uphillCount == 0) {
            return Parameter.saInitTemp;
        }

        double avgUphill = uphillSum / uphillCount;
        double p = Math.max(0.05, Math.min(0.90, Parameter.saTargetAcceptProb));
        double tuned = -avgUphill / Math.log(p);
        double tMin = Math.max(1e-6, Parameter.saInitTemp * 0.2);
        double tMax = Parameter.saInitTemp * Math.max(1.0, Parameter.alnsMaxTempMultiplier);
        if (!Double.isFinite(tuned)) {
            return Parameter.saInitTemp;
        }
        return Math.max(tMin, Math.min(tuned, tMax));
    }

    private static boolean shouldFeasibilityRescue(int noImproveIter) {
        int period = Math.max(1, Parameter.alnsFeasibilityRescueIters);
        return !Parameter.localSolution.feasible
                && noImproveIter > 0
                && noImproveIter % period == 0;
    }

    private static boolean shouldReheat(int noImproveIter) {
        int period = Math.max(1, Parameter.alnsNoImproveReheatIters);
        return noImproveIter > 0 && noImproveIter % period == 0;
    }

    private static boolean shouldDiversify(int noImproveIter) {
        return noImproveIter >= Math.max(1, Parameter.alnsDiversifyIters);
    }

    private static boolean shouldEliteInject(int iter, int noImproveIter) {
        int period = Math.max(1, Parameter.alnsEliteInjectIters);
        return eliteCount > 0
                && noImproveIter >= Math.max(1, Parameter.alnsStagnationDestroyBoostIters)
                && iter > 0
                && iter % period == 0;
    }

    private static boolean shouldPathRelinkInject(int iter, int noImproveIter) {
        int period = Math.max(1, Parameter.alnsPathRelinkInjectIters);
        if (eliteCount <= 1 || iter <= 0 || iter % period != 0) {
            return false;
        }
        if (noImproveIter < Math.max(1, Parameter.alnsStagnationDestroyBoostIters / 2)) {
            return false;
        }
        return CalculateTool.randomDouble() < Parameter.alnsPathRelinkProb;
    }

    private static AcceptResult feasibilityRescue(int baseRemove, int baseInsertK, double T, int noImproveIter) {
        int oldRemove = Parameter.removeNodeNumber;
        int oldInsertK = Parameter.insertionCandidateK;
        AcceptResult bestResult = AcceptResult.REJECT;

        int rounds = Math.max(1, Parameter.alnsFeasibilityRescueRounds);
        for (int k = 0; k < rounds; k++) {
            CalculateTool.clearSolution(Parameter.newSolution);
            CalculateTool.cloneSolution(Parameter.newSolution, Parameter.localSolution);
            Parameter.removeNodeList.clear();

            int remove = adaptiveRemoveSize(baseRemove, noImproveIter) + 2 + k;
            Parameter.removeNodeNumber = Math.min(remove, Math.max(1, Parameter.alnsMaxRemoveNodeNumber));
            Parameter.insertionCandidateK = Math.min(
                    Math.max(1, Parameter.alnsMaxInsertionCandidateK),
                    Math.max(baseInsertK + 2, oldInsertK));

            Parameter.destroySelection = (k % 2 == 0) ? 4 : 3;
            Parameter.repairSelection = (k % 2 == 0) ? 3 : 2;

            Destroy.apply(Parameter.newSolution, Parameter.destroySelection);
            Repair.apply(Parameter.newSolution, Parameter.repairSelection);

            double nv = Parameter.newSolution.getTotalCost();
            updateAdaptivePenaltyWindow(Parameter.newSolution.feasible);
            double ns = searchScore(Parameter.newSolution);
            double rescueT = Math.max(T, Parameter.saInitTemp);
            AcceptResult result = acceptSolution(rescueT, nv, ns);
            updateOperatorWeights(result);
            tryAddElite(Parameter.newSolution, nv);
            tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);

            if (resultRank(result) > resultRank(bestResult)) {
                bestResult = result;
            }
        }

        Parameter.removeNodeNumber = oldRemove;
        Parameter.insertionCandidateK = oldInsertK;
        return bestResult;
    }

    private static AcceptResult eliteGuidedKick(int baseRemove, double T, int noImproveIter) {
        int oldRemove = Parameter.removeNodeNumber;
        AcceptResult bestResult = AcceptResult.REJECT;

        int rounds = Math.max(1, Parameter.alnsEliteKickRounds);
        for (int k = 0; k < rounds; k++) {
            Solution guide = pickEliteGuide();
            if (guide == null) {
                break;
            }

            CalculateTool.clearSolution(Parameter.newSolution);
            CalculateTool.cloneSolution(Parameter.newSolution, guide);
            Parameter.removeNodeList.clear();

            int remove = adaptiveRemoveSize(baseRemove, noImproveIter) + Parameter.alnsEliteDestroyBoost + k;
            Parameter.removeNodeNumber = Math.min(remove, Math.max(1, Parameter.alnsMaxRemoveNodeNumber));
            Parameter.destroySelection = 4;
            Parameter.repairSelection = (k % 2 == 0) ? 3 : 2;

            Destroy.apply(Parameter.newSolution, Parameter.destroySelection);
            Repair.apply(Parameter.newSolution, Parameter.repairSelection);

            double nv = Parameter.newSolution.getTotalCost();
            updateAdaptivePenaltyWindow(Parameter.newSolution.feasible);
            double ns = searchScore(Parameter.newSolution);
            AcceptResult result = acceptSolution(T, nv, ns);
            if (result == AcceptResult.REJECT && CalculateTool.randomDouble() < Parameter.alnsEliteAcceptProb) {
                if (canAdoptEliteCandidate(Parameter.newSolution, Parameter.localSolution)) {
                    adoptNewAsLocal(nv);
                    result = AcceptResult.ACCEPT_NON_IMPROVE;
                }
            }

            if (result == AcceptResult.NEW_BEST) {
                updateOperatorWeights(result);
                tryAddElite(Parameter.bestSolution, Parameter.bestSolutionValue);
            }
            tryAddElite(Parameter.newSolution, nv);
            tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);

            if (resultRank(result) > resultRank(bestResult)) {
                bestResult = result;
            }
        }

        Parameter.removeNodeNumber = oldRemove;
        return bestResult;
    }

    private static AcceptResult pathRelinkingKick(double T, int noImproveIter) {
        Solution guide = pickPathRelinkGuide();
        if (guide == null) {
            return AcceptResult.REJECT;
        }

        Solution working = new Solution();
        CalculateTool.cloneSolution(working, Parameter.localSolution);
        Solution guideCopy = new Solution();
        CalculateTool.cloneSolution(guideCopy, guide);

        Repair.recoverUavCustomersToEvRoutes(working);
        Repair.recoverUavCustomersToEvRoutes(guideCopy);

        int extra = noImproveIter / Math.max(1, Parameter.alnsStagnationDestroyBoostIters);
        int steps = Math.max(1, Parameter.alnsPathRelinkSteps + extra);
        boolean moved = pathRelinkTowardsGuide(working, guideCopy, steps);
        if (!moved) {
            return AcceptResult.REJECT;
        }

        Parameter.removeNodeList.clear();
        Repair.apply(working, CalculateTool.randomDouble() < 0.5 ? 2 : 3);

        double nv = working.getTotalCost();
        updateAdaptivePenaltyWindow(working.feasible);
        double ns = searchScore(working);

        CalculateTool.clearSolution(Parameter.newSolution);
        CalculateTool.cloneSolution(Parameter.newSolution, working);

        double relinkT = Math.max(T, Parameter.saInitTemp * 0.6);
        AcceptResult result = acceptSolution(relinkT, nv, ns);
        tryAddElite(working, nv);
        tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);
        return result;
    }

    private static boolean pathRelinkTowardsGuide(Solution working, Solution guide, int steps) {
        Map<Integer, Integer> guideRouteMap = buildCustomerRouteMap(guide);
        if (guideRouteMap.isEmpty()) {
            return false;
        }

        boolean moved = false;
        for (int k = 0; k < steps; k++) {
            Integer customerId = selectRouteMismatchCustomer(working, guideRouteMap);
            if (customerId == null) {
                break;
            }
            int targetRoute = guideRouteMap.getOrDefault(customerId, -1);
            if (!relocateCustomerTowardsGuide(working, guide, customerId, targetRoute)) {
                break;
            }
            moved = true;
        }
        return moved;
    }

    private static Integer selectRouteMismatchCustomer(Solution working, Map<Integer, Integer> guideRouteMap) {
        Map<Integer, Integer> currentMap = buildCustomerRouteMap(working);
        List<Integer> mismatch = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : guideRouteMap.entrySet()) {
            Integer curRoute = currentMap.get(e.getKey());
            if (curRoute == null || !curRoute.equals(e.getValue())) {
                mismatch.add(e.getKey());
            }
        }
        if (mismatch.isEmpty()) {
            return null;
        }
        return mismatch.get(CalculateTool.intRandom(0, mismatch.size()));
    }

    private static boolean relocateCustomerTowardsGuide(
            Solution working, Solution guide, int customerId, int targetRouteIdx) {
        CustomerLoc from = locateCustomer(working, customerId);
        if (from == null) {
            return false;
        }

        int target = targetRouteIdx;
        if (target < 0 || target >= working.evRoutes.length) {
            target = from.routeIdx;
        }

        EV_Route src = working.evRoutes[from.routeIdx];
        EV_Route dst = working.evRoutes[target];
        Node customer = from.node;

        src.route.remove(from.pos);

        List<Node> guideRouteNodes = guide.evRoutes[target].route;
        int insertPos = suggestInsertPos(dst, guideRouteNodes, customerId);
        if (src == dst && insertPos > from.pos) {
            insertPos--;
        }
        insertPos = Math.max(1, Math.min(insertPos, dst.route.size() - 1));
        dst.route.add(insertPos, customer);

        src.uavTrips.clear();
        if (dst != src) {
            dst.uavTrips.clear();
        }
        return true;
    }

    private static int suggestInsertPos(EV_Route targetRoute, List<Node> guideRouteNodes, int customerId) {
        int guidePos = indexOfNodeId(guideRouteNodes, customerId);
        if (guidePos < 0) {
            return targetRoute.route.size() - 1;
        }

        for (int i = guidePos - 1; i >= 0; i--) {
            int anchorId = guideRouteNodes.get(i).id;
            int pos = indexOfNodeId(targetRoute.route, anchorId);
            if (pos >= 0 && pos < targetRoute.route.size() - 1) {
                return pos + 1;
            }
        }
        for (int i = guidePos + 1; i < guideRouteNodes.size(); i++) {
            int anchorId = guideRouteNodes.get(i).id;
            int pos = indexOfNodeId(targetRoute.route, anchorId);
            if (pos >= 0) {
                return pos;
            }
        }
        return targetRoute.route.size() - 1;
    }

    private static CustomerLoc locateCustomer(Solution s, int customerId) {
        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            for (int i = 1; i < route.route.size() - 1; i++) {
                Node n = route.route.get(i);
                if (n.type == NodeType.CUSTOMER && n.id == customerId) {
                    CustomerLoc loc = new CustomerLoc();
                    loc.routeIdx = r;
                    loc.pos = i;
                    loc.node = n;
                    return loc;
                }
            }
        }
        return null;
    }

    private static int indexOfNodeId(List<Node> route, int nodeId) {
        for (int i = 0; i < route.size(); i++) {
            if (route.get(i).id == nodeId) {
                return i;
            }
        }
        return -1;
    }

    private static Map<Integer, Integer> buildCustomerRouteMap(Solution s) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            for (Node n : route.route) {
                if (n.type == NodeType.CUSTOMER) {
                    map.put(n.id, r);
                }
            }
            for (List<Node> trip : route.uavTrips) {
                for (int i = 1; i < trip.size() - 1; i++) {
                    Node n = trip.get(i);
                    if (n.type == NodeType.CUSTOMER) {
                        map.put(n.id, r);
                    }
                }
            }
        }
        return map;
    }

    private static boolean canAdoptEliteCandidate(Solution cand, Solution local) {
        if (cand.feasible && !local.feasible) {
            return true;
        }
        if (!cand.feasible && local.feasible) {
            return false;
        }
        return true;
    }

    private static void adoptNewAsLocal(double newValue) {
        CalculateTool.clearSolution(Parameter.localSolution);
        CalculateTool.cloneSolution(Parameter.localSolution, Parameter.newSolution);
        Parameter.localSolutionValue = newValue;

        if (isBetter(Parameter.newSolution, Parameter.bestSolution)) {
            CalculateTool.clearSolution(Parameter.bestSolution);
            CalculateTool.cloneSolution(Parameter.bestSolution, Parameter.newSolution);
            Parameter.bestSolutionValue = newValue;
        }
    }

    private static void diversificationKick(int baseRemove) {
        int oldRemove = Parameter.removeNodeNumber;
        int kickRemove = Math.max(baseRemove + 2, oldRemove);
        kickRemove = Math.min(kickRemove, Math.max(1, Parameter.alnsMaxRemoveNodeNumber));
        Parameter.removeNodeNumber = kickRemove;

        for (int k = 0; k < Math.max(1, Parameter.alnsDiversifyRounds); k++) {
            CalculateTool.clearSolution(Parameter.newSolution);
            CalculateTool.cloneSolution(Parameter.newSolution, Parameter.localSolution);
            Parameter.removeNodeList.clear();

            if (k % 3 == 0) {
                Parameter.destroySelection = 4;
                Parameter.repairSelection = 3;
            } else if (k % 3 == 1) {
                Parameter.destroySelection = 3;
                Parameter.repairSelection = 1;
            } else {
                Parameter.destroySelection = 2;
                Parameter.repairSelection = 2;
            }

            Destroy.apply(Parameter.newSolution, Parameter.destroySelection);
            Repair.apply(Parameter.newSolution, Parameter.repairSelection);

            double nv = Parameter.newSolution.getTotalCost();
            if (isBetter(Parameter.newSolution, Parameter.localSolution) || CalculateTool.randomDouble() < 0.3) {
                CalculateTool.clearSolution(Parameter.localSolution);
                CalculateTool.cloneSolution(Parameter.localSolution, Parameter.newSolution);
                Parameter.localSolutionValue = nv;
            }

            if (isBetter(Parameter.newSolution, Parameter.bestSolution)) {
                CalculateTool.clearSolution(Parameter.bestSolution);
                CalculateTool.cloneSolution(Parameter.bestSolution, Parameter.newSolution);
                Parameter.bestSolutionValue = nv;
            }

            tryAddElite(Parameter.newSolution, nv);
            tryAddElite(Parameter.localSolution, Parameter.localSolutionValue);
        }
        Parameter.removeNodeNumber = oldRemove;
    }

    private static AcceptResult acceptSolution(double T, double newValue, double newSearch) {
        boolean localFeasible = Parameter.localSolution.feasible;
        boolean newFeasible = Parameter.newSolution.feasible;
        double localSearch = searchScore(Parameter.localSolution);
        double deltaSearch = newSearch - localSearch;

        boolean accept;
        if (!localFeasible && newFeasible) {
            accept = true;
        } else if (deltaSearch <= 1e-12) {
            accept = true;
        } else {
            double denom = Math.max(T, 1e-9);
            if (localFeasible && !newFeasible) {
                denom *= Math.max(1.0, Parameter.alnsInfeasibleAcceptBias);
            }
            double prob = Math.exp(-deltaSearch / denom);
            accept = CalculateTool.randomDouble() < prob;
        }

        if (!accept) {
            return AcceptResult.REJECT;
        }

        AcceptResult result;
        if (!localFeasible && newFeasible) {
            result = AcceptResult.ACCEPT_IMPROVE;
        } else {
            result = (deltaSearch < -1e-9) ? AcceptResult.ACCEPT_IMPROVE : AcceptResult.ACCEPT_NON_IMPROVE;
        }

        CalculateTool.clearSolution(Parameter.localSolution);
        CalculateTool.cloneSolution(Parameter.localSolution, Parameter.newSolution);
        Parameter.localSolutionValue = newValue;

        if (isBetter(Parameter.newSolution, Parameter.bestSolution)) {
            CalculateTool.clearSolution(Parameter.bestSolution);
            CalculateTool.cloneSolution(Parameter.bestSolution, Parameter.newSolution);
            Parameter.bestSolutionValue = newValue;
            return AcceptResult.NEW_BEST;
        }
        return result;
    }

    private static boolean isBetter(Solution a, Solution b) {
        if (a.feasible && !b.feasible) {
            return true;
        }
        if (!a.feasible && b.feasible) {
            return false;
        }
        return a.totalCost < b.totalCost;
    }

    private static double searchScore(Solution s) {
        double score = s.evUavCost + s.stationOpenCost;
        score += Parameter.alphaOverload * penaltyOverloadScale * s.overloadAmount;
        score += Parameter.betaTimeWindow * penaltyTimeScale * s.timeViolationAmount;
        if (s.energyViolated) {
            score += Parameter.gammaEnergy * penaltyEnergyScale;
        }
        if (s.structureViolated) {
            score += Parameter.gammaRouteStructure * penaltyStructureScale;
        }
        return score;
    }

    private static void resetAdaptivePenaltyState() {
        penaltyOverloadScale = 1.0;
        penaltyTimeScale = 1.0;
        penaltyEnergyScale = 1.0;
        penaltyStructureScale = 1.0;
        penaltyWindowSamples = 0;
        penaltyWindowFeasible = 0;
    }

    private static void updateAdaptivePenaltyWindow(boolean candidateFeasible) {
        if (!Parameter.alnsAdaptivePenalty) {
            return;
        }

        penaltyWindowSamples++;
        if (candidateFeasible) {
            penaltyWindowFeasible++;
        }

        int window = Math.max(5, Parameter.alnsPenaltyUpdateWindow);
        if (penaltyWindowSamples < window) {
            return;
        }

        double ratio = penaltyWindowFeasible / (double) penaltyWindowSamples;
        double target = Math.max(0.05, Math.min(0.95, Parameter.alnsTargetFeasibleRatio));
        double tolerance = 0.03;

        if (ratio < target - tolerance) {
            scalePenaltyFactors(Parameter.alnsPenaltyIncrease);
        } else if (ratio > target + tolerance) {
            scalePenaltyFactors(Parameter.alnsPenaltyDecrease);
        }

        penaltyWindowSamples = 0;
        penaltyWindowFeasible = 0;
    }

    private static void scalePenaltyFactors(double factor) {
        if (!Double.isFinite(factor) || factor <= 0) {
            return;
        }
        penaltyOverloadScale = clampPenaltyScale(penaltyOverloadScale * factor);
        penaltyTimeScale = clampPenaltyScale(penaltyTimeScale * factor);
        penaltyEnergyScale = clampPenaltyScale(penaltyEnergyScale * factor);
        penaltyStructureScale = clampPenaltyScale(penaltyStructureScale * factor);
    }

    private static double clampPenaltyScale(double value) {
        double minScale = Math.max(1e-6, Parameter.alnsPenaltyMinFactor);
        double maxScale = Math.max(minScale, Parameter.alnsPenaltyMaxFactor);
        if (!Double.isFinite(value)) {
            return 1.0;
        }
        if (value < minScale) {
            return minScale;
        }
        if (value > maxScale) {
            return maxScale;
        }
        return value;
    }

    private static int rouletteSelect(double[] weights) {
        double sum = 0;
        for (double w : weights) {
            sum += Math.max(w, Parameter.alnsWeightFloor);
        }
        double r = CalculateTool.randomDouble() * Math.max(sum, 1e-9);
        double c = 0;
        for (int i = 0; i < weights.length; i++) {
            c += Math.max(weights[i], Parameter.alnsWeightFloor);
            if (r <= c) {
                return i;
            }
        }
        return weights.length - 1;
    }

    private static void resetOperatorWeights() {
        for (int i = 0; i < Parameter.wDestroy.length; i++) {
            Parameter.wDestroy[i] = 1.0;
        }
        for (int i = 0; i < Parameter.wRepair.length; i++) {
            Parameter.wRepair[i] = 1.0;
        }
    }

    private static void updateOperatorWeights(AcceptResult result) {
        double reward;
        if (result == AcceptResult.NEW_BEST) {
            reward = Parameter.alnsRewardBest;
        } else if (result == AcceptResult.ACCEPT_IMPROVE) {
            reward = Parameter.alnsRewardImprove;
        } else if (result == AcceptResult.ACCEPT_NON_IMPROVE) {
            reward = Parameter.alnsRewardAccept;
        } else {
            reward = 0.0;
        }

        int d = Parameter.destroySelection;
        int r = Parameter.repairSelection;
        Parameter.wDestroy[d] = blendWeight(Parameter.wDestroy[d], reward);
        Parameter.wRepair[r] = blendWeight(Parameter.wRepair[r], reward);
    }

    private static double blendWeight(double oldWeight, double reward) {
        double rho = Parameter.alnsReactionFactor;
        double val = (1.0 - rho) * oldWeight + rho * reward;
        return Math.max(val, Parameter.alnsWeightFloor);
    }

    private static void initElitePool() {
        int cap = Math.max(1, Parameter.alnsEliteSize);
        eliteSolutions = new Solution[cap];
        eliteValues = new double[cap];
        eliteCount = 0;
    }

    private static void tryAddElite(Solution candidate, double value) {
        if (eliteSolutions.length == 0) {
            return;
        }

        for (int i = 0; i < eliteCount; i++) {
            if (Math.abs(eliteValues[i] - value) <= 1e-9) {
                return;
            }
        }

        int similarIdx = findSimilarEliteIndex(candidate, 0.93);
        if (similarIdx >= 0) {
            if (isBetter(candidate, eliteSolutions[similarIdx])) {
                Solution copy = new Solution();
                CalculateTool.cloneSolution(copy, candidate);
                eliteSolutions[similarIdx] = copy;
                eliteValues[similarIdx] = value;
                sortEliteByQuality();
            }
            return;
        }

        Solution copy = new Solution();
        CalculateTool.cloneSolution(copy, candidate);
        double v = value;

        if (eliteCount < eliteSolutions.length) {
            eliteSolutions[eliteCount] = copy;
            eliteValues[eliteCount] = v;
            eliteCount++;
            sortEliteByQuality();
            return;
        }

        int worst = eliteCount - 1;
        if (isBetter(copy, eliteSolutions[worst])) {
            eliteSolutions[worst] = copy;
            eliteValues[worst] = v;
            sortEliteByQuality();
        }
    }

    private static int findSimilarEliteIndex(Solution candidate, double threshold) {
        for (int i = 0; i < eliteCount; i++) {
            if (eliteSolutions[i] == null) {
                continue;
            }
            if (assignmentSimilarity(candidate, eliteSolutions[i]) >= threshold) {
                return i;
            }
        }
        return -1;
    }

    private static double assignmentSimilarity(Solution a, Solution b) {
        Map<Integer, Integer> mapA = buildCustomerRouteMap(a);
        Map<Integer, Integer> mapB = buildCustomerRouteMap(b);
        int total = 0;
        int same = 0;
        for (Node n : Parameter.allNodes) {
            if (n.type != NodeType.CUSTOMER) {
                continue;
            }
            Integer ra = mapA.get(n.id);
            Integer rb = mapB.get(n.id);
            if (ra == null && rb == null) {
                continue;
            }
            total++;
            if (ra != null && ra.equals(rb)) {
                same++;
            }
        }
        if (total == 0) {
            return 1.0;
        }
        return same / (double) total;
    }

    private static Solution pickEliteGuide() {
        if (eliteCount == 0) {
            return null;
        }
        int top = Math.max(1, eliteCount / 2 + 1);
        int idx = CalculateTool.intRandom(0, top);
        return eliteSolutions[idx];
    }

    private static Solution pickPathRelinkGuide() {
        if (eliteCount == 0) {
            return null;
        }
        Solution best = null;
        double bestScore = -Double.MAX_VALUE;
        for (int i = 0; i < eliteCount; i++) {
            Solution cand = eliteSolutions[i];
            if (cand == null) {
                continue;
            }
            double sim = assignmentSimilarity(cand, Parameter.localSolution);
            if (sim > 0.995) {
                continue;
            }

            double score = (1.0 - sim);
            if (cand.feasible) {
                score += 0.12;
            }
            if (isBetter(cand, Parameter.localSolution)) {
                score += 0.12;
            }
            if (score > bestScore) {
                bestScore = score;
                best = cand;
            }
        }
        if (best != null) {
            return best;
        }
        return pickEliteGuide();
    }

    private static void sortEliteByQuality() {
        for (int i = 0; i < eliteCount; i++) {
            for (int j = i + 1; j < eliteCount; j++) {
                if (isBetter(eliteSolutions[j], eliteSolutions[i])) {
                    Solution ts = eliteSolutions[i];
                    eliteSolutions[i] = eliteSolutions[j];
                    eliteSolutions[j] = ts;

                    double tv = eliteValues[i];
                    eliteValues[i] = eliteValues[j];
                    eliteValues[j] = tv;
                }
            }
        }
    }

    private static int resultRank(AcceptResult r) {
        if (r == AcceptResult.NEW_BEST) {
            return 3;
        }
        if (r == AcceptResult.ACCEPT_IMPROVE) {
            return 2;
        }
        if (r == AcceptResult.ACCEPT_NON_IMPROVE) {
            return 1;
        }
        return 0;
    }

    private enum AcceptResult {
        REJECT,
        ACCEPT_NON_IMPROVE,
        ACCEPT_IMPROVE,
        NEW_BEST
    }

    private static final class CustomerLoc {
        int routeIdx;
        int pos;
        Node node;
    }
}
