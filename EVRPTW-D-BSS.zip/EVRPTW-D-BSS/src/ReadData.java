import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadData {

    public static void init() {
        // 每次读新实例前重置三类解与移除池。
        Parameter.localSolution = new Solution();
        Parameter.newSolution = new Solution();
        Parameter.bestSolution = new Solution();
        Parameter.removeNodeList.clear();
    }

    public static void importInfo(String path) throws Exception {
        // 统一解析 CUSTOMER/STATION 块，兼容 Solomon 风格头部。
        List<Node> parsed = new ArrayList<>();
        boolean inNodeBlock = false;
        boolean inStationBlock = false;

        int declaredVehicleNum = -1;
        double declaredVehicleCap = -1;

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (t.isEmpty()) {
                    continue;
                }

                String upper = t.toUpperCase();

                if (upper.startsWith("VEHICLE")) {
                    inNodeBlock = false;
                    inStationBlock = false;
                    continue;
                }

                if (upper.startsWith("CUSTOMER")) {
                    inNodeBlock = true;
                    inStationBlock = false;
                    continue;
                }

                if (upper.startsWith("STATION") || upper.startsWith("BSS")) {
                    inNodeBlock = true;
                    inStationBlock = true;
                    continue;
                }

                // Solomon 风格：车辆数量 + 车辆容量。
                if (declaredVehicleNum < 0 && t.matches("^\\d+\\s+\\d+(\\.\\d+)?$")) {
                    String[] sp = t.split("\\s+");
                    declaredVehicleNum = Integer.parseInt(sp[0]);
                    declaredVehicleCap = Double.parseDouble(sp[1]);
                    continue;
                }

                // 节点行至少包含 7 列数值字段。
                String[] sp = t.split("\\s+");
                if (!inNodeBlock || sp.length < 7 || !isInteger(sp[0])) {
                    continue;
                }

                Node n = new Node();
                n.id = Integer.parseInt(sp[0]);
                n.x = Double.parseDouble(sp[1]);
                n.y = Double.parseDouble(sp[2]);
                n.demand = Double.parseDouble(sp[3]);
                n.readyTime = Double.parseDouble(sp[4]);
                n.dueTime = Double.parseDouble(sp[5]);
                n.serviceTime = Double.parseDouble(sp[6]);

                if (n.id == 0) {
                    n.type = NodeType.DEPOT;
                } else if (inStationBlock) {
                    n.type = NodeType.STATION;
                } else {
                    // 兼容模式：若无 STATION 块，零需求节点按站点处理。
                    if (n.demand == 0 && n.id != 0) {
                        n.type = NodeType.STATION;
                    } else {
                        n.type = NodeType.CUSTOMER;
                    }
                }

                parsed.add(n);
            }
        }

        if (parsed.isEmpty()) {
            throw new IllegalArgumentException("No nodes parsed from instance: " + path);
        }

        // 可选：从实例同步车辆数量与容量参数。
//        if (declaredVehicleNum > 0) {
//            Parameter.evCount = declaredVehicleNum;
//        }
//        if (declaredVehicleCap > 0) {
//            Parameter.evCapacity = declaredVehicleCap;
//        }

        // 拆分 depot/customers/stations，并保证 depot 存在。
        Node depot = null;
        List<Node> customers = new ArrayList<>();
        List<Node> stations = new ArrayList<>();
        for (Node n : parsed) {
            if (n.id == 0 && depot == null) {
                depot = n;
                depot.type = NodeType.DEPOT;
            } else if (n.type == NodeType.STATION) {
                stations.add(n);
            } else {
                customers.add(n);
            }
        }
        if (depot == null) {
            throw new IllegalArgumentException("Depot (id=0) not found in instance: " + path);
        }

        // 按坐标聚合同一物理站点，便于统一计开启成本。
        assignPhysicalStationIds(stations);

        Parameter.customerCount = customers.size();
        Parameter.stationCount = stations.size();

        List<Node> all = new ArrayList<>();
        all.add(depot);
        all.addAll(customers);
        all.addAll(stations);

        Node virtualDepot = new Node();
        virtualDepot.id = depot.id + 1_000_000;
        virtualDepot.x = depot.x;
        virtualDepot.y = depot.y;
        virtualDepot.demand = 0;
        virtualDepot.readyTime = depot.readyTime;
        virtualDepot.dueTime = depot.dueTime;
        virtualDepot.serviceTime = 0;
        virtualDepot.type = NodeType.VIRTUAL_DEPOT;
        all.add(virtualDepot);

        Parameter.nodeCount = all.size();
        Parameter.depotIndex = 0;
        Parameter.virtualDepotIndex = all.size() - 1;
        Parameter.allNodes = all.toArray(new Node[0]);

        // 若 EV 数量被实例覆盖，需要重建解对象内部数组。
        Parameter.localSolution = new Solution();
        Parameter.newSolution = new Solution();
        Parameter.bestSolution = new Solution();
    }

    private static void assignPhysicalStationIds(List<Node> stations) {
        // 同坐标站点副本共享 physicalStationId。
        Map<String, Integer> key2pid = new HashMap<>();
        int pid = 0;
        for (Node s : stations) {
            String key = s.x + "#" + s.y;
            if (!key2pid.containsKey(key)) {
                key2pid.put(key, pid++);
            }
            s.physicalStationId = key2pid.get(key);
        }
    }

    private static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
