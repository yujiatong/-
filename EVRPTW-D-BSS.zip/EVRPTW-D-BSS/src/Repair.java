import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Repair {
    public static void apply(Solution s, int op) {
        switch (op) {
            case 0:
                randomRepair(s);
                break;
            case 1:
                greedyRepair(s);
                break;
            case 2:
                stationAwareRepair(s);
                break;
            case 3:
                regretRepair(s);
                break;
            default:
                randomRepair(s);
        }
    }

    private static void randomRepair(Solution s) {
        List<Node> pool = new ArrayList<>(Parameter.removeNodeList);
        CalculateTool.shuffleList(pool);
        for (Node n : pool) {
            insertBestWithTieRandom(s, n);
        }
        improveEvRoutes(s);
        optimizeStations(s);
        interRouteRelocate(s, 25);
        interRouteSwap(s, 12);
        rebuildUavTrips(s);
        Parameter.removeNodeList.clear();
    }

    private static void greedyRepair(Solution s) {
        List<Node> pool = new ArrayList<>(Parameter.removeNodeList);
        pool.sort(Comparator.comparingDouble(a -> a.dueTime));
        for (Node n : pool) {
            insertBest(s, n);
        }
        improveEvRoutes(s);
        optimizeStations(s);
        interRouteRelocate(s, 25);
        interRouteSwap(s, 12);
        rebuildUavTrips(s);
        Parameter.removeNodeList.clear();
    }

    private static void stationAwareRepair(Solution s) {
        List<Node> pool = new ArrayList<>(Parameter.removeNodeList);
        if (pool.isEmpty()) {
            improveEvRoutes(s);
            optimizeStations(s);
            interRouteRelocate(s, 25);
            interRouteSwap(s, 10);
            rebuildUavTrips(s);
            Parameter.removeNodeList.clear();
            return;
        }

        // Customers closer to current opened stations are inserted earlier.
        pool.sort(Comparator.comparingDouble(a -> nearestOpenedStationDistance(s, a)));
        int cnt = 0;
        for (Node n : pool) {
            insertBest(s, n);
            cnt++;
            if (cnt % 2 == 0) {
                optimizeStations(s);
            }
        }
        improveEvRoutes(s);
        optimizeStations(s);
        interRouteRelocate(s, 30);
        interRouteSwap(s, 15);
        rebuildUavTrips(s);
        Parameter.removeNodeList.clear();
    }

    private static void regretRepair(Solution s) {
        List<Node> pool = new ArrayList<>(Parameter.removeNodeList);
        while (!pool.isEmpty()) {
            Node bestNode = null;
            double bestRegret = -Double.MAX_VALUE;

            for (Node n : pool) {
                List<Double> topTwo = bestTwoInsertCosts(s, n);
                if (topTwo.isEmpty()) {
                    continue;
                }
                double regret = (topTwo.size() == 1) ? (1_000_000 - topTwo.get(0)) : (topTwo.get(1) - topTwo.get(0));
                if (regret > bestRegret) {
                    bestRegret = regret;
                    bestNode = n;
                }
            }

            if (bestNode == null) {
                break;
            }
            insertBest(s, bestNode);
            pool.remove(bestNode);
        }
        improveEvRoutes(s);
        optimizeStations(s);
        interRouteRelocate(s, 25);
        interRouteSwap(s, 12);
        rebuildUavTrips(s);
        Parameter.removeNodeList.clear();
    }

    public static void rebuildUavCustomersForInitial(Solution s) {
        improveEvRoutes(s);
        optimizeStations(s);
        interRouteRelocate(s, 20);
        interRouteSwap(s, 10);
        rebuildUavTrips(s);
    }

    public static void recoverUavCustomersToEvRoutes(Solution s) {
        for (EV_Route r : s.evRoutes) {
            if (r.uavTrips.isEmpty()) {
                continue;
            }
            for (List<Node> trip : r.uavTrips) {
                if (trip.size() < 3) {
                    continue;
                }
                Node landing = trip.get(trip.size() - 1);
                int landingIdx = indexOfNode(r.route, landing);
                if (landingIdx < 0) {
                    landingIdx = Math.max(1, r.route.size() - 1);
                }
                for (int i = 1; i < trip.size() - 1; i++) {
                    Node customer = trip.get(i);
                    if (customer.type != NodeType.CUSTOMER) {
                        continue;
                    }
                    if (indexOfNode(r.route, customer) >= 0) {
                        continue;
                    }
                    r.route.add(landingIdx, customer);
                    landingIdx++;
                }
            }
            r.uavTrips.clear();
        }
    }

    // --------- UAV rebuild (gain-driven) ---------

    private static void rebuildUavTrips(Solution s) {
        for (EV_Route r : s.evRoutes) {
            rebuildUavTripsForRoute(r);
        }
    }

    private static void rebuildUavTripsForRoute(EV_Route route) {
        route.uavTrips.clear();
        if (route.route.size() < 4) {
            return;
        }

        CalculateTool.updateEVRouteMetrics(route);
        double baseScore = routeScore(route);

        int guard = 0;
        while (guard++ < 100) {
            SortieCandidate best = null;
            for (int startIdx = 1; startIdx < route.route.size() - 2; startIdx++) {
                SortieCandidate cand = evaluateSortieCandidate(route, startIdx, baseScore);
                if (cand == null) {
                    continue;
                }
                if (best == null || cand.improvement > best.improvement + 1e-9) {
                    best = cand;
                }
            }

            if (best == null) {
                break;
            }

            applySortie(route, best);
            CalculateTool.updateEVRouteMetrics(route);
            baseScore = routeScore(route);
        }
    }

    private static SortieCandidate evaluateSortieCandidate(EV_Route route, int startIdx, double baseScore) {
        Node start = route.route.get(startIdx);
        if (!isMeetingNode(start) || nodeUsedInTrip(route, start)) {
            return null;
        }

        int maxLanding = Math.min(route.route.size() - 2, startIdx + Parameter.uavTripMaxCustomers + 1);
        SortieCandidate best = null;

        for (int landingIdx = startIdx + 2; landingIdx <= maxLanding; landingIdx++) {
            Node landing = route.route.get(landingIdx);
            if (!isMeetingNode(landing) || nodeUsedInTrip(route, landing)) {
                continue;
            }

            boolean ok = true;
            double movedDemand = 0;
            List<Node> movedCustomers = new ArrayList<>();
            for (int i = startIdx + 1; i < landingIdx; i++) {
                Node n = route.route.get(i);
                if (n.type != NodeType.CUSTOMER || nodeUsedInTrip(route, n)) {
                    ok = false;
                    break;
                }
                movedDemand += n.demand;
                movedCustomers.add(n);
            }
            if (!ok || movedCustomers.isEmpty() || movedDemand > Parameter.uavCapacity + 1e-9) {
                continue;
            }

            EV_Route test = cloneRoute(route);
            List<Node> trip = new ArrayList<>();
            trip.add(start);
            trip.addAll(movedCustomers);
            trip.add(landing);

            for (int i = landingIdx - 1; i >= startIdx + 1; i--) {
                test.route.remove(i);
            }
            test.uavTrips.add(trip);

            CalculateTool.updateEVRouteMetrics(test);
            if (test.overload > 1e-9 || test.timeViolation > 1e-9 || test.energyViolated || test.structureViolated) {
                continue;
            }

            double improvement = baseScore - routeScore(test);
            if (improvement <= 1e-6) {
                continue;
            }

            SortieCandidate cand = new SortieCandidate();
            cand.startIndex = startIdx;
            cand.landingIndex = landingIdx;
            cand.start = start;
            cand.end = landing;
            cand.movedCustomers = movedCustomers;
            cand.improvement = improvement;
            if (best == null || cand.improvement > best.improvement + 1e-9) {
                best = cand;
            }
        }

        return best;
    }

    private static void applySortie(EV_Route route, SortieCandidate c) {
        List<Node> trip = new ArrayList<>();
        trip.add(c.start);
        trip.addAll(c.movedCustomers);
        trip.add(c.end);

        for (int i = c.landingIndex - 1; i >= c.startIndex + 1; i--) {
            route.route.remove(i);
        }
        route.uavTrips.add(trip);
    }

    // --------- EV local search ---------

    private static void improveEvRoutes(Solution s) {
        // UAV route will be rebuilt afterwards; optimize EV main routes first.
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 4) {
                continue;
            }
            twoOptImprove(r, 40);
        }
    }

    // --------- Station neighborhoods ---------

    private static void optimizeStations(Solution s) {
        for (int routeIdx = 0; routeIdx < s.evRoutes.length; routeIdx++) {
            EV_Route r = s.evRoutes[routeIdx];
            r.uavTrips.clear();
            if (r.route.size() <= 2) {
                continue;
            }

            boolean improved = true;
            int guard = 0;
            while (improved && guard++ < 30) {
                improved = false;
                if (tryStationRelocate(s, routeIdx)) {
                    improved = true;
                    continue;
                }
                if (tryStationRemove(s, routeIdx)) {
                    improved = true;
                    continue;
                }
                if (tryStationInsert(s, routeIdx)) {
                    improved = true;
                }
            }
        }
    }

    // --------- Inter-route relocate (1,0) ---------

    private static void interRouteRelocate(Solution s, int maxRound) {
        // UAV will be rebuilt after relocate, so keep only EV main routes here.
        for (EV_Route r : s.evRoutes) {
            r.uavTrips.clear();
        }

        int round = 0;
        while (round++ < maxRound) {
            RelocateMove best = findBestRelocateMove(s);
            if (best == null || best.delta >= -1e-9) {
                break;
            }
            applyRelocateMove(s, best);
        }
    }

    private static RelocateMove findBestRelocateMove(Solution s) {
        RelocateMove best = null;

        for (int fromIdx = 0; fromIdx < s.evRoutes.length; fromIdx++) {
            EV_Route fromRoute = s.evRoutes[fromIdx];
            for (int fromPos = 1; fromPos < fromRoute.route.size() - 1; fromPos++) {
                Node customer = fromRoute.route.get(fromPos);
                if (customer.type != NodeType.CUSTOMER) {
                    continue;
                }

                for (int toIdx = 0; toIdx < s.evRoutes.length; toIdx++) {
                    if (toIdx == fromIdx) {
                        continue;
                    }
                    EV_Route toRoute = s.evRoutes[toIdx];
                    for (int toPos = 1; toPos < toRoute.route.size(); toPos++) {
                        List<Node> candFrom = new ArrayList<>(fromRoute.route);
                        candFrom.remove(fromPos);
                        if (hasConsecutiveStations(candFrom)) {
                            continue;
                        }
                        if (!ensureEnergyFeasibleByStationInsertion(candFrom)) {
                            continue;
                        }

                        List<Node> candTo = new ArrayList<>(toRoute.route);
                        candTo.add(toPos, customer);
                        if (hasConsecutiveStations(candTo)) {
                            continue;
                        }
                        if (!ensureEnergyFeasibleByStationInsertion(candTo)) {
                            continue;
                        }

                        double delta = evaluateRelocateDelta(s, fromIdx, candFrom, toIdx, candTo);
                        if (delta < -1e-9 && (best == null || delta < best.delta - 1e-9)) {
                            best = new RelocateMove();
                            best.fromRouteIdx = fromIdx;
                            best.toRouteIdx = toIdx;
                            best.newFromRoute = candFrom;
                            best.newToRoute = candTo;
                            best.delta = delta;
                        }
                    }
                }
            }
        }
        return best;
    }

    private static double evaluateRelocateDelta(Solution s, int fromIdx, List<Node> candFrom, int toIdx, List<Node> candTo) {
        EV_Route oldFrom = s.evRoutes[fromIdx];
        EV_Route oldTo = s.evRoutes[toIdx];

        double oldScore = evalRouteScore(oldFrom.route, oldFrom.uavTrips) + evalRouteScore(oldTo.route, oldTo.uavTrips);
        double newScore = evalRouteScore(candFrom, new ArrayList<>()) + evalRouteScore(candTo, new ArrayList<>());
        double delta = newScore - oldScore;

        // EV fixed cost delta.
        delta += routeActivationDelta(oldFrom.route, candFrom);
        delta += routeActivationDelta(oldTo.route, candTo);

        // Global station-open delta for the two simultaneously changed routes.
        delta += estimateGlobalStationOpenDeltaTwoRoutes(s, fromIdx, candFrom, toIdx, candTo);
        return delta;
    }

    private static double routeActivationDelta(List<Node> oldRoute, List<Node> newRoute) {
        boolean oldUsed = oldRoute.size() > 2;
        boolean newUsed = newRoute.size() > 2;
        if (!oldUsed && newUsed) {
            return Parameter.evFixedCost;
        }
        if (oldUsed && !newUsed) {
            return -Parameter.evFixedCost;
        }
        return 0;
    }

    private static double estimateGlobalStationOpenDeltaTwoRoutes(
            Solution s, int idxA, List<Node> newA, int idxB, List<Node> newB) {
        Set<Integer> oldGlobal = openedStationIdsOfSolution(s);
        Set<Integer> newGlobal = new HashSet<>();
        for (int i = 0; i < s.evRoutes.length; i++) {
            if (i == idxA) {
                newGlobal.addAll(stationIdsInRoute(newA));
            } else if (i == idxB) {
                newGlobal.addAll(stationIdsInRoute(newB));
            } else {
                newGlobal.addAll(stationIdsInRoute(s.evRoutes[i].route));
            }
        }
        return (newGlobal.size() - oldGlobal.size()) * Parameter.stationOpenCost;
    }
    private static void applyRelocateMove(Solution s, RelocateMove m) {
        EV_Route from = s.evRoutes[m.fromRouteIdx];
        EV_Route to = s.evRoutes[m.toRouteIdx];

        from.route.clear();
        from.route.addAll(m.newFromRoute);
        from.uavTrips.clear();

        to.route.clear();
        to.route.addAll(m.newToRoute);
        to.uavTrips.clear();
    }
    // --------- Inter-route swap (1,1) ---------

    private static void interRouteSwap(Solution s, int maxRound) {
        for (EV_Route r : s.evRoutes) {
            r.uavTrips.clear();
        }

        int round = 0;
        while (round++ < maxRound) {
            SwapMove best = findBestSwapMove(s);
            if (best == null || best.delta >= -1e-9) {
                break;
            }
            applySwapMove(s, best);
        }
    }

    private static SwapMove findBestSwapMove(Solution s) {
        SwapMove best = null;

        for (int a = 0; a < s.evRoutes.length; a++) {
            EV_Route routeA = s.evRoutes[a];
            for (int b = a + 1; b < s.evRoutes.length; b++) {
                EV_Route routeB = s.evRoutes[b];

                for (int posA = 1; posA < routeA.route.size() - 1; posA++) {
                    Node nodeA = routeA.route.get(posA);
                    if (nodeA.type != NodeType.CUSTOMER) {
                        continue;
                    }
                    for (int posB = 1; posB < routeB.route.size() - 1; posB++) {
                        Node nodeB = routeB.route.get(posB);
                        if (nodeB.type != NodeType.CUSTOMER) {
                            continue;
                        }

                        List<Node> candA = new ArrayList<>(routeA.route);
                        List<Node> candB = new ArrayList<>(routeB.route);
                        candA.set(posA, nodeB);
                        candB.set(posB, nodeA);

                        if (hasConsecutiveStations(candA) || hasConsecutiveStations(candB)) {
                            continue;
                        }
                        if (!ensureEnergyFeasibleByStationInsertion(candA)) {
                            continue;
                        }
                        if (!ensureEnergyFeasibleByStationInsertion(candB)) {
                            continue;
                        }

                        double delta = evaluateSwapDelta(s, a, candA, b, candB);
                        if (delta < -1e-9 && (best == null || delta < best.delta - 1e-9)) {
                            best = new SwapMove();
                            best.routeAIdx = a;
                            best.routeBIdx = b;
                            best.newRouteA = candA;
                            best.newRouteB = candB;
                            best.delta = delta;
                        }
                    }
                }
            }
        }
        return best;
    }

    private static double evaluateSwapDelta(Solution s, int idxA, List<Node> candA, int idxB, List<Node> candB) {
        EV_Route oldA = s.evRoutes[idxA];
        EV_Route oldB = s.evRoutes[idxB];

        double oldScore = evalRouteScore(oldA.route, oldA.uavTrips) + evalRouteScore(oldB.route, oldB.uavTrips);
        double newScore = evalRouteScore(candA, new ArrayList<>()) + evalRouteScore(candB, new ArrayList<>());
        double delta = newScore - oldScore;
        delta += estimateGlobalStationOpenDeltaTwoRoutes(s, idxA, candA, idxB, candB);
        return delta;
    }

    private static void applySwapMove(Solution s, SwapMove m) {
        EV_Route a = s.evRoutes[m.routeAIdx];
        EV_Route b = s.evRoutes[m.routeBIdx];

        a.route.clear();
        a.route.addAll(m.newRouteA);
        a.uavTrips.clear();

        b.route.clear();
        b.route.addAll(m.newRouteB);
        b.uavTrips.clear();
    }

    // StationRelocate: 闁哄洦瀵у畷鑼崉椤栨氨绐炲☉鎿冨幖閸戯繝寮垫径宀€褰查柣鎰嚀婢瑰洭寮甸濠勭閻忓繑绻嗛惁顖炲箥閹冪厒闁哄洨绻濈槐顓熷濮橆剚鍊?闁瑰箍鍨婚弫鍛婃媴瀹ュ洨鏋傞柕?    
    private static boolean tryStationRelocate(Solution s, int routeIdx) {
        EV_Route route = s.evRoutes[routeIdx];
        List<Node> stations = CalculateTool.stationNodes();
        if (stations.isEmpty()) {
            return false;
        }

        double bestDelta = 0;
        List<Node> bestRoute = null;
        for (int i = 1; i < route.route.size() - 1; i++) {
            Node oldNode = route.route.get(i);
            if (oldNode.type != NodeType.STATION) {
                continue;
            }

            for (Node candStation : stations) {
                if (candStation == oldNode) {
                    continue;
                }
                List<Node> cand = new ArrayList<>(route.route);
                cand.set(i, candStation);
                if (hasConsecutiveStations(cand)) {
                    continue;
                }

                double delta = evaluateRouteReplacementDelta(s, routeIdx, cand);
                if (delta < bestDelta - 1e-9) {
                    bestDelta = delta;
                    bestRoute = cand;
                }
            }
        }

        if (bestRoute != null) {
            route.route.clear();
            route.route.addAll(bestRoute);
            route.uavTrips.clear();
            return true;
        }
        return false;
    }

    // StationInsertRemove: remove 闂侇喓鍔岄崹搴ㄦ晬鐏炶棄鐏╅梻鍕╁€曢崯鎴炴媴濞嗘垹褰查柣鎰畭閳?    
    private static boolean tryStationRemove(Solution s, int routeIdx) {
        EV_Route route = s.evRoutes[routeIdx];
        double bestDelta = 0;
        List<Node> bestRoute = null;

        for (int i = 1; i < route.route.size() - 1; i++) {
            if (route.route.get(i).type != NodeType.STATION) {
                continue;
            }
            List<Node> cand = new ArrayList<>(route.route);
            cand.remove(i);
            if (hasConsecutiveStations(cand)) {
                continue;
            }

            double delta = evaluateRouteReplacementDelta(s, routeIdx, cand);
            if (delta < bestDelta - 1e-9) {
                bestDelta = delta;
                bestRoute = cand;
            }
        }

        if (bestRoute != null) {
            route.route.clear();
            route.route.addAll(bestRoute);
            route.uavTrips.clear();
            return true;
        }
        return false;
    }

    // StationInsertRemove: insert 闂侇喓鍔岄崹搴ㄦ晬鐏炶姤韬柛娆樺灡濡鎷嬪Δ鍛€栧ù锝呯凹閸烆剚绂掗柨瀣槯濞戞捁顕ф慨鈺呭箵閹烘梻褰查柕?    
    private static boolean tryStationInsert(Solution s, int routeIdx) {
        EV_Route route = s.evRoutes[routeIdx];
        List<Node> stations = CalculateTool.stationNodes();
        if (stations.isEmpty()) {
            return false;
        }

        double bestDelta = 0;
        List<Node> bestRoute = null;

        for (int pos = 1; pos < route.route.size(); pos++) {
            Node prev = route.route.get(pos - 1);
            Node next = route.route.get(pos);
            if (prev.type == NodeType.STATION || next.type == NodeType.STATION) {
                continue;
            }

            for (Node st : stations) {
                List<Node> cand = new ArrayList<>(route.route);
                cand.add(pos, st);
                if (hasConsecutiveStations(cand)) {
                    continue;
                }
                double delta = evaluateRouteReplacementDelta(s, routeIdx, cand);
                if (delta < bestDelta - 1e-9) {
                    bestDelta = delta;
                    bestRoute = cand;
                }
            }
        }

        if (bestRoute != null) {
            route.route.clear();
            route.route.addAll(bestRoute);
            route.uavTrips.clear();
            return true;
        }
        return false;
    }

    private static double evaluateRouteReplacementDelta(Solution s, int routeIdx, List<Node> candRoute) {
        EV_Route oldRoute = s.evRoutes[routeIdx];
        double oldScore = evalRouteScore(oldRoute.route, oldRoute.uavTrips);
        double newScore = evalRouteScore(candRoute, new ArrayList<>());
        return (newScore - oldScore) + estimateGlobalStationOpenDelta(s, routeIdx, candRoute);
    }

    private static boolean hasConsecutiveStations(List<Node> route) {
        for (int i = 1; i < route.size(); i++) {
            if (route.get(i - 1).type == NodeType.STATION && route.get(i).type == NodeType.STATION) {
                return true;
            }
        }
        return false;
    }

    private static void twoOptImprove(EV_Route route, int maxRound) {
        route.uavTrips.clear();
        CalculateTool.updateEVRouteMetrics(route);
        double bestScore = routeScore(route);

        int round = 0;
        boolean improved = true;
        while (improved && round++ < maxRound) {
            improved = false;
            List<Node> bestNodes = null;

            // Keep first(depot) and last(virtual depot) fixed.
            for (int i = 1; i < route.route.size() - 2; i++) {
                for (int j = i + 1; j < route.route.size() - 1; j++) {
                    List<Node> cand = twoOptNodes(route.route, i, j);
                    if (!ensureEnergyFeasibleByStationInsertion(cand)) {
                        continue;
                    }

                    EV_Route test = new EV_Route();
                    test.route.addAll(cand);
                    CalculateTool.updateEVRouteMetrics(test);
                    double score = routeScore(test);
                    if (score + 1e-9 < bestScore) {
                        bestScore = score;
                        bestNodes = cand;
                        improved = true;
                    }
                }
            }

            if (improved && bestNodes != null) {
                route.route.clear();
                route.route.addAll(bestNodes);
                CalculateTool.updateEVRouteMetrics(route);
            }
        }
    }

    private static List<Node> twoOptNodes(List<Node> nodes, int i, int j) {
        List<Node> out = new ArrayList<>(nodes.size());
        for (int k = 0; k < i; k++) {
            out.add(nodes.get(k));
        }
        for (int k = j; k >= i; k--) {
            out.add(nodes.get(k));
        }
        for (int k = j + 1; k < nodes.size(); k++) {
            out.add(nodes.get(k));
        }
        return out;
    }

    // --------- insertion with global-cost awareness ---------

    private static void insertBestWithTieRandom(Solution s, Node n) {
        double bestDelta = Double.MAX_VALUE;
        List<InsertionPlan> bestPlans = new ArrayList<>();

        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            double oldRouteScore = evalRouteScore(route.route, route.uavTrips);
            List<Integer> positions = candidateInsertPositions(route, n, Parameter.insertionCandidateK);
            for (int pos : positions) {
                InsertionPlan plan = evaluateInsertion(
                        s, r, route, pos, n, oldRouteScore, bestDelta);
                if (!plan.feasible) {
                    continue;
                }
                if (plan.delta < bestDelta - 1e-9) {
                    bestDelta = plan.delta;
                    bestPlans.clear();
                    bestPlans.add(plan);
                } else if (Math.abs(plan.delta - bestDelta) <= 1e-9) {
                    bestPlans.add(plan);
                }
            }
        }

        if (bestPlans.isEmpty()) {
            forceInsertBestDistance(s, n);
            return;
        }
        int pick = CalculateTool.intRandom(0, bestPlans.size());
        applyPlan(s.evRoutes[bestPlans.get(pick).routeIndex], bestPlans.get(pick));
    }

    private static void insertBest(Solution s, Node n) {
        double bestDelta = Double.MAX_VALUE;
        InsertionPlan bestPlan = null;

        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            double oldRouteScore = evalRouteScore(route.route, route.uavTrips);
            List<Integer> positions = candidateInsertPositions(route, n, Parameter.insertionCandidateK);
            for (int pos : positions) {
                InsertionPlan plan = evaluateInsertion(
                        s, r, route, pos, n, oldRouteScore, bestDelta);
                if (!plan.feasible) {
                    continue;
                }
                if (plan.delta < bestDelta) {
                    bestDelta = plan.delta;
                    bestPlan = plan;
                }
            }
        }

        if (bestPlan != null) {
            applyPlan(s.evRoutes[bestPlan.routeIndex], bestPlan);
            return;
        }
        forceInsertBestDistance(s, n);
    }

    private static List<Double> bestTwoInsertCosts(Solution s, Node n) {
        List<Double> vals = new ArrayList<>();
        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            double oldRouteScore = evalRouteScore(route.route, route.uavTrips);
            List<Integer> positions = candidateInsertPositions(route, n, Parameter.insertionCandidateK);
            for (int pos : positions) {
                InsertionPlan plan = evaluateInsertion(
                        s, r, route, pos, n, oldRouteScore, Double.MAX_VALUE);
                if (plan.feasible) {
                    vals.add(plan.delta);
                }
            }
        }
        vals.sort(Double::compareTo);
        if (vals.isEmpty()) {
            for (EV_Route route : s.evRoutes) {
                for (int pos = 1; pos < route.route.size(); pos++) {
                    vals.add(rawInsertionDelta(route, pos, n));
                }
            }
            vals.sort(Double::compareTo);
        }
        if (vals.size() == 1) {
            return vals.subList(0, 1);
        }
        return vals.subList(0, 2);
    }

    private static InsertionPlan evaluateInsertion(
            Solution s,
            int routeIdx,
            EV_Route route,
            int pos,
            Node customer,
            double oldRouteScore,
            double bestDeltaUpperBound) {
        InsertionPlan plan = new InsertionPlan();
        plan.feasible = false;

        // Quick lower-bound pruning: distance-only gain scaled by minimum EV segment weight.
        double rawDelta = rawInsertionDelta(route, pos, customer);
        double minEnergyDeltaLb = Parameter.evConsumeTravel * Parameter.evWeight * rawDelta;
        double activationLb = (route.route.size() <= 2) ? Parameter.evFixedCost : 0;
        double lowerBound = minEnergyDeltaLb + activationLb;
        if (bestDeltaUpperBound < Double.MAX_VALUE
                && lowerBound > bestDeltaUpperBound + Parameter.insertionPruneSlack) {
            return plan;
        }

        List<Node> trial = new ArrayList<>(route.route);
        trial.add(pos, customer);

        if (!ensureEnergyFeasibleByStationInsertion(trial)) {
            return plan;
        }

        double newRouteScore = evalRouteScore(trial, new ArrayList<>());
        double delta = newRouteScore - oldRouteScore;

        // New EV activation cost.
        if (route.route.size() <= 2 && trial.size() > 2) {
            delta += Parameter.evFixedCost;
        }

        // Global station-open delta.
        delta += estimateGlobalStationOpenDelta(s, routeIdx, trial);

        plan.feasible = true;
        plan.delta = delta;
        plan.newRoute = trial;
        plan.routeIndex = routeIdx;
        return plan;
    }

    private static double estimateGlobalStationOpenDelta(Solution s, int routeIdx, List<Node> newRoute) {
        Set<Integer> oldGlobal = openedStationIdsOfSolution(s);

        Set<Integer> oldRoute = stationIdsInRoute(s.evRoutes[routeIdx].route);
        Set<Integer> newRouteIds = stationIdsInRoute(newRoute);

        Set<Integer> newGlobal = new HashSet<>(oldGlobal);
        for (int pid : oldRoute) {
            if (!usedByOtherRoutes(s, routeIdx, pid)) {
                newGlobal.remove(pid);
            }
        }
        newGlobal.addAll(newRouteIds);

        int deltaCount = newGlobal.size() - oldGlobal.size();
        return deltaCount * Parameter.stationOpenCost;
    }

    private static boolean usedByOtherRoutes(Solution s, int routeIdx, int pid) {
        for (int i = 0; i < s.evRoutes.length; i++) {
            if (i == routeIdx) {
                continue;
            }
            for (Node n : s.evRoutes[i].route) {
                if (n.type == NodeType.STATION && n.physicalStationId == pid) {
                    return true;
                }
            }
        }
        return false;
    }

    private static Set<Integer> openedStationIdsOfSolution(Solution s) {
        Set<Integer> ids = new HashSet<>();
        for (EV_Route r : s.evRoutes) {
            ids.addAll(stationIdsInRoute(r.route));
        }
        return ids;
    }

    private static Set<Integer> stationIdsInRoute(List<Node> route) {
        Set<Integer> ids = new HashSet<>();
        for (Node n : route) {
            if (n.type == NodeType.STATION && n.physicalStationId >= 0) {
                ids.add(n.physicalStationId);
            }
        }
        return ids;
    }

    private static double nearestOpenedStationDistance(Solution s, Node customer) {
        double best = Double.MAX_VALUE;
        for (EV_Route r : s.evRoutes) {
            for (Node n : r.route) {
                if (n.type != NodeType.STATION) {
                    continue;
                }
                best = Math.min(best, dist(n, customer));
            }
        }
        if (best < Double.MAX_VALUE) {
            return best;
        }
        for (Node n : Parameter.allNodes) {
            if (n.type == NodeType.STATION) {
                best = Math.min(best, dist(n, customer));
            }
        }
        return best;
    }

    private static double evalRouteScore(List<Node> routeNodes, List<List<Node>> uavTrips) {
        EV_Route t = new EV_Route();
        t.route.addAll(routeNodes);
        for (List<Node> trip : uavTrips) {
            t.uavTrips.add(new ArrayList<>(trip));
        }
        CalculateTool.updateEVRouteMetrics(t);
        return routeScore(t);
    }

    private static void applyPlan(EV_Route route, InsertionPlan plan) {
        route.route.clear();
        route.route.addAll(plan.newRoute);
        route.uavTrips.clear();
    }

    // --------- EV energy repair by inserting stations ---------

    private static boolean ensureEnergyFeasibleByStationInsertion(List<Node> route) {
        if (route.size() < 2) {
            return true;
        }

        List<Node> stations = CalculateTool.stationNodes();
        if (stations.isEmpty()) {
            return false;
        }

        int maxInsertions = Math.max(4, route.size() * 2);
        int inserted = 0;

        while (inserted <= maxInsertions) {
            double remainingDemand = routeDemand(route);
            double battery = Parameter.evEnergy;
            boolean changed = false;

            for (int i = 1; i < route.size(); i++) {
                Node prev = route.get(i - 1);
                Node cur = route.get(i);
                double d = dist(prev, cur);
                double need = CalculateTool.computeEvTravelEnergy(remainingDemand, d);

                if (need > battery + 1e-9) {
                    Node station = pickBestStationBetween(route, i, prev, cur, battery, remainingDemand, stations);
                    if (station == null) {
                        return false;
                    }
                    route.add(i, station);
                    inserted++;
                    changed = true;
                    break;
                }

                battery -= need;
                if (cur.type == NodeType.STATION || cur.type == NodeType.DEPOT) {
                    battery = Parameter.evEnergy;
                }
                if (cur.type == NodeType.CUSTOMER) {
                    remainingDemand = Math.max(0, remainingDemand - cur.demand);
                }
            }

            if (!changed) {
                return true;
            }
        }

        return false;
    }

    private static Node pickBestStationBetween(
            List<Node> route,
            int insertPos,
            Node prev,
            Node cur,
            double battery,
            double remainingDemand,
            List<Node> stations) {
        Node best = null;
        double bestScore = Double.MAX_VALUE;
        double direct = dist(prev, cur);
        double baseScore = evalRouteOnlyScore(route);
        Set<Integer> existingPhysicalIds = stationIdsInRoute(route);

        for (Node s : stations) {
            if (prev.type == NodeType.STATION || cur.type == NodeType.STATION) {
                continue;
            }

            double d1 = dist(prev, s);
            double d2 = dist(s, cur);
            double e1 = CalculateTool.computeEvTravelEnergy(remainingDemand, d1);
            double e2 = CalculateTool.computeEvTravelEnergy(remainingDemand, d2);

            if (e1 > battery + 1e-9) {
                continue;
            }
            if (e2 > Parameter.evEnergy + 1e-9) {
                continue;
            }

            double score = evaluateStationInsertionScore(
                    route, insertPos, s, baseScore, direct, d1, d2, existingPhysicalIds);
            if (score < bestScore - 1e-9) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    private static double evaluateStationInsertionScore(
            List<Node> route,
            int insertPos,
            Node station,
            double baseScore,
            double direct,
            double d1,
            double d2,
            Set<Integer> existingPhysicalIds) {
        List<Node> trial = new ArrayList<>(route);
        trial.add(insertPos, station);
        if (hasConsecutiveStations(trial)) {
            return Double.MAX_VALUE;
        }

        double trialScore = evalRouteOnlyScore(trial);
        if (Double.isInfinite(trialScore)) {
            return Double.MAX_VALUE;
        }

        // 缂備胶鍘ч幃搴㈡櫠閻愬搫娅ら柨娑欎亢閻箖鎮?闁哄啫鐖煎Λ璺ㄧ玻?闁煎啿鈧啿鍋撳Δ浣稿姦缂傚啯鑹捐ぐ澶愬礌?+ 鐎殿喒鍋撶紒鏃€鐟ㄧ粩鐔兼⒔閸涱剙鏁╅柣鐐叉閸ㄦ岸寮?+ 缂備焦娲濋、鎴濐嚗椤旇偐姣堢紒顖滅帛閺嗙喖鏁嶉崼鐔封叺闁活喗娼欓柦鈺冧沪閳ь剟鏁嶆径鍫氬亾?        
        double delta = trialScore - baseScore;
        if (station.physicalStationId >= 0 && !existingPhysicalIds.contains(station.physicalStationId)) {
            delta += Parameter.stationOpenCost;
        }
        delta += 0.01 * (d1 + d2 - direct);
        return delta;
    }

    private static double evalRouteOnlyScore(List<Node> routeNodes) {
        EV_Route t = new EV_Route();
        t.route.addAll(routeNodes);
        CalculateTool.updateEVRouteMetrics(t);
        return routeScore(t);
    }

    // --------- utilities ---------

    private static double routeScore(EV_Route r) {
        double score = r.energyConsumption + r.uavEnergyConsumption;
        if (r.overload > 1e-9) {
            score += Parameter.alphaOverload * r.overload;
        }
        if (r.timeViolation > 1e-9) {
            score += Parameter.betaTimeWindow * r.timeViolation;
        }
        if (r.energyViolated) {
            score += Parameter.gammaEnergy;
        }
        if (r.structureViolated) {
            score += Parameter.gammaRouteStructure;
        }
        return score;
    }

    private static boolean isMeetingNode(Node n) {
        return n.type == NodeType.CUSTOMER || n.type == NodeType.STATION;
    }

    private static boolean nodeUsedInTrip(EV_Route route, Node target) {
        for (List<Node> trip : route.uavTrips) {
            for (Node n : trip) {
                if (n == target || n.id == target.id) {
                    return true;
                }
            }
        }
        return false;
    }

    private static EV_Route cloneRoute(EV_Route src) {
        EV_Route t = new EV_Route();
        t.route.addAll(src.route);
        for (List<Node> trip : src.uavTrips) {
            t.uavTrips.add(new ArrayList<>(trip));
        }
        return t;
    }

    private static int indexOfNode(List<Node> route, Node target) {
        for (int i = 0; i < route.size(); i++) {
            if (route.get(i) == target) {
                return i;
            }
        }
        for (int i = 0; i < route.size(); i++) {
            if (route.get(i).id == target.id) {
                return i;
            }
        }
        return -1;
    }

    private static double routeDemand(List<Node> route) {
        double demand = 0;
        for (Node n : route) {
            if (n.type == NodeType.CUSTOMER) {
                demand += n.demand;
            }
        }
        return demand;
    }

    private static void forceInsertBestDistance(Solution s, Node n) {
        double bestDelta = Double.MAX_VALUE;
        int bestR = -1;
        int bestPos = -1;
        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            for (int pos = 1; pos < route.route.size(); pos++) {
                double delta = rawInsertionDelta(route, pos, n);
                if (delta < bestDelta) {
                    bestDelta = delta;
                    bestR = r;
                    bestPos = pos;
                }
            }
        }
        if (bestR >= 0) {
            s.evRoutes[bestR].route.add(bestPos, n);
        }
    }

    private static double rawInsertionDelta(EV_Route r, int pos, Node n) {
        Node prev = r.route.get(pos - 1);
        Node next = r.route.get(pos);
        return dist(prev, n) + dist(n, next) - dist(prev, next);
    }

    private static List<Integer> candidateInsertPositions(EV_Route route, Node n, int k) {
        List<PosDelta> scored = new ArrayList<>();
        for (int pos = 1; pos < route.route.size(); pos++) {
            PosDelta pd = new PosDelta();
            pd.pos = pos;
            pd.delta = rawInsertionDelta(route, pos, n);
            scored.add(pd);
        }
        scored.sort(Comparator.comparingDouble(a -> a.delta));

        int keep = Math.max(1, Math.min(k, scored.size()));
        List<Integer> out = new ArrayList<>(keep);
        for (int i = 0; i < keep; i++) {
            out.add(scored.get(i).pos);
        }
        return out;
    }

    private static double dist(Node a, Node b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static final class InsertionPlan {
        boolean feasible;
        int routeIndex;
        double delta;
        List<Node> newRoute = new ArrayList<>();
    }

    private static final class SortieCandidate {
        int startIndex;
        int landingIndex;
        Node start;
        Node end;
        List<Node> movedCustomers = new ArrayList<>();
        double improvement;
    }

    private static final class RelocateMove {
        int fromRouteIdx;
        int toRouteIdx;
        List<Node> newFromRoute = new ArrayList<>();
        List<Node> newToRoute = new ArrayList<>();
        double delta;
    }

    private static final class SwapMove {
        int routeAIdx;
        int routeBIdx;
        List<Node> newRouteA = new ArrayList<>();
        List<Node> newRouteB = new ArrayList<>();
        double delta;
    }

    private static final class PosDelta {
        int pos;
        double delta;
    }
}
