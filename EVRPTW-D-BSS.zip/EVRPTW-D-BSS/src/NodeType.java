public enum NodeType {
    DEPOT,
    VIRTUAL_DEPOT,
    CUSTOMER,
    STATION
}
