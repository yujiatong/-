import java.util.ArrayList;
import java.util.List;

public class EV_Route extends Route {
    public ArrayList<List<Node>> uavTrips = new ArrayList<>();
    public double uavEnergyConsumption = 0;
    public int swapCount = 0;
}
