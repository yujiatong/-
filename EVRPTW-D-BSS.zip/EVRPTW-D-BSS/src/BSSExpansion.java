public class BSSExpansion {
    public static void expandStations() {
        // 当前默认：站点副本由实例文件直接给出（同物理站可多行出现）。
        // 该方法保留为扩展点，后续可在此自动生成站点副本。
    }
}
