public class Main {
    // =========================
    // Manual Config Area
    // =========================
    // If true, run with the constants below (no need to use command line).
    // If false, use command line args only.
    private static final boolean USE_MANUAL_CONFIG = true;

    // Option A: set direct instance path (recommended for manual use).
    // Example:
    // "./instances/c101_bss_for_current_parser.txt"
    // "./instances_bss_bigscal/rc201_n75_bss.txt"
    // Leave empty to use Option B.
//    private static final String MANUAL_INSTANCE_PATH = "./instances_bss_bigscal/c101_n25_bss.txt";
    private static final String MANUAL_INSTANCE_PATH = "./instances/c101_bss_for_current_parser.txt";

    // Option B: build big-scale path automatically:
    // "./instances_bss_bigscal/{MANUAL_BIG_TYPE}_n{MANUAL_BIG_N}_bss.txt"
    // Used only when MANUAL_INSTANCE_PATH is empty.
    private static final String MANUAL_BIG_TYPE = "c101"; // c101/c201/r101/r201/rc101/rc201
    private static final Integer MANUAL_BIG_N = 25;       // 25/50/75/100

    // Optional manual runtime settings.
    private static final Long MANUAL_SEED = 1L;      // null means random
    private static final boolean MANUAL_QUIET = false;
    private static final int MANUAL_ITER = -1;       // <=0 keep Parameter default
    private static final int MANUAL_RESTARTS = -1;   // <=0 keep Parameter default
    private static final int MANUAL_REMOVE = -1;     // <=0 keep Parameter default
    private static final int MANUAL_INS_K = -1;      // <=0 keep Parameter default
    private static final double MANUAL_EV_ENERGY = -1;   // <=0 keep Parameter default
    private static final double MANUAL_EV_CAPACITY = -1; // <=0 keep Parameter default
    private static final Boolean MANUAL_SA_AUTO_TUNE = null; // null keep default

    public static void main(String[] args) throws Exception {
        RunConfig cfg = defaultConfig();

        if (USE_MANUAL_CONFIG) {
            applyManualConfig(cfg);
        }
        // Optional: allow command-line args to override current config.
        parseArgs(args, cfg);

        applyRuntimeOverrides(cfg);

        String instancePath = resolveInstancePath(cfg);
        if (cfg.randomSeed != null) {
            CalculateTool.setRandomSeed(cfg.randomSeed);
        }

        long t0 = System.currentTimeMillis();

        ReadData.init();
        ReadData.importInfo(instancePath);
        BSSExpansion.expandStations();
        CalculateTool.generateDistanceMatrix();

        InitialSolutionBuilder.buildInitialSolution(Parameter.localSolution);
        CalculateTool.updateSolutionMetrics(Parameter.localSolution);
        ALNS.solve();

        long t1 = System.currentTimeMillis();
        System.out.println("Best objective: " + Parameter.bestSolutionValue);
        System.out.println("Feasible: " + Parameter.bestSolution.feasible);
        System.out.println("violations: overload=" + Parameter.bestSolution.overloadViolated
                + ", tw=" + Parameter.bestSolution.timeWindowViolated
                + ", energy=" + Parameter.bestSolution.energyViolated
                + ", structure=" + Parameter.bestSolution.structureViolated);
        System.out.println("timeMs: " + (t1 - t0));
        System.out.println("instance: " + instancePath);
        System.out.println("seed: " + (cfg.randomSeed == null ? "auto" : cfg.randomSeed));
        System.out.println("evEnergy: " + Parameter.evEnergy + ", evCapacity: " + Parameter.evCapacity);
        if (!cfg.quiet) {
            Output.outputSolution(Parameter.bestSolution);
        }
    }

    private static RunConfig defaultConfig() {
        RunConfig cfg = new RunConfig();
        cfg.instancePath = "./instances/c101_bss_for_current_parser.txt";
        cfg.bigType = "c101";
        cfg.bigN = null;
        cfg.randomSeed = null;
        cfg.quiet = false;
        return cfg;
    }

    private static void applyManualConfig(RunConfig cfg) {
        cfg.instancePath = MANUAL_INSTANCE_PATH;
        cfg.bigType = MANUAL_BIG_TYPE;
        cfg.bigN = MANUAL_BIG_N;
        cfg.randomSeed = MANUAL_SEED;
        cfg.quiet = MANUAL_QUIET;

        cfg.iter = MANUAL_ITER;
        cfg.restarts = MANUAL_RESTARTS;
        cfg.remove = MANUAL_REMOVE;
        cfg.insK = MANUAL_INS_K;
        cfg.evEnergy = MANUAL_EV_ENERGY;
        cfg.evCapacity = MANUAL_EV_CAPACITY;
        cfg.saAutoTune = MANUAL_SA_AUTO_TUNE;
    }

    private static void parseArgs(String[] args, RunConfig cfg) {
        for (String arg : args) {
            if (arg == null || arg.trim().isEmpty()) {
                continue;
            }
            if (arg.startsWith("--instance=")) {
                cfg.instancePath = arg.substring("--instance=".length());
            } else if (arg.startsWith("--bigType=")) {
                cfg.bigType = arg.substring("--bigType=".length()).trim().toLowerCase();
            } else if (arg.startsWith("--bigN=")) {
                cfg.bigN = Integer.parseInt(arg.substring("--bigN=".length()));
            } else if (arg.startsWith("--seed=")) {
                cfg.randomSeed = Long.parseLong(arg.substring("--seed=".length()));
            } else if (arg.startsWith("--evEnergy=")) {
                cfg.evEnergy = Double.parseDouble(arg.substring("--evEnergy=".length()));
            } else if (arg.startsWith("--evCapacity=")) {
                cfg.evCapacity = Double.parseDouble(arg.substring("--evCapacity=".length()));
            } else if (arg.startsWith("--iter=")) {
                cfg.iter = Integer.parseInt(arg.substring("--iter=".length()));
            } else if (arg.startsWith("--restarts=")) {
                cfg.restarts = Integer.parseInt(arg.substring("--restarts=".length()));
            } else if (arg.startsWith("--remove=")) {
                cfg.remove = Integer.parseInt(arg.substring("--remove=".length()));
            } else if (arg.startsWith("--insK=")) {
                cfg.insK = Integer.parseInt(arg.substring("--insK=".length()));
            } else if (arg.startsWith("--saAutoTune=")) {
                cfg.saAutoTune = Boolean.parseBoolean(arg.substring("--saAutoTune=".length()));
            } else if (arg.equals("--quiet")) {
                cfg.quiet = true;
            }
        }
    }

    private static void applyRuntimeOverrides(RunConfig cfg) {
        if (cfg.evEnergy > 0) {
            Parameter.evEnergy = cfg.evEnergy;
        }
        if (cfg.evCapacity > 0) {
            Parameter.evCapacity = cfg.evCapacity;
        }
        if (cfg.iter > 0) {
            Parameter.maxIteration = cfg.iter;
        }
        if (cfg.restarts > 0) {
            Parameter.alnsRestarts = cfg.restarts;
        }
        if (cfg.remove > 0) {
            Parameter.removeNodeNumber = cfg.remove;
        }
        if (cfg.insK > 0) {
            Parameter.insertionCandidateK = cfg.insK;
        }
        if (cfg.saAutoTune != null) {
            Parameter.saAutoTune = cfg.saAutoTune;
        }
    }

    private static String resolveInstancePath(RunConfig cfg) {
        if (cfg.instancePath != null && !cfg.instancePath.trim().isEmpty()) {
            return cfg.instancePath.trim();
        }

        if (cfg.bigN == null) {
            throw new IllegalArgumentException("No instance selected. Set MANUAL_INSTANCE_PATH or MANUAL_BIG_N.");
        }
        if (cfg.bigN != 25 && cfg.bigN != 50 && cfg.bigN != 75 && cfg.bigN != 100) {
            throw new IllegalArgumentException("bigN only supports 25/50/75/100, got: " + cfg.bigN);
        }
        String type = (cfg.bigType == null || cfg.bigType.trim().isEmpty()) ? "c101" : cfg.bigType.trim().toLowerCase();
        return "./instances_bss_bigscal/" + type + "_n" + cfg.bigN + "_bss.txt";
    }

    private static final class RunConfig {
        String instancePath;
        String bigType;
        Integer bigN;
        Long randomSeed;
        boolean quiet;

        int iter = -1;
        int restarts = -1;
        int remove = -1;
        int insK = -1;
        double evEnergy = -1;
        double evCapacity = -1;
        Boolean saAutoTune = null;
    }
}
