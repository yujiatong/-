public class Node {
    // 基础时空与需求属性。
    public int id;
    public double x;
    public double y;
    public double demand;
    public double readyTime;
    public double dueTime;
    public double serviceTime;

    public NodeType type = NodeType.CUSTOMER;

    // 同一物理站点可在实例中出现多个副本节点。
    public int physicalStationId = -1;

    // EV/UAV 在该节点的时序信息（由评价函数更新）。
    public double evArrivalTime;
    public double evServiceTime;
    public double evDepartureTime;

    public double uavArrivalTime;
    public double uavServiceTime;
    public double uavDepartureTime;

    public Node() {}
}
