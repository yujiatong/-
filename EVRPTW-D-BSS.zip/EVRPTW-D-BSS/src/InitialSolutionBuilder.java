import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InitialSolutionBuilder {
    // 初始解：每条路径先放 depot -> virtualDepot，再插入客户。
    public static void buildInitialSolution(Solution s) {
        CalculateTool.clearSolution(s);

        Node depot = Parameter.allNodes[Parameter.depotIndex];
        Node vDepot = Parameter.allNodes[Parameter.virtualDepotIndex];

        for (EV_Route r : s.evRoutes) {
            r.route.add(depot);
            r.route.add(vDepot);
        }

        List<Node> customers = new ArrayList<>();
        for (Node n : Parameter.allNodes) {
            if (n.type == NodeType.CUSTOMER) {
                customers.add(n);
            }
        }

        // 先插入 dueTime 更紧的客户，提升时间窗可行率。
        customers.sort(Comparator.comparingDouble(a -> a.dueTime));

        int evIdx = 0;
        double currentLoad = 0;
        for (Node c : customers) {
            boolean inserted = false;
            for (int tries = 0; tries < s.evRoutes.length; tries++) {
                EV_Route r = s.evRoutes[evIdx];
                if (r.route.size() == 2) {
                    currentLoad = 0;
                }
                if (currentLoad + c.demand <= Parameter.evCapacity) {
                    r.route.add(r.route.size() - 1, c);
                    currentLoad += c.demand;
                    inserted = true;
                    break;
                }
                evIdx = (evIdx + 1) % s.evRoutes.length;
                currentLoad = routeCustomerDemand(s.evRoutes[evIdx]);
            }
            if (!inserted) {
                // 兜底插入：允许暂时不可行，交给后续 ALNS 修复。
                s.evRoutes[evIdx].route.add(s.evRoutes[evIdx].route.size() - 1, c);
                currentLoad = routeCustomerDemand(s.evRoutes[evIdx]);
            }
        }

        // 初始解构建完成后，尝试生成首版 UAV 航程。
        Repair.rebuildUavCustomersForInitial(s);
    }

    private static double routeCustomerDemand(EV_Route r) {
        double d = 0;
        for (Node n : r.route) {
            if (n.type == NodeType.CUSTOMER) {
                d += n.demand;
            }
        }
        return d;
    }
}
