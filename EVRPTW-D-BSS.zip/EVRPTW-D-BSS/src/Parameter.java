public class Parameter {
    // 实例规模参数。
    public static int customerCount = 0;
    public static int stationCount = 0;
    public static int nodeCount = 0; // depot + customers + stations + virtual depot

    // EV 参数。
    public static int evCount = 15;
    public static double evCapacity = 200;
    public static double evEnergy = 800;
    public static double evSpeed = 1.0;
    public static double evWeight = 50;
    public static double evConsumeTravel = 0.1;

    // UAV 参数（当前版本以框架支持为主）。
    public static double uavCapacity = 30;
    public static double uavEnergy = 30;
    public static double uavSpeed = 2.0;
    public static double uavWeight = 5;
    public static double uavConsumeTravel = 0.05;
    public static double uavConsumeTakeoff = 0.05;
    public static double uavConsumeLanding = 0.05;
    public static double uavMaxDelay = 200;
    public static int uavTripMaxCustomers = 5;

    // 成本参数。
    public static double evFixedCost = 1500;
    public static double stationOpenCost = 3000;

    // 可行性优先：违反约束给予大惩罚。
    public static double alphaOverload = 10_000;
    public static double betaTimeWindow = 1_000;
    public static double gammaEnergy = 1_000_000;
    public static double gammaRouteStructure = 1_000_000;

    // ALNS 参数。
    public static int maxIteration = 500;
    public static int alnsRestarts = 4;
    public static int removeNodeNumber = 3;
    public static double saInitTemp = 100.0;
    public static double saCooling = 0.995;
    public static boolean saAutoTune = false;
    public static double saTargetAcceptProb = 0.28;
    public static int saCalibrateSamples = 6;

    // ALNS 自适应算子参数。
    public static double alnsReactionFactor = 0.2;
    public static double alnsRewardBest = 6.0;
    public static double alnsRewardImprove = 3.0;
    public static double alnsRewardAccept = 1.0;
    public static double alnsWeightFloor = 0.1;
    public static int alnsNoImproveReheatIters = 80;
    public static double alnsReheatFactor = 1.5;
    public static double alnsMaxTempMultiplier = 5.0;
    public static int alnsDiversifyIters = 120;
    public static int alnsDiversifyRounds = 3;
    public static int alnsStagnationDestroyBoostIters = 40;
    public static int alnsMaxRemoveNodeNumber = 8;
    public static int alnsEliteSize = 6;
    public static int alnsEliteInjectIters = 60;
    public static int alnsEliteKickRounds = 2;
    public static int alnsEliteDestroyBoost = 2;
    public static double alnsEliteAcceptProb = 0.12;
    public static int alnsFeasibilityRescueIters = 90;
    public static int alnsFeasibilityRescueRounds = 2;
    public static int alnsInsertionBoostIters = 50;
    public static int alnsMaxInsertionCandidateK = 22;
    public static int alnsPathRelinkInjectIters = 55;
    public static int alnsPathRelinkSteps = 6;
    public static double alnsPathRelinkProb = 0.25;

    // Acceptance/penalty adaptation for stronger global exploration.
    public static boolean alnsAdaptivePenalty = true;
    public static int alnsPenaltyUpdateWindow = 25;
    public static double alnsTargetFeasibleRatio = 0.45;
    public static double alnsPenaltyIncrease = 1.12;
    public static double alnsPenaltyDecrease = 0.94;
    public static double alnsPenaltyMinFactor = 0.2;
    public static double alnsPenaltyMaxFactor = 8.0;
    public static double alnsInfeasibleAcceptBias = 1.6;

    // Multi-dimensional Shaw relatedness destroy weights.
    public static double alnsShawWeightDistance = 1.0;
    public static double alnsShawWeightTime = 0.9;
    public static double alnsShawWeightDemand = 0.5;
    public static double alnsShawWeightRoute = 0.6;
    public static double alnsShawWeightPressure = 0.7;
    public static double alnsShawNoise = 0.05;

    // Station perturbation controls (EV-UAV coupling aware).
    public static double alnsStationPerturbSwapProb = 0.45;
    public static double alnsStationPerturbLocalRatio = 0.55;
    public static double alnsStationPerturbUavBias = 0.72;
    public static double alnsStationPerturbHardProb = 0.35;
    public static int alnsStationPerturbSoftStationRemoveMax = 1;
    public static int alnsStationPerturbHardStationRemoveMax = 2;
    public static double alnsStationSwapDetourTolerance = 1.08;

    // Fast insertion-search controls.
    public static int insertionCandidateK = 12;
    public static double insertionPruneSlack = 40.0;

    public static double uavPrepTime = 5;
    public static double uavTakeoffTime = 1;
    public static double uavLandingTime = 1;

    public static double stationSwapTimeDefault = 20;

    // 数据与索引。
    public static Node[] allNodes = new Node[0];
    public static int depotIndex = 0;
    public static int virtualDepotIndex = 0;

    public static double[][] distanceMatrix = new double[0][0];

    public static final java.util.ArrayList<Node> removeNodeList = new java.util.ArrayList<>();

    // 三类解：当前解 / 邻域新解 / 全局最好解。
    public static Solution localSolution = new Solution();
    public static Solution newSolution = new Solution();
    public static Solution bestSolution = new Solution();

    public static double bestSolutionValue = Double.MAX_VALUE;
    public static double localSolutionValue = Double.MAX_VALUE;
    public static double newSolutionValue = Double.MAX_VALUE;

    // 算子权重（当前版本暂未做自适应更新）。
    public static final double[] wDestroy = new double[] {1, 1, 1, 1, 1};
    public static final double[] wRepair = new double[] {1, 1, 1, 1};

    public static int destroySelection = 0;
    public static int repairSelection = 0;
}
