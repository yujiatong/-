import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class test_small {
    private static final int RUNS_PER_CASE = 10;
    private static final String PARAM_SET_LABEL = "SmallScaleParamSet-UserUpdated";

    private static final Path PROGRESS_FILE = Paths.get("result", "smallscale_10runs_progress.tsv");

    private static final DecimalFormat COST_FMT = new DecimalFormat("0.1");
    private static final DecimalFormat GAP_FMT = new DecimalFormat("0.00");
    private static final DecimalFormat TIME_FMT = new DecimalFormat("0.1");

    public static void main(String[] args) throws Exception {
        List<CaseSpec> cases = buildCaseList();
        Map<String, Map<Long, RunResult>> done = loadProgress(PROGRESS_FILE);
        List<CaseResult> results = new ArrayList<>();

        System.out.println("Small-scale batch started. cases=" + cases.size()
                + ", runsPerCase=" + RUNS_PER_CASE
                + ", paramSet=" + PARAM_SET_LABEL);
        System.out.println("Progress file: " + PROGRESS_FILE.toAbsolutePath());

        int caseIdx = 0;
        for (CaseSpec spec : cases) {
            caseIdx++;
            System.out.println();
            System.out.println("[" + caseIdx + "/" + cases.size() + "] " + spec.caseName + " -> " + spec.path);
            CaseResult cr = runCase(spec, done);
            results.add(cr);
            System.out.println("Completed " + spec.caseName
                    + " | best=" + COST_FMT.format(cr.bestRun.cost)
                    + " | avg=" + COST_FMT.format(cr.avgCost)
                    + " | gap%=" + GAP_FMT.format(cr.gapPercent)
                    + " | avgTime(s)=" + TIME_FMT.format(cr.avgTimeSec)
                    + " | feasibleRuns=" + cr.feasibleRuns + "/" + cr.runs.size());
        }

        Path resultDir = Paths.get("result");
        if (!Files.exists(resultDir)) {
            Files.createDirectories(resultDir);
        }
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path out = resultDir.resolve("smallscale_10runs_report_" + ts + ".md");
        Files.write(out, buildMarkdown(results).getBytes(StandardCharsets.UTF_8));

        System.out.println();
        System.out.println("Report written: " + out.toAbsolutePath());
    }

    private static CaseResult runCase(CaseSpec spec, Map<String, Map<Long, RunResult>> done) throws Exception {
        CaseResult cr = new CaseResult();
        cr.spec = spec;

        for (int i = 0; i < RUNS_PER_CASE; i++) {
            long seed = i + 1L;
            RunResult rr = getDoneRun(done, spec.caseName, seed);
            if (rr != null) {
                System.out.println("  run " + (i + 1) + "/" + RUNS_PER_CASE
                        + " seed=" + seed
                        + " reused"
                        + " cost=" + COST_FMT.format(rr.cost)
                        + " feasible=" + rr.feasible
                        + " time(s)=" + TIME_FMT.format(rr.timeSec));
            } else {
                rr = runSingleWithRetry(spec, seed, i + 1);
                putDoneRun(done, spec.caseName, rr);
                appendProgress(PROGRESS_FILE, spec, rr);
            }
            cr.runs.add(rr);
        }

        cr.bestRun = pickBestRun(cr.runs);
        double sumCost = 0;
        double sumTime = 0;
        int feasibleCnt = 0;
        for (RunResult rr : cr.runs) {
            sumCost += rr.cost;
            sumTime += rr.timeSec;
            if (rr.feasible) {
                feasibleCnt++;
            }
        }
        cr.avgCost = sumCost / cr.runs.size();
        cr.avgTimeSec = sumTime / cr.runs.size();
        cr.feasibleRuns = feasibleCnt;
        if (Math.abs(cr.bestRun.cost) <= 1e-9) {
            cr.gapPercent = 0;
        } else {
            cr.gapPercent = (cr.avgCost - cr.bestRun.cost) / cr.bestRun.cost * 100.0;
        }
        return cr;
    }

    private static RunResult runSingleWithRetry(CaseSpec spec, long seed, int runIndex) throws Exception {
        int maxRetry = 3;
        Exception last = null;
        for (int attempt = 1; attempt <= maxRetry; attempt++) {
            try {
                RunResult rr = runSingle(spec, seed);
                System.out.println("  run " + runIndex + "/" + RUNS_PER_CASE
                        + " seed=" + seed
                        + " attempt=" + attempt
                        + " cost=" + COST_FMT.format(rr.cost)
                        + " feasible=" + rr.feasible
                        + " time(s)=" + TIME_FMT.format(rr.timeSec));
                return rr;
            } catch (Exception ex) {
                last = ex;
                System.out.println("  run " + runIndex + "/" + RUNS_PER_CASE
                        + " seed=" + seed
                        + " attempt=" + attempt
                        + " failed: " + ex.getMessage());
            }
        }
        throw last;
    }

    private static RunResult runSingle(CaseSpec spec, long seed) throws Exception {
        CalculateTool.setRandomSeed(seed);
        long t0 = System.currentTimeMillis();

        ReadData.init();
        ReadData.importInfo(spec.path);
        BSSExpansion.expandStations();
        CalculateTool.generateDistanceMatrix();

        InitialSolutionBuilder.buildInitialSolution(Parameter.localSolution);
        CalculateTool.updateSolutionMetrics(Parameter.localSolution);
        ALNS.solve();

        long t1 = System.currentTimeMillis();

        Solution copy = new Solution();
        CalculateTool.cloneSolution(copy, Parameter.bestSolution);
        copy.getTotalCost();

        RunResult rr = new RunResult();
        rr.seed = seed;
        rr.timeSec = (t1 - t0) / 1000.0;
        rr.cost = copy.totalCost;
        rr.feasible = copy.feasible;
        rr.overloadViolated = copy.overloadViolated;
        rr.timeWindowViolated = copy.timeWindowViolated;
        rr.energyViolated = copy.energyViolated;
        rr.structureViolated = copy.structureViolated;
        rr.totalCost = copy.totalCost;
        rr.evUavCost = copy.evUavCost;
        rr.stationOpenCost = copy.stationOpenCost;
        rr.violationCost = copy.violationCost;
        rr.overloadAmount = copy.overloadAmount;
        rr.timeViolationAmount = copy.timeViolationAmount;
        rr.solutionText = formatSolution(copy);
        return rr;
    }

    private static RunResult pickBestRun(List<RunResult> runs) {
        RunResult best = null;
        for (RunResult rr : runs) {
            if (best == null) {
                best = rr;
                continue;
            }
            if (rr.feasible && !best.feasible) {
                best = rr;
                continue;
            }
            if (!rr.feasible && best.feasible) {
                continue;
            }
            if (rr.cost < best.cost - 1e-9) {
                best = rr;
            }
        }
        return best;
    }

    private static String buildMarkdown(List<CaseResult> results) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Small-Scale Instances Report (10 runs each)\n\n");
        sb.append("- Generated at: ").append(LocalDateTime.now()).append("\n");
        sb.append("- Cases: ").append(results.size()).append("\n");
        sb.append("- Runs per case: ").append(RUNS_PER_CASE).append("\n");
        sb.append("- Parameter set label: ").append(PARAM_SET_LABEL).append("\n\n");

        sb.append("## Small-Scale Parameter Set (Current)\n\n");
        Map<String, String> params = collectParameterSnapshot();
        for (Map.Entry<String, String> e : params.entrySet()) {
            sb.append("- ").append(e.getKey()).append(": ").append(e.getValue()).append("\n");
        }
        sb.append("\n");

        sb.append("## Summary Table\n\n");
        sb.append("| CASE | BestCost | AvgCost | Gap% | Time(s) |\n");
        sb.append("|---|---:|---:|---:|---:|\n");
        for (CaseResult cr : results) {
            sb.append("| ").append(cr.spec.caseName)
                    .append(" | ").append(COST_FMT.format(cr.bestRun.cost))
                    .append(" | ").append(COST_FMT.format(cr.avgCost))
                    .append(" | ").append(GAP_FMT.format(cr.gapPercent))
                    .append(" | ").append(TIME_FMT.format(cr.avgTimeSec))
                    .append(" |\n");
        }
        sb.append("\n");

        sb.append("## Best Routes And Run Logs\n\n");
        for (CaseResult cr : results) {
            sb.append("### ").append(cr.spec.caseName).append("\n\n");
            sb.append("- Instance: `").append(cr.spec.path).append("`\n");
            sb.append("- Feasible runs: ").append(cr.feasibleRuns).append("/").append(cr.runs.size()).append("\n");
            sb.append("- Best run seed: ").append(cr.bestRun.seed).append("\n");
            sb.append("- Best cost: ").append(COST_FMT.format(cr.bestRun.cost)).append("\n");
            sb.append("- Avg cost: ").append(COST_FMT.format(cr.avgCost)).append("\n");
            sb.append("- Avg time(s): ").append(TIME_FMT.format(cr.avgTimeSec)).append("\n");
            sb.append("- Gap%: ").append(GAP_FMT.format(cr.gapPercent)).append("\n");
            sb.append("- Best feasible: ").append(cr.bestRun.feasible).append("\n");
            sb.append("- Best violations: overload=").append(cr.bestRun.overloadViolated)
                    .append(", tw=").append(cr.bestRun.timeWindowViolated)
                    .append(", energy=").append(cr.bestRun.energyViolated)
                    .append(", structure=").append(cr.bestRun.structureViolated).append("\n\n");

            sb.append("#### Run Log\n\n");
            sb.append("| Run | Seed | Cost | Feasible | Time(s) |\n");
            sb.append("|---:|---:|---:|---:|---:|\n");
            for (int i = 0; i < cr.runs.size(); i++) {
                RunResult rr = cr.runs.get(i);
                sb.append("| ").append(i + 1)
                        .append(" | ").append(rr.seed)
                        .append(" | ").append(COST_FMT.format(rr.cost))
                        .append(" | ").append(rr.feasible)
                        .append(" | ").append(TIME_FMT.format(rr.timeSec))
                        .append(" |\n");
            }
            sb.append("\n");

            sb.append("#### Best Route Plan\n\n");
            sb.append("```text\n");
            sb.append(cr.bestRun.solutionText);
            sb.append("```\n\n");
        }
        return sb.toString();
    }

    private static Map<String, String> collectParameterSnapshot() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("evCount", String.valueOf(Parameter.evCount));
        m.put("evCapacity", String.valueOf(Parameter.evCapacity));
        m.put("evEnergy", String.valueOf(Parameter.evEnergy));
        m.put("evSpeed", String.valueOf(Parameter.evSpeed));
        m.put("evWeight", String.valueOf(Parameter.evWeight));
        m.put("evConsumeTravel", String.valueOf(Parameter.evConsumeTravel));
        m.put("uavCapacity", String.valueOf(Parameter.uavCapacity));
        m.put("uavEnergy", String.valueOf(Parameter.uavEnergy));
        m.put("uavSpeed", String.valueOf(Parameter.uavSpeed));
        m.put("uavWeight", String.valueOf(Parameter.uavWeight));
        m.put("uavConsumeTravel", String.valueOf(Parameter.uavConsumeTravel));
        m.put("uavConsumeTakeoff", String.valueOf(Parameter.uavConsumeTakeoff));
        m.put("uavConsumeLanding", String.valueOf(Parameter.uavConsumeLanding));
        m.put("uavMaxDelay", String.valueOf(Parameter.uavMaxDelay));
        m.put("uavTripMaxCustomers", String.valueOf(Parameter.uavTripMaxCustomers));
        m.put("evFixedCost", String.valueOf(Parameter.evFixedCost));
        m.put("stationOpenCost", String.valueOf(Parameter.stationOpenCost));
        m.put("alphaOverload", String.valueOf(Parameter.alphaOverload));
        m.put("betaTimeWindow", String.valueOf(Parameter.betaTimeWindow));
        m.put("gammaEnergy", String.valueOf(Parameter.gammaEnergy));
        m.put("gammaRouteStructure", String.valueOf(Parameter.gammaRouteStructure));
        m.put("maxIteration", String.valueOf(Parameter.maxIteration));
        m.put("alnsRestarts", String.valueOf(Parameter.alnsRestarts));
        m.put("removeNodeNumber", String.valueOf(Parameter.removeNodeNumber));
        m.put("saInitTemp", String.valueOf(Parameter.saInitTemp));
        m.put("saCooling", String.valueOf(Parameter.saCooling));
        m.put("saAutoTune", String.valueOf(Parameter.saAutoTune));
        m.put("insertionCandidateK", String.valueOf(Parameter.insertionCandidateK));
        m.put("alnsMaxInsertionCandidateK", String.valueOf(Parameter.alnsMaxInsertionCandidateK));
        m.put("alnsFeasibilityRescueIters", String.valueOf(Parameter.alnsFeasibilityRescueIters));
        m.put("alnsFeasibilityRescueRounds", String.valueOf(Parameter.alnsFeasibilityRescueRounds));
        return m;
    }

    private static String formatSolution(Solution s) {
        StringBuilder sb = new StringBuilder();
        sb.append("totalCost=").append(s.totalCost)
                .append(", evUavCost=").append(s.evUavCost)
                .append(", stationOpenCost=").append(s.stationOpenCost)
                .append(", violationCost=").append(s.violationCost)
                .append(", overloadAmount=").append(s.overloadAmount)
                .append(", timeViolationAmount=").append(s.timeViolationAmount).append("\n");
        int idx = 0;
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 2) {
                idx++;
                continue;
            }
            sb.append("EV Route-").append(idx).append(": ");
            for (Node n : r.route) {
                sb.append(n.id).append("(").append(n.type).append(") -> ");
            }
            sb.append("\n");
            int t = 1;
            for (List<Node> trip : r.uavTrips) {
                sb.append("  UAV Trip ").append(t++).append(": ");
                for (Node n : trip) {
                    sb.append(n.id).append(" -> ");
                }
                sb.append("\n");
            }
            idx++;
        }
        return sb.toString();
    }

    private static List<CaseSpec> buildCaseList() {
        List<CaseSpec> list = new ArrayList<>();
        list.add(new CaseSpec("C1", "./instances/c101_bss_for_current_parser.txt"));
        list.add(new CaseSpec("C2", "./instances/c201_bss_for_current_parser.txt"));
        list.add(new CaseSpec("R1", "./instances/r101_bss_for_current_parser.txt"));
        list.add(new CaseSpec("R2", "./instances/r201_bss_for_current_parser.txt"));
        list.add(new CaseSpec("RC1", "./instances/rc101_bss_for_current_parser.txt"));
        list.add(new CaseSpec("RC2", "./instances/rc201_bss_for_current_parser.txt"));
        return list;
    }

    private static Map<String, Map<Long, RunResult>> loadProgress(Path path) throws Exception {
        Map<String, Map<Long, RunResult>> map = new LinkedHashMap<>();
        if (!Files.exists(path)) {
            return map;
        }
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.isEmpty()) {
            return map;
        }
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line == null || line.trim().isEmpty()) {
                continue;
            }
            String[] sp = line.split("\t", -1);
            if (sp.length < 17) {
                continue;
            }
            RunResult rr = new RunResult();
            String caseName = sp[0];
            rr.seed = Long.parseLong(sp[2]);
            rr.cost = Double.parseDouble(sp[3]);
            rr.timeSec = Double.parseDouble(sp[4]);
            rr.feasible = Boolean.parseBoolean(sp[5]);
            rr.overloadViolated = Boolean.parseBoolean(sp[6]);
            rr.timeWindowViolated = Boolean.parseBoolean(sp[7]);
            rr.energyViolated = Boolean.parseBoolean(sp[8]);
            rr.structureViolated = Boolean.parseBoolean(sp[9]);
            rr.totalCost = Double.parseDouble(sp[10]);
            rr.evUavCost = Double.parseDouble(sp[11]);
            rr.stationOpenCost = Double.parseDouble(sp[12]);
            rr.violationCost = Double.parseDouble(sp[13]);
            rr.overloadAmount = Double.parseDouble(sp[14]);
            rr.timeViolationAmount = Double.parseDouble(sp[15]);
            rr.solutionText = new String(Base64.getDecoder().decode(sp[16]), StandardCharsets.UTF_8);
            putDoneRun(map, caseName, rr);
        }
        return map;
    }

    private static void appendProgress(Path path, CaseSpec spec, RunResult rr) throws Exception {
        Path parent = path.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        boolean newFile = !Files.exists(path);
        StringBuilder line = new StringBuilder();
        if (newFile) {
            line.append("caseName\tpath\tseed\tcost\ttimeSec\tfeasible\toverloadViolated\ttimeWindowViolated\tenergyViolated\tstructureViolated\ttotalCost\tevUavCost\tstationOpenCost\tviolationCost\toverloadAmount\ttimeViolationAmount\tsolutionBase64\n");
        }
        String solutionBase64 = Base64.getEncoder().encodeToString(rr.solutionText.getBytes(StandardCharsets.UTF_8));
        line.append(spec.caseName).append('\t')
                .append(spec.path).append('\t')
                .append(rr.seed).append('\t')
                .append(rr.cost).append('\t')
                .append(rr.timeSec).append('\t')
                .append(rr.feasible).append('\t')
                .append(rr.overloadViolated).append('\t')
                .append(rr.timeWindowViolated).append('\t')
                .append(rr.energyViolated).append('\t')
                .append(rr.structureViolated).append('\t')
                .append(rr.totalCost).append('\t')
                .append(rr.evUavCost).append('\t')
                .append(rr.stationOpenCost).append('\t')
                .append(rr.violationCost).append('\t')
                .append(rr.overloadAmount).append('\t')
                .append(rr.timeViolationAmount).append('\t')
                .append(solutionBase64).append('\n');
        if (newFile) {
            Files.write(path, line.toString().getBytes(StandardCharsets.UTF_8));
        } else {
            Files.write(path, line.toString().getBytes(StandardCharsets.UTF_8), java.nio.file.StandardOpenOption.APPEND);
        }
    }

    private static RunResult getDoneRun(Map<String, Map<Long, RunResult>> done, String caseName, long seed) {
        Map<Long, RunResult> m = done.get(caseName);
        if (m == null) {
            return null;
        }
        return m.get(seed);
    }

    private static void putDoneRun(Map<String, Map<Long, RunResult>> done, String caseName, RunResult rr) {
        Map<Long, RunResult> m = done.get(caseName);
        if (m == null) {
            m = new LinkedHashMap<>();
            done.put(caseName, m);
        }
        m.put(rr.seed, rr);
    }

    private static final class CaseSpec {
        String caseName;
        String path;

        CaseSpec(String caseName, String path) {
            this.caseName = caseName;
            this.path = path;
        }
    }

    private static final class RunResult {
        long seed;
        double cost;
        double timeSec;
        boolean feasible;
        boolean overloadViolated;
        boolean timeWindowViolated;
        boolean energyViolated;
        boolean structureViolated;
        double totalCost;
        double evUavCost;
        double stationOpenCost;
        double violationCost;
        double overloadAmount;
        double timeViolationAmount;
        String solutionText;
    }

    private static final class CaseResult {
        CaseSpec spec;
        List<RunResult> runs = new ArrayList<>();
        RunResult bestRun;
        int feasibleRuns;
        double avgCost;
        double avgTimeSec;
        double gapPercent;
    }
}
