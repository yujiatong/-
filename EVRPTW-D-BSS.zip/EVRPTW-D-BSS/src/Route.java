import java.util.ArrayList;

public class Route {
    public ArrayList<Node> route = new ArrayList<>();
    public double distance = 0;
    public double overload = 0;
    public double timeViolation = 0;
    public double energyConsumption = 0;
    public boolean energyViolated = false;
    public boolean structureViolated = false;
}
