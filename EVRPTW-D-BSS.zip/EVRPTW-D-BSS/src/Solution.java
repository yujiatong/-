public class Solution {
    // 每辆 EV 一条主路径（含可选 UAV 子行程）。
    public EV_Route[] evRoutes = new EV_Route[Parameter.evCount];

    // 成本分解：基础成本 + 站点开启成本 + 违约惩罚。
    public double totalCost = 0;
    public double evUavCost = 0;
    public double stationOpenCost = 0;
    public double violationCost = 0;
    public double overloadAmount = 0;
    public double timeViolationAmount = 0;

    // 各类约束是否违反。
    public boolean feasible = false;
    public boolean energyViolated = false;
    public boolean timeWindowViolated = false;
    public boolean overloadViolated = false;
    public boolean structureViolated = false;

    public Solution() {
        for (int i = 0; i < evRoutes.length; i++) {
            evRoutes[i] = new EV_Route();
        }
    }

    public double getTotalCost() {
        // 每次读取目标值前，先刷新路径指标与约束状态。
        CalculateTool.updateSolutionMetrics(this);
        return totalCost;
    }
}
