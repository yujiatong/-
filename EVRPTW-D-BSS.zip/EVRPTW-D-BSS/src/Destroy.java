import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Destroy {
    private static final Set<Integer> recentUavMeetingNodeIds = new HashSet<>();

    public static void apply(Solution s, int op) {
        captureUavMeetingHints(s);
        // Recover UAV-served customers first so destroy always works on the full customer set.
        Repair.recoverUavCustomersToEvRoutes(s);
        switch (op) {
            case 0:
                randomDestroy(s);
                break;
            case 1:
                longestDestroy(s);
                break;
            case 2:
                relatedDestroy(s);
                break;
            case 3:
                stationDestroy(s);
                break;
            case 4:
                collaborativePerturbDestroy(s);
                break;
            default:
                randomDestroy(s);
        }
    }

    private static void randomDestroy(Solution s) {
        Parameter.removeNodeList.clear();
        List<Node> customers = collectServedCustomers(s);
        CalculateTool.shuffleList(customers);
        int k = Math.min(Parameter.removeNodeNumber, customers.size());
        for (int i = 0; i < k; i++) {
            removeCustomerFromSolution(s, customers.get(i));
        }
    }

    private static void longestDestroy(Solution s) {
        Parameter.removeNodeList.clear();
        List<Node> candidates = collectServedCustomers(s);
        candidates.sort(Comparator.comparingDouble(n -> -removalSavingApprox(s, n)));
        int k = Math.min(Parameter.removeNodeNumber, candidates.size());
        for (int i = 0; i < k; i++) {
            removeCustomerFromSolution(s, candidates.get(i));
        }
    }

    private static void relatedDestroy(Solution s) {
        Parameter.removeNodeList.clear();
        List<Node> all = collectServedCustomers(s);
        if (all.isEmpty()) {
            return;
        }
        CalculateTool.updateSolutionMetrics(s);

        Node seed = all.get(CalculateTool.intRandom(0, all.size()));
        removeCustomerFromSolution(s, seed);

        int target = Math.min(Parameter.removeNodeNumber, all.size());
        while (Parameter.removeNodeList.size() < target) {
            List<Node> remain = collectServedCustomers(s);
            if (remain.isEmpty()) {
                break;
            }
            Node related = selectMostRelatedCustomer(s, seed, remain);
            if (related == null) {
                break;
            }
            removeCustomerFromSolution(s, related);
            if (CalculateTool.randomDouble() < 0.35) {
                seed = related;
            }
        }
    }

    private static void clusterDestroy(Solution s) {
        Parameter.removeNodeList.clear();
        List<Node> all = collectServedCustomers(s);
        if (all.isEmpty()) {
            return;
        }
        Node seed = all.get(CalculateTool.intRandom(0, all.size()));
        all.sort(Comparator.comparingDouble(n -> distance(seed, n)));
        int k = Math.min(Parameter.removeNodeNumber, all.size());
        for (int i = 0; i < k; i++) {
            removeCustomerFromSolution(s, all.get(i));
        }
    }

    private static void stationDestroy(Solution s) {
        Parameter.removeNodeList.clear();

        CalculateTool.updateSolutionMetrics(s);
        List<StationOccurrence> occurrences = collectStationOccurrences(s);
        if (occurrences.isEmpty()) {
            clusterDestroy(s);
            return;
        }

        StationOccurrence anchor = selectStationAnchor(s, occurrences);
        if (anchor == null) {
            anchor = occurrences.get(CalculateTool.intRandom(0, occurrences.size()));
        }

        double pressure = routePressureScore(s.evRoutes[anchor.routeIdx]);
        boolean hardMode = shouldUseHardStationPerturb(s, anchor, pressure);

        if (!isAnchorNearUavHint(s, anchor) && CalculateTool.randomDouble() < Parameter.alnsStationPerturbSwapProb) {
            swapAnchorWithAlternativeStation(s, anchor);
        }

        int availableCustomers = collectServedCustomers(s).size();
        int targetBase = Math.max(1, Parameter.removeNodeNumber);
        int target = hardMode ? Math.min(availableCustomers, targetBase + 1) : Math.min(availableCustomers, targetBase);
        if (target <= 0) {
            return;
        }
        removeCustomersAroundStation(s, anchor, target);
        int stationRemoveCap = hardMode
                ? Math.max(1, Parameter.alnsStationPerturbHardStationRemoveMax)
                : Math.max(0, Parameter.alnsStationPerturbSoftStationRemoveMax);
        purgeAnchorStationFamily(s, anchor, stationRemoveCap);
        fillNearestCustomersToStation(s, anchor.station, target);
    }

    private static boolean shouldUseHardStationPerturb(Solution s, StationOccurrence anchor, double pressure) {
        double pHard = Parameter.alnsStationPerturbHardProb;
        double pressureRef = Math.max(1.0, averageRoutePressure(s));
        if (pressure > pressureRef * 1.2) {
            pHard += 0.15;
        }
        if (isAnchorNearUavHint(s, anchor)) {
            // If coupled with UAV meeting structure, keep perturbation softer by default.
            pHard -= 0.15;
        }
        pHard = Math.max(0.05, Math.min(0.85, pHard));
        return CalculateTool.randomDouble() < pHard;
    }

    private static void removeCustomersAroundStation(Solution s, StationOccurrence anchor, int target) {
        if (target <= 0) {
            return;
        }

        EV_Route route = s.evRoutes[anchor.routeIdx];
        int anchorPos = indexOfNodeInRoute(route.route, anchor.station);
        if (anchorPos < 0) {
            anchorPos = Math.max(1, route.route.size() / 2);
        }

        int localTarget = Math.max(1, (int) Math.round(target * Parameter.alnsStationPerturbLocalRatio));
        localTarget = Math.min(localTarget, target);

        List<NodeScore> local = new ArrayList<>();
        for (int i = 1; i < route.route.size() - 1; i++) {
            Node n = route.route.get(i);
            if (n.type != NodeType.CUSTOMER) {
                continue;
            }
            NodeScore ns = new NodeScore();
            ns.node = n;
            ns.score = distance(anchor.station, n) + 6.0 * Math.abs(i - anchorPos);
            local.add(ns);
        }
        local.sort(Comparator.comparingDouble(a -> a.score));
        for (NodeScore ns : local) {
            if (Parameter.removeNodeList.size() >= localTarget) {
                break;
            }
            removeCustomerFromSolution(s, ns.node);
        }
    }

    private static void fillNearestCustomersToStation(Solution s, Node station, int target) {
        if (station == null) {
            return;
        }
        List<Node> remaining = collectServedCustomers(s);
        remaining.sort(Comparator.comparingDouble(n -> distance(station, n)));
        for (Node n : remaining) {
            if (Parameter.removeNodeList.size() >= target) {
                break;
            }
            removeCustomerFromSolution(s, n);
        }
    }

    private static void purgeAnchorStationFamily(Solution s, StationOccurrence anchor, int maxRemove) {
        int pid = anchor.station.physicalStationId;
        if (pid < 0 || maxRemove <= 0) {
            return;
        }
        int total = countPhysicalStationOccurrences(s, pid);
        if (total <= 1) {
            return;
        }

        int removed = 0;
        for (EV_Route r : s.evRoutes) {
            for (int i = r.route.size() - 2; i >= 1; i--) {
                Node n = r.route.get(i);
                if (n.type != NodeType.STATION || n.physicalStationId != pid) {
                    continue;
                }
                if (removed >= maxRemove || total - removed <= 1) {
                    return;
                }
                boolean isUavHint = recentUavMeetingNodeIds.contains(n.id);
                if (isUavHint && CalculateTool.randomDouble() < Parameter.alnsStationPerturbUavBias) {
                    continue;
                }
                r.route.remove(i);
                removed++;
            }
        }
    }

    private static void swapAnchorWithAlternativeStation(Solution s, StationOccurrence anchor) {
        List<Node> stations = CalculateTool.stationNodes();
        if (stations.isEmpty()) {
            return;
        }
        EV_Route route = s.evRoutes[anchor.routeIdx];
        int pos = indexOfNodeInRoute(route.route, anchor.station);
        if (pos <= 0 || pos >= route.route.size() - 1) {
            return;
        }
        Node prev = route.route.get(pos - 1);
        Node next = route.route.get(pos + 1);

        double oldLocal = distance(prev, anchor.station) + distance(anchor.station, next);
        double tolerance = Math.max(1.0, Parameter.alnsStationSwapDetourTolerance);

        Node best = null;
        double bestLocal = oldLocal;
        for (Node st : stations) {
            if (st.id == anchor.station.id) {
                continue;
            }
            if (st.physicalStationId == anchor.station.physicalStationId) {
                continue;
            }
            double local = distance(prev, st) + distance(st, next);
            if (local <= oldLocal * tolerance && local < bestLocal - 1e-9) {
                bestLocal = local;
                best = st;
            }
        }
        if (best == null) {
            return;
        }

        route.route.set(pos, best);
        anchor.station = best;
    }

    // Large perturbation: break customer clusters and nearby station structures together.
    private static void collaborativePerturbDestroy(Solution s) {
        Parameter.removeNodeList.clear();
        List<Node> customers = collectServedCustomers(s);
        if (customers.isEmpty()) {
            return;
        }

        CalculateTool.updateSolutionMetrics(s);
        Node anchor = selectAnchorCustomer(s, customers);
        if (anchor == null) {
            anchor = customers.get(CalculateTool.intRandom(0, customers.size()));
        }

        int target = Math.max(Parameter.removeNodeNumber + 2,
                (int) Math.ceil(Parameter.removeNodeNumber * 1.7));
        target = Math.min(target, customers.size());

        removeCustomerFromSolution(s, anchor);

        int aroundAnchor = Math.max(1, (int) Math.round(target * 0.6));
        while (Parameter.removeNodeList.size() < aroundAnchor) {
            Node nearest = nearestCustomerToAnchor(s, anchor);
            if (nearest == null) {
                break;
            }
            removeCustomerFromSolution(s, nearest);
        }

        while (Parameter.removeNodeList.size() < target) {
            Node highImpact = highestSavingCustomer(s);
            if (highImpact == null) {
                break;
            }
            removeCustomerFromSolution(s, highImpact);
        }

        purgeNearbyStations(s, Parameter.removeNodeList);
    }

    private static void captureUavMeetingHints(Solution s) {
        recentUavMeetingNodeIds.clear();
        for (EV_Route r : s.evRoutes) {
            for (List<Node> trip : r.uavTrips) {
                if (trip.size() < 2) {
                    continue;
                }
                recentUavMeetingNodeIds.add(trip.get(0).id);
                recentUavMeetingNodeIds.add(trip.get(trip.size() - 1).id);
            }
        }
    }

    private static List<StationOccurrence> collectStationOccurrences(Solution s) {
        List<StationOccurrence> occ = new ArrayList<>();
        for (int r = 0; r < s.evRoutes.length; r++) {
            EV_Route route = s.evRoutes[r];
            for (int i = 1; i < route.route.size() - 1; i++) {
                Node n = route.route.get(i);
                if (n.type != NodeType.STATION) {
                    continue;
                }
                StationOccurrence so = new StationOccurrence();
                so.routeIdx = r;
                so.pos = i;
                so.station = n;
                occ.add(so);
            }
        }
        return occ;
    }

    private static StationOccurrence selectStationAnchor(Solution s, List<StationOccurrence> occ) {
        if (occ.isEmpty()) {
            return null;
        }

        Map<Integer, Integer> stationUsage = stationUsageByPhysicalId(occ);
        double maxDetour = 1.0;
        double maxPressure = 1.0;
        for (StationOccurrence so : occ) {
            EV_Route route = s.evRoutes[so.routeIdx];
            Node prev = route.route.get(so.pos - 1);
            Node next = route.route.get(so.pos + 1);
            double detour = dist(prev, so.station) + dist(so.station, next) - dist(prev, next);
            maxDetour = Math.max(maxDetour, Math.max(0.0, detour));
            maxPressure = Math.max(maxPressure, routePressureScore(route));
        }

        double sum = 0.0;
        for (StationOccurrence so : occ) {
            double score = stationCriticalityScore(s, so, stationUsage, maxDetour, maxPressure);
            so.score = Math.max(1e-6, score);
            sum += so.score;
        }
        if (sum <= 1e-9) {
            return occ.get(CalculateTool.intRandom(0, occ.size()));
        }

        double r = CalculateTool.randomDouble() * sum;
        double c = 0.0;
        for (StationOccurrence so : occ) {
            c += so.score;
            if (r <= c) {
                return so;
            }
        }
        return occ.get(occ.size() - 1);
    }

    private static double stationCriticalityScore(
            Solution s,
            StationOccurrence so,
            Map<Integer, Integer> stationUsage,
            double maxDetour,
            double maxPressure) {
        EV_Route route = s.evRoutes[so.routeIdx];
        Node prev = route.route.get(so.pos - 1);
        Node next = route.route.get(so.pos + 1);

        double detour = Math.max(0.0, dist(prev, so.station) + dist(so.station, next) - dist(prev, next));
        double detourNorm = detour / maxDetour;

        double pressureNorm = routePressureScore(route) / maxPressure;

        int usage = stationUsage.getOrDefault(so.station.physicalStationId, 1);
        double singleUseBonus = (usage <= 1) ? 1.0 : 0.0;

        boolean uavHint = recentUavMeetingNodeIds.contains(so.station.id)
                || recentUavMeetingNodeIds.contains(prev.id)
                || recentUavMeetingNodeIds.contains(next.id);
        double uavBonus = uavHint ? 1.0 : 0.0;

        // Higher score => more likely selected as perturbation anchor.
        return 0.50 * detourNorm
                + 0.25 * pressureNorm
                + 0.15 * singleUseBonus
                + 0.10 * uavBonus;
    }

    private static Map<Integer, Integer> stationUsageByPhysicalId(List<StationOccurrence> occ) {
        Map<Integer, Integer> usage = new HashMap<>();
        for (StationOccurrence so : occ) {
            int pid = so.station.physicalStationId;
            if (pid < 0) {
                continue;
            }
            usage.put(pid, usage.getOrDefault(pid, 0) + 1);
        }
        return usage;
    }

    private static int countPhysicalStationOccurrences(Solution s, int pid) {
        int cnt = 0;
        for (EV_Route r : s.evRoutes) {
            for (Node n : r.route) {
                if (n.type == NodeType.STATION && n.physicalStationId == pid) {
                    cnt++;
                }
            }
        }
        return cnt;
    }

    private static double averageRoutePressure(Solution s) {
        double sum = 0;
        int cnt = 0;
        for (EV_Route r : s.evRoutes) {
            if (r.route.size() <= 2) {
                continue;
            }
            sum += routePressureScore(r);
            cnt++;
        }
        if (cnt == 0) {
            return 1.0;
        }
        return sum / cnt;
    }

    private static boolean isAnchorNearUavHint(Solution s, StationOccurrence anchor) {
        EV_Route r = s.evRoutes[anchor.routeIdx];
        if (anchor.pos <= 0 || anchor.pos >= r.route.size() - 1) {
            return recentUavMeetingNodeIds.contains(anchor.station.id);
        }
        Node prev = r.route.get(anchor.pos - 1);
        Node next = r.route.get(anchor.pos + 1);
        return recentUavMeetingNodeIds.contains(anchor.station.id)
                || recentUavMeetingNodeIds.contains(prev.id)
                || recentUavMeetingNodeIds.contains(next.id);
    }

    private static int indexOfNodeInRoute(List<Node> route, Node target) {
        for (int i = 0; i < route.size(); i++) {
            Node n = route.get(i);
            if (n == target || n.id == target.id) {
                return i;
            }
        }
        return -1;
    }

    private static List<Node> collectServedCustomers(Solution s) {
        List<Node> res = new ArrayList<>();
        for (EV_Route r : s.evRoutes) {
            for (Node n : r.route) {
                if (n.type == NodeType.CUSTOMER) {
                    res.add(n);
                }
            }
        }
        return res;
    }

    private static void removeCustomerFromSolution(Solution s, Node customer) {
        for (EV_Route r : s.evRoutes) {
            for (int i = 1; i < r.route.size() - 1; i++) {
                Node cur = r.route.get(i);
                if (cur == customer || cur.id == customer.id) {
                    r.route.remove(i);
                    Parameter.removeNodeList.add(cur);
                    return;
                }
            }
        }
    }

    private static double removalSavingApprox(Solution s, Node n) {
        for (EV_Route r : s.evRoutes) {
            for (int i = 1; i < r.route.size() - 1; i++) {
                if (r.route.get(i) == n || r.route.get(i).id == n.id) {
                    Node a = r.route.get(i - 1);
                    Node b = r.route.get(i);
                    Node c = r.route.get(i + 1);
                    return dist(a, b) + dist(b, c) - dist(a, c);
                }
            }
        }
        return 0;
    }

    private static Node selectAnchorCustomer(Solution s, List<Node> customers) {
        Node best = null;
        double bestScore = -Double.MAX_VALUE;
        double dueRef = 1.0;
        for (Node c : customers) {
            dueRef = Math.max(dueRef, c.dueTime);
        }

        for (Node c : customers) {
            double saving = Math.max(0, removalSavingApprox(s, c));
            double twWidth = Math.max(1.0, c.dueTime - c.readyTime);
            double timeTight = 1.0 / twWidth;
            int routeIdx = routeIndexOfCustomer(s, c);
            double routePressure = (routeIdx >= 0) ? routePressureScore(s.evRoutes[routeIdx]) : 0;
            double score = saving + 8.0 * timeTight + 0.05 * routePressure + 0.2 * (dueRef - c.readyTime) / dueRef;
            if (score > bestScore) {
                bestScore = score;
                best = c;
            }
        }
        return best;
    }

    private static Node nearestCustomerToAnchor(Solution s, Node anchor) {
        Node best = null;
        double bestDist = Double.MAX_VALUE;
        for (Node c : collectServedCustomers(s)) {
            if (c == anchor || c.id == anchor.id) {
                continue;
            }
            double d = distance(anchor, c);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    private static Node highestSavingCustomer(Solution s) {
        Node best = null;
        double bestSaving = -Double.MAX_VALUE;
        for (Node c : collectServedCustomers(s)) {
            double saving = removalSavingApprox(s, c);
            if (saving > bestSaving) {
                bestSaving = saving;
                best = c;
            }
        }
        return best;
    }

    private static Node selectMostRelatedCustomer(Solution s, Node seed, List<Node> candidates) {
        if (candidates.isEmpty()) {
            return null;
        }

        int seedRoute = routeIndexOfCustomer(s, seed);
        Map<Integer, Double> routePressure = new HashMap<>();
        double maxPressure = 1.0;
        for (int r = 0; r < s.evRoutes.length; r++) {
            double p = routePressureScore(s.evRoutes[r]);
            routePressure.put(r, p);
            maxPressure = Math.max(maxPressure, p);
        }
        double seedPressure = (seedRoute >= 0) ? routePressure.getOrDefault(seedRoute, 0.0) : 0.0;
        double seedSaving = Math.max(0.0, removalSavingApprox(s, seed));

        double maxDist = 1.0;
        double maxTimeDiff = 1.0;
        double maxDemandDiff = 1.0;
        double maxSavingDiff = 1.0;
        for (Node c : candidates) {
            maxDist = Math.max(maxDist, distance(seed, c));
            double timeDiff = Math.abs(seed.readyTime - c.readyTime) + Math.abs(seed.dueTime - c.dueTime);
            maxTimeDiff = Math.max(maxTimeDiff, timeDiff);
            maxDemandDiff = Math.max(maxDemandDiff, Math.abs(seed.demand - c.demand));
            double savingDiff = Math.abs(seedSaving - Math.max(0.0, removalSavingApprox(s, c)));
            maxSavingDiff = Math.max(maxSavingDiff, savingDiff);
        }

        Node best = null;
        double bestScore = Double.MAX_VALUE;
        for (Node c : candidates) {
            double dNorm = distance(seed, c) / maxDist;
            double tNorm = (Math.abs(seed.readyTime - c.readyTime) + Math.abs(seed.dueTime - c.dueTime)) / maxTimeDiff;
            double qNorm = Math.abs(seed.demand - c.demand) / maxDemandDiff;

            int routeIdx = routeIndexOfCustomer(s, c);
            double routeNorm = (routeIdx >= 0 && routeIdx == seedRoute) ? 0.0 : 1.0;

            double pressureC = (routeIdx >= 0) ? routePressure.getOrDefault(routeIdx, 0.0) : 0.0;
            double pNorm = Math.abs(pressureC - seedPressure) / maxPressure;

            double savingDiff = Math.abs(seedSaving - Math.max(0.0, removalSavingApprox(s, c)));
            double sNorm = savingDiff / maxSavingDiff;

            double score = 0.0;
            score += Parameter.alnsShawWeightDistance * dNorm;
            score += Parameter.alnsShawWeightTime * tNorm;
            score += Parameter.alnsShawWeightDemand * qNorm;
            score += Parameter.alnsShawWeightRoute * routeNorm;
            score += Parameter.alnsShawWeightPressure * (0.6 * pNorm + 0.4 * sNorm);

            double noise = 1.0 + Parameter.alnsShawNoise * (CalculateTool.randomDouble() - 0.5);
            score *= noise;

            if (score < bestScore) {
                bestScore = score;
                best = c;
            }
        }
        return best;
    }

    private static void purgeNearbyStations(Solution s, List<Node> removedCustomers) {
        if (removedCustomers.isEmpty()) {
            return;
        }
        for (EV_Route r : s.evRoutes) {
            for (int i = r.route.size() - 2; i >= 1; i--) {
                Node n = r.route.get(i);
                if (n.type != NodeType.STATION) {
                    continue;
                }
                double minDist = Double.MAX_VALUE;
                for (Node c : removedCustomers) {
                    minDist = Math.min(minDist, distance(n, c));
                }
                if (minDist <= 35.0) {
                    r.route.remove(i);
                }
            }
        }
    }

    private static int routeIndexOfCustomer(Solution s, Node customer) {
        for (int r = 0; r < s.evRoutes.length; r++) {
            for (Node n : s.evRoutes[r].route) {
                if (n.type == NodeType.CUSTOMER && (n == customer || n.id == customer.id)) {
                    return r;
                }
            }
        }
        return -1;
    }

    private static double routePressureScore(EV_Route r) {
        int stationCnt = 0;
        int customerCnt = 0;
        double travel = 0;
        for (Node n : r.route) {
            if (n.type == NodeType.STATION) {
                stationCnt++;
            } else if (n.type == NodeType.CUSTOMER) {
                customerCnt++;
            }
        }
        for (int i = 1; i < r.route.size(); i++) {
            travel += dist(r.route.get(i - 1), r.route.get(i));
        }
        double pressure = travel;
        pressure += stationCnt * 15.0 + customerCnt * 2.0;
        return pressure;
    }

    private static final class StationOccurrence {
        int routeIdx;
        int pos;
        Node station;
        double score;
    }

    private static final class NodeScore {
        Node node;
        double score;
    }

    private static double distance(Node a, Node b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double dist(Node a, Node b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
