﻿# EVRPTW-D-BSS (Java)

This project is a new sibling codebase for the fixed battery swapping station variant:
EVRPTW-D-BSS (Electric Vehicle Routing Problem with Time Windows, Drone, and Battery Swapping Stations).

Current status:
- Project skeleton is created.
- Core classes and method signatures are prepared for iterative development.
- Next step is to finalize modeling details, then implement operators and full ALNS workflow.

Planned architecture:
- Main: entry and experiment pipeline
- ReadData: instance parsing (customers + fixed stations + depot)
- BSSExpansion: station node augmentation
- CalculateTool: distance, timing, energy, cost, feasibility metrics
- ALNS/Destroy/Repair: metaheuristic solver
- Solution/EV_Route/UAVTrip: solution representation

Build note:
- Source files include Chinese comments. Compile with UTF-8, e.g. `javac -encoding UTF-8 src/*.java`.

Problem notes (current implementation):
- Problem type: EVRPTW-D-BSS (fixed battery swapping stations + EV/UAV collaboration + time windows).
- Service rule: each customer is served exactly once, by EV or UAV.
- UAV sortie: one trip can visit multiple customers and must be closed by rendezvous with its EV.
- Rendezvous node: can be either a customer node or a fixed station node (`CUSTOMER` or `STATION`).
- EV charging rule: EV is fully charged when leaving depot or after each station swap.
- Time windows: hard windows are enforced via feasibility checks and penalties.

